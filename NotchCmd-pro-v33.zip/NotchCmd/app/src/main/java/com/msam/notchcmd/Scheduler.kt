package com.msam.notchcmd

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.app.NotificationManager
import java.text.SimpleDateFormat
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** days: bitmask, Sunday = bit0 ... Saturday = bit6. 0 = sirf ek baar */
/** at > 0: one dated run (epoch ms) that belongs to a day-by-day plan named grp */
data class Sched(val id: Int, val hh: Int, val mm: Int, val cmd: String, val days: Int, val on: Boolean, val at: Long = 0L, val grp: String = "")

object Scheduler {
    private const val PREF = "sched"

    fun load(c: Context): MutableList<Sched> {
        val out = ArrayList<Sched>()
        try {
            val a = JSONArray(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Sched(o.getInt("id"), o.getInt("hh"), o.getInt("mm"), o.getString("cmd"), o.getInt("days"), o.getBoolean("on"), o.optLong("at", 0L), o.optString("grp", "")))
            }
        } catch (_: Exception) {}
        return out
    }

    fun save(c: Context, l: List<Sched>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("hh", it.hh).put("mm", it.mm).put("cmd", it.cmd).put("days", it.days).put("on", it.on).put("at", it.at).put("grp", it.grp)) }
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", a.toString()).apply()
    }

    fun canExact(c: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()

    fun nextTime(s: Sched, now: Long = System.currentTimeMillis()): Long {
        if (s.at > 0L) return s.at
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, s.hh); cal.set(Calendar.MINUTE, s.mm); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        for (i in 0..8) {
            val okDay = s.days == 0 || (s.days and (1 shl (cal.get(Calendar.DAY_OF_WEEK) - 1))) != 0
            if (okDay && cal.timeInMillis > now) return cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return now + 60_000
    }

    private fun pi(c: Context, id: Int) = PendingIntent.getBroadcast(c, 5000 + id,
        Intent(c, SchedReceiver::class.java).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun prePi(c: Context, id: Int) = PendingIntent.getBroadcast(c, 9000 + id,
        Intent(c, PreReceiver::class.java).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun cancelBoth(c: Context, id: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(c, id)); am.cancel(prePi(c, id))
    }

    /** minutes before a scheduled post to show a heads-up notification (0 = off) */
    fun lead(c: Context): Int = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt("lead", 10)
    fun setLead(c: Context, m: Int) { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt("lead", m).apply() }

    fun isPost(s: Sched): Boolean = s.grp.isNotBlank() || s.cmd.lowercase(Locale.ROOT).contains("post")

    private val PREFIXES = listOf("post everywhere image", "channel post image", "facebook post image", "post everywhere", "channel post", "facebook post")

    /** "channel post image <topic>" -> ("channel post image", "<topic>") */
    fun splitCmd(cmd: String): Pair<String, String> {
        val p = PREFIXES.firstOrNull { cmd.startsWith("$it ") }
        return if (p != null) Pair(p, cmd.substring(p.length).trim()) else Pair("", cmd)
    }

    fun arm(c: Context, s: Sched) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!s.on) { cancelBoth(c, s.id); return }
        val t = nextTime(s)
        val leadMin = lead(c)
        am.cancel(prePi(c, s.id))
        if (leadMin > 0 && isPost(s)) {
            val pt = t - leadMin * 60_000L
            if (pt > System.currentTimeMillis() + 5_000L) {
                try {
                    if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, pt, prePi(c, s.id))
                    else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, pt, prePi(c, s.id))
                } catch (_: Exception) {}
            }
        }
        try {
            if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, s.id))
            else am.setAlarmClock(AlarmManager.AlarmClockInfo(t, pi(c, s.id)), pi(c, s.id))   // permission ke bina bhi theek waqt par
        } catch (_: Exception) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, s.id)) }
    }

    private const val STALE = 3 * 3600_000L

    /** plan posts that were missed by more than 3 hours (phone off) are switched off instead of posting a day late */
    fun armAll(c: Context) {
        val now = System.currentTimeMillis()
        val l = load(c)
        var changed = false
        val l2 = l.map { if (it.at > 0L && it.on && it.at < now - STALE) { changed = true; it.copy(on = false) } else it }
        if (changed) save(c, l2)
        l2.forEach { arm(c, it) }
    }

    /** one post per day: topics[0] on the first day, topics[1] the next day ... all at hh:mm. Returns the first run time. */
    fun addPlan(c: Context, name: String, hh: Int, mm: Int, startDay: Calendar, prefix: String, topics: List<String>): Long {
        val l = load(c)
        var id = l.maxOfOrNull { it.id } ?: 0
        val cal = startDay.clone() as Calendar
        cal.set(Calendar.HOUR_OF_DAY, hh); cal.set(Calendar.MINUTE, mm); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        while (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        val first = cal.timeInMillis
        val made = ArrayList<Sched>()
        topics.forEach { t ->
            made.add(Sched(++id, hh, mm, prefix + " " + t, 0, true, cal.timeInMillis, name))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        l.addAll(made); save(c, l)
        made.forEach { arm(c, it) }
        return first
    }

    fun removePlan(c: Context, grp: String) {
        val l = load(c)
        l.filter { it.grp == grp }.forEach { cancelBoth(c, it.id) }
        save(c, l.filter { it.grp != grp })
    }

    /** change the text of one plan day (the prefix, i.e. where it posts, stays) */
    fun editTopic(c: Context, id: Int, newTopic: String) {
        val l = load(c).map { if (it.id == id) { val pre = splitCmd(it.cmd).first; it.copy(cmd = if (pre.isBlank()) newTopic else "$pre $newTopic") } else it }
        save(c, l)
    }

    /** move this day and every later day of the plan by `days` (+1 = one day later, -1 = one day earlier) */
    fun shiftPlan(c: Context, grp: String, fromAt: Long, days: Int) {
        val l = load(c).map {
            if (it.grp == grp && it.at >= fromAt) {
                val cal = Calendar.getInstance(); cal.timeInMillis = it.at; cal.add(Calendar.DAY_OF_YEAR, days)
                it.copy(at = cal.timeInMillis)
            } else it
        }
        save(c, l)
        l.filter { it.grp == grp }.forEach { arm(c, it) }
    }

    /** off = pause every post; on = resume the posts that are still in the future */
    fun setPlanOn(c: Context, grp: String, on: Boolean) {
        val now = System.currentTimeMillis()
        val l = load(c).map { if (it.grp == grp && (!on || it.at > now)) it.copy(on = on) else it }
        save(c, l)
        l.filter { it.grp == grp }.forEach { arm(c, it) }
    }

    fun add(c: Context, hh: Int, mm: Int, cmd: String, days: Int): Sched {
        val l = load(c)
        val s = Sched((l.maxOfOrNull { it.id } ?: 0) + 1, hh, mm, cmd, days, true)
        l.add(s); save(c, l); arm(c, s)
        return s
    }

    fun remove(c: Context, id: Int) {
        val l = load(c)
        l.firstOrNull { it.id == id }?.let { cancelBoth(c, it.id) }
        save(c, l.filter { it.id != id })
    }

    fun setOn(c: Context, id: Int, on: Boolean) {
        val l = load(c).map { if (it.id == id) it.copy(on = on) else it }
        save(c, l)
        l.firstOrNull { it.id == id }?.let { arm(c, it) }
    }
}

/** Waqt hote hi: screen jagao aur command chalao (lock ho tab bhi; UI wali commands ke liye screen unlock chahiye) */
class SchedReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val s = Scheduler.load(c).firstOrNull { it.id == id } ?: return
        if (s.days != 0) Scheduler.arm(c, s) else Scheduler.setOn(c, id, false)   // repeat: agla waqt; ek baar: band
        if (!s.on) return
        try {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "notchcmd:sched").acquire(60_000L)
        } catch (_: Exception) {}
        try { c.startForegroundService(Intent(c, OverlayService::class.java).putExtra("cmd", s.cmd).putExtra("sched", true)) } catch (_: Exception) {}
    }
}

/** Phone restart / app update ke baad saare schedule dobara lagao */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Scheduler.armAll(c) }
}


/** Shortly before a scheduled post: a notification with the topic (and a Skip button for plan posts). */
class PreReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val s = Scheduler.load(c).firstOrNull { it.id == id } ?: return
        val nm = c.getSystemService(NotificationManager::class.java)
        if (i.getStringExtra("act") == "skip") {
            if (s.at > 0L) Scheduler.setOn(c, id, false)
            nm.cancel(7000 + id)
            return
        }
        if (!s.on) return
        val t = Scheduler.nextTime(s)
        val whenTxt = SimpleDateFormat("HH:mm", Locale.ENGLISH).format(t)
        val topic = Scheduler.splitCmd(s.cmd).second
        Notify.show(c, 7000 + id, "Post coming up at $whenTxt", topic + (if (s.grp.isNotBlank()) "\n(" + s.grp + ")" else ""), if (s.at > 0L) id else -1)
    }
}
