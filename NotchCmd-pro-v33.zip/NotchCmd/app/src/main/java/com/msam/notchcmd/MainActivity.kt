package com.msam.notchcmd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.DatePickerDialog
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.Spinner
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import android.text.InputType
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private var openPlanFn: ((String) -> Unit)? = null
    private var refreshHistFn: (() -> Unit)? = null

    /** every day of a plan; tap a day to edit its topic, skip it, remove it or push the plan later */
    private fun showPlanDays(g: String, refresh: () -> Unit) {
        val dFmt = SimpleDateFormat("d MMM", Locale.ENGLISH)
        val now = System.currentTimeMillis()
        val items = Scheduler.load(this).filter { it.grp == g }.sortedBy { it.at }
        if (items.isEmpty()) return
        val rows = items.map { x ->
            val st = if (x.on) "" else if (x.at < now) "[done] " else "[off] "
            st + dFmt.format(x.at) + "  " + Scheduler.splitCmd(x.cmd).second
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle(g + " (tap a day)").setItems(rows) { _, which ->
            val x = items[which]
            val future = x.at > System.currentTimeMillis()
            val acts = mutableListOf("Edit topic")
            if (future) { acts.add(if (x.on) "Skip this day (leave a gap)" else "Turn this day back on"); acts.add("Remove day, move later posts one day earlier"); acts.add("Postpone this and later posts by one day") }
            AlertDialog.Builder(this).setTitle(dFmt.format(x.at) + ": " + Scheduler.splitCmd(x.cmd).second.take(40))
                .setItems(acts.toTypedArray()) { _, k ->
                    when (acts[k]) {
                        "Edit topic" -> {
                            val et = EditText(this).apply { setText(Scheduler.splitCmd(x.cmd).second) }
                            AlertDialog.Builder(this).setTitle("Topic").setView(et)
                                .setPositiveButton("Save") { _, _ ->
                                    val t = et.text.toString().trim()
                                    if (t.isNotEmpty()) { Scheduler.editTopic(this, x.id, t); refresh() }
                                }.setNegativeButton("Cancel", null).show()
                        }
                        "Skip this day (leave a gap)", "Turn this day back on" -> { Scheduler.setOn(this, x.id, !x.on); refresh() }
                        "Remove day, move later posts one day earlier" -> {
                            Scheduler.remove(this, x.id); Scheduler.shiftPlan(this, g, x.at + 1, -1); refresh()
                        }
                        else -> { Scheduler.shiftPlan(this, g, x.at, 1); refresh() }
                    }
                }.setNegativeButton("Cancel", null).show()
        }.setPositiveButton("Close", null).show()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(TextView(this).apply { text = "NotchCmd  (build v33)\nDouble-tap the notch or say \"MJ\" → the mic turns on by itself; speak, or tap to type"; textSize = 18f; tag = "title" })
        root.addView(Button(this).apply {
            text = "Change style: " + (Style.labels[Style.cur(this@MainActivity)] ?: "Glass") + "  ▸"
            setOnClickListener { Style.next(this@MainActivity); Style.buzz(this@MainActivity, "heavy"); recreate() }
        })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Overlay permission") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Mic, contacts, call, notification permission") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2b. Brightness permission (Modify system settings)") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        btn("3. Turn on Accessibility (NotchCmd)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3b. Power button: Default digital assistant = NotchCmd") { try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        btn("4. Start (notch button on)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java)) }
        btn("MJ ON (listens while screen is on)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", true)) }
        btn("MJ OFF (mic off)") { startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", false)) }
        btn("Check: full app diagnostics") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("cmd", "check app")) }
        btn("Stop") { stopService(Intent(this, OverlayService::class.java)) }
        btn("Test: open the box now") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) }
        // ---------- Schedule: fix time par command ----------
        root.addView(TextView(this).apply { text = "\nSchedule (run a command at a fixed time, even when locked)"; textSize = 18f })
        btn("S1. Alarms & reminders permission (for exact timing)") { if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
        btn("S2. Battery: set to Unrestricted") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        // ---------- Lock screen: auto-unlock + data ----------
        val pinTv = TextView(this).apply { textSize = 14f }
        fun pinInfo() { val n = Unlocker.pinLen(this); pinTv.text = if (n == 0) "PIN not set" else "PIN set: $n digits" }
        root.addView(pinTv)
        btn("S3. Set phone unlock PIN") {
            val et = EditText(this).apply { hint = "Phone lock PIN (4-16 digits)"; setSingleLine(true)
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
            AlertDialog.Builder(this).setTitle("Unlock PIN").setMessage("The number of digits is detected automatically. The PIN is stored encrypted.").setView(et)
                .setPositiveButton("Save") { _, _ ->
                    val p = et.text.toString().trim()
                    if (p.length in 4..16 && p.all { it.isDigit() }) { Unlocker.setPin(this, p); Toast.makeText(this, "${p.length}-digit PIN saved", Toast.LENGTH_SHORT).show() }
                    else Toast.makeText(this, "PIN must be 4 to 16 digits", Toast.LENGTH_SHORT).show()
                    pinInfo()
                }.setNeutralButton("Remove PIN") { _, _ -> Unlocker.clearPin(this); pinInfo() }
                .setNegativeButton("Cancel", null).show()
        }
        val unlockBtn = Button(this)
        fun unlockLabel() { unlockBtn.text = "S4. Auto-unlock when locked: " + if (Unlocker.unlockOn(this)) "ON" else "OFF" }
        unlockBtn.setOnClickListener { Unlocker.setUnlockOn(this, !Unlocker.unlockOn(this)); unlockLabel() }
        root.addView(unlockBtn)
        val dataBtn = Button(this)
        fun dataLabel() { dataBtn.text = "S5. Turn data ON if it is off: " + if (Unlocker.dataOn(this)) "ON" else "OFF" }
        dataBtn.setOnClickListener { Unlocker.setDataOn(this, !Unlocker.dataOn(this)); dataLabel() }
        root.addView(dataBtn)
        val bioBtn = Button(this)
        fun bioLabel() { bioBtn.text = "S7. \"Use PIN\" + PIN on biometric prompt: " + if (Unlocker.bioOn(this)) "ON" else "OFF" }
        bioBtn.setOnClickListener { Unlocker.setBioOn(this, !Unlocker.bioOn(this)); bioLabel() }
        root.addView(bioBtn)
        val gBtn = Button(this)
        fun gLabel() { gBtn.text = "V3. After speaking with the Gboard mic, the command runs after " + (OfflineVoice.gboard(this) / 1000) + " sec of silence (tap = change). When typing, press ▶" }
        gBtn.setOnClickListener { OfflineVoice.nextGboard(this); gLabel() }
        root.addView(gBtn); gLabel()
        val mBtn = Button(this)
        fun mLabel() { mBtn.text = "V4. Auto-press the Gboard mic: " + if (OfflineVoice.gbMic(this)) "ON" else "OFF" }
        mBtn.setOnClickListener { OfflineVoice.toggleGbMic(this); mLabel() }
        root.addView(mBtn); mLabel()
        btn("D1. Screen dump after 8 sec (open the screen to inspect)") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Turn on Accessibility first", Toast.LENGTH_SHORT).show()
            else {
                Toast.makeText(this, "Open that screen within 8 sec", Toast.LENGTH_LONG).show()
                Handler(Looper.getMainLooper()).postDelayed({
                    val d = a.dump()
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("dump", d))
                    Toast.makeText(this, "Copied (${d.lines().size} lines). Paste it in the chat", Toast.LENGTH_LONG).show()
                }, 8000)
            }
        }
        btn("S6. Test: lock the phone, then try unlock after 6 sec") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Turn on Accessibility first", Toast.LENGTH_SHORT).show()
            else {
                a.act("lock")
                Handler(Looper.getMainLooper()).postDelayed({
                    try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("prep_only", true).putExtra("sched", true)) } catch (_: Exception) {}
                }, 6000)
            }
        }
        pinInfo(); unlockLabel(); dataLabel(); bioLabel()
        // ---------- Mobile limit + awaaz ke jawab ----------
        root.addView(TextView(this).apply { text = "Phone limit and voice"; textSize = 18f })
        fun numDialog(title: String, cur: Int, ok: (Int) -> Unit) {
            val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "minutes"; setSingleLine(true); if (cur > 0) setText(cur.toString()) }
            AlertDialog.Builder(this).setTitle(title).setView(et)
                .setPositiveButton("Save") { _, _ -> ok(et.text.toString().trim().toIntOrNull() ?: 0) }
                .setNegativeButton("Cancel", null).show()
        }
        fun appLabel(pkg: String): String = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        btn("U1. Usage access permission (required for limits)") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        val scrBtn = Button(this)
        fun scrLabel() { val m = UsageGuard.screenLimit(this); scrBtn.text = "U2. Daily screen limit: " + if (m <= 0) "OFF" else "$m minutes" }
        scrBtn.setOnClickListener { numDialog("Daily screen limit (minutes, 0 = OFF)", UsageGuard.screenLimit(this)) { UsageGuard.setScreenLimit(this, it); scrLabel() } }
        root.addView(scrBtn)
        btn("U3. Set an app limit") {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }.filter { it.first != packageName }.sortedBy { it.second.lowercase() }
            AlertDialog.Builder(this).setTitle("Which app?").setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                val (pkg, name) = apps[i]
                numDialog("$name: daily limit (minutes, 0 = remove)", UsageGuard.limits(this)[pkg] ?: 0) {
                    UsageGuard.setLimit(this, pkg, it)
                    Toast.makeText(this, if (it > 0) "$name: $it min/day" else "$name limit removed", Toast.LENGTH_SHORT).show()
                }
            }.show()
        }
        btn("U4. View / remove app limits") {
            val l = UsageGuard.limits(this).entries.sortedBy { appLabel(it.key).lowercase() }
            if (l.isEmpty()) Toast.makeText(this, "No app limits set", Toast.LENGTH_SHORT).show()
            else AlertDialog.Builder(this).setTitle("Tap to remove").setItems(l.map { appLabel(it.key) + "  -  " + it.value + " min/day" }.toTypedArray()) { _, i ->
                UsageGuard.setLimit(this, l[i].key, 0)
                Toast.makeText(this, appLabel(l[i].key) + " limit removed", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Close", null).show()
        }
        val talkBtn = Button(this)
        fun talkLabel() { talkBtn.text = "U5. Voice replies (I'm ready / Done): " + if (UsageGuard.voiceOn(this)) "ON" else "OFF" }
        talkBtn.setOnClickListener { UsageGuard.setVoiceOn(this, !UsageGuard.voiceOn(this)); talkLabel() }
        root.addView(talkBtn)
        val rsBtn = Button(this)
        fun rsLabel() { rsBtn.text = "R1. AI app for research: " + ResearchPrefs.selected(this).label + "  (tap = change)" }
        rsBtn.setOnClickListener {
            val all = ResearchPrefs.ALL
            val names = all.map { it.label + if (ResearchPrefs.installed(this, it)) "" else "  (not installed)" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Which AI app should \"research ...\" use?")
                .setSingleChoiceItems(names, all.indexOfFirst { it.key == ResearchPrefs.selected(this).key }) { d, i ->
                    ResearchPrefs.select(this, all[i].key); rsLabel(); d.dismiss()
                }.setNegativeButton("Close", null).show()
        }
        root.addView(rsBtn)
        // ---------- WhatsApp Channel post ----------
        root.addView(TextView(this).apply { text = "\nWhatsApp Channel post"; textSize = 18f })
        root.addView(TextView(this).apply { text = "Say or type: channel post <topic>  (e.g. channel post good morning quote), or just \"channel post\" if your prompt (C3) needs no topic. Today's date is added to the prompt every time. The AI app from R1 writes it, then it is pasted and sent to your channel. You can schedule the same command below."; textSize = 13f })
        val chNameBtn = Button(this)
        fun chNameLabel() { chNameBtn.text = "C1. Channel name: " + ChannelPrefs.name(this).ifBlank { "(not set)" } }
        chNameBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Channel name exactly as in WhatsApp"; setSingleLine(true); setText(ChannelPrefs.name(this@MainActivity)) }
            AlertDialog.Builder(this).setTitle("Channel name").setView(et)
                .setPositiveButton("Save") { _, _ -> ChannelPrefs.setName(this, et.text.toString()); chNameLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(chNameBtn)
        val chAppBtn = Button(this)
        fun chAppLabel() { chAppBtn.text = "C2. Post using: " + ChannelPrefs.label(this) + "  (tap = change)" }
        chAppBtn.setOnClickListener { ChannelPrefs.toggleBusiness(this); chAppLabel() }
        root.addView(chAppBtn)
        val chPromptBtn = Button(this)
        fun chPromptLabel() { chPromptBtn.text = "C3. Prompt for the AI: " + (if (ChannelPrefs.hasCustomPrompt(this)) "custom" else "default") + "  (tap = edit)" }
        chPromptBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Prompt. Use {topic} and {date} where they should go"; setText(ChannelPrefs.prompt(this@MainActivity)); minLines = 4; gravity = Gravity.TOP }
            AlertDialog.Builder(this).setTitle("Prompt for the AI").setMessage("{topic} is replaced by what you say after \"channel post\" (it can be empty). {date} is replaced by today's date; if you do not write {date}, \"Today's date: ...\" is added at the end automatically. Example for a multi-day plan: Continue our 100-day plan. Today is {date}. Work out which day it is and write only today's WhatsApp channel post. Output ONLY the post text.").setView(et)
                .setPositiveButton("Save") { _, _ -> ChannelPrefs.setPrompt(this, et.text.toString()); chPromptLabel() }
                .setNeutralButton("Reset") { _, _ -> ChannelPrefs.setPrompt(this, ""); chPromptLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(chPromptBtn)
        val chCleanBtn = Button(this)
        fun chCleanLabel() { chCleanBtn.text = "C4. After a scheduled post: data OFF + lock phone: " + if (ChannelPrefs.cleanup(this)) "ON" else "OFF" }
        chCleanBtn.setOnClickListener { ChannelPrefs.toggleCleanup(this); chCleanLabel() }
        root.addView(chCleanBtn)
        val chStatusBtn = Button(this)
        fun chStatusLabel() { chStatusBtn.text = "C5. Also share the post to my WhatsApp status: " + if (ChannelPrefs.shareStatus(this)) "ON" else "OFF" }
        chStatusBtn.setOnClickListener { ChannelPrefs.toggleShareStatus(this); chStatusLabel() }
        root.addView(chStatusBtn)
        chNameLabel(); chAppLabel(); chPromptLabel(); chCleanLabel(); chStatusLabel()
        // ---------- Facebook post ----------
        root.addView(TextView(this).apply { text = "\nFacebook post"; textSize = 18f })
        root.addView(TextView(this).apply { text = "Say or type: facebook post <topic>  (e.g. facebook post good morning quote). The AI app from R1 writes it, then it is pasted and posted from the Facebook home feed. It posts as the profile that is active in the Facebook app (to post to your Page, switch to the Page profile in Facebook first). You can schedule the same command below."; textSize = 13f })
        val fbAppBtn = Button(this)
        fun fbAppLabel() { fbAppBtn.text = "F1. Post using: " + FbPrefs.label(this) + "  (tap = change)" }
        fbAppBtn.setOnClickListener { FbPrefs.toggleLite(this); fbAppLabel() }
        root.addView(fbAppBtn)
        val fbPromptBtn = Button(this)
        fun fbPromptLabel() { fbPromptBtn.text = "F2. Prompt for the AI: " + (if (FbPrefs.hasCustomPrompt(this)) "custom" else "default") + "  (tap = edit)" }
        fbPromptBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Prompt. Use {topic} and {date} where they should go"; setText(FbPrefs.prompt(this@MainActivity)); minLines = 4; gravity = Gravity.TOP }
            AlertDialog.Builder(this).setTitle("Prompt for the AI").setMessage("{topic} is replaced by what you say after \"facebook post\" (it can be empty). {date} is replaced by today's date; if you do not write {date}, \"Today's date: ...\" is added at the end automatically.").setView(et)
                .setPositiveButton("Save") { _, _ -> FbPrefs.setPrompt(this, et.text.toString()); fbPromptLabel() }
                .setNeutralButton("Reset") { _, _ -> FbPrefs.setPrompt(this, ""); fbPromptLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(fbPromptBtn)
        val fbCleanBtn = Button(this)
        fun fbCleanLabel() { fbCleanBtn.text = "F3. After a scheduled post: data OFF + lock phone: " + if (FbPrefs.cleanup(this)) "ON" else "OFF" }
        fbCleanBtn.setOnClickListener { FbPrefs.toggleCleanup(this); fbCleanLabel() }
        root.addView(fbCleanBtn)
        fbAppLabel(); fbPromptLabel(); fbCleanLabel()

        // ---------- Facebook: Page / profile to post as ----------
        val fbPageBtn = Button(this)
        fun fbPageLabel() { fbPageBtn.text = "F4. Facebook Page name: " + FbPrefs.pageName(this).ifBlank { "not set" } + "  (tap = edit)" }
        fbPageBtn.setOnClickListener {
            val et = EditText(this); et.setText(FbPrefs.pageName(this)); et.hint = "Name exactly as the New post screen shows it"
            AlertDialog.Builder(this).setTitle("Page name").setMessage("Used by: facebook page post <topic>. The app switches Facebook to this Page first.").setView(et)
                .setPositiveButton("Save") { _, _ -> FbPrefs.setPageName(this, et.text.toString()); FbPrefs.setActive(this, ""); fbPageLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(fbPageBtn)
        val fbProfBtn = Button(this)
        fun fbProfLabel() { fbProfBtn.text = "F5. Facebook profile name: " + FbPrefs.profileName(this).ifBlank { "not set" } + "  (tap = edit)" }
        fbProfBtn.setOnClickListener {
            val et = EditText(this); et.setText(FbPrefs.profileName(this)); et.hint = "Your own profile name"
            AlertDialog.Builder(this).setTitle("Profile name").setMessage("Used by: facebook profile post <topic>. The app switches Facebook to this profile first.").setView(et)
                .setPositiveButton("Save") { _, _ -> FbPrefs.setProfileName(this, et.text.toString()); FbPrefs.setActive(this, ""); fbProfLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(fbProfBtn)
        fbPageLabel(); fbProfLabel()

        // ---------- Poster image + post everywhere ----------
        root.addView(TextView(this).apply { text = "\nPoster image and post everywhere"; textSize = 18f })
        root.addView(TextView(this).apply { text = "Add the word image or poster to a command (channel post image <topic>, facebook post poster <topic>, post everywhere image <topic>) and the app draws a poster from the AI's first line and posts it with the text as caption. post everywhere <topic> writes once and posts to your channel and Facebook (the channel part also shares to status when C5 is ON)."; textSize = 13f })
        val posterAllBtn = Button(this)
        fun posterAllLabel() { posterAllBtn.text = "I1. Poster image with every post: " + if (PosterPrefs.always(this)) "ON" else "OFF" }
        posterAllBtn.setOnClickListener { PosterPrefs.toggleAlways(this); posterAllLabel() }
        root.addView(posterAllBtn)
        val footBtn = Button(this)
        fun footLabel() { footBtn.text = "I2. Poster footer line: " + (if (PosterPrefs.hasFooter(this)) PosterPrefs.footer(this) else "channel name") + "  (tap = edit)" }
        footBtn.setOnClickListener {
            val et = EditText(this); et.setText(if (PosterPrefs.hasFooter(this)) PosterPrefs.footer(this) else ""); et.hint = "Empty = your channel name"
            AlertDialog.Builder(this).setTitle("Poster footer").setView(et)
                .setPositiveButton("Save") { _, _ -> PosterPrefs.setFooter(this, et.text.toString()); footLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(footBtn)
        posterAllLabel(); footLabel()

        // ---------- button names + last failure screen ----------
        root.addView(TextView(this).apply { text = "\nButton names"; textSize = 18f })
        root.addView(TextView(this).apply { text = "If an app update renames a button, change its name here (no new APK needed). When a post fails, the screen is saved automatically: L2 copies it so you can paste it in the chat."; textSize = 13f })
        val lblBtn = Button(this)
        lblBtn.text = "L1. Button names the app looks for (tap = edit)"
        lblBtn.setOnClickListener {
            val keys = Labels.NOTES.keys.toList()
            val items = keys.map { k -> (if (Labels.isCustom(this, k)) "* " else "") + (Labels.NOTES[k] ?: k) }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Which button? (* = changed by you)").setItems(items) { _, i ->
                val key = keys[i]
                val et = EditText(this); et.setText(Labels.raw(this, key)); et.minLines = 3; et.gravity = Gravity.TOP
                AlertDialog.Builder(this).setTitle(Labels.NOTES[key] ?: key).setMessage("Names separated by commas. Capital letters do not matter.").setView(et)
                    .setPositiveButton("Save") { _, _ -> Labels.set(this, key, et.text.toString()) }
                    .setNeutralButton("Reset") { _, _ -> Labels.reset(this, key) }
                    .setNegativeButton("Cancel", null).show()
            }.setNeutralButton("Reset all") { _, _ -> Labels.resetAll(this) }.setNegativeButton("Close", null).show()
        }
        root.addView(lblBtn)
        val dumpBtn = Button(this)
        dumpBtn.text = "L2. Copy the screen saved at the last failure"
        dumpBtn.setOnClickListener {
            val d = Labels.lastDump(this)
            if (d.isBlank()) Toast.makeText(this, "Nothing saved yet", Toast.LENGTH_SHORT).show()
            else {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("dump", d))
                Toast.makeText(this, "Copied (" + d.lines().size + " lines). Paste it in the chat", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(dumpBtn)
        val nameBtn = Button(this)
        fun nameLabel() { nameBtn.text = "U7. What the assistant calls you: " + if (UsageGuard.hasName(this)) UsageGuard.userName(this) else "muhtaram (set a name)" }
        nameBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Your name (empty = muhtaram)"; setSingleLine(true); if (UsageGuard.hasName(this@MainActivity)) setText(UsageGuard.userName(this@MainActivity)) }
            AlertDialog.Builder(this).setTitle("What should the assistant call you?").setMessage("This name is used in voice replies and reminders. Leave empty for \"muhtaram\".").setView(et)
                .setPositiveButton("Save") { _, _ -> UsageGuard.setUserName(this, et.text.toString()); nameLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(nameBtn)
        btn("U6. Test: play the voice") {
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("say", "Yes " + UsageGuard.userName(this) + ", I'm ready")) } catch (_: Exception) {}
        }
        scrLabel(); talkLabel(); nameLabel(); rsLabel()
        // ---------- Offline AI model ----------
        root.addView(TextView(this).apply { text = "AI"; textSize = 18f })
        val aiTv = TextView(this).apply { textSize = 13f }
        fun aiInfo() { aiTv.text = "AI: " + LlmBrain.status(this) + "\n" + LlmBrain.onlineStatus(this) + (if (LlmBrain.memoryCount(this) > 0) "\nMemory: ${LlmBrain.memoryCount(this)} items" else "") }
        root.addView(aiTv)
        btn("A3. Clear AI memory") { LlmBrain.forget(this); aiInfo(); Toast.makeText(this, "Memory cleared", Toast.LENGTH_SHORT).show() }
        aiInfo()
        val schedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun dayName(mask: Int): String = if (mask == 0) "Once" else if (mask == 127) "Daily"
            else listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat").filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(",")
        fun refreshSched() {
            schedBox.removeAllViews()
            val all = Scheduler.load(this)
            val dFmt = SimpleDateFormat("d MMM", Locale.ENGLISH)
            all.filter { it.grp.isBlank() }.forEach { s ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 16) }
                row.addView(TextView(this).apply { text = "%02d:%02d • %s • %s%s".format(s.hh, s.mm, dayName(s.days), s.cmd, if (s.on) "" else "  (off)"); textSize = 15f })
                val br = LinearLayout(this)
                br.addView(Button(this).apply { text = if (s.on) "OFF" else "ON"; setOnClickListener { Scheduler.setOn(this@MainActivity, s.id, !s.on); refreshSched() } })
                br.addView(Button(this).apply { text = "Run now"; setOnClickListener { startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", s.cmd).putExtra("sched", true)) } })
                br.addView(Button(this).apply { text = "Remove"; setOnClickListener { Scheduler.remove(this@MainActivity, s.id); refreshSched() } })
                row.addView(br); schedBox.addView(row)
            }
            all.filter { it.grp.isNotBlank() }.groupBy { it.grp }.forEach { (g, items) ->
                val pending = items.filter { it.on && it.at > 0L }.sortedBy { it.at }
                val next = pending.firstOrNull()
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 16) }
                val info = "Plan: $g\n${items.size} posts • ${pending.size} left" +
                    (if (next != null) "\nNext: " + dFmt.format(next.at) + " %02d:%02d • %s".format(next.hh, next.mm, next.cmd) else "\nFinished or paused")
                row.addView(TextView(this).apply { text = info; textSize = 15f })
                val br = LinearLayout(this)
                val br2 = LinearLayout(this)
                val anyOn = items.any { it.on }
                br.addView(Button(this).apply { text = if (anyOn) "Pause" else "Resume"; setOnClickListener { Scheduler.setPlanOn(this@MainActivity, g, !anyOn); refreshSched() } })
                br.addView(Button(this).apply {
                    text = "View / edit topics"
                    setOnClickListener { showPlanDays(g) { refreshSched() } }
                })
                br2.addView(Button(this).apply {
                    text = "Post next now"
                    setOnClickListener {
                        if (next != null) {
                            Scheduler.setOn(this@MainActivity, next.id, false)
                            startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", next.cmd).putExtra("sched", true))
                            refreshSched()
                        }
                    }
                })
                br2.addView(Button(this).apply { text = "Delete plan"; setOnClickListener { Scheduler.removePlan(this@MainActivity, g); refreshSched() } })
                row.addView(br); row.addView(br2); schedBox.addView(row)
            }
            Style.skin(this, schedBox)
        }
        btn("+ New schedule") {
            val et = EditText(this).apply { hint = "Command, e.g.: open youtube"; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle("Which command should run?").setView(et)
                .setPositiveButton("Next") { _, _ ->
                    val cmd = et.text.toString().trim()
                    if (cmd.isNotEmpty()) TimePickerDialog(this, { _, hh, mm ->
                        val sel = BooleanArray(7)
                        AlertDialog.Builder(this).setTitle("Which days? (none selected = once only)")
                            .setMultiChoiceItems(arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"), sel) { _, i, c -> sel[i] = c }
                            .setPositiveButton("Save") { _, _ ->
                                var mask = 0
                                sel.forEachIndexed { i, b -> if (b) mask = mask or (1 shl i) }
                                Scheduler.add(this, hh, mm, cmd, mask); refreshSched()
                            }.setNegativeButton("Cancel", null).show()
                    }, 8, 0, false).show()
                }.setNegativeButton("Cancel", null).show()
        }
        fun shakeRefresh() { try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("shake_refresh", true)) } catch (_: Exception) {} }
        val shOn = Button(this); val shCnt = Button(this); val shStr = Button(this)
        fun shakeLabels() {
            shOn.text = "G1. Shake to open the assistant: " + (if (ShakePrefs.on(this)) "ON" else "OFF")
            shCnt.text = "G2. Shakes needed: ${ShakePrefs.count(this)}  (tap to change)"
            shStr.text = "G3. Shake strength: " + (if (ShakePrefs.hard(this)) "Hard shake" else "Normal shake") + "  (tap to change)"
        }
        shOn.setOnClickListener { ShakePrefs.setOn(this, !ShakePrefs.on(this)); shakeLabels(); shakeRefresh() }
        shCnt.setOnClickListener {
            AlertDialog.Builder(this).setTitle("How many shakes?")
                .setItems(arrayOf("2 shakes", "3 shakes", "4 shakes", "5 shakes", "6 shakes")) { _, w -> ShakePrefs.setCount(this, w + 2); shakeLabels() }.show()
        }
        shStr.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Shake strength")
                .setItems(arrayOf("Normal shake (easy, may trigger while walking fast)", "Hard shake (strong, fewer accidents)")) { _, w -> ShakePrefs.setHard(this, w == 1); shakeLabels() }.show()
        }
        root.addView(shOn); root.addView(shCnt); root.addView(shStr); shakeLabels()
        val leadBtn = Button(this)
        fun leadLabel() { val m = Scheduler.lead(this); leadBtn.text = "H1. Heads-up notification before posts: " + (if (m == 0) "OFF" else "$m min") + "  (tap to change)" }
        leadBtn.setOnClickListener {
            val opts = intArrayOf(0, 5, 10, 30, 60)
            AlertDialog.Builder(this).setTitle("Notify before a scheduled post")
                .setItems(arrayOf("Off", "5 minutes", "10 minutes", "30 minutes", "1 hour")) { _, w -> Scheduler.setLead(this, opts[w]); Scheduler.armAll(this); leadLabel() }.show()
        }
        root.addView(leadBtn); leadLabel()
        fun openPlan(prefill: String) {
            val ctx = this
            val lay = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
            val types = arrayOf("WhatsApp channel", "Facebook", "Both (post everywhere)")
            val prefixes = arrayOf("channel post", "facebook post", "post everywhere")
            val sp = Spinner(ctx).apply { adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, types) }
            val cb = CheckBox(ctx).apply { text = "With poster image" }
            val nameEt = EditText(ctx).apply { hint = "Plan name (optional)"; setSingleLine(true) }
            val et = EditText(ctx).apply {
                hint = "One topic per line.\nLine 1 = day 1, line 2 = day 2 ..."
                setText(prefill)
                minLines = 8; gravity = Gravity.TOP
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            }
            var hh = 8; var mm = 0
            val cal = Calendar.getInstance()
            val dateBtn = Button(ctx); val timeBtn = Button(ctx)
            fun lbl() {
                dateBtn.text = "First post date: " + SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(cal.time)
                timeBtn.text = "Post time every day: %02d:%02d".format(hh, mm)
            }
            dateBtn.setOnClickListener {
                DatePickerDialog(ctx, { _, y, m, d -> cal.set(y, m, d); lbl() }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
            }
            timeBtn.setOnClickListener { TimePickerDialog(ctx, { _, h, mi -> hh = h; mm = mi; lbl() }, hh, mm, false).show() }
            lbl()
            val aiBtn = Button(ctx).apply {
                text = "Let the AI write the topics"
                setOnClickListener {
                    val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
                    val nicheEt = EditText(ctx).apply { hint = "Niche / subject, e.g. healthy habits"; setSingleLine(true) }
                    val daysEt = EditText(ctx).apply { hint = "How many days"; setText("30"); inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(true) }
                    box.addView(nicheEt); box.addView(daysEt)
                    AlertDialog.Builder(ctx).setTitle("AI topics (" + ResearchPrefs.selected(ctx).label + ")").setView(box)
                        .setPositiveButton("Write") { _, _ ->
                            val niche = nicheEt.text.toString().trim()
                            val n = (daysEt.text.toString().trim().toIntOrNull() ?: 30).coerceIn(1, 100)
                            if (niche.isEmpty()) { Toast.makeText(ctx, "Write the niche first", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                            try {
                                startForegroundService(Intent(ctx, OverlayService::class.java).putExtra("topics_niche", niche).putExtra("topics_days", n))
                                Toast.makeText(ctx, "The AI app opens; the topics come back here when it is done", Toast.LENGTH_LONG).show()
                            } catch (_: Exception) {}
                        }.setNegativeButton("Cancel", null).show()
                }
            }
            lay.addView(aiBtn); lay.addView(sp); lay.addView(cb); lay.addView(nameEt); lay.addView(et); lay.addView(dateBtn); lay.addView(timeBtn)
            AlertDialog.Builder(ctx).setTitle("Daily post plan").setView(ScrollView(ctx).apply { addView(lay) })
                .setPositiveButton("Create") { _, _ ->
                    val topics = et.text.toString().lines()
                        .map { it.trim().replace(Regex("^(?i)(day\\s*)?\\d+\\s*[.):\\-]\\s*"), "").trim() }
                        .filter { it.isNotEmpty() }.take(366)
                    if (topics.isEmpty()) { Toast.makeText(ctx, "Add at least one topic", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                    val prefix = prefixes[sp.selectedItemPosition] + (if (cb.isChecked) " image" else "")
                    val name = nameEt.text.toString().trim().ifBlank { "Plan " + SimpleDateFormat("d MMM", Locale.ENGLISH).format(cal.time) }
                    val first = Scheduler.addPlan(ctx, name, hh, mm, cal, prefix, topics)
                    Toast.makeText(ctx, "${topics.size} posts scheduled, first on " + SimpleDateFormat("d MMM, HH:mm", Locale.ENGLISH).format(first), Toast.LENGTH_LONG).show()
                    refreshSched()
                }.setNegativeButton("Cancel", null).show()
        }
        openPlanFn = { t -> openPlan(t) }
        btn("+ Daily post plan (many days at once)") { openPlan("") }
        root.addView(schedBox)
        Scheduler.armAll(this); refreshSched()
        root.addView(TextView(this).apply { text = "\nPost history"; textSize = 18f })
        val histBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refreshHist() {
            histBox.removeAllViews()
            val l = PostLog.load(this).take(15)
            if (l.isEmpty()) histBox.addView(TextView(this).apply { text = "No posts yet"; textSize = 13f })
            val fmt = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH)
            l.forEach { e ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
                row.addView(TextView(this).apply {
                    text = fmt.format(e.time) + " • " + (if (e.ok) "posted" else "FAILED") + " • " + e.kind + (if (e.sched) " (scheduled)" else "") +
                        "\n" + e.topic + (if (!e.ok && e.note.isNotBlank()) "\n" + e.note else "")
                    textSize = 14f
                })
                if (!e.ok && e.cmd.isNotBlank()) row.addView(Button(this).apply {
                    text = "Retry"
                    setOnClickListener {
                        try { startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", e.cmd)) } catch (_: Exception) {}
                        Toast.makeText(this@MainActivity, "Retrying: " + e.topic, Toast.LENGTH_SHORT).show()
                    }
                })
                histBox.addView(row)
            }
            Style.skin(this, histBox)
        }
        btn("Clear post history") { PostLog.clear(this); refreshHist() }
        root.addView(histBox)
        refreshHistFn = { refreshHist() }
        refreshHist()
        Style.skin(this, root)
        (root.findViewWithTag<TextView>("title"))?.setTextColor(Style.theme(this).stroke)
        setContentView(ScrollView(this).apply { background = Style.background(this@MainActivity); addView(root) })
        Style.enter(root)
        if (b == null) Style.buzz(this, "launch")
    }

    // App kholte hi (ya permission dene ke baad) service khud chalu: mic sirf "MJ" ke liye sunta rehta hai
    override fun onResume() {
        super.onResume()
        refreshHistFn?.invoke()
        PlanDraft.take(this)?.let { openPlanFn?.invoke(it) }   // topics written by the AI app: open the plan dialog with them
        if (Settings.canDrawOverlays(this) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }
}
