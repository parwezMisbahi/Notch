package com.msam.notchcmd

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

/** One chat message. role: "u" = you, "a" = assistant */
class ChatMsg(val role: String, val text: String, val imgs: List<String>, val ok: Boolean, val ts: Long)

/** Chat history kept on the phone (last 150 messages) */
object ChatStore {
    private const val MAX = 150
    private fun sp(c: Context) = c.getSharedPreferences("chat", Context.MODE_PRIVATE)

    @Synchronized fun load(c: Context): MutableList<ChatMsg> {
        val out = ArrayList<ChatMsg>()
        try {
            val a = JSONArray(sp(c).getString("h", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val im = ArrayList<String>()
                o.optJSONArray("i")?.let { for (k in 0 until it.length()) im.add(it.getString(k)) }
                out.add(ChatMsg(o.optString("r"), o.optString("t"), im, o.optBoolean("ok", true), o.optLong("ts")))
            }
        } catch (_: Exception) {}
        return out
    }

    @Synchronized fun add(c: Context, m: ChatMsg) {
        val l = load(c); l.add(m)
        val keep = if (l.size > MAX) l.subList(l.size - MAX, l.size) else l
        val a = JSONArray()
        for (x in keep) {
            val im = JSONArray(); x.imgs.forEach { im.put(it) }
            a.put(JSONObject().put("r", x.role).put("t", x.text).put("i", im).put("ok", x.ok).put("ts", x.ts))
        }
        sp(c).edit().putString("h", a.toString()).apply()
    }

    @Synchronized fun clear(c: Context) { sp(c).edit().remove("h").apply() }
}

/**
 * Bridge between the chat screen and OverlayService (which actually runs the commands).
 * The service reports every progress line (status) and the end of a run (finish); the chat shows them as replies.
 */
object ChatBus {
    @Volatile var busy = false
    @Volatile var live = ""
    @Volatile var ui: ChatActivity? = null
    private val trail = CopyOnWriteArrayList<String>()
    private val main = Handler(Looper.getMainLooper())

    fun begin() { trail.clear(); live = "Starting…"; busy = true }

    fun status(m: String) {
        if (!busy || m.isBlank()) return
        live = m
        if (!m.endsWith("...") && !m.endsWith("…") && trail.lastOrNull() != m) trail.add(m)
        main.post { ui?.onStatus(m) }
    }

    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    /** end of a run: ok = everything finished, headline = optional fixed reply text */
    fun finish(c: Context, ok: Boolean, headline: String? = null) {
        if (!busy) return
        busy = false; live = ""
        val t = trail.takeLast(8).map { cap(it) }
        trail.clear()
        val text = when {
            headline != null -> headline
            ok && t.size <= 1 -> "✅ " + (t.firstOrNull() ?: "Done")
            ok -> "✅ Done\n" + t.joinToString("\n") { "• $it" }
            t.size <= 1 -> "❌ " + (t.firstOrNull() ?: "The task could not be finished")
            else -> "❌ " + t.last() + "\n\nSteps so far:\n" + t.dropLast(1).joinToString("\n") { "• $it" }
        }
        val msg = ChatMsg("a", text, emptyList(), ok, System.currentTimeMillis())
        ChatStore.add(c, msg)
        main.post { ui?.onFinish(msg) }
        if (c.getSharedPreferences("n", Context.MODE_PRIVATE).getBoolean("chat_back", true) && !ChatActivity.visible) {
            main.postDelayed({
                try { c.startActivity(Intent(c, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Exception) {}
            }, 700)
        }
    }
}

/** Main screen: chat with the assistant. Type a command, the assistant runs it and answers here. */
class ChatActivity : Activity() {
    companion object { @Volatile var visible = false }

    private lateinit var t: Style.T
    private lateinit var msgBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: ImageButton
    private lateinit var attachBar: LinearLayout
    private lateinit var tray: HorizontalScrollView
    private lateinit var trayRow: LinearLayout
    private lateinit var emptyV: View
    private lateinit var banner: TextView
    private lateinit var subT: TextView
    private lateinit var drawer: LinearLayout
    private lateinit var scrim: View
    private var drawerOpen = false
    private var liveRow: View? = null
    private var liveText: TextView? = null
    private var livePulse: ObjectAnimator? = null
    private var selPlugin: String? = null
    private val imgs = ArrayList<String>()
    private var msgCount = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ small view helpers
    private fun round(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(color); if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun icon(res: Int, desc: String, size: Int = 44, tint: Int = t.text, onClick: () -> Unit): ImageButton = ImageButton(this).apply {
        setImageResource(res); scaleType = ImageView.ScaleType.CENTER_INSIDE
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, mask)
        setPadding(dp(10), dp(10), dp(10), dp(10)); setColorFilter(tint); contentDescription = desc
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        setOnClickListener { Style.buzz(this@ChatActivity, "tick"); onClick() }
    }

    private fun thumb(path: String, px: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / s > px * 2 && o.outHeight / s > px * 2) s *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (_: Throwable) { null }

    private fun picView(path: String, size: Int, r: Int): ImageView? {
        val bm = thumb(path, dp(size)) ?: return null
        return ImageView(this).apply {
            setImageBitmap(bm); scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(0, 0, dp(6), 0) }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(r).toFloat()) }
            }
            clipToOutline = true
        }
    }

    // ------------------------------------------------------------------ build
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        t = Style.theme(this)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        val root = FrameLayout(this).apply { background = Style.background(this@ChatActivity) }
        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ---- header: menu (3 lines) | robot + title | new chat
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(8), dp(6), dp(6)) }
        header.addView(icon(R.drawable.ic_menu, "Menu") { toggleDrawer(true) })
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_robot_mono); setColorFilter(t.stroke)
            layoutParams = LinearLayout.LayoutParams(dp(50), dp(50)).apply { setMargins(dp(2), 0, 0, 0) }
        })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(TextView(this).apply { text = "NotchCmd"; textSize = 19f; tag = "title"; typeface = android.graphics.Typeface.DEFAULT_BOLD })
        subT = TextView(this).apply { text = "Ready"; textSize = 11.5f; tag = "sub" }
        col.addView(subT)
        header.addView(col)
        header.addView(icon(R.drawable.ic_new, "New chat") { confirmClear() })
        main.addView(header)
        main.addView(View(this).apply { setBackgroundColor((t.stroke and 0x00FFFFFF) or 0x30000000); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) })

        // ---- setup banner (only while a permission is missing)
        banner = TextView(this).apply {
            textSize = 13f; tag = "chat_banner"; visibility = View.GONE
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = round(0x33FFB020, 14, 0x88FFB020.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), 0) }
            setOnClickListener { openSettings(0) }
        }
        main.addView(banner)

        // ---- messages + empty state
        val frame = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        scroll = ScrollView(this).apply { isFillViewport = false; overScrollMode = View.OVER_SCROLL_NEVER }
        msgBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(14)) }
        scroll.addView(msgBox)
        frame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        emptyV = buildEmpty()
        frame.addView(emptyV, FrameLayout.LayoutParams(-1, -1))
        main.addView(frame)

        // ---- plugin tray (shown when the plug icon is tapped)
        tray = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; visibility = View.GONE; setPadding(dp(10), dp(4), dp(10), dp(4)) }
        trayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tray.addView(trayRow)
        main.addView(tray)

        // ---- attachments (chosen plugin + photos)
        attachBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE; setPadding(dp(14), dp(4), dp(14), dp(2)) }
        main.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(attachBar) })

        // ---- input bar: photo | plugins | text | mic | send
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM
            background = Style.card(this@ChatActivity, t, 28)
            setPadding(dp(4), dp(4), dp(6), dp(4))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(10), dp(4), dp(10), dp(10)) }
        }
        bar.addView(icon(R.drawable.ic_photo, "Add photo", 42) { pickPhoto() })
        bar.addView(icon(R.drawable.ic_plug, "Plugins", 42) { toggleTray() })
        input = EditText(this).apply {
            hint = "Message NotchCmd…"; textSize = 16f; background = null; maxLines = 5
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(6), dp(10), dp(6), dp(10)); setTextColor(t.text); setHintTextColor(t.sub)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { updateSend() }
            })
            setOnClickListener { hideTray() }
        }
        bar.addView(input)
        bar.addView(icon(R.drawable.ic_mic, "Voice", 42) { listen() })
        sendBtn = ImageButton(this).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE; setColorFilter(t.btnText)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(dp(4), 0, 0, 0) }
            setOnClickListener { Style.buzz(this@ChatActivity, "click"); if (ChatBus.busy) stopRun() else send() }
        }
        bar.addView(sendBtn)
        main.addView(bar)
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        // ---- drawer (settings), hidden to the left
        scrim = View(this).apply { setBackgroundColor(0x99000000.toInt()); alpha = 0f; visibility = View.GONE; setOnClickListener { toggleDrawer(false) } }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        drawer = buildDrawer()
        root.addView(drawer, FrameLayout.LayoutParams(dp(300), -1))
        drawer.translationX = -dp(320).toFloat()

        setContentView(root)
        Style.skin(this, header); Style.skin(this, drawer); Style.skin(this, input)
        banner.setTextColor(t.text)
        refreshTray(); refreshAttach(); updateSend()

        val hist = ChatStore.load(this)
        hist.forEach { addMsg(it, false) }
        updateEmpty()
        if (ChatBus.busy) showLive(ChatBus.live)
        scrollDown(false)
    }

    private fun buildEmpty(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(22), dp(10), dp(22), dp(10)) }
        v.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        v.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_robot_mono); setColorFilter(t.stroke)
            layoutParams = LinearLayout.LayoutParams(dp(130), dp(130))
        })
        v.addView(TextView(this).apply { text = "How can I help?"; textSize = 24f; setTextColor(t.text); gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD })
        v.addView(TextView(this).apply {
            text = "Write a command like you chat with ChatGPT.\nI will run it on your phone and tell you when it is done."
            textSize = 13.5f; setTextColor(t.sub); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(14))
        })
        val ex = listOf("Open WhatsApp, search Parwez, send assalamualaikum", "research karo how solar panels work", "image banao a robot flying over a city at night")
        for (e in ex) v.addView(TextView(this).apply {
            text = e; textSize = 13.5f; setTextColor(t.text); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), Style.card(this@ChatActivity, t, 16), null)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) }
            setOnClickListener { input.setText(e); input.setSelection(e.length); input.requestFocus(); Style.buzz(this@ChatActivity, "tick") }
        })
        v.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        return v
    }

    private fun buildDrawer(): LinearLayout {
        val sp = getSharedPreferences("n", MODE_PRIVATE)
        val d = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(t.bg1, t.bg2)).apply { setStroke(dp(1), (t.stroke and 0x00FFFFFF) or 0x44000000) }
            elevation = dp(16).toFloat(); isClickable = true
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(40), dp(10), dp(8)) }
        top.addView(TextView(this).apply { text = "Settings"; textSize = 24f; tag = "title"; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        top.addView(icon(R.drawable.ic_menu, "Close menu") { toggleDrawer(false) })
        d.addView(top)
        val sc = ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), dp(20)) }
        sc.addView(list); d.addView(sc)

        fun row(ic: String, title: String, sub: String, onClick: () -> Unit) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = "card"
                setPadding(dp(14), dp(13), dp(12), dp(13))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
                setOnClickListener { Style.buzz(this@ChatActivity, "tick"); onClick() }
            }
            r.addView(TextView(this).apply { text = ic; textSize = 22f; setPadding(0, 0, dp(14), 0) })
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            c.addView(TextView(this).apply { text = title; textSize = 15f })
            if (sub.isNotBlank()) c.addView(TextView(this).apply { text = sub; textSize = 11.5f; tag = "sub" })
            r.addView(c)
            r.addView(TextView(this).apply { text = "›"; textSize = 22f; tag = "back" })
            list.addView(r)
        }
        fun label(s: String) = list.addView(TextView(this).apply { text = s; textSize = 12f; tag = "sec"; setPadding(dp(4), dp(14), 0, dp(2)) })

        label("ASSISTANT")
        row("⚙", "Setup and control", "Permissions, start and stop, tests") { openSettings(0) }
        row("🗓", "Schedule and plans", "Timed commands, daily post plans, briefing") { openSettings(1) }
        row("📣", "Posting", "WhatsApp channel, Facebook, poster, history") { openSettings(2) }
        row("⚡", "Automation", "Routines, triggers, shake, digest, reply helper") { openSettings(3) }
        row("🎙", "Phone, voice and AI", "Lock screen, limits, voice, AI app") { openSettings(4) }
        row("☰", "All settings", "MJ voice wake and everything else") { openSettings(-1) }

        label("CHAT")
        val sw = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = "card"
            setPadding(dp(14), dp(12), dp(10), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
        }
        val sc2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        sc2.addView(TextView(this).apply { text = "Come back to chat when done"; textSize = 15f })
        sc2.addView(TextView(this).apply { text = "Opens this chat with the answer after a task"; textSize = 11.5f; tag = "sub" })
        val s = Switch(this).apply {
            isChecked = sp.getBoolean("chat_back", true)
            setOnCheckedChangeListener { _, v -> sp.edit().putBoolean("chat_back", v).apply(); Style.buzz(this@ChatActivity, "click") }
        }
        sw.addView(sc2); sw.addView(s); sw.setOnClickListener { s.toggle() }
        list.addView(sw)
        row("🗑", "Clear chat", "Delete all messages") { toggleDrawer(false); confirmClear() }

        label("THEME")
        val names = Style.names
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, 0) }
        val cur = Style.cur(this)
        names.forEach { n ->
            strip.addView(TextView(this).apply {
                text = Style.labels[n] ?: n; gravity = Gravity.CENTER; tag = if (n == cur) "chipOn" else "chipOff"
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), dp(8)) }
                setOnClickListener { Style.set(this@ChatActivity, n); Style.buzz(this@ChatActivity, "heavy"); recreate() }
            })
        }
        list.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) })
        list.addView(TextView(this).apply { text = "build v63"; textSize = 11f; tag = "sub"; setPadding(dp(4), dp(16), 0, 0) })
        return d
    }

    // ------------------------------------------------------------------ drawer / navigation
    private fun toggleDrawer(open: Boolean) {
        hideKeyboard(); hideTray()
        drawerOpen = open
        if (open) scrim.visibility = View.VISIBLE
        scrim.animate().alpha(if (open) 1f else 0f).setDuration(200).withEndAction { if (!drawerOpen) scrim.visibility = View.GONE }.start()
        drawer.animate().translationX(if (open) 0f else -dp(320).toFloat()).setDuration(240).start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) toggleDrawer(false)
        else if (tray.visibility == View.VISIBLE) hideTray()
        else super.onBackPressed()
    }

    private fun openSettings(page: Int) {
        toggleDrawer(false)
        startActivity(Intent(this, MainActivity::class.java).putExtra("page", page))
    }

    private fun hideKeyboard() {
        try { (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0) } catch (_: Exception) {}
    }

    private fun confirmClear() {
        if (ChatBus.busy) { Toast.makeText(this, "A task is running. Stop it first", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("New chat").setMessage("Delete all messages?")
            .setPositiveButton("Delete") { _, _ ->
                ChatStore.clear(this); msgBox.removeAllViews(); msgCount = 0; liveRow = null; liveText = null; updateEmpty()
            }.setNegativeButton("Cancel", null).show()
    }

    // ------------------------------------------------------------------ plugins + photos
    private fun toggleTray() { if (tray.visibility == View.VISIBLE) hideTray() else { hideKeyboard(); tray.visibility = View.VISIBLE } }
    private fun hideTray() { tray.visibility = View.GONE }

    private fun refreshTray() {
        trayRow.removeAllViews()
        for (p in Plugins.ALL) {
            val c = TextView(this)
            c.text = p.icon + " " + p.label; c.gravity = Gravity.CENTER
            c.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }
            Style.chip(this, c, t, p.key == selPlugin)
            c.setOnClickListener {
                selPlugin = if (selPlugin == p.key) null else p.key
                Style.buzz(this, "tick"); hideTray(); refreshTray(); refreshAttach(); input.requestFocus()
            }
            trayRow.addView(c)
        }
    }

    private fun refreshAttach() {
        attachBar.removeAllViews()
        val p = Plugins.ALL.firstOrNull { it.key == selPlugin }
        input.hint = p?.hint ?: "Message NotchCmd…"
        if (p != null) {
            val c = TextView(this); c.text = p.icon + " " + p.label + "  ✕"
            c.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }
            Style.chip(this, c, t, true)
            c.setOnClickListener { selPlugin = null; refreshTray(); refreshAttach() }
            attachBar.addView(c)
        }
        for (path in imgs.toList()) {
            val v = picView(path, 46, 12) ?: continue
            v.setOnClickListener { imgs.remove(path); refreshAttach() }
            attachBar.addView(v)
        }
        attachBar.visibility = if (attachBar.childCount > 0) View.VISIBLE else View.GONE
        updateSend()
    }

    private fun pickPhoto() {
        hideTray()
        val room = 6 - imgs.size
        if (room <= 0) { Toast.makeText(this, "Maximum 6 photos. Tap a photo to remove it", Toast.LENGTH_SHORT).show(); return }
        PluginBus.onImages = { paths -> runOnUiThread { for (p in paths) if (imgs.size < 6) imgs.add(p); refreshAttach() } }
        try { startActivity(Intent(this, PickActivity::class.java).putExtra("max", room)) } catch (_: Exception) { PluginBus.onImages = null }
    }

    private fun listen() {
        hideTray()
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your command"), 91)
        } catch (_: Exception) { Toast.makeText(this, "Voice input is not available on this phone", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 91 && res == RESULT_OK) {
            val s = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            val cur = input.text.toString()
            val n = if (cur.isBlank()) s else "$cur $s"
            input.setText(n); input.setSelection(n.length)
        }
    }

    // ------------------------------------------------------------------ sending
    private fun updateSend() {
        if (!::sendBtn.isInitialized) return
        val busy = ChatBus.busy
        val can = busy || input.text.toString().isNotBlank() || imgs.isNotEmpty()
        sendBtn.setImageResource(if (busy) R.drawable.ic_stop else R.drawable.ic_send)
        sendBtn.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply { shape = GradientDrawable.OVAL; setStroke(dp(1), t.stroke) }
        sendBtn.alpha = if (can) 1f else 0.4f
        subT.text = if (busy) "Working…" else if (banner.visibility == View.VISIBLE) "Setup needed" else "Ready"
    }

    private fun send() {
        val txt = input.text.toString().trim()
        if (ChatBus.busy || (txt.isEmpty() && imgs.isEmpty())) return
        hideTray(); hideKeyboard()
        val plug = selPlugin
        val shown = (plug?.let { Plugins.ALL.firstOrNull { p -> p.key == it }?.let { p -> "${p.icon} ${p.label}\n" } } ?: "") + txt
        val um = ChatMsg("u", shown.trim(), ArrayList(imgs), true, System.currentTimeMillis())
        ChatStore.add(this, um); addMsg(um, true)
        if (!Settings.canDrawOverlays(this)) {
            val am = ChatMsg("a", "⚠ I need the overlay permission first. Open the menu ☰ → Setup and control, then try again.", emptyList(), false, System.currentTimeMillis())
            ChatStore.add(this, am); addMsg(am, true)
            input.setText(""); imgs.clear(); selPlugin = null; refreshTray(); refreshAttach(); updateEmpty()
            return
        }
        val i = Intent(this, OverlayService::class.java)
            .putExtra("chat_cmd", txt).putExtra("chat_plugin", plug ?: "").putExtra("chat_imgs", imgs.toTypedArray())
        input.setText(""); imgs.clear(); selPlugin = null; refreshTray(); refreshAttach(); updateEmpty()
        ChatBus.begin()
        showLive("Starting…")
        updateSend()
        try { startForegroundService(i) } catch (_: Exception) { ChatBus.finish(this, false, "❌ Could not start the assistant service.") }
    }

    private fun stopRun() {
        try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("chat_stop", true)) } catch (_: Exception) { ChatBus.finish(this, false, "Stopped.") }
    }

    // ------------------------------------------------------------------ messages
    private fun addMsg(m: ChatMsg, animate: Boolean) {
        val me = m.role == "u"
        val maxW = (resources.displayMetrics.widthPixels * 0.80f).toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = if (me) Gravity.END else Gravity.START
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
        }
        val bubble = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        val r = dp(20).toFloat(); val s = dp(5).toFloat()
        bubble.background = if (me) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply {
            cornerRadii = floatArrayOf(r, r, r, r, s, s, r, r)
        } else GradientDrawable().apply {
            cornerRadii = floatArrayOf(r, r, r, r, r, r, s, s)
            setColor(if (t.light) 0xCCFFFFFF.toInt() else 0x1AFFFFFF); setStroke(dp(1), (t.stroke and 0x00FFFFFF) or 0x44000000)
        }
        val pics = m.imgs.mapNotNull { picView(it, 84, 14) }
        if (pics.isNotEmpty()) {
            val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, if (m.text.isNotBlank()) dp(8) else 0) }
            pics.forEach { pr.addView(it) }
            bubble.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(pr) })
        }
        if (m.text.isNotBlank()) bubble.addView(TextView(this).apply {
            text = m.text; textSize = 15f; setTextColor(if (me) t.btnText else t.text); maxWidth = maxW - dp(28)
            setTextIsSelectable(true); setLineSpacing(0f, 1.08f)
        })
        row.addView(bubble, LinearLayout.LayoutParams(-2, -2))
        val at = liveRow?.let { msgBox.indexOfChild(it) } ?: -1
        if (at >= 0) msgBox.addView(row, at) else msgBox.addView(row)
        msgCount++
        if (animate) {
            row.alpha = 0f; row.translationY = dp(24).toFloat()
            row.animate().alpha(1f).translationY(0f).setDuration(260).start()
            scrollDown(true)
        }
        updateEmpty()
    }

    private fun showLive(text: String) {
        if (liveRow == null) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.START
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
            }
            val bubble = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable().apply {
                    val r = dp(20).toFloat(); val s = dp(5).toFloat()
                    cornerRadii = floatArrayOf(r, r, r, r, r, r, s, s)
                    setColor(if (t.light) 0xCCFFFFFF.toInt() else 0x1AFFFFFF); setStroke(dp(1), t.stroke)
                }
            }
            bubble.addView(TextView(this).apply { text = "●"; textSize = 14f; setTextColor(t.stroke); setPadding(0, 0, dp(10), 0) }.also {
                livePulse = ObjectAnimator.ofFloat(it, "alpha", 1f, 0.2f).apply { duration = 650; repeatMode = ObjectAnimator.REVERSE; repeatCount = ObjectAnimator.INFINITE; start() }
            })
            val tv = TextView(this).apply { textSize = 14.5f; setTextColor(t.text); maxWidth = (resources.displayMetrics.widthPixels * 0.72f).toInt() }
            bubble.addView(tv)
            row.addView(bubble, LinearLayout.LayoutParams(-2, -2))
            msgBox.addView(row); liveRow = row; liveText = tv
            row.alpha = 0f; row.animate().alpha(1f).setDuration(200).start()
            updateEmpty()
        }
        liveText?.text = text
        scrollDown(true)
    }

    private fun hideLive() {
        livePulse?.cancel(); livePulse = null
        liveRow?.let { msgBox.removeView(it) }
        liveRow = null; liveText = null
    }

    fun onStatus(m: String) { if (ChatBus.busy) showLive(m) }

    fun onFinish(m: ChatMsg) {
        hideLive()
        addMsg(m, true)
        Style.buzz(this, if (m.ok) "click" else "heavy")
        updateSend()
    }

    private fun updateEmpty() { emptyV.visibility = if (msgCount == 0 && liveRow == null) View.VISIBLE else View.GONE }

    private fun scrollDown(smooth: Boolean) {
        scroll.post { if (smooth) scroll.smoothScrollTo(0, msgBox.height) else scroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onResume() {
        super.onResume()
        visible = true
        ChatBus.ui = this
        val overlay = Settings.canDrawOverlays(this)
        val a11y = NotchA11y.inst != null
        banner.visibility = if (!overlay || !a11y) View.VISIBLE else View.GONE
        banner.text = if (!overlay) "⚠ Setup needed: overlay permission is off. Tap here to fix it"
            else "⚠ Setup needed: turn on the Accessibility service (NotchCmd) so I can control the phone. Tap here"
        if (ChatBus.busy) showLive(ChatBus.live.ifBlank { "Working…" }) else if (liveRow != null) hideLive()
        updateSend()
        if (overlay && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == 0) {
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onPause() { super.onPause(); visible = false }

    override fun onDestroy() {
        if (ChatBus.ui === this) ChatBus.ui = null
        livePulse?.cancel()
        super.onDestroy()
    }
}
