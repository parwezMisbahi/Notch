package com.msam.notchcmd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import android.text.InputType
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(TextView(this).apply { text = "NotchCmd\nNotch par double-tap ya bolo \"MJ\" → mic apne aap on, bolo ya tap karke likho"; textSize = 18f; tag = "title" })
        root.addView(Button(this).apply {
            text = "Style badlo: " + (Style.labels[Style.cur(this@MainActivity)] ?: "Glass") + "  ▸"
            setOnClickListener { Style.next(this@MainActivity); Style.buzz(this@MainActivity, "heavy"); recreate() }
        })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Overlay permission") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Mic, contacts, call, notification permission") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2b. Brightness permission (Modify system settings)") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        btn("3. Accessibility on karo (NotchCmd)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3b. Power button: Default digital assistant = NotchCmd") { try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        btn("4. Start (notch button on)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java)) }
        btn("MJ ON (screen on par sunega)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", true)) }
        btn("MJ OFF (mic band)") { startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", false)) }
        btn("Check: pura app ki jaanch") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("cmd", "check app")) }
        btn("Stop") { stopService(Intent(this, OverlayService::class.java)) }
        btn("Test: box abhi kholo") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) }
        // ---------- Schedule: fix time par command ----------
        root.addView(TextView(this).apply { text = "\nSchedule (fix time par command, lock hone par bhi)"; textSize = 18f })
        btn("S1. Alarms & reminders permission (theek waqt ke liye)") { if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
        btn("S2. Battery: Unrestricted karo") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        // ---------- Lock screen: auto-unlock + data ----------
        val pinTv = TextView(this).apply { textSize = 14f }
        fun pinInfo() { val n = Unlocker.pinLen(this); pinTv.text = if (n == 0) "PIN set nahi hai" else "PIN set: $n digit" }
        root.addView(pinTv)
        btn("S3. Phone unlock PIN set karo") {
            val et = EditText(this).apply { hint = "Phone ka lock PIN (4-16 digit)"; setSingleLine(true)
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
            AlertDialog.Builder(this).setTitle("Unlock PIN").setMessage("Digit apne aap gin liye jayenge. PIN encrypted rakha jata hai.").setView(et)
                .setPositiveButton("Save") { _, _ ->
                    val p = et.text.toString().trim()
                    if (p.length in 4..16 && p.all { it.isDigit() }) { Unlocker.setPin(this, p); Toast.makeText(this, "${p.length} digit PIN save", Toast.LENGTH_SHORT).show() }
                    else Toast.makeText(this, "PIN 4 se 16 digit ka hona chahiye", Toast.LENGTH_SHORT).show()
                    pinInfo()
                }.setNeutralButton("PIN hatao") { _, _ -> Unlocker.clearPin(this); pinInfo() }
                .setNegativeButton("Raddh", null).show()
        }
        val unlockBtn = Button(this)
        fun unlockLabel() { unlockBtn.text = "S4. Lock hone par auto-unlock: " + if (Unlocker.unlockOn(this)) "ON" else "OFF" }
        unlockBtn.setOnClickListener { Unlocker.setUnlockOn(this, !Unlocker.unlockOn(this)); unlockLabel() }
        root.addView(unlockBtn)
        val dataBtn = Button(this)
        fun dataLabel() { dataBtn.text = "S5. Data band ho to ON karo: " + if (Unlocker.dataOn(this)) "ON" else "OFF" }
        dataBtn.setOnClickListener { Unlocker.setDataOn(this, !Unlocker.dataOn(this)); dataLabel() }
        root.addView(dataBtn)
        val bioBtn = Button(this)
        fun bioLabel() { bioBtn.text = "S7. Biometric prompt par \"Use PIN\" + PIN: " + if (Unlocker.bioOn(this)) "ON" else "OFF" }
        bioBtn.setOnClickListener { Unlocker.setBioOn(this, !Unlocker.bioOn(this)); bioLabel() }
        root.addView(bioBtn)
        val capBtn = Button(this)
        fun capLabel() { val c = Unlocker.payCap(this); capBtn.text = "P1. Payment limit (max \u20B9 ek payment): " + if (c <= 0.0) "SET NAHI (payment band)" else "\u20B9" + (if (c == Math.floor(c)) c.toLong().toString() else c.toString()) }
        capBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Max amount, jaise 100"; setSingleLine(true); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
            AlertDialog.Builder(this).setTitle("Ek payment ki max limit").setMessage("Isse zyada amount ki command chalegi hi nahi. 0 = payment band.").setView(et)
                .setPositiveButton("Save") { _, _ -> Unlocker.setPayCap(this, et.text.toString().toDoubleOrNull() ?: 0.0); capLabel() }
                .setNegativeButton("Raddh", null).show()
        }
        root.addView(capBtn)
        root.addView(TextView(this).apply { text = "Payment command (schedule mein ya type karke, voice se nahi): pay sekh parbez 50   ya   pay 7797942157@ybl 50"; textSize = 13f })
        btn("D1. Screen dump: 8 sec baad (tab dekhni wali screen kholo)") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Pehle Accessibility on karo", Toast.LENGTH_SHORT).show()
            else {
                Toast.makeText(this, "8 sec mein wo screen kholo", Toast.LENGTH_LONG).show()
                Handler(Looper.getMainLooper()).postDelayed({
                    val d = a.dump()
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("dump", d))
                    Toast.makeText(this, "Copy ho gaya (${d.lines().size} lines). Chat mein paste karo", Toast.LENGTH_LONG).show()
                }, 8000)
            }
        }
        btn("S6. Test: phone lock karke 6 sec baad unlock try") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Pehle Accessibility on karo", Toast.LENGTH_SHORT).show()
            else {
                a.act("lock")
                Handler(Looper.getMainLooper()).postDelayed({
                    try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("prep_only", true).putExtra("sched", true)) } catch (_: Exception) {}
                }, 6000)
            }
        }
        pinInfo(); unlockLabel(); dataLabel(); bioLabel(); capLabel()
        val schedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun dayName(mask: Int): String = if (mask == 0) "Ek baar" else if (mask == 127) "Roz"
            else listOf("Ravi", "Som", "Mangal", "Budh", "Guru", "Shukra", "Shani").filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(",")
        fun refreshSched() {
            schedBox.removeAllViews()
            Scheduler.load(this).forEach { s ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 16) }
                row.addView(TextView(this).apply { text = "%02d:%02d • %s • %s%s".format(s.hh, s.mm, dayName(s.days), s.cmd, if (s.on) "" else "  (band)"); textSize = 15f })
                val br = LinearLayout(this)
                br.addView(Button(this).apply { text = if (s.on) "OFF" else "ON"; setOnClickListener { Scheduler.setOn(this@MainActivity, s.id, !s.on); refreshSched() } })
                br.addView(Button(this).apply { text = "Abhi chalao"; setOnClickListener { startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", s.cmd).putExtra("sched", true)) } })
                br.addView(Button(this).apply { text = "Hatao"; setOnClickListener { Scheduler.remove(this@MainActivity, s.id); refreshSched() } })
                row.addView(br); schedBox.addView(row)
            }
            Style.skin(this, schedBox)
        }
        btn("+ Naya schedule") {
            val et = EditText(this).apply { hint = "Command, jaise: youtube kholo"; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle("Kaun si command chalani hai?").setView(et)
                .setPositiveButton("Aage") { _, _ ->
                    val cmd = et.text.toString().trim()
                    if (cmd.isNotEmpty()) TimePickerDialog(this, { _, hh, mm ->
                        val sel = BooleanArray(7)
                        AlertDialog.Builder(this).setTitle("Kin dino? (kuch na chuno = sirf ek baar)")
                            .setMultiChoiceItems(arrayOf("Ravivar", "Somvar", "Mangalvar", "Budhvar", "Guruvar", "Shukravar", "Shanivar"), sel) { _, i, c -> sel[i] = c }
                            .setPositiveButton("Save") { _, _ ->
                                var mask = 0
                                sel.forEachIndexed { i, b -> if (b) mask = mask or (1 shl i) }
                                Scheduler.add(this, hh, mm, cmd, mask); refreshSched()
                            }.setNegativeButton("Raddh", null).show()
                    }, 8, 0, false).show()
                }.setNegativeButton("Raddh", null).show()
        }
        root.addView(schedBox)
        Scheduler.armAll(this); refreshSched()
        Style.skin(this, root)
        (root.findViewWithTag<TextView>("title"))?.setTextColor(Style.theme(this).stroke)
        setContentView(ScrollView(this).apply { background = Style.background(this@MainActivity); addView(root) })
        Style.enter(root)
        if (b == null) Style.buzz(this, "launch")
    }

    // App kholte hi (ya permission dene ke baad) service khud chalu: mic sirf "MJ" ke liye sunta rehta hai
    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }
}
