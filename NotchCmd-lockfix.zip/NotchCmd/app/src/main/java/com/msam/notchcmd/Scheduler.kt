package com.msam.notchcmd

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** days: bitmask, Sunday = bit0 ... Saturday = bit6. 0 = sirf ek baar */
data class Sched(val id: Int, val hh: Int, val mm: Int, val cmd: String, val days: Int, val on: Boolean)

object Scheduler {
    private const val PREF = "sched"

    fun load(c: Context): MutableList<Sched> {
        val out = ArrayList<Sched>()
        try {
            val a = JSONArray(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Sched(o.getInt("id"), o.getInt("hh"), o.getInt("mm"), o.getString("cmd"), o.getInt("days"), o.getBoolean("on")))
            }
        } catch (_: Exception) {}
        return out
    }

    fun save(c: Context, l: List<Sched>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("hh", it.hh).put("mm", it.mm).put("cmd", it.cmd).put("days", it.days).put("on", it.on)) }
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", a.toString()).apply()
    }

    fun canExact(c: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()

    fun nextTime(s: Sched, now: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, s.hh); cal.set(Calendar.MINUTE, s.mm); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        for (i in 0..8) {
            val okDay = s.days == 0 || (s.days and (1 shl (cal.get(Calendar.DAY_OF_WEEK) - 1))) != 0
            if (okDay && cal.timeInMillis > now) return cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return now + 60_000
    }

    private fun pi(c: Context, id: Int) = PendingIntent.getBroadcast(c, 5000 + id,
        Intent(c, SchedReceiver::class.java).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun arm(c: Context, s: Sched) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!s.on) { am.cancel(pi(c, s.id)); return }
        val t = nextTime(s)
        try {
            if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, s.id))
            else am.setAlarmClock(AlarmManager.AlarmClockInfo(t, pi(c, s.id)), pi(c, s.id))   // permission ke bina bhi theek waqt par
        } catch (_: Exception) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, s.id)) }
    }

    fun armAll(c: Context) { load(c).forEach { arm(c, it) } }

    fun add(c: Context, hh: Int, mm: Int, cmd: String, days: Int): Sched {
        val l = load(c)
        val s = Sched((l.maxOfOrNull { it.id } ?: 0) + 1, hh, mm, cmd, days, true)
        l.add(s); save(c, l); arm(c, s)
        return s
    }

    fun remove(c: Context, id: Int) {
        val l = load(c)
        l.firstOrNull { it.id == id }?.let { (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, it.id)) }
        save(c, l.filter { it.id != id })
    }

    fun setOn(c: Context, id: Int, on: Boolean) {
        val l = load(c).map { if (it.id == id) it.copy(on = on) else it }
        save(c, l)
        l.firstOrNull { it.id == id }?.let { arm(c, it) }
    }
}

/** Waqt hote hi: screen jagao aur command chalao (lock ho tab bhi; UI wali commands ke liye screen unlock chahiye) */
class SchedReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val s = Scheduler.load(c).firstOrNull { it.id == id } ?: return
        if (s.days != 0) Scheduler.arm(c, s) else Scheduler.setOn(c, id, false)   // repeat: agla waqt; ek baar: band
        if (!s.on) return
        try {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "notchcmd:sched").acquire(60_000L)
        } catch (_: Exception) {}
        try { c.startForegroundService(Intent(c, OverlayService::class.java).putExtra("cmd", s.cmd).putExtra("sched", true)) } catch (_: Exception) {}
    }
}

/** Phone restart / app update ke baad saare schedule dobara lagao */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Scheduler.armAll(c) }
}
