package com.msam.notchcmd

import android.app.KeyguardManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Schedule ke waqt: phone lock ho to swipe-up + PIN, data band ho to ON, phir command.
 * PIN Android Keystore ke AES key se encrypt karke rakha jata hai (plain text nahi).
 */
object Unlocker {
    private const val PREF = "unlock"
    private const val ALIAS = "notchcmd_pin_key"
    private val h = Handler(Looper.getMainLooper())

    private fun p(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return kg.generateKey()
    }

    fun setPin(c: Context, pin: String) {
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.ENCRYPT_MODE, key())
        val ct = ci.doFinal(pin.toByteArray())
        p(c).edit().putString("pin", Base64.encodeToString(ci.iv + ct, Base64.NO_WRAP)).apply()
    }

    fun getPin(c: Context): String? {
        return try {
            val raw = p(c).getString("pin", null)
            if (raw == null) null else {
                val b = Base64.decode(raw, Base64.NO_WRAP)
                val ci = Cipher.getInstance("AES/GCM/NoPadding")
                ci.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b.copyOfRange(0, 12)))
                String(ci.doFinal(b.copyOfRange(12, b.size)))
            }
        } catch (_: Exception) { null }
    }

    fun clearPin(c: Context) { p(c).edit().remove("pin").apply() }
    fun pinLen(c: Context): Int = getPin(c)?.length ?: 0

    fun unlockOn(c: Context) = p(c).getBoolean("on", true)
    fun setUnlockOn(c: Context, v: Boolean) { p(c).edit().putBoolean("on", v).apply() }
    fun dataOn(c: Context) = p(c).getBoolean("data", true)
    fun setDataOn(c: Context, v: Boolean) { p(c).edit().putBoolean("data", v).apply() }

    fun bioOn(c: Context) = p(c).getBoolean("bio", false)
    fun setBioOn(c: Context, v: Boolean) { p(c).edit().putBoolean("bio", v).apply() }

    // ---- payment safety ----
    fun payCap(c: Context): Double = p(c).getFloat("paycap", 0f).toDouble()
    fun setPayCap(c: Context, v: Double) { p(c).edit().putFloat("paycap", v.toFloat()).apply() }
    /** Pay button dabne ke baad 2 minute tak dusri payment nahi (fail hui koshish ginti nahi hoti) */
    fun payAllowed(c: Context): Boolean = System.currentTimeMillis() - p(c).getLong("lastpay", 0L) >= 120_000L
    fun markPay(c: Context) { p(c).edit().putLong("lastpay", System.currentTimeMillis()).apply() }

    fun isLocked(c: Context): Boolean =
        (c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked

    fun hasNet(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }

    /** Main thread par chalao. Kaam khatam hone par done() */
    fun prepare(c: Context, done: () -> Unit) {
        val a = NotchA11y.inst
        fun waitNet(n: Int, f: () -> Unit) { if (hasNet(c) || n <= 0) f() else h.postDelayed({ waitNet(n - 1, f) }, 1000) }
        fun dataStep() {
            if (a == null || !dataOn(c) || hasNet(c)) { done(); return }
            a.toggleTile("mobile data|internet|data", 1) { waitNet(10) { done() } }
        }
        val pin = getPin(c)
        if (a == null || pin == null || !unlockOn(c) || !isLocked(c)) { dataStep(); return }
        a.unlock(pin, { isLocked(c) }) { h.postDelayed({ dataStep() }, 1200) }
    }
}
