package com.msam.notchcmd

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class NotchA11y : AccessibilityService() {
    companion object { var inst: NotchA11y? = null }
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { stopAuto(); inst = null; return super.onUnbind(i) }
    // ---------- biometric prompt par "Use PIN" dabakar PIN daalna (opt-in) ----------
    private var bioBusy = false
    private var bioLast = 0L
    private var bioTries = 0
    private val credWords = listOf("use pin", "use password", "use screen lock", "use passcode", "use lock screen", "use device password", "use pattern", "पिन का उपयोग", "पासवर्ड का उपयोग")
    private fun credNode(): AccessibilityNodeInfo? = all().firstOrNull { n ->
        !n.isEditable && n.isVisibleToUser && listOfNotNull(n.text, n.contentDescription).any { t ->
            val x = t.toString().lowercase(); x.length < 40 && credWords.any { x.contains(it) } }
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || bioBusy) return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            !(e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && e.packageName?.toString() == "com.android.systemui")) return
        if (!Unlocker.bioOn(this)) return
        val now = android.os.SystemClock.uptimeMillis()
        if (now - bioLast > 120_000) bioTries = 0
        if (bioTries >= 2 && now - bioLast < 600_000) return      // galat PIN se phone lock na ho: 2 koshish ke baad 10 min ruko
        if (now - bioLast < 15_000) return
        val pin = Unlocker.getPin(this) ?: return
        val n = credNode() ?: return
        bioBusy = true; bioLast = now; bioTries++
        tap(n)
        h.postDelayed({
            retry(8, 500, { digitNode(pin[0]) != null }) { found ->
                if (!found) bioBusy = false
                else typePin(pin, 0, { digitNode(pin[0]) != null }) { _ -> bioBusy = false; bioLast = android.os.SystemClock.uptimeMillis() }
            }
        }, 900)
    }

    // Volume Up + Volume Down ek saath dabao -> panel khule (mic tabhi on hoga)
    private var upDown = false; private var downDown = false; private var comboFired = false
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val up = e.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        val down = e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (!up && !down) return false
        val pressed = e.action == KeyEvent.ACTION_DOWN
        if (up) upDown = pressed else downDown = pressed
        if (pressed && upDown && downDown && !comboFired) {
            comboFired = true
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) } catch (_: Exception) {}
            return true
        }
        if (!upDown && !downDown) { val was = comboFired; comboFired = false; return was }
        return comboFired   // combo ke dauran volume nahi badlega
    }
    override fun onInterrupt() {}

    fun fgPkg(): String = rootInActiveWindow?.packageName?.toString() ?: ""

    // ---------- "scroll karte raho": jab tak stop/ruko na bolo ----------
    var autoOn = false
    private var autoDown = true
    private val autoRun = object : Runnable {
        override fun run() { if (!autoOn) return; scroll(autoDown); h.postDelayed(this, 3000) }
    }
    fun startAuto(down: Boolean) { autoDown = down; autoOn = true; h.removeCallbacks(autoRun); h.postDelayed(autoRun, 400) }
    fun stopAuto(): Boolean { val was = autoOn; autoOn = false; h.removeCallbacks(autoRun); return was }

    private fun all(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        val r = rootInActiveWindow
        if (r != null) walk(r) else windows.forEach { w -> w.root?.let { walk(it) } }
        return out
    }
    private fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) { if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.parent }
        return false
    }
    private fun tapXY(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }
    /** pehle normal click, na ho to screen par us jagah gesture-tap */
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        if (click(n)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        tapXY(r.exactCenterX(), r.exactCenterY()); return true
    }
    private fun setText(n: AccessibilityNodeInfo, s: String) = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
        Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s) })
    private fun retry(t: Int, d: Long, f: () -> Boolean, done: (Boolean) -> Unit) {
        if (f()) done(true) else if (t <= 1) done(false) else h.postDelayed({ retry(t - 1, d, f, done) }, d)
    }
    private fun isSearch(n: AccessibilityNodeInfo): Boolean {
        if (n.isEditable) return false
        val s = (n.contentDescription ?: n.text)?.toString()?.lowercase() ?: return false
        return s.length < 40 && (s.contains("search") || s.contains("खोज") || s.contains("سرچ"))
    }

    // ---------- poori screen ka control ----------
    fun act(name: String) {
        when (name) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "shot" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            "scrolldown" -> scroll(true)
            "scrollup" -> scroll(false)
            "autodown" -> startAuto(true)
            "autoup" -> startAuto(false)
            "stopauto" -> stopAuto()
            "lock" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            "qs" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "swl" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.85f, m.heightPixels * 0.5f, m.widthPixels * 0.15f, m.heightPixels * 0.5f) }
            "swr" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.15f, m.heightPixels * 0.5f, m.widthPixels * 0.85f, m.heightPixels * 0.5f) }
            "swu" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.5f, m.heightPixels * 0.7f, m.widthPixels * 0.5f, m.heightPixels * 0.3f) }
            "swd" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.5f, m.heightPixels * 0.3f, m.widthPixels * 0.5f, m.heightPixels * 0.7f) }
            "doubletap" -> { val m = resources.displayMetrics; val x = m.widthPixels / 2f; val y = m.heightPixels / 2f; tapXY(x, y); h.postDelayed({ tapXY(x, y) }, 130) }
        }
    }
    private fun scroll(down: Boolean) {
        val ok = all().firstOrNull { it.isScrollable }?.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false
        if (!ok) {
            val m = resources.displayMetrics; val x = m.widthPixels / 2f; val a = m.heightPixels * 0.7f; val b = m.heightPixels * 0.3f
            if (down) swipe(x, a, x, b) else swipe(x, b, x, a)
        }
    }

    // ---------- lock screen: swipe up + PIN ----------
    private fun digitNode(d: Char): AccessibilityNodeInfo? = if (fgPkg() == "com.fampay.in") null else all().firstOrNull { n ->
        !n.isEditable && n.isVisibleToUser && (
            Regex("^\\s*$d(\\s|$)").containsMatchIn(n.text?.toString() ?: "") ||
            n.contentDescription?.toString()?.trim() == d.toString() ||
            n.viewIdResourceName?.endsWith("key$d") == true)
    }
    private fun enterNode(): AccessibilityNodeInfo? = all().firstOrNull { n ->
        val cd = n.contentDescription?.toString()?.trim()?.lowercase() ?: ""
        val tx = n.text?.toString()?.trim()?.lowercase() ?: ""
        n.isVisibleToUser && (n.viewIdResourceName?.endsWith("key_enter") == true || n.viewIdResourceName?.endsWith("enter") == true ||
            cd in setOf("enter", "ok", "confirm", "done") || tx in setOf("ok", "enter", "done"))
    }
    private fun swipeUpUnlock() {
        val m = resources.displayMetrics
        swipe(m.widthPixels * 0.5f, m.heightPixels * 0.85f, m.widthPixels * 0.5f, m.heightPixels * 0.25f)
    }

    /** Lock ho to swipe-up karke PIN daalta hai. cb(true) = ab unlock hai */
    fun unlock(pin: String, stillLocked: () -> Boolean, cb: (Boolean) -> Unit) {
        if (!stillLocked()) { cb(true); return }
        swipeUpUnlock()
        h.postDelayed({
            if (!stillLocked()) { cb(true); return@postDelayed }
            var swipes = 1
            retry(8, 500, {
                if (digitNode(pin[0]) != null) true
                else { if (swipes < 3) { swipes++; swipeUpUnlock() }; false }
            }) { found ->
                if (!found) cb(!stillLocked()) else typePin(pin, 0, stillLocked, cb)
            }
        }, 1000)
    }
    private fun typePin(pin: String, i: Int, stillLocked: () -> Boolean, cb: (Boolean) -> Unit) {
        if (i >= pin.length) {
            h.postDelayed({
                if (stillLocked()) enterNode()?.let { tap(it) }
                h.postDelayed({ cb(!stillLocked()) }, 1500)
            }, 500)
            return
        }
        val n = digitNode(pin[i])
        if (n != null) tap(n)
        h.postDelayed({ typePin(pin, i + 1, stillLocked, cb) }, 280)
    }
    /** Diagnostic: abhi screen par accessibility ko kya dikh raha hai (text / description / id / clickable) */
    fun dump(): String {
        val sb = StringBuilder()
        val ws = windows
        sb.append("windows=").append(ws.size).append(" root=").append(rootInActiveWindow?.packageName).append("\n")
        val seen = HashSet<String>()
        for (n in all()) {
            if (!n.isVisibleToUser) continue
            val t = n.text?.toString()?.take(40) ?: ""
            val d = n.contentDescription?.toString()?.take(40) ?: ""
            val id = n.viewIdResourceName?.substringAfter(":id/") ?: ""
            if (t.isEmpty() && d.isEmpty() && id.isEmpty()) continue
            val line = "t=[$t] d=[$d] id=[$id]" + (if (n.isClickable) " CLICK" else "") + (if (n.isEditable) " EDIT" else "")
            if (seen.add(line)) sb.append(line).append("\n")
        }
        return sb.toString()
    }


    // ---------- FamPay payment (har step verify hota hai, shak hote hi ruk jata hai) ----------
    private fun cdl(n: AccessibilityNodeInfo): String =
        ((n.contentDescription?.toString() ?: "") + " " + (n.text?.toString() ?: "")).lowercase().trim()
    private val rupee = Regex("\u20B9\\s*([0-9,]+(?:\\.[0-9]+)?)")

    fun pay(to: String, amt: String, cap: Double, pin: String?, cb: (Boolean, String) -> Unit) {
        val amount = amt.toDoubleOrNull()
        val end: (Boolean, String) -> Unit = { ok, m -> bioBusy = false; cb(ok, m) }
        if (amount == null || amount <= 0.0 || !Regex("^\\d{1,6}(\\.\\d{1,2})?$").matches(amt)) { cb(false, "Amount galat hai"); return }
        if (cap <= 0.0) { cb(false, "Pehle app mein payment limit set karo (P1)"); return }
        if (amount > cap) { cb(false, "Amount limit se zyada hai, roka"); return }
        if (pin == null) { cb(false, "Phone PIN save nahi hai (S3)"); return }
        if (bioBusy) { cb(false, "Dusra kaam chal raha hai, roka"); return }
        bioBusy = true   // S7 wala auto-handler beech mein na aaye
        PayJob(to.lowercase().trim(), amount, amt, pin, end).loop(40)
    }

    private inner class PayJob(val want: String, val amount: Double, val amt: String, val pin: String, val cb: (Boolean, String) -> Unit) {
        val isUpi = want.contains("@")
        var stage = 0
        var backs = 0

        fun loop(n: Int) {
            if (n <= 0) { cb(false, "FamPay mein payment screen tak nahi pahunch paya, roka"); return }
            val nodes = all()
            if (nodes.any { cdl(it).contains("add a note") }) { h.postDelayed({ enterAmount() }, 500); return }
            val onSearch = nodes.any { val c = cdl(it); c == "pay search" || c == "paste" }
            if (onSearch) {
                if (!isUpi) {
                    val hit = nodes.firstOrNull { it.isClickable && it.isVisibleToUser && cdl(it) == want }
                        ?: nodes.firstOrNull { it.isClickable && it.isVisibleToUser && cdl(it).contains(want) }
                    if (hit != null) tap(hit)
                } else when (stage) {
                    0 -> { nodes.firstOrNull { it.isClickable && cdl(it).contains("pay any") }?.let { tap(it); stage = 1 } }
                    1 -> { val ed = nodes.firstOrNull { it.isEditable }; if (ed != null && setText(ed, want)) stage = 2 }
                    else -> { nodes.firstOrNull { !it.isEditable && it.isVisibleToUser && cdl(it).contains(want) }?.let { tap(it) } }
                }
            } else {
                val home = nodes.firstOrNull { it.isClickable && cdl(it).contains("pay any") }
                if (home != null) tap(home)
                else if (n % 8 == 0 && backs < 3 && fgPkg() == "com.fampay.in") { performGlobalAction(GLOBAL_ACTION_BACK); backs++ }
            }
            h.postDelayed({ loop(n - 1) }, 900)
        }

        fun enterAmount() {
            val nodes = all()
            if (nodes.any { it.isClickable && Regex("^[0-9.]+$").matches(it.text?.toString() ?: "") }) { cb(false, "Amount pehle se bhara hai, roka"); return }
            if (nodes.none { cdl(it).contains(want) }) { cb(false, "Payee screen par nahi dikha, roka"); return }
            val bal = nodes.firstOrNull { cdl(it).contains("balance") }?.let { rupee.find(cdl(it))?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() }
            if (bal != null && amount > bal) { cb(false, "Wallet balance kam hai, roka"); return }
            typeChars(0)
        }

        fun typeChars(i: Int) {
            if (i >= amt.length) { h.postDelayed({ verifyAndPay() }, 700); return }
            val k = amt[i].toString()
            val node = all().firstOrNull { it.isClickable && it.isVisibleToUser && it.contentDescription?.toString() == k }
            if (node == null) { cb(false, "Keypad ka '$k' nahi mila, roka"); return }
            tap(node)
            h.postDelayed({ typeChars(i + 1) }, 380)
        }

        fun verifyAndPay() {
            val nodes = all()
            val payNode = nodes.firstOrNull { it.isClickable && cdl(it).startsWith("pay \u20B9") }
            val shown = payNode?.let { rupee.find(cdl(it))?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() }
            if (payNode == null || shown == null || Math.abs(shown - amount) > 0.001) { cb(false, "Pay button par amount mel nahi khaya, roka"); return }
            if (nodes.none { cdl(it).contains(want) }) { cb(false, "Payee badal gaya, roka"); return }
            tap(payNode)
            h.postDelayed({ confirm() }, 1200)
        }

        fun confirm() {
            retry(12, 600, { credNode() != null }) { found ->
                val c = if (found) credNode() else null
                if (c == null) { cb(false, "Biometric par 'Use PIN' nahi mila. FamPay history check karo"); return@retry }
                tap(c)
                h.postDelayed({
                    retry(10, 500, { fgPkg() != "com.fampay.in" && digitNode(pin[0]) != null }) { ok ->
                        if (!ok) cb(false, "PIN keypad nahi aaya. FamPay history check karo")
                        else typePin(pin, 0, { digitNode(pin[0]) != null }) { _ ->
                            h.postDelayed({ cb(true, "PIN daal diya. FamPay history mein confirm kar lena") }, 3000)
                        }
                    }
                }, 900)
            }
        }
    }

    /** screen par jo text/description match kare use dabao */
    fun tapText(q: String, cb: (Boolean) -> Unit) {
        val alts = q.lowercase().split("|").filter { it.isNotBlank() }   // "a|b|c" = koi bhi ek
        retry(6, 500, {
            all().firstOrNull { nd -> !nd.isEditable && alts.any { a ->
                nd.text?.toString()?.lowercase()?.contains(a) == true || nd.contentDescription?.toString()?.lowercase()?.contains(a) == true } }?.let { tap(it) } ?: false
        }, cb)
    }

    // ---------- Quick Settings tiles (Wi-Fi, Bluetooth, Airplane, Data, Hotspot, DND, Rotate) ----------
    private fun tileState(n: AccessibilityNodeInfo): Boolean? {
        var c: AccessibilityNodeInfo? = n
        var i = 0
        while (c != null && i < 3) {
            if (c.isCheckable) return c.isChecked
            val sd = if (Build.VERSION.SDK_INT >= 30) c.stateDescription?.toString() ?: "" else ""
            val txt = (sd + " " + (c.contentDescription ?: "")).lowercase()
            if (Regex("\\boff\\b").containsMatchIn(txt)) return false
            if (Regex("\\bon\\b").containsMatchIn(txt)) return true
            c = c.parent; i++
        }
        return null
    }

    /** want: 1 = on, 0 = off, -1 = toggle */
    fun toggleTile(labels: String, want: Int, cb: (Boolean) -> Unit) {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        val alts = labels.lowercase().split("|").filter { it.isNotBlank() }
        h.postDelayed({
            retry(8, 500, {
                val nodes = all()
                var hit: AccessibilityNodeInfo? = null
                for (a in alts) {
                    hit = nodes.firstOrNull { nd -> !nd.isEditable && (nd.text?.toString()?.lowercase()?.contains(a) == true ||
                        nd.contentDescription?.toString()?.lowercase()?.contains(a) == true) }
                    if (hit != null) break
                }
                val nd = hit
                if (nd == null) false else {
                    val st = tileState(nd)
                    if (want >= 0 && st != null && st == (want == 1)) true else tap(nd)
                }
            }) { ok -> h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK); cb(ok) }, 500) }
        }, 900)
    }
    /** screen par n-wa item (upar se neeche, phir left se right). q="video" to jis node ke text/description mein "video" ho */
    fun tapNth(n: Int, q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        val dm = resources.displayMetrics
        retry(8, 600, {
            val found = mutableListOf<Pair<Rect, AccessibilityNodeInfo>>()
            for (nd in all()) {
                if (nd.isEditable) continue
                val r = Rect(); nd.getBoundsInScreen(r)
                if (r.isEmpty || r.bottom <= 0 || r.top >= dm.heightPixels || r.right <= 0 || r.left >= dm.widthPixels) continue
                if (r.height() < 120) continue
                val t = ((nd.text ?: "").toString() + " " + (nd.contentDescription ?: "")).lowercase()
                val ok = if (ql.isEmpty()) nd.isClickable else t.contains(ql)
                if (ok) found.add(Pair(r, nd))
            }
            val top = found.filter { a -> found.none { b -> b !== a && b.first != a.first && b.first.contains(a.first) } }
                .sortedWith(compareBy({ it.first.top }, { it.first.left }))
            top.getOrNull(n - 1)?.let { tap(it.second) } ?: false
        }, cb)
    }
    fun typeText(t: String, cb: (Boolean) -> Unit) {
        retry(6, 400, {
            val n = all()
            (n.firstOrNull { it.isFocused && it.isEditable } ?: n.firstOrNull { it.isEditable })?.let { setText(it, t) } ?: false
        }, cb)
    }

    // ---------- kisi bhi app ke andar search ----------
    private fun searchEditable(n: List<AccessibilityNodeInfo>) = n.firstOrNull { e ->
        e.isEditable && listOfNotNull(e.hintText, e.contentDescription, e.viewIdResourceName, e.text).any { it.toString().lowercase().contains("search") }
    }

    fun appSearch(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(6, 500, {
            val n = all()
            val ed = searchEditable(n)
            if (ed != null) { tap(ed); true } else n.firstOrNull { isSearch(it) }?.let { tap(it) } ?: false
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, {
                    val n = all()
                    (n.firstOrNull { it.isFocused && it.isEditable } ?: searchEditable(n) ?: n.firstOrNull { it.isEditable })?.let { setText(it, q) } ?: false
                }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({ submitSearch(ql, cb) }, 900)
                }
            }, 800)
        }
    }

    private fun submitSearch(ql: String, cb: (Boolean) -> Unit) {
        val n = all()
        val ed = n.firstOrNull { it.isFocused && it.isEditable } ?: n.firstOrNull { it.isEditable }
        var ok = false
        if (Build.VERSION.SDK_INT >= 30 && ed != null) ok = ed.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        if (!ok) ok = n.firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { tap(it) } ?: false
        cb(ok)
    }

    // ---------- WhatsApp ----------
    private fun isEntry(n: AccessibilityNodeInfo) = n.isEditable && n.viewIdResourceName?.endsWith("entry") == true

    /** chat khuli ho to pehle back karke chats list par aao (warna compose box mein search type ho jata tha) */
    private fun leaveChat(tries: Int, done: () -> Unit) {
        if (tries > 0 && all().any { isEntry(it) }) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            h.postDelayed({ leaveChat(tries - 1, done) }, 700)
        } else done()
    }

    fun waSearch(q: String, cb: (Boolean) -> Unit) = leaveChat(3) { waSearch2(q, cb) }

    private fun waSearch2(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(8, 500, {
            val n = all(); val s = n.firstOrNull { isSearch(it) }
            if (s != null) { tap(s); true } else n.any { it.isEditable && !isEntry(it) }
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, { all().firstOrNull { it.isEditable && !isEntry(it) }?.let { setText(it, q) } ?: false }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({
                        retry(10, 500, {
                            all().firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { tap(it) } ?: false
                        }, cb)
                    }, 1200)
                }
            }, 800)
        }
    }

    fun sendMsg(t: String, cb: (Boolean) -> Unit) {
        h.postDelayed({
            retry(10, 500, {
                val n = all()
                val e = n.firstOrNull { it.isEditable && it.viewIdResourceName?.endsWith("entry") == true } ?: n.lastOrNull { it.isEditable }
                e?.let { setText(it, t) } ?: false
            }) { ok ->
                if (!ok) cb(false) else h.postDelayed({
                    retry(8, 400, {
                        all().firstOrNull { val c = it.contentDescription?.toString()?.lowercase(); c == "send" || c == "भेजें" || c == "ارسال" }?.let { tap(it) } ?: false
                    }, cb)
                }, 600)
            }
        }, 800)
    }
}
