package com.msam.notchcmd

import android.content.Context
import android.content.Intent

/** Facebook posting: settings (Facebook / Facebook Lite, prompt, cleanup) kept in SharedPreferences. */
object FbPrefs {
    const val FB = "com.facebook.katana"
    const val FBL = "com.facebook.lite"
    const val DEFAULT_PROMPT = "Write a ready-to-post Facebook post about: {topic}. Make it engaging and natural, use short paragraphs and a few fitting emojis. Output ONLY the post text, no intro, no notes."

    private fun p(c: Context) = c.getSharedPreferences("fbpost", Context.MODE_PRIVATE)

    fun prompt(c: Context): String = (p(c).getString("prompt", "") ?: "").ifBlank { DEFAULT_PROMPT }
    fun hasCustomPrompt(c: Context): Boolean = (p(c).getString("prompt", "") ?: "").isNotBlank()
    fun setPrompt(c: Context, v: String) { p(c).edit().putString("prompt", v.trim()).apply() }

    fun buildPrompt(c: Context, topic: String): String {
        var t = prompt(c)
        t = if (t.contains("{topic}")) t.replace("{topic}", topic)
            else if (topic.isNotBlank()) t + "\n\nTopic: " + topic else t
        t = if (t.contains("{date}")) t.replace("{date}", ChannelPrefs.today()) else t + "\n\nToday's date: " + ChannelPrefs.today() + "."
        return t
    }

    fun lite(c: Context): Boolean = p(c).getBoolean("lite", false)
    fun toggleLite(c: Context): Boolean { val n = !lite(c); p(c).edit().putBoolean("lite", n).apply(); return n }

    private fun installed(c: Context, pkg: String) = try { c.packageManager.getLaunchIntentForPackage(pkg) != null } catch (_: Exception) { false }

    /** chosen app; if it is not installed, the other one is used */
    fun pkg(c: Context): String {
        val want = if (lite(c)) FBL else FB
        val other = if (want == FB) FBL else FB
        return if (installed(c, want) || !installed(c, other)) want else other
    }

    fun label(c: Context): String = if (pkg(c) == FBL) "Facebook Lite" else "Facebook"

    fun launchIntent(c: Context): Intent? = try {
        c.packageManager.getLaunchIntentForPackage(pkg(c))?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    } catch (_: Exception) { null }

    /** after a scheduled post: turn mobile data off and lock the phone */
    fun cleanup(c: Context): Boolean = p(c).getBoolean("cleanup", true)
    fun toggleCleanup(c: Context): Boolean { val n = !cleanup(c); p(c).edit().putBoolean("cleanup", n).apply(); return n }
}
