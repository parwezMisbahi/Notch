package com.msam.notchcmd

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import java.util.Locale

class CommandActivity : Activity() {
    private lateinit var web: WebView
    private var sr: SpeechRecognizer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/command.html")
        }
        setContentView(web)
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    inner class Bridge {
        @JavascriptInterface fun listen() = runOnUiThread { startListening() }
        @JavascriptInterface fun close() = runOnUiThread { finish() }
        @JavascriptInterface fun run(cmd: String) = runOnUiThread { execute(cmd) }
    }

    private fun startListening() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != 0) {
            Toast.makeText(this, "Pehle app mein mic permission do", Toast.LENGTH_LONG).show(); return
        }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) = js("setState('listening')")
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    js("gotText(${org.json.JSONObject.quote(t)})"); execute(t)
                }
                override fun onError(e: Int) = js("setState('idle','Samajh nahi aaya, dobara bolo')")
                override fun onPartialResults(p: Bundle?) {
                    val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    js("gotText(${org.json.JSONObject.quote(t)})")
                }
                override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            })
        }
    }

    private val filler = setOf("open", "kholo", "khol", "karo", "kar", "do", "dijiye", "chalao", "chala", "ko", "app", "start", "launch",
        "खोलो", "खोल", "करो", "दो", "चलाओ", "को", "ऐप", "the", "please", "plz")
    private val alias = mapOf("यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "कैमरा" to "camera",
        "क्रोम" to "chrome", "सेटिंग" to "settings", "सेटिंग्स" to "settings", "गैलरी" to "gallery", "फोन" to "phone", "इंस्टाग्राम" to "instagram")

    private fun execute(raw: String) {
        val words = raw.lowercase(Locale.ROOT).trim().split(Regex("\\s+")).map { alias[it] ?: it }.filter { it !in filler }
        val q = words.joinToString(" ")
        if (q.isEmpty()) return
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { (l, _) -> val n = l.lowercase(Locale.ROOT); n == q || n.contains(q) || q.contains(n) }
            .minByOrNull { it.first.length }
        val intent = hit?.let { pm.getLaunchIntentForPackage(it.second) }
        if (intent != null) { startActivity(intent); finish() }
        else js("setState('idle','App nahi mila: ' + ${org.json.JSONObject.quote(q)})")
    }

    override fun onDestroy() { sr?.destroy(); super.onDestroy() }
}
