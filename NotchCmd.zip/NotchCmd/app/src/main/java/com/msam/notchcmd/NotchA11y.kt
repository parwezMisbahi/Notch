package com.msam.notchcmd

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class NotchA11y : AccessibilityService() {
    companion object { var inst: NotchA11y? = null }
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun fgPkg(): String = rootInActiveWindow?.packageName?.toString() ?: ""

    private fun all(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        val r = rootInActiveWindow
        if (r != null) walk(r) else windows.forEach { w -> w.root?.let { walk(it) } }
        return out
    }
    private fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) { if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.parent }
        return false
    }
    private fun tapXY(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }
    /** pehle normal click, na ho to screen par us jagah gesture-tap */
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        if (click(n)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        tapXY(r.exactCenterX(), r.exactCenterY()); return true
    }
    private fun setText(n: AccessibilityNodeInfo, s: String) = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
        Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s) })
    private fun retry(t: Int, d: Long, f: () -> Boolean, done: (Boolean) -> Unit) {
        if (f()) done(true) else if (t <= 1) done(false) else h.postDelayed({ retry(t - 1, d, f, done) }, d)
    }
    private fun isSearch(n: AccessibilityNodeInfo): Boolean {
        if (n.isEditable) return false
        val s = (n.contentDescription ?: n.text)?.toString()?.lowercase() ?: return false
        return s.length < 40 && (s.contains("search") || s.contains("खोज") || s.contains("سرچ"))
    }

    // ---------- poori screen ka control ----------
    fun act(name: String) {
        when (name) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "shot" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            "scrolldown" -> scroll(true)
            "scrollup" -> scroll(false)
        }
    }
    private fun scroll(down: Boolean) {
        val ok = all().firstOrNull { it.isScrollable }?.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false
        if (!ok) {
            val m = resources.displayMetrics; val x = m.widthPixels / 2f; val a = m.heightPixels * 0.7f; val b = m.heightPixels * 0.3f
            if (down) swipe(x, a, x, b) else swipe(x, b, x, a)
        }
    }
    /** screen par jo text/description match kare use dabao */
    fun tapText(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(6, 500, {
            all().firstOrNull { !it.isEditable && (it.text?.toString()?.lowercase()?.contains(ql) == true ||
                it.contentDescription?.toString()?.lowercase()?.contains(ql) == true) }?.let { tap(it) } ?: false
        }, cb)
    }
    fun typeText(t: String, cb: (Boolean) -> Unit) {
        retry(6, 400, {
            val n = all()
            (n.firstOrNull { it.isFocused && it.isEditable } ?: n.firstOrNull { it.isEditable })?.let { setText(it, t) } ?: false
        }, cb)
    }

    // ---------- WhatsApp ----------
    private fun isEntry(n: AccessibilityNodeInfo) = n.isEditable && n.viewIdResourceName?.endsWith("entry") == true

    /** chat khuli ho to pehle back karke chats list par aao (warna compose box mein search type ho jata tha) */
    private fun leaveChat(tries: Int, done: () -> Unit) {
        if (tries > 0 && all().any { isEntry(it) }) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            h.postDelayed({ leaveChat(tries - 1, done) }, 700)
        } else done()
    }

    fun waSearch(q: String, cb: (Boolean) -> Unit) = leaveChat(3) { waSearch2(q, cb) }

    private fun waSearch2(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(8, 500, {
            val n = all(); val s = n.firstOrNull { isSearch(it) }
            if (s != null) { tap(s); true } else n.any { it.isEditable && !isEntry(it) }
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, { all().firstOrNull { it.isEditable && !isEntry(it) }?.let { setText(it, q) } ?: false }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({
                        retry(10, 500, {
                            all().firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { tap(it) } ?: false
                        }, cb)
                    }, 1200)
                }
            }, 800)
        }
    }

    fun sendMsg(t: String, cb: (Boolean) -> Unit) {
        h.postDelayed({
            retry(10, 500, {
                val n = all()
                val e = n.firstOrNull { it.isEditable && it.viewIdResourceName?.endsWith("entry") == true } ?: n.lastOrNull { it.isEditable }
                e?.let { setText(it, t) } ?: false
            }) { ok ->
                if (!ok) cb(false) else h.postDelayed({
                    retry(8, 400, {
                        all().firstOrNull { val c = it.contentDescription?.toString()?.lowercase(); c == "send" || c == "भेजें" || c == "ارسال" }?.let { tap(it) } ?: false
                    }, cb)
                }, 600)
            }
        }, 800)
    }
}
