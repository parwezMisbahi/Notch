package com.msam.notchcmd

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class NotchA11y : AccessibilityService() {
    companion object { var inst: NotchA11y? = null }
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun all(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        walk(rootInActiveWindow); return out
    }
    private fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) { if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.parent }
        return false
    }
    private fun setText(n: AccessibilityNodeInfo, s: String) = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
        Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s) })
    private fun retry(t: Int, d: Long, f: () -> Boolean, done: (Boolean) -> Unit) {
        if (f()) done(true) else if (t <= 1) done(false) else h.postDelayed({ retry(t - 1, d, f, done) }, d)
    }
    private fun isSearch(n: AccessibilityNodeInfo): Boolean {
        val s = (n.contentDescription ?: n.text)?.toString()?.lowercase() ?: return false
        return s == "search" || s == "खोजें" || s == "سرچ"
    }

    /** WhatsApp: search icon dabao -> naam type karo -> pehla result kholo */
    fun waSearch(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(8, 500, {
            val n = all(); val s = n.firstOrNull { isSearch(it) }
            if (s != null) { click(s); true } else n.any { it.isEditable }
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, { all().firstOrNull { it.isEditable }?.let { setText(it, q) } ?: false }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({
                        retry(10, 500, {
                            all().firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { click(it) } ?: false
                        }, cb)
                    }, 1200)
                }
            }, 700)
        }
    }

    /** Khule chat mein message likho aur Send dabao */
    fun sendMsg(t: String, cb: (Boolean) -> Unit) {
        h.postDelayed({
            retry(10, 500, {
                val n = all()
                val e = n.firstOrNull { it.isEditable && it.viewIdResourceName?.endsWith("entry") == true } ?: n.lastOrNull { it.isEditable }
                e?.let { setText(it, t) } ?: false
            }) { ok ->
                if (!ok) cb(false) else h.postDelayed({
                    retry(8, 400, {
                        all().firstOrNull { val c = it.contentDescription?.toString()?.lowercase(); c == "send" || c == "भेजें" || c == "ارسال" }?.let { click(it) } ?: false
                    }, cb)
                }, 600)
            }
        }, 800)
    }
}
