package com.msam.notchcmd

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class NotchA11y : AccessibilityService() {
    companion object { var inst: NotchA11y? = null }
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { stopAuto(); inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}

    // Volume Up + Volume Down ek saath dabao -> panel khule (mic tabhi on hoga)
    private var upDown = false; private var downDown = false; private var comboFired = false
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val up = e.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        val down = e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (!up && !down) return false
        val pressed = e.action == KeyEvent.ACTION_DOWN
        if (up) upDown = pressed else downDown = pressed
        if (pressed && upDown && downDown && !comboFired) {
            comboFired = true
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) } catch (_: Exception) {}
            return true
        }
        if (!upDown && !downDown) { val was = comboFired; comboFired = false; return was }
        return comboFired   // combo ke dauran volume nahi badlega
    }
    override fun onInterrupt() {}

    fun fgPkg(): String = rootInActiveWindow?.packageName?.toString() ?: ""

    // ---------- "scroll karte raho": jab tak stop/ruko na bolo ----------
    var autoOn = false
    private var autoDown = true
    private val autoRun = object : Runnable {
        override fun run() { if (!autoOn) return; scroll(autoDown); h.postDelayed(this, 3000) }
    }
    fun startAuto(down: Boolean) { autoDown = down; autoOn = true; h.removeCallbacks(autoRun); h.postDelayed(autoRun, 400) }
    fun stopAuto(): Boolean { val was = autoOn; autoOn = false; h.removeCallbacks(autoRun); return was }

    private fun all(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        val r = rootInActiveWindow
        if (r != null) walk(r) else windows.forEach { w -> w.root?.let { walk(it) } }
        return out
    }
    private fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) { if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.parent }
        return false
    }
    private fun tapXY(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }
    /** pehle normal click, na ho to screen par us jagah gesture-tap */
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        if (click(n)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        tapXY(r.exactCenterX(), r.exactCenterY()); return true
    }
    private fun setText(n: AccessibilityNodeInfo, s: String) = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
        Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s) })
    private fun retry(t: Int, d: Long, f: () -> Boolean, done: (Boolean) -> Unit) {
        if (f()) done(true) else if (t <= 1) done(false) else h.postDelayed({ retry(t - 1, d, f, done) }, d)
    }
    private fun isSearch(n: AccessibilityNodeInfo): Boolean {
        if (n.isEditable) return false
        val s = (n.contentDescription ?: n.text)?.toString()?.lowercase() ?: return false
        return s.length < 40 && (s.contains("search") || s.contains("खोज") || s.contains("سرچ"))
    }

    // ---------- poori screen ka control ----------
    fun act(name: String) {
        when (name) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "shot" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            "scrolldown" -> scroll(true)
            "scrollup" -> scroll(false)
            "autodown" -> startAuto(true)
            "autoup" -> startAuto(false)
            "stopauto" -> stopAuto()
            "lock" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            "qs" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "swl" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.85f, m.heightPixels * 0.5f, m.widthPixels * 0.15f, m.heightPixels * 0.5f) }
            "swr" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.15f, m.heightPixels * 0.5f, m.widthPixels * 0.85f, m.heightPixels * 0.5f) }
            "swu" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.5f, m.heightPixels * 0.7f, m.widthPixels * 0.5f, m.heightPixels * 0.3f) }
            "swd" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.5f, m.heightPixels * 0.3f, m.widthPixels * 0.5f, m.heightPixels * 0.7f) }
            "doubletap" -> { val m = resources.displayMetrics; val x = m.widthPixels / 2f; val y = m.heightPixels / 2f; tapXY(x, y); h.postDelayed({ tapXY(x, y) }, 130) }
        }
    }
    private fun scroll(down: Boolean) {
        val ok = all().firstOrNull { it.isScrollable }?.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false
        if (!ok) {
            val m = resources.displayMetrics; val x = m.widthPixels / 2f; val a = m.heightPixels * 0.7f; val b = m.heightPixels * 0.3f
            if (down) swipe(x, a, x, b) else swipe(x, b, x, a)
        }
    }
    /** screen par jo text/description match kare use dabao */
    fun tapText(q: String, cb: (Boolean) -> Unit) {
        val alts = q.lowercase().split("|").filter { it.isNotBlank() }   // "a|b|c" = koi bhi ek
        retry(6, 500, {
            all().firstOrNull { nd -> !nd.isEditable && alts.any { a ->
                nd.text?.toString()?.lowercase()?.contains(a) == true || nd.contentDescription?.toString()?.lowercase()?.contains(a) == true } }?.let { tap(it) } ?: false
        }, cb)
    }

    // ---------- Quick Settings tiles (Wi-Fi, Bluetooth, Airplane, Data, Hotspot, DND, Rotate) ----------
    private fun tileState(n: AccessibilityNodeInfo): Boolean? {
        var c: AccessibilityNodeInfo? = n
        var i = 0
        while (c != null && i < 3) {
            if (c.isCheckable) return c.isChecked
            val sd = if (Build.VERSION.SDK_INT >= 30) c.stateDescription?.toString() ?: "" else ""
            val txt = (sd + " " + (c.contentDescription ?: "")).lowercase()
            if (Regex("\\boff\\b").containsMatchIn(txt)) return false
            if (Regex("\\bon\\b").containsMatchIn(txt)) return true
            c = c.parent; i++
        }
        return null
    }

    /** want: 1 = on, 0 = off, -1 = toggle */
    fun toggleTile(labels: String, want: Int, cb: (Boolean) -> Unit) {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        val alts = labels.lowercase().split("|").filter { it.isNotBlank() }
        h.postDelayed({
            retry(8, 500, {
                val nodes = all()
                var hit: AccessibilityNodeInfo? = null
                for (a in alts) {
                    hit = nodes.firstOrNull { nd -> !nd.isEditable && (nd.text?.toString()?.lowercase()?.contains(a) == true ||
                        nd.contentDescription?.toString()?.lowercase()?.contains(a) == true) }
                    if (hit != null) break
                }
                val nd = hit
                if (nd == null) false else {
                    val st = tileState(nd)
                    if (want >= 0 && st != null && st == (want == 1)) true else tap(nd)
                }
            }) { ok -> h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK); cb(ok) }, 500) }
        }, 900)
    }
    /** screen par n-wa item (upar se neeche, phir left se right). q="video" to jis node ke text/description mein "video" ho */
    fun tapNth(n: Int, q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        val dm = resources.displayMetrics
        retry(8, 600, {
            val found = mutableListOf<Pair<Rect, AccessibilityNodeInfo>>()
            for (nd in all()) {
                if (nd.isEditable) continue
                val r = Rect(); nd.getBoundsInScreen(r)
                if (r.isEmpty || r.bottom <= 0 || r.top >= dm.heightPixels || r.right <= 0 || r.left >= dm.widthPixels) continue
                if (r.height() < 120) continue
                val t = ((nd.text ?: "").toString() + " " + (nd.contentDescription ?: "")).lowercase()
                val ok = if (ql.isEmpty()) nd.isClickable else t.contains(ql)
                if (ok) found.add(Pair(r, nd))
            }
            val top = found.filter { a -> found.none { b -> b !== a && b.first != a.first && b.first.contains(a.first) } }
                .sortedWith(compareBy({ it.first.top }, { it.first.left }))
            top.getOrNull(n - 1)?.let { tap(it.second) } ?: false
        }, cb)
    }
    fun typeText(t: String, cb: (Boolean) -> Unit) {
        retry(6, 400, {
            val n = all()
            (n.firstOrNull { it.isFocused && it.isEditable } ?: n.firstOrNull { it.isEditable })?.let { setText(it, t) } ?: false
        }, cb)
    }

    // ---------- kisi bhi app ke andar search ----------
    private fun searchEditable(n: List<AccessibilityNodeInfo>) = n.firstOrNull { e ->
        e.isEditable && listOfNotNull(e.hintText, e.contentDescription, e.viewIdResourceName, e.text).any { it.toString().lowercase().contains("search") }
    }

    fun appSearch(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(6, 500, {
            val n = all()
            val ed = searchEditable(n)
            if (ed != null) { tap(ed); true } else n.firstOrNull { isSearch(it) }?.let { tap(it) } ?: false
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, {
                    val n = all()
                    (n.firstOrNull { it.isFocused && it.isEditable } ?: searchEditable(n) ?: n.firstOrNull { it.isEditable })?.let { setText(it, q) } ?: false
                }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({ submitSearch(ql, cb) }, 900)
                }
            }, 800)
        }
    }

    private fun submitSearch(ql: String, cb: (Boolean) -> Unit) {
        val n = all()
        val ed = n.firstOrNull { it.isFocused && it.isEditable } ?: n.firstOrNull { it.isEditable }
        var ok = false
        if (Build.VERSION.SDK_INT >= 30 && ed != null) ok = ed.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        if (!ok) ok = n.firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { tap(it) } ?: false
        cb(ok)
    }

    // ---------- WhatsApp ----------
    private fun isEntry(n: AccessibilityNodeInfo) = n.isEditable && n.viewIdResourceName?.endsWith("entry") == true

    /** chat khuli ho to pehle back karke chats list par aao (warna compose box mein search type ho jata tha) */
    private fun leaveChat(tries: Int, done: () -> Unit) {
        if (tries > 0 && all().any { isEntry(it) }) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            h.postDelayed({ leaveChat(tries - 1, done) }, 700)
        } else done()
    }

    fun waSearch(q: String, cb: (Boolean) -> Unit) = leaveChat(3) { waSearch2(q, cb) }

    private fun waSearch2(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(8, 500, {
            val n = all(); val s = n.firstOrNull { isSearch(it) }
            if (s != null) { tap(s); true } else n.any { it.isEditable && !isEntry(it) }
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, { all().firstOrNull { it.isEditable && !isEntry(it) }?.let { setText(it, q) } ?: false }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({
                        retry(10, 500, {
                            all().firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { tap(it) } ?: false
                        }, cb)
                    }, 1200)
                }
            }, 800)
        }
    }

    fun sendMsg(t: String, cb: (Boolean) -> Unit) {
        h.postDelayed({
            retry(10, 500, {
                val n = all()
                val e = n.firstOrNull { it.isEditable && it.viewIdResourceName?.endsWith("entry") == true } ?: n.lastOrNull { it.isEditable }
                e?.let { setText(it, t) } ?: false
            }) { ok ->
                if (!ok) cb(false) else h.postDelayed({
                    retry(8, 400, {
                        all().firstOrNull { val c = it.contentDescription?.toString()?.lowercase(); c == "send" || c == "भेजें" || c == "ارسال" }?.let { tap(it) } ?: false
                    }, cb)
                }, 600)
            }
        }, 800)
    }
}
