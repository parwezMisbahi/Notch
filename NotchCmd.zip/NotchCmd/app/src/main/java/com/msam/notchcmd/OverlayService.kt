package com.msam.notchcmd

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.*
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale

sealed class Step {
    data class Open(val q: String) : Step()
    data class Call(val q: String) : Step()
    data class Search(val q: String) : Step()
    data class Msg(val t: String) : Step()
    data class Act(val name: String) : Step()
    data class Tap(val q: String) : Step()
    data class Type(val t: String) : Step()
    data class Dev(val name: String) : Step()
    data class TapN(val n: Int, val q: String) : Step()
    data class Tile(val labels: String, val want: Int) : Step()
}

class OverlayService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val wm get() = getSystemService(WINDOW_SERVICE) as WindowManager
    private var trigger: View? = null
    private var panel: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var web: WebView? = null
    private var sr: SpeechRecognizer? = null       // panel ki voice
    private var wake: SpeechRecognizer? = null     // "MJ" sunne wali voice
    private var wakeOn = false
    private var typing = false
    private var silent = 0
    private var pendingCmd: String? = null
    private var lastPkg = ""
    private var gen = 0                      // "close" par purane callbacks band
    private val queue = ArrayDeque<Step>()   // baaki bache steps
    private var running = false
    private val idleClose = Runnable { if (panel != null && !typing) hidePanel() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i != null && i.hasExtra("wake")) {
            setWake(i.getBooleanExtra("wake", false))
            say(if (wakeOn) "MJ wake word ON — bolo: \"MJ\"" else "MJ wake word OFF")
        }
        if (i?.getBooleanExtra("show", false) == true) showPanel()
        if (wakeOn) startWake()   // permission baad mein mile to bhi mic-listening shuru
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("notch", "NotchCmd", NotificationManager.IMPORTANCE_MIN))
        wakeOn = getSharedPreferences("n", MODE_PRIVATE).getBoolean("wake", true)
        val n = buildNotif()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == 0) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean { showPanel(); return true }
        })
        val d = resources.displayMetrics.density
        val v = View(this).apply { setBackgroundColor(0x01000000); setOnTouchListener { _, e -> gd.onTouchEvent(e) } }
        val lp = WindowManager.LayoutParams((140 * d).toInt(), (56 * d).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp); trigger = v

        // screen off hote hi mic band, screen on hote hi (agar MJ ON hai) wapas
        val f = android.content.IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) }
        registerReceiver(screenRx, f)
        initTts()
        if (wakeOn) startWake()
    }

    private val screenRx = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context?, i: Intent?) {
            if (i?.action == Intent.ACTION_SCREEN_OFF) stopWake()
            else if (i?.action == Intent.ACTION_SCREEN_ON) startWake()
        }
    }

    private fun buildNotif(): Notification {
        val pi = PendingIntent.getForegroundService(this, 7, Intent(this, OverlayService::class.java).putExtra("wake", !wakeOn),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "notch").setContentTitle("NotchCmd chal raha hai")
            .setContentText(if (wakeOn) "MJ sun raha hai (screen on par). Notch par double-tap bhi chalega" else "Mic OFF. Notch par double-tap karo ya neeche MJ ON dabao")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(0, if (wakeOn) "MJ OFF (mic band)" else "MJ ON", pi).build()).build()
    }

    /** MJ listening ON/OFF (save bhi hota hai). OFF = mic poori tarah band. */
    private fun setWake(on: Boolean) {
        wakeOn = on
        getSharedPreferences("n", MODE_PRIVATE).edit().putBoolean("wake", on).apply()
        if (on) startWake() else stopWake()
        getSystemService(NotificationManager::class.java).notify(1, buildNotif())
    }

    override fun onDestroy() { wakeOn = false; stopWake(); try { unregisterReceiver(screenRx) } catch (_: Exception) {}; tts?.shutdown(); hidePanel(); h.removeCallbacksAndMessages(null); trigger?.let { wm.removeView(it) }; super.onDestroy() }

    // ---------- floating panel ----------
    // Panel NOT_FOCUSABLE rehta hai taake neeche wali app focus mein rahe (live control).
    // Sirf jab tum input box par tap karo tab focusable hota hai (keyboard ke liye).
    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun showPanel(cmd: String? = null) {
        if (panel != null) { if (cmd != null) submit(cmd, true); return }
        stopWake()
        pendingCmd = cmd; silent = 0; typing = false
        val d = resources.displayMetrics.density
        val w = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, u: String?) {
                    val c = pendingCmd; pendingCmd = null
                    if (c != null) { js("gotText(${JSONObject.quote(c)})"); submit(c, true) } else startListen()   // mic apne aap on
                }
            }
            loadUrl("file:///android_asset/command.html")
        }
        val f = FrameLayout(this)
        f.addView(w)
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, (180 * d).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(f, lp); panel = f; web = w; panelLp = lp
        armIdle()
    }

    private fun hidePanel(resumeWake: Boolean = true) {
        h.removeCallbacks(idleClose)
        gen++; queue.clear(); running = false
        stopListen(); typing = false
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        web?.destroy(); web = null; panel = null; panelLp = null
        if (resumeWake) h.postDelayed({ startWake() }, 600)   // panel band, ab wapas "MJ" sunna
    }

    private fun armIdle() { h.removeCallbacks(idleClose); h.postDelayed(idleClose, 20000) }

    private fun setTyping(on: Boolean) {
        typing = on
        val lp = panelLp ?: return; val p = panel ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try { wm.updateViewLayout(p, lp) } catch (_: Exception) {}
        if (on) {
            stopListen(); h.removeCallbacks(idleClose)
            web?.requestFocus()
            js("setState('typing')")
            h.postDelayed({ js("focusInput()") }, 120)
        } else armIdle()
    }

    private fun js(c: String) { h.post { web?.evaluateJavascript(c, null) } }
    private fun say(m: String) { h.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }; js("setState('busy',${JSONObject.quote(m)})") }

    inner class Bridge {
        @JavascriptInterface fun listen() { h.post { if (typing) setTyping(false); silent = 0; startListen() } }
        @JavascriptInterface fun startTyping() { h.post { if (!typing) setTyping(true) } }
        @JavascriptInterface fun close() { h.post { hidePanel() } }
        @JavascriptInterface fun run(c: String) { h.post { submit(c, false) } }
    }

    // ---------- voice (English letters: en-IN) ----------
    private fun speechIntent(partial: Boolean) = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, partial)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
    }

    /** jo result English letters mein ho wahi lo, warna pehla (parse Hindi ko Roman bana lega) */
    private fun pick(b: Bundle?): String {
        val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return ""
        return l.firstOrNull { s -> s.isNotBlank() && s.none { isDev(it) } } ?: l.firstOrNull() ?: ""
    }

    private fun stopListen() { sr?.destroy(); sr = null }

    private fun startListen() {
        if (panel == null || typing || speaking) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != 0) { say("App mein mic permission do"); return }
        armIdle()
        stopListen()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { js(if (running) "setMic(true)" else "setState('listening')") }
            override fun onResults(b: Bundle?) {
                if (sr !== r) return
                val t = pick(b)
                if (t.isBlank()) { retryListen(); return }
                silent = 0
                js("gotText(${JSONObject.quote(t)})")
                h.post { submit(t, true) }
            }
            override fun onPartialResults(p: Bundle?) {
                if (sr !== r) return
                val t = pick(p); if (t.isNotBlank()) js("gotText(${JSONObject.quote(t)})")
            }
            override fun onError(e: Int) {
                if (sr !== r) return
                when (e) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retryListen()
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> h.postDelayed({ startListen() }, 600)
                    else -> js("setState('idle','Voice error $e. Mic dabao ya likho')")
                }
            }
            override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(speechIntent(true))
    }

    private fun retryListen() {
        if (!running) silent++
        if (silent >= 3) { silent = 0; js("setState('idle','Mic band. 🎤 dabao ya likho')"); return }
        h.postDelayed({ startListen() }, 300)
    }

    // ---------- "MJ" wake word (hands-free) ----------
    // MJ ki har spelling: M.J., M-J, Em Jay, Emjay, M Jay, Am Jay, AMJ, A.J., MJX, MJee ... (normalize karke match)
    private val wakeSet = setOf("mj", "emj", "emjay", "mjay", "amj", "amjay", "aj", "mjx", "mjayx", "emjayx", "mjee", "emjx",
        "एमजे", "एमजय", "अमजय", "ऐमजे", "एमजे", "अमजे")
    private val lead = setOf("hey", "ok", "okay", "hi", "hello", "oye", "arey")
    private val wordRe = Regex("[\\p{L}\\p{M}\\p{N}\\u02B2]+")

    /** wake word bilkul shuru mein ho to uske baad ka text ("" ho sakta hai), warna null */
    private fun findWake(text: String): String? {
        val ms = wordRe.findAll(text).toList()
        val tk = ms.map { it.value.lowercase(Locale.ROOT).replace('\u02B2', 'j') }
        val st = if (tk.isNotEmpty() && tk[0] in lead) 1 else 0
        for (len in 1..3) {
            if (st + len > tk.size) break
            if (tk.subList(st, st + len).joinToString("") in wakeSet) {
                val end = ms[st + len - 1].range.last + 1
                return text.substring(end).trimStart(' ', ',', '.', '-', ':', ';', '!', '?', '_', '•', '×', '|')
            }
        }
        return null
    }

    private fun startWake() {
        if (!wakeOn || panel != null || wake != null) return
        if (!(getSystemService(POWER_SERVICE) as PowerManager).isInteractive) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != 0) return
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        wake = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                if (wake !== r) return
                val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                val rest = l.firstNotNullOfOrNull { findWake(it) }
                if (rest == null) { restartWake(300); return }
                val rl = rest.lowercase(Locale.ROOT)
                if (rl in setOf("ruk", "ruko", "रुको", "रुक")) { h.post { if (NotchA11y.inst?.stopAuto() == true) say("Scroll band") }; restartWake(300); return }
                if (rl in setOf("close", "klos", "stop", "band", "bas", "cancel")) {
                    if (NotchA11y.inst?.stopAuto() == true) { h.post { say("Scroll band") }; restartWake(300); return }
                    h.post { setWake(false); say("MJ OFF, mic band") }; return
                }
                stopWake(); buzz()
                showPanel(if (rest.isBlank()) null else rest)
            }
            override fun onError(e: Int) {
                if (wake !== r) return
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { h.post { stopWake() }; return }
                restartWake(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
            }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(speechIntent(false))
    }

    /** MJ suna gaya: halka sa vibrate (assistant jaisa confirmation) */
    @Suppress("DEPRECATION")
    private fun buzz() { try { (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {} }

    private fun stopWake() { wake?.destroy(); wake = null }
    private fun restartWake(ms: Long) { h.post { stopWake() }; h.postDelayed({ startWake() }, ms) }

    // ---------- Devanagari -> Roman (agar recognizer Hindi script de de) ----------
    private fun isDev(c: Char) = c in '\u0900'..'\u097F'
    private val cons = mapOf('क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n", 'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n", 'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m", 'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh",
        'स' to "s", 'ह' to "h", '\u0958' to "q", '\u0959' to "kh", '\u095A' to "g", '\u095B' to "z", '\u095C' to "d", '\u095D' to "rh", '\u095E' to "f", '\u095F' to "y")
    private val vow = mapOf('अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo", 'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o")
    private val mat = mapOf('ा' to "a", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au", 'ॉ' to "o", 'ॅ' to "e")

    private fun roman(s: String): String {
        if (s.none { isDev(it) }) return s
        val sb = StringBuilder(); var pend = false
        for (c in s) {
            when {
                cons.containsKey(c) -> { if (pend) sb.append('a'); sb.append(cons[c]); pend = true }
                vow.containsKey(c) -> { if (pend) sb.append('a'); pend = false; sb.append(vow[c]) }
                mat.containsKey(c) -> { pend = false; sb.append(mat[c]) }
                c == '\u094D' -> pend = false
                c == '\u093C' -> { if (sb.endsWith("j")) { sb.setLength(sb.length - 1); sb.append('z') } }
                c == 'ं' || c == 'ँ' -> { if (pend) sb.append('a'); pend = false; sb.append('n') }
                c == 'ः' -> { if (pend) sb.append('a'); pend = false; sb.append('h') }
                c in '\u0966'..'\u096F' -> { pend = false; sb.append(c - '\u0966') }
                c == '।' -> { pend = false }
                else -> { pend = false; sb.append(c) }
            }
        }
        return sb.toString()
    }

    // ---------- command ko parts mein todna ----------
    private val seps = Regex("\\s*[,،]\\s*|\\s+(?:aur|phir|fir|then|and|और|फिर)\\s+")
    private val cut = setOf("karo", "kar", "kholo", "khol", "kolo", "khulo", "chalao", "lagao", "dabao", "करो", "खोलो", "चलाओ", "दबाओ")
    private val fill = setOf("open", "kholo", "khol", "kolo", "khulo", "karo", "kar", "do", "dijiye", "chalao", "chala", "ko", "app", "start", "launch", "ki", "ka", "ke", "par", "pe", "mein", "me",
        "please", "plz", "khud", "khudse", "खोलो", "खोल", "करो", "दो", "चलाओ", "को", "ऐप", "की", "का", "पर", "में")
    private val msgKw = setOf("message", "msg", "maisej", "मैसेज", "likho", "bhejo", "bejo", "bhej", "send", "भेजो", "लिखो")
    private val callKw = setOf("call", "kol", "kaul", "कॉल", "कोल")
    private val searchKw = setOf("search", "sarch", "surch", "khojo", "dhundo", "सर्च", "खोजो", "ढूंढो")
    private val tapKw = setOf("tap", "click", "klik", "dabao", "press", "दबाओ", "क्लिक")
    private val actKw = mapOf("back" to "back", "wapas" to "back", "vapas" to "back", "peeche" to "back", "peechhe" to "back", "पीछे" to "back", "वापस" to "back",
        "home" to "home", "hom" to "home", "होम" to "home", "recents" to "recents", "recent" to "recents", "notification" to "notif", "notifications" to "notif",
        "screenshot" to "shot", "close" to "close", "klos" to "close", "stop" to "close", "cancel" to "close", "bas" to "close", "band" to "close",
        "lock" to "lock", "lok" to "lock", "लॉक" to "lock", "quick" to "qs", "panel" to "qs",
        "ruk" to "stopauto", "ruko" to "stopauto", "रुको" to "stopauto", "रुक" to "stopauto")
    private val alias = mapOf("यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "कैमरा" to "camera",
        "क्रोम" to "chrome", "सेटिंग" to "settings", "सेटिंग्स" to "settings", "गैलरी" to "gallery", "इंस्टाग्राम" to "instagram",
        "wa" to "whatsapp", "yt" to "youtube", "insta" to "instagram", "fb" to "facebook",
        "yootyoob" to "youtube", "yutyub" to "youtube", "yutub" to "youtube", "yootub" to "youtube", "vhatsaep" to "whatsapp", "vhatsap" to "whatsapp",
        "watsapp" to "whatsapp", "whatsap" to "whatsapp", "krom" to "chrome",
        "skrol" to "scroll", "scrol" to "scroll", "स्क्रॉल" to "scroll", "स्क्रोल" to "scroll", "swaip" to "swipe", "स्वाइप" to "swipe")
    private val volKw = setOf("volume", "vol", "sound", "sond", "saund", "awaaz", "aawaz", "avaaz", "awaz", "आवाज", "वॉल्यूम", "साउंड")
    private val brKw = setOf("brightness", "brightnes", "roshni", "roshani", "ब्राइटनेस", "रोशनी")
    private val torchKw = setOf("torch", "tarch", "flashlight", "flash", "light", "lite", "टॉर्च", "फ्लैश", "लाइट")
    private val upKw = setOf("badhao", "badha", "badhaao", "up", "increase", "zyada", "jyada", "tez", "बढ़ाओ", "बढ़ा", "ज्यादा")
    private val downKw = setOf("ghatao", "ghata", "kam", "down", "decrease", "low", "dheema", "घटाओ", "कम")
    private val maxKw = setOf("max", "maximum", "full", "poori", "pura")
    private val minKw = setOf("min", "minimum", "lowest")
    private val muteKw = setOf("mute", "silent", "chup", "म्यूट")
    private val offKw = setOf("off", "band", "bujhao", "bujha", "stop", "disable", "बंद", "ऑफ", "बुझाओ")
    private val openWords = setOf("open", "kholo", "khol", "kolo", "khulo", "खोलो", "खोल")
    private val postpos = setOf("par", "pe", "mein", "me", "में", "पर")
    private val dblKw = setOf("double", "dubal", "dabal", "डबल")
    private val autoKw = setOf("raho", "rehna", "karte", "auto", "lagatar", "continuous", "रहो", "करते")
    private val ordMap = mapOf("first" to 1, "1st" to 1, "pehla" to 1, "pehli" to 1, "pahla" to 1, "pahli" to 1, "पहला" to 1, "पहली" to 1,
        "second" to 2, "2nd" to 2, "dusra" to 2, "doosra" to 2, "dusri" to 2, "doosri" to 2, "दूसरा" to 2, "दूसरी" to 2,
        "third" to 3, "3rd" to 3, "teesra" to 3, "tisra" to 3, "teesri" to 3, "तीसरा" to 3, "तीसरी" to 3,
        "fourth" to 4, "4th" to 4, "chautha" to 4, "chauthi" to 4, "चौथा" to 4,
        "fifth" to 5, "5th" to 5, "panchva" to 5, "paanchva" to 5, "पांचवा" to 5)
    private val onKw = setOf("on", "chalu", "enable", "jalao", "chala", "chalao", "start", "ऑन", "चालू", "जलाओ")
    private val wifiKw = setOf("wifi", "wi-fi", "waifai", "vaifai", "wai-fai", "वाईफाई", "वाई-फाई", "वाईफ़ाई")
    private val btKw = setOf("bluetooth", "blutooth", "ब्लूटूथ")
    private val airKw = setOf("airplane", "aeroplane", "flight", "एयरप्लेन")
    private val hotKw = setOf("hotspot", "hotspat", "हॉटस्पॉट")
    private val dndKw = setOf("dnd", "disturb")
    private val rotKw = setOf("rotate", "rotation", "autorotate", "auto-rotate", "रोटेट")
    private val dataKw = setOf("data", "internet", "net", "डेटा", "इंटरनेट")
    private val spkKw = setOf("speaker", "spiker", "loudspeaker", "स्पीकर")
    private val endW = setOf("kaato", "kato", "kaat", "reject", "disconnect", "cut", "decline", "काटो", "कट")
    private val ansW = setOf("uthao", "utha", "receive", "answer", "pick", "उठाओ", "रिसीव")
    private val phoneKw = setOf("phone", "fone", "फोन")
    private val contactKw = setOf("contact", "kontact", "कॉन्टैक्ट")
    private val photoKw = setOf("photo", "foto", "picture", "pic", "selfie", "फोटो", "सेल्फी")
    private val shootKw = setOf("kheencho", "kheench", "khicho", "kheecho", "lo", "le", "click", "capture", "खींचो", "लो")
    private val mNext = setOf("next", "agla", "agle", "badlo", "अगला")
    private val mPrev = setOf("previous", "prev", "pichla", "pichle", "पिछला")
    private val mPause = setOf("pause", "paus", "पॉज")
    private val mPlay = setOf("play", "resume", "प्ले")
    private val mSong = setOf("gaana", "gana", "gaane", "song", "songs", "music", "media", "गाना", "गाने", "म्यूजिक")
    private val medSet = mNext + mPrev + mPause + mPlay + mSong
    private val batKw = setOf("battery", "batri", "bettery", "betri", "बैटरी")
    private val dateKw = setOf("date", "tarikh", "taareekh", "tareekh", "तारीख")
    private val timeKw = setOf("time", "samay", "waqt", "baje", "टाइम", "समय", "वक्त")
    private val timerKw = setOf("timer", "taimar", "टाइमर")
    private val alarmKw = setOf("alarm", "alaram", "अलार्म")
    private val remKw = setOf("reminder", "remind", "yaad", "yad", "रिमाइंडर", "याद")
    private val cancelKw = setOf("cancel", "delete", "hatao", "hata", "हटाओ")
    private val clockWords = setOf("baje", "bje", "am", "pm", "oclock", "o'clock", "बजे", "subah", "morning", "sawere", "dopahar", "afternoon",
        "shaam", "sham", "evening", "raat", "night", "saade", "saadhe", "sawa", "paune", "kal", "aaj", "tomorrow", "at")
    private val minUnit = setOf("minute", "minutes", "min", "mins", "minat", "mint", "मिनट")
    private val hrUnit = setOf("hour", "hours", "hr", "hrs", "ghanta", "ghante", "घंटा", "घंटे")
    private val secUnit = setOf("second", "seconds", "sec", "secs", "sekand", "सेकंड")
    private val labelJunk = setOf("set", "laga", "lagao", "lagana", "baad", "after", "in", "for", "liye", "hai", "tak", "a", "the", "to",
        "yaad", "dilana", "dilao", "daalo", "dikhao", "batao", "show", "find", "dhundo", "dekho", "kya")
    private val numWords = mapOf("ek" to 1, "one" to 1, "do" to 2, "two" to 2, "teen" to 3, "three" to 3, "char" to 4, "four" to 4,
        "paanch" to 5, "panch" to 5, "five" to 5, "chhe" to 6, "che" to 6, "chah" to 6, "six" to 6, "saat" to 7, "seven" to 7,
        "aath" to 8, "eight" to 8, "nau" to 9, "nine" to 9, "das" to 10, "ten" to 10, "gyarah" to 11, "barah" to 12, "terah" to 13,
        "chaudah" to 14, "pandrah" to 15, "fifteen" to 15, "solah" to 16, "satrah" to 17, "atharah" to 18, "unnis" to 19, "bees" to 20,
        "twenty" to 20, "pachees" to 25, "tees" to 30, "thirty" to 30, "chalis" to 40, "forty" to 40, "paintalis" to 45, "pachaas" to 50,
        "fifty" to 50, "saath" to 60, "sixty" to 60)
    private val known: Set<String> by lazy { cut + fill + msgKw + callKw + searchKw + tapKw + actKw.keys + alias.keys +
        volKw + brKw + torchKw + upKw + downKw + maxKw + minKw + muteKw + offKw + openWords + postpos + dblKw + autoKw + ordMap.keys +
        onKw + wifiKw + btKw + airKw + hotKw + dndKw + rotKw + dataKw + spkKw + endW + ansW + phoneKw + contactKw + photoKw + shootKw +
        medSet + batKw + dateKw + timeKw + timerKw + alarmKw + remKw + cancelKw + clockWords + minUnit + hrUnit + secUnit + labelJunk + numWords.keys }

    private fun numOf(t: String): Int? = t.toIntOrNull() ?: numWords[t]

    /** "5 minute", "2 ghante", "aadha ghanta", "dedh ghanta" -> seconds */
    private fun parseDur(tk: List<String>): Int? {
        var total = 0.0; var found = false
        for (i in tk.indices) {
            val t = tk[i]
            val u = when {
                t in minUnit -> 60
                t in hrUnit -> 3600
                t in secUnit -> 1
                else -> 0
            }
            if (u == 0) continue
            val prev = if (i > 0) tk[i - 1] else ""
            val n: Double? = when (prev) {
                "aadha", "adha", "half", "आधा" -> 0.5
                "dedh", "derh", "डेढ़" -> 1.5
                "dhai", "dhaai", "ढाई" -> 2.5
                else -> numOf(prev)?.toDouble()
            }
            if (n != null) { total += n * u; found = true }
        }
        return if (found && total > 0) total.toInt() else null
    }

    /** "6 baje", "subah 6:30", "shaam 5 baje", "saade 6 baje", "7 pm" -> (hour24, minute) */
    private fun parseClock(tk: List<String>): Pair<Int, Int>? {
        var hr = -1; var mn = 0; var suffix = ""
        for (i in tk.indices) {
            val t = tk[i]
            val m1 = Regex("^(\\d{1,2})[:.](\\d{2})(am|pm)?$").find(t)
            val m2 = Regex("^(\\d{1,2})(am|pm)$").find(t)
            if (m1 != null) { hr = m1.groupValues[1].toInt(); mn = m1.groupValues[2].toInt(); suffix = m1.groupValues[3]; break }
            if (m2 != null) { hr = m2.groupValues[1].toInt(); suffix = m2.groupValues[2]; break }
            if (i > 0 && t in setOf("baje", "bje", "बजे", "oclock", "o'clock", "am", "pm")) {
                val n = numOf(tk[i - 1])
                if (n != null) {
                    hr = n
                    if (i >= 2) {
                        when (tk[i - 2]) {
                            "saade", "saadhe" -> mn = 30
                            "sawa" -> mn = 15
                            "paune" -> { hr = if (n == 1) 12 else n - 1; mn = 45 }
                            else -> {}
                        }
                    }
                    if (t == "am" || t == "pm") suffix = t
                    break
                }
            }
        }
        if (hr < 0 || hr > 24 || mn > 59) return null
        val w = tk.toSet()
        val per = when {
            suffix == "am" || "am" in w || "subah" in w || "morning" in w || "sawere" in w -> "am"
            suffix == "pm" || "pm" in w || "shaam" in w || "sham" in w || "evening" in w -> "pm"
            "dopahar" in w || "afternoon" in w -> "noon"
            "raat" in w || "night" in w -> "night"
            else -> ""
        }
        val h24: Int = if (hr >= 13) hr else when (per) {
            "am" -> if (hr == 12) 0 else hr
            "pm" -> if (hr < 12) hr + 12 else hr
            "noon" -> if (hr in 1..6) hr + 12 else hr
            "night" -> if (hr in 6..11) hr + 12 else if (hr == 12) 0 else hr
            else -> {
                val now = java.util.Calendar.getInstance()
                val nowM = now.get(java.util.Calendar.HOUR_OF_DAY) * 60 + now.get(java.util.Calendar.MINUTE)
                val c1 = hr % 12; val c2 = hr % 12 + 12
                if (c1 * 60 + mn > nowM) c1 else if (c2 * 60 + mn > nowM) c2 else c1
            }
        }
        return Pair(h24 % 24, mn)
    }

    private fun swipeDir(p: List<String>): String? = when {
        p.any { it in setOf("left", "baye", "bayen", "bayein", "baayen", "baen", "बाएं", "लेफ्ट") } -> "swl"
        p.any { it in setOf("right", "daye", "dayen", "dayein", "daayen", "daen", "दाएं", "राइट") } -> "swr"
        p.any { it in setOf("up", "upar", "ऊपर") } -> "swu"
        p.any { it in setOf("down", "neeche", "niche", "नीचे") } -> "swd"
        else -> null
    }

    /** alias -> Roman; Hindi script ka anjaan lafz (naam, query, message) Roman ban jata hai */
    private fun norm(t: String): String = alias[t] ?: if (t.any { isDev(it) } && t !in known) roman(t) else t

    private fun parse(raw: String): List<Step> {
        val out = mutableListOf<Step>()
        for (chunk in raw.lowercase(Locale.ROOT).trim().split(seps)) {
            val tokens = chunk.split(Regex("\\s+")).filter { it.isNotBlank() }.map { norm(it) }
            // timer / alarm / reminder: poori line ek saath (kyunki "karo" se line toot jati hai)
            if (tokens.any { it in timerKw || it in alarmKw || it in remKw }) {
                val hasAlarm = tokens.any { it in alarmKw }
                val isCancel = tokens.any { it in offKw || it in cancelKw } && tokens.none { it in remKw }
                val dur = parseDur(tokens)
                val clk = if (dur == null) parseClock(tokens) else null
                val label = tokens.filter { t -> t !in fill && t !in labelJunk && t !in timerKw && t !in alarmKw && t !in remKw &&
                    t !in clockWords && t !in minUnit && t !in hrUnit && t !in secUnit && !t.first().isDigit() && numOf(t) == null }.joinToString(" ")
                when {
                    isCancel -> out.add(Step.Dev(if (hasAlarm) "showalarms" else "showtimers"))
                    dur != null -> out.add(Step.Dev("timer|$dur|$label"))
                    clk != null -> out.add(Step.Dev("alarm|${clk.first}|${clk.second}|$label"))
                    else -> out.add(Step.Dev("needtime"))
                }
                continue
            }
            // "search arijit singh" / "call ali" / "tap play video" (verb pehle) bhi chalega
            val f0 = tokens.firstOrNull()
            if (f0 != null && tokens.size > 1 && (f0 in searchKw || (f0 in callKw && tokens.none { it in endW || it in ansW }) || (f0 in tapKw && tokens.none { it in ordMap }))) {
                val q = tokens.drop(1).filter { it !in fill }.joinToString(" ")
                out.add(if (f0 in searchKw) Step.Search(q) else if (f0 in callKw) Step.Call(q) else Step.Tap(q))
                continue
            }
            val parts = mutableListOf<List<String>>(); var acc = mutableListOf<String>()
            for ((i, t) in tokens.withIndex()) {
                acc.add(t)
                if (t in cut && i < tokens.size - 1 && acc.none { it in msgKw }) { parts.add(acc); acc = mutableListOf() }
            }
            if (acc.isNotEmpty()) parts.add(acc)
            for (pp in parts) {
                var p = pp
                // "yt par first video par click karo" -> pehle app kholo, phir baaki
                val oi0 = p.indexOfFirst { it in ordMap }
                if (oi0 > 1) {
                    val k = p.indexOfFirst { it in postpos }
                    if (k in 1 until oi0) {
                        val pre = p.take(k).filter { it !in fill }.joinToString(" ")
                        if (pre.isNotEmpty() && findApp(pre) != null) { out.add(Step.Open(pre)); p = p.drop(k + 1) }
                    }
                }
                val mi = p.indexOfFirst { it in msgKw }; val ci = p.indexOfFirst { it in callKw }
                val si = p.indexOfFirst { it in searchKw }; val ti = p.indexOfFirst { it in tapKw }
                val ty = p.indexOf("type"); val sc = p.indexOf("scroll"); val ai = p.indexOfFirst { it in actKw }
                val sw = p.indexOf("swipe")
                val oi = p.indexOfFirst { it in ordMap }
                val openish = p.any { it in openWords }
                val hasVol = p.any { it in volKw }; val hasBr = p.any { it in brKw }; val hasTorch = p.any { it in torchKw }
                val upW = p.any { it in upKw }; val downW = p.any { it in downKw }; val offW = p.any { it in offKw }
                val ordOk = oi >= 0 && (ti >= 0 || (oi < p.size - 1 && p[oi + 1] !in fill && p[oi + 1] !in cut))
                val devName: String? = if (openish) null else when {
                    p.any { it in muteKw } && (hasVol || p.size <= 2) -> "mute"
                    hasVol -> when {
                        p.any { it in maxKw } -> "volmax"
                        downW -> "voldown"
                        upW -> "volup"
                        else -> "volshow"
                    }
                    hasBr -> when {
                        p.any { it in minKw } -> "brmin"
                        p.any { it in maxKw } -> "brmax"
                        downW -> "brdown"
                        else -> "brup"
                    }
                    hasTorch && (upW || downW) && p.any { it == "light" || it == "lite" || it == "लाइट" } -> if (downW) "brdown" else "brup"
                    hasTorch -> if (offW) "torchoff" else "torchon"
                    else -> null
                }
                val onW = p.any { it in onKw }
                val isPhone = ci >= 0 || p.any { it in phoneKw }
                val callDev: String? = when {
                    isPhone && p.any { it in endW } -> "endcall"
                    isPhone && p.any { it in ansW } -> "answercall"
                    else -> null
                }
                val spk = p.any { it in spkKw }
                val tileLabels: String? = if (openish) null else when {
                    p.any { it in wifiKw } -> "wi-fi|wifi|wlan"
                    p.any { it in btKw } -> "bluetooth"
                    p.any { it in airKw } -> "airplane|aeroplane|flight mode"
                    p.any { it in hotKw } -> "hotspot|tethering"
                    p.any { it in dndKw } -> "do not disturb|dnd"
                    p.any { it in rotKw } -> "auto-rotate|auto rotate|rotation|rotate"
                    p.any { it in dataKw } && (onW || offW) -> "mobile data|internet|data"
                    else -> null
                }
                val tileWant = if (onW) 1 else if (offW) 0 else -1
                val contactIdx = p.indexOfFirst { it in contactKw }
                val contactName = if (openish || contactIdx < 0) "" else
                    p.filterIndexed { i, _ -> i != contactIdx }.filter { it !in fill && it !in labelJunk }.joinToString(" ")
                val photoName: String? = if (openish) null else when {
                    p.any { it == "selfie" || it == "सेल्फी" } -> "selfie"
                    p.any { it in photoKw } && p.any { it in shootKw } -> "photo"
                    else -> null
                }
                val medWords = p.filter { it in medSet }
                val medOnly = medWords.isNotEmpty() && p.all { it in medSet || it in fill || it in offKw || it in onKw }
                val mediaName: String? = if (!medOnly || openish) null else when {
                    p.any { it in mNext } -> "mnext"
                    p.any { it in mPrev } -> "mprev"
                    p.any { it in mPause } || (p.any { it in mSong } && offW) -> "mpause"
                    else -> "mplay"
                }
                val infoName: String? = if (openish) null else when {
                    p.any { it in batKw } -> "ibat"
                    p.any { it in dateKw } -> "idate"
                    p.any { it in timeKw } && p.none { numOf(it) != null } -> "itime"
                    else -> null
                }
                fun rest(skip: Int) = p.filterIndexed { i, _ -> i != skip }.filter { it !in fill }.joinToString(" ")
                if (mi >= 0) {
                    val before = p.take(mi).filter { it !in fill }.joinToString(" ")
                    val after = p.drop(mi + 1).dropWhile { it in fill }.joinToString(" ")
                    if (after.isNotEmpty()) { if (before.isNotEmpty()) out.add(Step.Search(before)); out.add(Step.Msg(after)) }
                    else if (before.isNotEmpty()) out.add(Step.Msg(before))   // "hi bejo"
                } else if (callDev != null) out.add(Step.Dev(callDev))
                else if (spk) out.add(Step.Tap("speaker|loudspeaker"))
                else if (ci >= 0) out.add(Step.Call(rest(ci)))
                else if (si >= 0) out.add(Step.Search(rest(si)))
                else if (tileLabels != null) out.add(Step.Tile(tileLabels, tileWant))
                else if (devName != null) out.add(Step.Dev(devName))
                else if (contactName.isNotEmpty()) out.add(Step.Dev("contact|$contactName"))
                else if (photoName != null) out.add(Step.Dev(photoName))
                else if (mediaName != null) out.add(Step.Dev(mediaName))
                else if (infoName != null) out.add(Step.Dev(infoName))
                else if (p.any { it in dblKw }) out.add(Step.Act("doubletap"))
                else if (ordOk && ty < 0) out.add(Step.TapN(ordMap[p[oi]]!!,
                    p.filterIndexed { i, _ -> i != oi }.filter { it !in fill && it !in tapKw && it !in cut }.joinToString(" ")))
                else if (ti >= 0) out.add(Step.Tap(rest(ti)))
                else if (ty >= 0) out.add(Step.Type(p.drop(ty + 1).joinToString(" ")))
                else if (sw >= 0 && swipeDir(p) != null) out.add(Step.Act(swipeDir(p)!!))
                else if (sc >= 0) {
                    val upw = p.any { it in setOf("up", "upar", "ऊपर") }; val au = p.any { it in autoKw }
                    out.add(Step.Act(if (au) (if (upw) "autoup" else "autodown") else (if (upw) "scrollup" else "scrolldown")))
                }
                else if (ai >= 0) out.add(Step.Act(actKw[p[ai]]!!))
                else out.add(Step.Open(p.filter { it !in fill }.joinToString(" ")))
            }
        }
        return out.filter { s -> when (s) {
            is Step.Open -> s.q.isNotEmpty(); is Step.Call -> s.q.isNotEmpty(); is Step.Search -> s.q.isNotEmpty()
            is Step.Tap -> s.q.isNotEmpty(); is Step.Type -> s.t.isNotEmpty(); is Step.Msg -> s.t.isNotEmpty(); is Step.Act -> true
            is Step.Dev -> true; is Step.TapN -> true; is Step.Tile -> true } }
    }

    // ---------- commands ki line (queue): ek khatam hote hi agla shuru ----------
    /** voice=true: mic chalta rehta hai, bolte jao, commands line mein lagte jate hain.
     *  voice=false (typed): poora hone tak mic off, phir wapas on. */
    private fun submit(raw0: String, voice: Boolean) {
        val wasTyping = typing
        if (wasTyping) setTyping(false)
        h.removeCallbacks(idleClose)
        val raw = findWake(raw0) ?: raw0            // "mj youtube kholo" -> "youtube kholo"
        val steps = parse(raw)
        if (steps.isEmpty()) { say("Command samajh nahi aayi"); if (voice) h.postDelayed({ startListen() }, 300) else afterRun(); return }
        if (steps.any { it is Step.Act && it.name == "close" } && NotchA11y.inst?.stopAuto() == true) {
            say("Scroll band kar diya"); armIdle()
            if (voice) h.postDelayed({ if (panel != null && !typing) startListen() }, 250) else afterRun()
            return
        }
        if (steps.any { it is Step.Act && it.name == "close" }) { setWake(false); say("Band kar diya, mic OFF"); hidePanel(false); return }
        queue.addAll(steps)
        if (voice) h.postDelayed({ if (panel != null && !typing) startListen() }, 250) else stopListen()
        if (!running) {
            running = true
            val g = gen
            h.postDelayed({ if (g == gen) pump() }, if (wasTyping) 500L else 0L)
        }
    }

    /** queue khatam / fail -> panel khula ho to mic dobara sunne lage (agar pehle se sun raha ho to kuch nahi) */
    private fun afterRun() {
        if (panel == null) return
        armIdle()
        if (sr == null) h.postDelayed({ if (panel != null && !typing && sr == null && !running) startListen() }, 900)
    }

    private fun pump() {
        val st = queue.removeFirstOrNull()
        if (st == null) { running = false; afterRun(); return }
        running = true
        val g = gen
        exec(st) { ok, wait ->
            if (g == gen) {
                if (ok) h.postDelayed({ if (g == gen) pump() }, wait)
                else { queue.clear(); running = false; afterRun() }
            }
        }
    }

    private fun exec(st: Step, done: (Boolean, Long) -> Unit) {
        val a = NotchA11y.inst
        val need = { say("Accessibility service on karo"); done(false, 0L) }
        val fail: (String) -> Unit = { m -> say(m); done(false, 0L) }
        say(when (st) {
            is Step.Open -> "open ${st.q}"; is Step.Call -> "call ${st.q}"; is Step.Search -> "search ${st.q}"; is Step.Msg -> "message ${st.t}"
            is Step.Act -> st.name; is Step.Tap -> "tap ${st.q}"; is Step.Type -> "type ${st.t}"
            is Step.Dev -> st.name; is Step.TapN -> "tap #${st.n} ${st.q}"
            is Step.Tile -> "toggle ${st.labels.substringBefore('|')}" })
        when (st) {
            is Step.Open -> if (openApp(st.q)) done(true, 3000L) else fail("App nahi mila: ${st.q}")
            is Step.Call -> if (doCall(st.q)) done(true, 800L) else done(false, 0L)
            is Step.Search -> doSearch(st.q) { ok -> if (ok) done(true, 800L) else fail("Search nahi hua: ${st.q}") }
            is Step.Msg -> if (a == null) need() else a.sendMsg(st.t) { ok -> if (ok) { say("Message bhej diya"); done(true, 800L) } else fail("Message nahi gaya") }
            is Step.Act -> if (a == null) need() else { a.act(st.name); done(true, 800L) }
            is Step.Tap -> if (a == null) need() else a.tapText(st.q) { ok -> if (ok) done(true, 800L) else fail("Screen par nahi mila: ${st.q}") }
            is Step.Type -> if (a == null) need() else a.typeText(st.t) { ok -> if (ok) done(true, 800L) else fail("Type box nahi mila") }
            is Step.Dev -> when (st.name) {
                "photo", "selfie" -> if (a == null) need() else shoot(st.name == "selfie", a, done)
                else -> { runDev(st.name); done(true, 400L) }
            }
            is Step.Tile -> if (a == null) need() else a.toggleTile(st.labels, st.want) { ok -> if (ok) done(true, 800L) else fail("Quick settings mein ${st.labels.substringBefore('|')} tile nahi mila") }
            is Step.TapN -> if (a == null) need() else a.tapNth(st.n, st.q) { ok -> if (ok) done(true, 800L) else fail("${st.n} number wala ${st.q} nahi mila") }
        }
    }

    // ---------- phone control: volume, brightness, torch ----------
    private var torchOn = false

    private fun runDev(n: String) {
        if (n.startsWith("timer|")) { val a = n.split("|"); setTimer(a[1].toInt(), a.getOrElse(2) { "" }); return }
        if (n.startsWith("alarm|")) { val a = n.split("|"); setAlarm(a[1].toInt(), a[2].toInt(), a.getOrElse(3) { "" }); return }
        if (n.startsWith("contact|")) { openContact(n.substringAfter("|")); return }
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        val st = android.media.AudioManager.STREAM_MUSIC
        val ui = android.media.AudioManager.FLAG_SHOW_UI
        when (n) {
            "volup" -> { am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_RAISE, 0); am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_RAISE, ui) }
            "voldown" -> { am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_LOWER, 0); am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_LOWER, ui) }
            "volshow" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_SAME, ui)
            "volmax" -> am.setStreamVolume(st, am.getStreamMaxVolume(st), ui)
            "mute" -> am.setStreamVolume(st, 0, ui)
            "brup", "brdown", "brmax", "brmin" -> setBright(n)
            "torchon" -> setTorch(true)
            "torchoff" -> setTorch(false)
            "mplay" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            "mpause" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
            "mnext" -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            "mprev" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            "answercall" -> callCtl(true)
            "endcall" -> callCtl(false)
            "showalarms" -> try { startActivity(Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            "showtimers" -> try { startActivity(Intent(android.provider.AlarmClock.ACTION_SHOW_TIMERS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            "needtime" -> say("Time bhi batao: jaise 5 minute ya subah 6 baje")
            "itime" -> speak("Time is " + java.text.SimpleDateFormat("h:mm a", Locale.ENGLISH).format(java.util.Date()))
            "idate" -> speak("Today is " + java.text.SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(java.util.Date()))
            "ibat" -> {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                speak("Battery is " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent" + (if (bm.isCharging) ", charging" else ""))
            }
        }
    }

    private fun setBright(n: String) {
        if (!android.provider.Settings.System.canWrite(this)) {
            say("Modify system settings mein NotchCmd ko allow karo")
            try { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            return
        }
        try {
            val cr = contentResolver
            val cur = android.provider.Settings.System.getInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS, 128)
            val v = when (n) { "brup" -> cur + 60; "brdown" -> cur - 60; "brmax" -> 255; else -> 10 }.coerceIn(5, 255)
            android.provider.Settings.System.putInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE, android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            android.provider.Settings.System.putInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS, v)
            say("Brightness " + (v * 100 / 255) + "%")
        } catch (_: Exception) { say("Brightness change nahi hui") }
    }

    private fun setTorch(on: Boolean) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { say("Flash nahi mila"); return }
            cm.setTorchMode(id, on); torchOn = on
            say(if (on) "Torch ON" else "Torch OFF")
        } catch (_: Exception) { say("Torch nahi chala") }
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    @Suppress("DEPRECATION")
    private fun callCtl(answer: Boolean) {
        if (checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) != 0) { say("Phone call permission do (app mein button 2)"); return }
        try {
            val tm = getSystemService(TELECOM_SERVICE) as android.telecom.TelecomManager
            if (answer) tm.acceptRingingCall() else tm.endCall()
        } catch (_: Exception) { say("Call control nahi hua") }
    }

    private fun fmtDur(sec: Int): String {
        val hh = sec / 3600; val mm = (sec % 3600) / 60; val ss = sec % 60
        return listOfNotNull(if (hh > 0) "$hh ghanta" else null, if (mm > 0) "$mm minute" else null, if (ss > 0) "$ss second" else null).joinToString(" ")
    }

    private fun setTimer(sec: Int, label: String) {
        try {
            startActivity(Intent(android.provider.AlarmClock.ACTION_SET_TIMER)
                .putExtra(android.provider.AlarmClock.EXTRA_LENGTH, sec.coerceIn(1, 86400))
                .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Timer" })
                .putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            say("Timer set: " + fmtDur(sec))
        } catch (_: Exception) { say("Timer set nahi hua") }
    }

    private fun setAlarm(hh: Int, mm: Int, label: String) {
        try {
            startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
                .putExtra(android.provider.AlarmClock.EXTRA_HOUR, hh).putExtra(android.provider.AlarmClock.EXTRA_MINUTES, mm)
                .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Alarm" })
                .putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            say("Alarm set: " + String.format(Locale.ROOT, "%02d:%02d", hh, mm))
        } catch (_: Exception) { say("Alarm set nahi hua") }
    }

    private fun openContact(name: String) {
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != 0) { say("Contacts permission do"); return }
        contentResolver.query(ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.LOOKUP_KEY),
            ContactsContract.Contacts.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null)?.use {
            if (it.moveToFirst()) {
                val uri = ContactsContract.Contacts.getLookupUri(it.getLong(0), it.getString(1))
                try { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { say("Contact nahi khula") }
                return
            }
        }
        say("Contact nahi mila: $name")
    }

    /** camera kholo, (selfie ho to front camera), shutter dabao */
    private fun shoot(selfie: Boolean, a: NotchA11y, done: (Boolean, Long) -> Unit) {
        try { startActivity(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { say("Camera nahi khula"); done(false, 0L); return }
        val g = gen
        h.postDelayed({
            if (g == gen) {
                val snap = { a.tapText("shutter|capture|take photo|take picture") { ok -> done(ok, 1200L) } }
                if (selfie) a.tapText("switch|flip|selfie|front") { snap() } else snap()
            }
        }, 2500)
    }

    // ---------- bolkar jawab (time / battery / date) ----------
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false

    private fun initTts() {
        tts = android.speech.tts.TextToSpeech(this) { st ->
            h.post {
                if (st == android.speech.tts.TextToSpeech.SUCCESS) {
                    tts?.language = Locale("en", "IN")
                    tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { h.post { endSpeak() } }
                        @Suppress("OVERRIDE_DEPRECATION")
                        override fun onError(id: String?) { h.post { endSpeak() } }
                    })
                    ttsReady = true
                }
            }
        }
    }

    private fun speak(t: String) {
        say(t)
        val e = tts
        if (!ttsReady || e == null) return
        speaking = true; stopListen()
        e.speak(t, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "n1")
        h.postDelayed({ endSpeak() }, 7000)
    }

    private fun endSpeak() {
        if (!speaking) return
        speaking = false
        if (panel != null && !typing && sr == null) startListen()
    }

    private fun findApp(q0: String): String? {
        val pm = packageManager
        val q = q0.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) return null
        val toks = q.split(" ")
        fun rank(n: String): Int = when {
            n == q -> 0
            n.contains(q) -> 1
            toks.all { n.contains(it) } -> 2
            n.length >= 4 && q.contains(n) -> 3
            else -> 9
        }
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Pair(it.loadLabel(pm).toString().lowercase(Locale.ROOT), it.activityInfo.packageName) }
            .map { Pair(it, rank(it.first)) }.filter { it.second < 9 }
            .minWithOrNull(compareBy({ it.second }, { it.first.first.length }))?.first?.second
    }

    private fun openApp(q0: String): Boolean {
        val pm = packageManager
        val q = q0.trim()
        if (q.contains(".") && !q.contains(" ")) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(if (q.startsWith("http")) q else "https://$q")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
        }
        val toks = q.split(" ")
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Triple(it.loadLabel(pm).toString().lowercase(Locale.ROOT), it.activityInfo.packageName, 0) }
        fun rank(n: String): Int = when {
            n == q -> 0
            n.contains(q) -> 1
            toks.all { n.contains(it) } -> 2
            n.length >= 4 && q.contains(n) -> 3
            else -> 9
        }
        val hit = apps.map { Pair(it, rank(it.first)) }.filter { it.second < 9 }
            .minWithOrNull(compareBy({ it.second }, { it.first.first.length }))?.first ?: return false
        val intent = pm.getLaunchIntentForPackage(hit.second)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return false
        lastPkg = hit.second
        startActivity(intent); return true
    }

    private fun homePkg(): String = packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName ?: ""

    private fun openUrl(u: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    /** Jo app abhi khuli hai usi ke andar search: WhatsApp / YouTube / koi bhi app. Koi app khuli na ho (ya browser) to Google. */
    private fun doSearch(q: String, cb: (Boolean) -> Unit) {
        val a = NotchA11y.inst
        val fg = if (a != null) a.fgPkg() else lastPkg
        val web = fg.isEmpty() || fg == packageName || fg == homePkg() || fg.startsWith("com.android.systemui") ||
            listOf("chrome", "browser", "firefox", "opera", "brave", "edge").any { fg.contains(it) }
        when {
            q.startsWith("youtube ") -> { openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q.removePrefix("youtube "))); cb(true) }
            fg.startsWith("com.whatsapp") -> if (a == null) { say("Accessibility service on karo"); cb(false) } else a.waSearch(q, cb)
            fg.contains("youtube") -> { openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q)); cb(true) }
            web -> { openUrl("https://www.google.com/search?q=" + Uri.encode(q)); cb(true) }
            a == null -> { say("Accessibility service on karo"); cb(false) }
            else -> a.appSearch(q, cb)
        }
    }

    private fun findNumber(name: String): String? {
        if (name.matches(Regex("[+0-9 ]{5,}"))) return name.replace(" ", "")
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != 0) return null
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        contentResolver.query(uri, arrayOf(numCol), "$nameCol LIKE ?", arrayOf("%$name%"), null)?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun doCall(name: String): Boolean {
        val num = findNumber(name)
        if (num == null) { say("Contact nahi mila: $name"); return false }
        val act = if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) == 0) Intent.ACTION_CALL else Intent.ACTION_DIAL
        startActivity(Intent(act, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }
}
