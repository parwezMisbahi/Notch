package com.msam.notchcmd

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*

class OverlayService : Service() {
    private var view: View? = null
    private val wm get() = getSystemService(WINDOW_SERVICE) as WindowManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "notch"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "NotchCmd", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, ch).setContentTitle("NotchCmd chal raha hai")
            .setContentText("Notch par double-tap karo").setSmallIcon(android.R.drawable.ic_btn_speak_now).build())

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                startActivity(Intent(this@OverlayService, CommandActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            }
        })
        val v = View(this).apply {
            setBackgroundColor(0x01000000) // almost invisible, still touchable
            setOnTouchListener { _, e -> gd.onTouchEvent(e) }
        }
        val lp = WindowManager.LayoutParams(
            (140 * resources.displayMetrics.density).toInt(), (56 * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp); view = v
    }

    override fun onDestroy() { view?.let { wm.removeView(it) }; super.onDestroy() }
}
