package com.msam.notchcmd

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.*
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale

sealed class Step {
    data class Open(val q: String) : Step()
    data class Call(val q: String) : Step()
    data class Search(val q: String) : Step()
    data class Msg(val t: String) : Step()
}

class OverlayService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val wm get() = getSystemService(WINDOW_SERVICE) as WindowManager
    private var trigger: View? = null
    private var panel: FrameLayout? = null
    private var web: WebView? = null
    private var sr: SpeechRecognizer? = null
    private var lastApp = ""

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.getBooleanExtra("show", false) == true) showPanel()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("notch", "NotchCmd", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "notch").setContentTitle("NotchCmd chal raha hai")
            .setContentText("Notch par double-tap karo").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean { showPanel(); return true }
        })
        val d = resources.displayMetrics.density
        val v = View(this).apply { setBackgroundColor(0x01000000); setOnTouchListener { _, e -> gd.onTouchEvent(e) } }
        val lp = WindowManager.LayoutParams((140 * d).toInt(), (56 * d).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp); trigger = v
    }

    override fun onDestroy() { hidePanel(); trigger?.let { wm.removeView(it) }; super.onDestroy() }

    // ---------- floating panel (app ke upar) ----------
    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun showPanel() {
        if (panel != null) return
        val d = resources.displayMetrics.density
        val w = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/command.html")
        }
        val f = object : FrameLayout(this) {
            override fun dispatchKeyEvent(e: KeyEvent): Boolean {
                if (e.keyCode == KeyEvent.KEYCODE_BACK) { if (e.action == KeyEvent.ACTION_UP) hidePanel(); return true }
                return super.dispatchKeyEvent(e)
            }
        }
        f.addView(w)
        f.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) hidePanel(); false }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, (230 * d).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP; softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN }
        wm.addView(f, lp); panel = f; web = w
    }

    private fun hidePanel() {
        sr?.destroy(); sr = null
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        web?.destroy(); web = null; panel = null
    }

    private fun js(c: String) = h.post { web?.evaluateJavascript(c, null) }
    private fun say(m: String) = h.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    inner class Bridge {
        @JavascriptInterface fun listen() { h.post { startListen() } }
        @JavascriptInterface fun close() { h.post { hidePanel() } }
        @JavascriptInterface fun run(c: String) { h.post { runAll(c) } }
    }

    private fun startListen() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != 0) { say("App mein mic permission do"); return }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { js("setState('listening')") }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    js("gotText(${JSONObject.quote(t)})"); if (t.isNotBlank()) runAll(t)
                }
                override fun onError(e: Int) { js("setState('idle','Samajh nahi aaya, dobara bolo')") }
                override fun onPartialResults(p: Bundle?) {
                    val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    js("gotText(${JSONObject.quote(t)})")
                }
                override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            })
        }
    }

    // ---------- command ko parts mein todna ----------
    private val seps = Regex("\\s*[,،]\\s*|\\s+(?:aur|phir|fir|then|and|और|फिर)\\s+")
    private val cut = setOf("karo", "kar", "kholo", "khol", "chalao", "lagao", "करो", "खोलो", "चलाओ")
    private val fill = setOf("open", "kholo", "khol", "karo", "kar", "do", "dijiye", "chalao", "chala", "ko", "app", "start", "launch", "ki", "ka", "ke", "par", "pe", "mein", "me",
        "please", "plz", "खोलो", "खोल", "करो", "दो", "चलाओ", "को", "ऐप", "की", "का", "पर", "में")
    private val msgKw = setOf("message", "msg", "मैसेज", "likho", "bhejo", "send", "भेजो", "लिखो")
    private val callKw = setOf("call", "कॉल", "कोल")
    private val searchKw = setOf("search", "khojo", "dhundo", "सर्च", "खोजो", "ढूंढो")
    private val alias = mapOf("यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "कैमरा" to "camera",
        "क्रोम" to "chrome", "सेटिंग" to "settings", "सेटिंग्स" to "settings", "गैलरी" to "gallery", "इंस्टाग्राम" to "instagram")

    private fun parse(raw: String): List<Step> {
        val out = mutableListOf<Step>()
        for (chunk in raw.lowercase(Locale.ROOT).trim().split(seps)) {
            val tokens = chunk.split(Regex("\\s+")).filter { it.isNotBlank() }.map { alias[it] ?: it }
            val parts = mutableListOf<List<String>>(); var acc = mutableListOf<String>()
            for ((i, t) in tokens.withIndex()) {
                acc.add(t)
                if (t in cut && i < tokens.size - 1 && acc.none { it in msgKw }) { parts.add(acc); acc = mutableListOf() }
            }
            if (acc.isNotEmpty()) parts.add(acc)
            for (p in parts) {
                val mi = p.indexOfFirst { it in msgKw }
                val ci = p.indexOfFirst { it in callKw }
                val si = p.indexOfFirst { it in searchKw }
                fun rest(skip: Int) = p.filterIndexed { i, _ -> i != skip }.filter { it !in fill }.joinToString(" ")
                if (mi >= 0) {
                    val name = p.take(mi).filter { it !in fill }.joinToString(" ")
                    val text = p.drop(mi + 1).dropWhile { it in fill }.joinToString(" ")
                    if (name.isNotEmpty()) out.add(Step.Search(name))
                    if (text.isNotEmpty()) out.add(Step.Msg(text))
                } else if (ci >= 0) out.add(Step.Call(rest(ci)))
                else if (si >= 0) out.add(Step.Search(rest(si)))
                else out.add(Step.Open(p.filter { it !in fill }.joinToString(" ")))
            }
        }
        return out.filter { s -> when (s) { is Step.Open -> s.q.isNotEmpty(); is Step.Call -> s.q.isNotEmpty(); is Step.Search -> s.q.isNotEmpty(); is Step.Msg -> true } }
    }

    // ---------- ek ek karke chalana ----------
    private fun runAll(raw: String) {
        hidePanel()   // panel hatao taake neeche wali app par kaam ho sake
        val steps = parse(raw)
        if (steps.isEmpty()) { say("Command samajh nahi aayi"); return }
        runStep(steps, 0)
    }

    private fun runStep(s: List<Step>, i: Int) {
        if (i >= s.size) return
        val next = { h.postDelayed({ runStep(s, i + 1) }, 700) }
        val st = s[i]
        say("${i + 1}/${s.size}: " + when (st) { is Step.Open -> "open ${st.q}"; is Step.Call -> "call ${st.q}"; is Step.Search -> "search ${st.q}"; is Step.Msg -> "message ${st.t}" })
        when (st) {
            is Step.Open -> if (openApp(st.q)) h.postDelayed({ runStep(s, i + 1) }, 2500) else say("App nahi mila: ${st.q}")
            is Step.Call -> if (doCall(st.q)) next()
            is Step.Search -> doSearch(st.q) { ok -> if (ok) next() else say("Search nahi hua: ${st.q}") }
            is Step.Msg -> {
                val a = NotchA11y.inst
                if (a == null) say("Accessibility service on karo") else a.sendMsg(st.t) { ok -> say(if (ok) "Message bhej diya" else "Message nahi gaya"); if (ok) next() }
            }
        }
    }

    private fun openApp(q: String): Boolean {
        val pm = packageManager
        if (q.contains(".") && !q.contains(" ")) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(if (q.startsWith("http")) q else "https://$q")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
        }
        val hit = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { (l, _) -> val n = l.lowercase(Locale.ROOT); n == q || n.contains(q) || q.contains(n) }
            .minByOrNull { it.first.length } ?: return false
        val intent = pm.getLaunchIntentForPackage(hit.second)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return false
        lastApp = hit.first.lowercase(Locale.ROOT)
        startActivity(intent); return true
    }

    private fun doSearch(q: String, cb: (Boolean) -> Unit) {
        if (lastApp.contains("whatsapp")) {
            val a = NotchA11y.inst
            if (a == null) { say("Accessibility service on karo"); cb(false) } else a.waSearch(q, cb)
            return
        }
        val yt = lastApp.contains("youtube") || q.startsWith("youtube ")
        val url = if (yt) "https://www.youtube.com/results?search_query=" + Uri.encode(q.removePrefix("youtube "))
                  else "https://www.google.com/search?q=" + Uri.encode(q)
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); cb(true)
    }

    private fun findNumber(name: String): String? {
        if (name.matches(Regex("[+0-9 ]{5,}"))) return name.replace(" ", "")
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != 0) return null
        val P = ContactsContract.CommonDataKinds.Phone
        contentResolver.query(P.CONTENT_URI, arrayOf(P.NUMBER), "${P.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun doCall(name: String): Boolean {
        val num = findNumber(name)
        if (num == null) { say("Contact nahi mila: $name"); return false }
        val act = if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) == 0) Intent.ACTION_CALL else Intent.ACTION_DIAL
        startActivity(Intent(act, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }
}
