package com.msam.notchcmd

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.*
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale

sealed class Step {
    data class Open(val q: String) : Step()
    data class Call(val q: String) : Step()
    data class Search(val q: String) : Step()
    data class Msg(val t: String) : Step()
    data class Act(val name: String) : Step()
    data class Tap(val q: String) : Step()
    data class Type(val t: String) : Step()
}

class OverlayService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val wm get() = getSystemService(WINDOW_SERVICE) as WindowManager
    private var trigger: View? = null
    private var panel: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var web: WebView? = null
    private var sr: SpeechRecognizer? = null       // panel ki voice
    private var wake: SpeechRecognizer? = null     // "MJ" sunne wali voice
    private var wakeOn = false
    private var typing = false
    private var silent = 0
    private var pendingCmd: String? = null
    private var lastPkg = ""
    private val idleClose = Runnable { if (panel != null && !typing) hidePanel() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i != null && i.hasExtra("wake")) {
            wakeOn = i.getBooleanExtra("wake", false)
            getSharedPreferences("n", MODE_PRIVATE).edit().putBoolean("wake", wakeOn).apply()
            if (wakeOn) startWake() else stopWake()
            say(if (wakeOn) "MJ wake word ON — bolo: \"MJ\"" else "MJ wake word OFF")
        }
        if (i?.getBooleanExtra("show", false) == true) showPanel()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("notch", "NotchCmd", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "notch").setContentTitle("NotchCmd chal raha hai")
            .setContentText("Notch par double-tap karo ya bolo: MJ").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean { showPanel(); return true }
        })
        val d = resources.displayMetrics.density
        val v = View(this).apply { setBackgroundColor(0x01000000); setOnTouchListener { _, e -> gd.onTouchEvent(e) } }
        val lp = WindowManager.LayoutParams((140 * d).toInt(), (56 * d).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp); trigger = v

        wakeOn = getSharedPreferences("n", MODE_PRIVATE).getBoolean("wake", false)
        if (wakeOn) startWake()
    }

    override fun onDestroy() { wakeOn = false; stopWake(); hidePanel(); h.removeCallbacksAndMessages(null); trigger?.let { wm.removeView(it) }; super.onDestroy() }

    // ---------- floating panel ----------
    // Panel NOT_FOCUSABLE rehta hai taake neeche wali app focus mein rahe (live control).
    // Sirf jab tum input box par tap karo tab focusable hota hai (keyboard ke liye).
    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun showPanel(cmd: String? = null) {
        if (panel != null) { if (cmd != null) runAll(cmd); return }
        stopWake()
        pendingCmd = cmd; silent = 0; typing = false
        val d = resources.displayMetrics.density
        val w = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, u: String?) {
                    val c = pendingCmd; pendingCmd = null
                    if (c != null) { js("gotText(${JSONObject.quote(c)})"); runAll(c) } else startListen()   // mic apne aap on
                }
            }
            loadUrl("file:///android_asset/command.html")
        }
        val f = FrameLayout(this)
        f.addView(w)
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, (180 * d).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(f, lp); panel = f; web = w; panelLp = lp
        armIdle()
    }

    private fun hidePanel() {
        h.removeCallbacks(idleClose)
        stopListen(); typing = false
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        web?.destroy(); web = null; panel = null; panelLp = null
        h.postDelayed({ startWake() }, 600)   // panel band, ab wapas "MJ" sunna
    }

    private fun armIdle() { h.removeCallbacks(idleClose); h.postDelayed(idleClose, 20000) }

    private fun setTyping(on: Boolean) {
        typing = on
        val lp = panelLp ?: return; val p = panel ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try { wm.updateViewLayout(p, lp) } catch (_: Exception) {}
        if (on) {
            stopListen(); h.removeCallbacks(idleClose)
            web?.requestFocus()
            js("setState('typing')")
            h.postDelayed({ js("focusInput()") }, 120)
        } else armIdle()
    }

    private fun js(c: String) { h.post { web?.evaluateJavascript(c, null) } }
    private fun say(m: String) { h.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }; js("setState('busy',${JSONObject.quote(m)})") }

    inner class Bridge {
        @JavascriptInterface fun listen() { h.post { if (typing) setTyping(false); silent = 0; startListen() } }
        @JavascriptInterface fun startTyping() { h.post { if (!typing) setTyping(true) } }
        @JavascriptInterface fun close() { h.post { hidePanel() } }
        @JavascriptInterface fun run(c: String) { h.post { runAll(c) } }
    }

    // ---------- voice (English letters: en-IN) ----------
    private fun speechIntent(partial: Boolean) = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, partial)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
    }

    /** jo result English letters mein ho wahi lo, warna pehla (parse Hindi ko Roman bana lega) */
    private fun pick(b: Bundle?): String {
        val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return ""
        return l.firstOrNull { s -> s.isNotBlank() && s.none { isDev(it) } } ?: l.firstOrNull() ?: ""
    }

    private fun stopListen() { sr?.destroy(); sr = null }

    private fun startListen() {
        if (panel == null || typing) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != 0) { say("App mein mic permission do"); return }
        armIdle()
        stopListen()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { js("setState('listening')") }
            override fun onResults(b: Bundle?) {
                if (sr !== r) return
                val t = pick(b)
                if (t.isBlank()) { retryListen(); return }
                silent = 0
                js("gotText(${JSONObject.quote(t)})")
                h.post { runAll(t) }
            }
            override fun onPartialResults(p: Bundle?) {
                if (sr !== r) return
                val t = pick(p); if (t.isNotBlank()) js("gotText(${JSONObject.quote(t)})")
            }
            override fun onError(e: Int) {
                if (sr !== r) return
                when (e) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retryListen()
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> h.postDelayed({ startListen() }, 600)
                    else -> js("setState('idle','Voice error $e. Mic dabao ya likho')")
                }
            }
            override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(speechIntent(true))
    }

    private fun retryListen() {
        silent++
        if (silent >= 3) { silent = 0; js("setState('idle','Mic band. 🎤 dabao ya likho')"); return }
        h.postDelayed({ startListen() }, 300)
    }

    // ---------- "MJ" wake word (hands-free) ----------
    private val wakeRe = Regex("(?<![a-z])(mj|m\\.? ?j\\.?|em ?jay|एमजे|एम जे)(?![a-z])")

    private fun startWake() {
        if (!wakeOn || panel != null || wake != null) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != 0) return
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        wake = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                if (wake !== r) return
                val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty().map { it.lowercase(Locale.ROOT) }
                val m = l.firstNotNullOfOrNull { s -> wakeRe.find(s)?.let { mr -> s to mr } }
                if (m == null) { restartWake(300); return }
                val rest = m.first.substring(m.second.range.last + 1).trim(' ', ',', '.')
                stopWake()
                showPanel(if (rest.isBlank()) null else rest)
            }
            override fun onError(e: Int) { if (wake === r) restartWake(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400) }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(speechIntent(false))
    }

    private fun stopWake() { wake?.destroy(); wake = null }
    private fun restartWake(ms: Long) { h.post { stopWake() }; h.postDelayed({ startWake() }, ms) }

    // ---------- Devanagari -> Roman (agar recognizer Hindi script de de) ----------
    private fun isDev(c: Char) = c in '\u0900'..'\u097F'
    private val cons = mapOf('क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n", 'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n", 'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m", 'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh",
        'स' to "s", 'ह' to "h", '\u0958' to "q", '\u0959' to "kh", '\u095A' to "g", '\u095B' to "z", '\u095C' to "d", '\u095D' to "rh", '\u095E' to "f", '\u095F' to "y")
    private val vow = mapOf('अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo", 'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o")
    private val mat = mapOf('ा' to "a", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au", 'ॉ' to "o", 'ॅ' to "e")

    private fun roman(s: String): String {
        if (s.none { isDev(it) }) return s
        val sb = StringBuilder(); var pend = false
        for (c in s) {
            when {
                cons.containsKey(c) -> { if (pend) sb.append('a'); sb.append(cons[c]); pend = true }
                vow.containsKey(c) -> { if (pend) sb.append('a'); pend = false; sb.append(vow[c]) }
                mat.containsKey(c) -> { pend = false; sb.append(mat[c]) }
                c == '\u094D' -> pend = false
                c == '\u093C' -> { if (sb.endsWith("j")) { sb.setLength(sb.length - 1); sb.append('z') } }
                c == 'ं' || c == 'ँ' -> { if (pend) sb.append('a'); pend = false; sb.append('n') }
                c == 'ः' -> { if (pend) sb.append('a'); pend = false; sb.append('h') }
                c in '\u0966'..'\u096F' -> { pend = false; sb.append(c - '\u0966') }
                c == '।' -> { pend = false }
                else -> { pend = false; sb.append(c) }
            }
        }
        return sb.toString()
    }

    // ---------- command ko parts mein todna ----------
    private val seps = Regex("\\s*[,،]\\s*|\\s+(?:aur|phir|fir|then|and|और|फिर)\\s+")
    private val cut = setOf("karo", "kar", "kholo", "khol", "kolo", "khulo", "chalao", "lagao", "dabao", "करो", "खोलो", "चलाओ", "दबाओ")
    private val fill = setOf("open", "kholo", "khol", "kolo", "khulo", "karo", "kar", "do", "dijiye", "chalao", "chala", "ko", "app", "start", "launch", "ki", "ka", "ke", "par", "pe", "mein", "me",
        "please", "plz", "khud", "khudse", "खोलो", "खोल", "करो", "दो", "चलाओ", "को", "ऐप", "की", "का", "पर", "में")
    private val msgKw = setOf("message", "msg", "maisej", "मैसेज", "likho", "bhejo", "bejo", "bhej", "send", "भेजो", "लिखो")
    private val callKw = setOf("call", "kol", "kaul", "कॉल", "कोल")
    private val searchKw = setOf("search", "sarch", "surch", "khojo", "dhundo", "सर्च", "खोजो", "ढूंढो")
    private val tapKw = setOf("tap", "click", "klik", "dabao", "press", "दबाओ", "क्लिक")
    private val actKw = mapOf("back" to "back", "wapas" to "back", "vapas" to "back", "peeche" to "back", "peechhe" to "back", "पीछे" to "back", "वापस" to "back",
        "home" to "home", "hom" to "home", "होम" to "home", "recents" to "recents", "recent" to "recents", "notification" to "notif", "notifications" to "notif",
        "screenshot" to "shot", "close" to "close", "cancel" to "close", "bas" to "close", "band" to "close")
    private val alias = mapOf("यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "कैमरा" to "camera",
        "क्रोम" to "chrome", "सेटिंग" to "settings", "सेटिंग्स" to "settings", "गैलरी" to "gallery", "इंस्टाग्राम" to "instagram",
        "wa" to "whatsapp", "yt" to "youtube", "insta" to "instagram", "fb" to "facebook",
        "yootyoob" to "youtube", "yutyub" to "youtube", "yutub" to "youtube", "yootub" to "youtube", "vhatsaep" to "whatsapp", "vhatsap" to "whatsapp",
        "watsapp" to "whatsapp", "whatsap" to "whatsapp", "krom" to "chrome")
    private val known: Set<String> by lazy { cut + fill + msgKw + callKw + searchKw + tapKw + actKw.keys + alias.keys }

    /** alias -> Roman; Hindi script ka anjaan lafz (naam, query, message) Roman ban jata hai */
    private fun norm(t: String): String = alias[t] ?: if (t.any { isDev(it) } && t !in known) roman(t) else t

    private fun parse(raw: String): List<Step> {
        val out = mutableListOf<Step>()
        for (chunk in raw.lowercase(Locale.ROOT).trim().split(seps)) {
            val tokens = chunk.split(Regex("\\s+")).filter { it.isNotBlank() }.map { norm(it) }
            // "search arijit singh" / "call ali" / "tap play video" (verb pehle) bhi chalega
            val f0 = tokens.firstOrNull()
            if (f0 != null && tokens.size > 1 && (f0 in searchKw || f0 in callKw || f0 in tapKw)) {
                val q = tokens.drop(1).filter { it !in fill }.joinToString(" ")
                out.add(if (f0 in searchKw) Step.Search(q) else if (f0 in callKw) Step.Call(q) else Step.Tap(q))
                continue
            }
            val parts = mutableListOf<List<String>>(); var acc = mutableListOf<String>()
            for ((i, t) in tokens.withIndex()) {
                acc.add(t)
                if (t in cut && i < tokens.size - 1 && acc.none { it in msgKw }) { parts.add(acc); acc = mutableListOf() }
            }
            if (acc.isNotEmpty()) parts.add(acc)
            for (p in parts) {
                val mi = p.indexOfFirst { it in msgKw }; val ci = p.indexOfFirst { it in callKw }
                val si = p.indexOfFirst { it in searchKw }; val ti = p.indexOfFirst { it in tapKw }
                val ty = p.indexOf("type"); val sc = p.indexOf("scroll"); val ai = p.indexOfFirst { it in actKw }
                fun rest(skip: Int) = p.filterIndexed { i, _ -> i != skip }.filter { it !in fill }.joinToString(" ")
                if (mi >= 0) {
                    val before = p.take(mi).filter { it !in fill }.joinToString(" ")
                    val after = p.drop(mi + 1).dropWhile { it in fill }.joinToString(" ")
                    if (after.isNotEmpty()) { if (before.isNotEmpty()) out.add(Step.Search(before)); out.add(Step.Msg(after)) }
                    else if (before.isNotEmpty()) out.add(Step.Msg(before))   // "hi bejo"
                } else if (ci >= 0) out.add(Step.Call(rest(ci)))
                else if (si >= 0) out.add(Step.Search(rest(si)))
                else if (ti >= 0) out.add(Step.Tap(rest(ti)))
                else if (ty >= 0) out.add(Step.Type(p.drop(ty + 1).joinToString(" ")))
                else if (sc >= 0) out.add(Step.Act(if (p.any { it in setOf("up", "upar", "ऊपर") }) "scrollup" else "scrolldown"))
                else if (ai >= 0) out.add(Step.Act(actKw[p[ai]]!!))
                else out.add(Step.Open(p.filter { it !in fill }.joinToString(" ")))
            }
        }
        return out.filter { s -> when (s) {
            is Step.Open -> s.q.isNotEmpty(); is Step.Call -> s.q.isNotEmpty(); is Step.Search -> s.q.isNotEmpty()
            is Step.Tap -> s.q.isNotEmpty(); is Step.Type -> s.t.isNotEmpty(); is Step.Msg -> s.t.isNotEmpty(); is Step.Act -> true } }
    }

    // ---------- ek ek karke chalana (live: kaam ke baad mic phir on) ----------
    private fun runAll(raw: String) {
        if (typing) setTyping(false)
        stopListen(); h.removeCallbacks(idleClose)
        val steps = parse(raw)
        if (steps.isEmpty()) { say("Command samajh nahi aayi"); afterRun(); return }
        runStep(steps, 0)
    }

    /** command khatam (ya fail) -> panel khula ho to mic dobara sunne lage */
    private fun afterRun() {
        if (panel == null) return
        armIdle()
        h.postDelayed({ if (panel != null && !typing) startListen() }, 900)
    }

    private fun runStep(s: List<Step>, i: Int) {
        if (i >= s.size) { afterRun(); return }
        val next = { h.postDelayed({ runStep(s, i + 1) }, 800) }
        val fail: (String) -> Unit = { m -> say(m); afterRun() }
        val st = s[i]
        val a = NotchA11y.inst
        val need = { fail("Accessibility service on karo") }
        say("${i + 1}/${s.size}: " + when (st) {
            is Step.Open -> "open ${st.q}"; is Step.Call -> "call ${st.q}"; is Step.Search -> "search ${st.q}"; is Step.Msg -> "message ${st.t}"
            is Step.Act -> st.name; is Step.Tap -> "tap ${st.q}"; is Step.Type -> "type ${st.t}" })
        when (st) {
            is Step.Open -> if (openApp(st.q)) h.postDelayed({ runStep(s, i + 1) }, 3000) else fail("App nahi mila: ${st.q}")
            is Step.Call -> if (doCall(st.q)) next() else afterRun()
            is Step.Search -> doSearch(st.q) { ok -> if (ok) next() else fail("Search nahi hua: ${st.q}") }
            is Step.Msg -> if (a == null) need() else a.sendMsg(st.t) { ok -> if (ok) { say("Message bhej diya"); next() } else fail("Message nahi gaya") }
            is Step.Act -> if (st.name == "close") hidePanel() else if (a == null) need() else { a.act(st.name); next() }
            is Step.Tap -> if (a == null) need() else a.tapText(st.q) { ok -> if (ok) next() else fail("Screen par nahi mila: ${st.q}") }
            is Step.Type -> if (a == null) need() else a.typeText(st.t) { ok -> if (ok) next() else fail("Type box nahi mila") }
        }
    }

    private fun openApp(q0: String): Boolean {
        val pm = packageManager
        val q = q0.trim()
        if (q.contains(".") && !q.contains(" ")) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(if (q.startsWith("http")) q else "https://$q")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
        }
        val toks = q.split(" ")
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Triple(it.loadLabel(pm).toString().lowercase(Locale.ROOT), it.activityInfo.packageName, 0) }
        fun rank(n: String): Int = when {
            n == q -> 0
            n.contains(q) -> 1
            toks.all { n.contains(it) } -> 2
            n.length >= 4 && q.contains(n) -> 3
            else -> 9
        }
        val hit = apps.map { Pair(it, rank(it.first)) }.filter { it.second < 9 }
            .minWithOrNull(compareBy({ it.second }, { it.first.first.length }))?.first ?: return false
        val intent = pm.getLaunchIntentForPackage(hit.second)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return false
        lastPkg = hit.second
        startActivity(intent); return true
    }

    private fun doSearch(q: String, cb: (Boolean) -> Unit) {
        val a = NotchA11y.inst
        val inWa = lastPkg.startsWith("com.whatsapp") || (a?.fgPkg() ?: "").startsWith("com.whatsapp")
        if (inWa) {
            if (a == null) { say("Accessibility service on karo"); cb(false) } else a.waSearch(q, cb)
            return
        }
        val yt = lastPkg.contains("youtube") || q.startsWith("youtube ")
        val url = if (yt) "https://www.youtube.com/results?search_query=" + Uri.encode(q.removePrefix("youtube "))
                  else "https://www.google.com/search?q=" + Uri.encode(q)
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); cb(true)
    }

    private fun findNumber(name: String): String? {
        if (name.matches(Regex("[+0-9 ]{5,}"))) return name.replace(" ", "")
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != 0) return null
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        contentResolver.query(uri, arrayOf(numCol), "$nameCol LIKE ?", arrayOf("%$name%"), null)?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun doCall(name: String): Boolean {
        val num = findNumber(name)
        if (num == null) { say("Contact nahi mila: $name"); return false }
        val act = if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) == 0) Intent.ACTION_CALL else Intent.ACTION_DIAL
        startActivity(Intent(act, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }
}
