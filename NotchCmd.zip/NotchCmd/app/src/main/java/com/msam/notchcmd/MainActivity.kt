package com.msam.notchcmd

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(TextView(this).apply { text = "NotchCmd\nNotch par double-tap ya bolo \"MJ\" → mic apne aap on, bolo ya tap karke likho"; textSize = 18f })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Overlay permission") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Mic, contacts, call, notification permission") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2b. Brightness permission (Modify system settings)") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        btn("3. Accessibility on karo (NotchCmd)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3b. Power button: Default digital assistant = NotchCmd") { try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        btn("4. Start (notch button on)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java)) }
        btn("MJ ON (screen on par sunega)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", true)) }
        btn("MJ OFF (mic band)") { startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", false)) }
        btn("Stop") { stopService(Intent(this, OverlayService::class.java)) }
        btn("Test: box abhi kholo") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    // App kholte hi (ya permission dene ke baad) service khud chalu: mic sirf "MJ" ke liye sunta rehta hai
    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }
}
