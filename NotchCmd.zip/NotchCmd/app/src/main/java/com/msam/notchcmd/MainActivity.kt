package com.msam.notchcmd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(TextView(this).apply { text = "NotchCmd\nNotch par double-tap ya bolo \"MJ\" → mic apne aap on, bolo ya tap karke likho"; textSize = 18f })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Overlay permission") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Mic, contacts, call, notification permission") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2b. Brightness permission (Modify system settings)") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        btn("3. Accessibility on karo (NotchCmd)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3b. Power button: Default digital assistant = NotchCmd") { try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        btn("4. Start (notch button on)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java)) }
        btn("MJ ON (screen on par sunega)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", true)) }
        btn("MJ OFF (mic band)") { startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", false)) }
        btn("Check: pura app ki jaanch") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("cmd", "check app")) }
        btn("Stop") { stopService(Intent(this, OverlayService::class.java)) }
        btn("Test: box abhi kholo") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) }
        // ---------- Schedule: fix time par command ----------
        root.addView(TextView(this).apply { text = "\nSchedule (fix time par command, lock hone par bhi)"; textSize = 18f })
        btn("S1. Alarms & reminders permission (theek waqt ke liye)") { if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
        btn("S2. Battery: Unrestricted karo") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        val schedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun dayName(mask: Int): String = if (mask == 0) "Ek baar" else if (mask == 127) "Roz"
            else listOf("Ravi", "Som", "Mangal", "Budh", "Guru", "Shukra", "Shani").filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(",")
        fun refreshSched() {
            schedBox.removeAllViews()
            Scheduler.load(this).forEach { s ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 16) }
                row.addView(TextView(this).apply { text = "%02d:%02d • %s • %s%s".format(s.hh, s.mm, dayName(s.days), s.cmd, if (s.on) "" else "  (band)"); textSize = 15f })
                val br = LinearLayout(this)
                br.addView(Button(this).apply { text = if (s.on) "OFF" else "ON"; setOnClickListener { Scheduler.setOn(this@MainActivity, s.id, !s.on); refreshSched() } })
                br.addView(Button(this).apply { text = "Abhi chalao"; setOnClickListener { startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", s.cmd).putExtra("sched", true)) } })
                br.addView(Button(this).apply { text = "Hatao"; setOnClickListener { Scheduler.remove(this@MainActivity, s.id); refreshSched() } })
                row.addView(br); schedBox.addView(row)
            }
        }
        btn("+ Naya schedule") {
            val et = EditText(this).apply { hint = "Command, jaise: youtube kholo"; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle("Kaun si command chalani hai?").setView(et)
                .setPositiveButton("Aage") { _, _ ->
                    val cmd = et.text.toString().trim()
                    if (cmd.isNotEmpty()) TimePickerDialog(this, { _, hh, mm ->
                        val sel = BooleanArray(7)
                        AlertDialog.Builder(this).setTitle("Kin dino? (kuch na chuno = sirf ek baar)")
                            .setMultiChoiceItems(arrayOf("Ravivar", "Somvar", "Mangalvar", "Budhvar", "Guruvar", "Shukravar", "Shanivar"), sel) { _, i, c -> sel[i] = c }
                            .setPositiveButton("Save") { _, _ ->
                                var mask = 0
                                sel.forEachIndexed { i, b -> if (b) mask = mask or (1 shl i) }
                                Scheduler.add(this, hh, mm, cmd, mask); refreshSched()
                            }.setNegativeButton("Raddh", null).show()
                    }, 8, 0, false).show()
                }.setNegativeButton("Raddh", null).show()
        }
        root.addView(schedBox)
        Scheduler.armAll(this); refreshSched()
        setContentView(ScrollView(this).apply { addView(root) })
    }

    // App kholte hi (ya permission dene ke baad) service khud chalu: mic sirf "MJ" ke liye sunta rehta hai
    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }
}
