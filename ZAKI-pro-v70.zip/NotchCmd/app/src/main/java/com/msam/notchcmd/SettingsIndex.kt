package com.msam.notchcmd

/** Searchable list of every setting (page 0-4 = category page, -1 = main settings list). Used by the chat: "whatsapp settings". */
object SettingsIndex {
    class Item(val title: String, val sub: String, val page: Int, val find: String = title, val nth: Int = 0)

    val items: List<Item> = listOf(
        Item("1. Overlay permission", "", 0),
        Item("2. Mic, contacts, call, notification permission", "", 0),
        Item("2c. Photos permission (to use the image ChatGPT saves)", "", 0),
        Item("2b. Brightness permission (Modify system settings)", "", 0),
        Item("3. Turn on Accessibility (ZAKI)", "", 0),
        Item("3b. Power button: Default digital assistant = ZAKI", "", 0),
        Item("4. Start (notch button on)", "", 0),
        Item("Check: full app diagnostics", "", 0),
        Item("Stop", "", 0),
        Item("📄 Download guide PDF (all commands, steps and fixes)", "", 0),
        Item("Test: open the box now", "", 0),
        Item("S1. Alarms & reminders permission (for exact timing)", "", 1),
        Item("S2. Battery: set to Unrestricted", "", 1),
        Item("S3. Set phone unlock PIN", "", 4),
        Item("Auto-unlock when locked", "Wakes the screen and enters your PIN before scheduled commands", 4),
        Item("Touch guard during scheduled runs", "Blocks all touches while a scheduled command runs; only the X button works and it stops the run and locks the phone", 4),
        Item("Lock the phone when a scheduled run ends", "Locks right after the command finishes or fails", 4),
        Item("Pickup / movement alarm", "If the phone is lifted or shaken during a scheduled run, stop and lock it (turn off if you hold the phone at that time)", 4),
        Item("Movement sensitivity", "High reacts to small movements", 4),
        Item("Charger unplug alarm", "If the phone was charging and the charger is pulled during a scheduled run, stop and lock it", 4),
        Item("Safety timer", "If a scheduled run is not finished by then, the phone locks by itself, even if the app crashes", 4),
        Item("Turn mobile data on if it is off", "Used before scheduled commands and posts", 4),
        Item("Use PIN on the biometric prompt", "Presses \"Use PIN\" and enters the PIN", 4),
        Item("Gboard mic: run the command after silence of", "When typing, press the send arrow instead", 4),
        Item("Auto-press the Gboard mic", "Starts Gboard voice typing by itself", 4),
        Item("D1. Screen dump after 8 sec (open the screen to inspect)", "", 0),
        Item("S6. Test: lock the phone, then try unlock after 6 sec", "", 0),
        Item("U1. Usage access permission (required for limits)", "", 4),
        Item("U3. Set an app limit", "", 4),
        Item("U4. View / remove app limits", "", 4),
        Item("Voice replies", "Says \"I'm ready\" and \"Done\"", 4),
        Item("AI app for research and posts", "Used by research, plugins, channel and Facebook posts, plans and replies", 4),
        Item("Post using", "whatsapp business channel", 2),
        Item("After a scheduled post: data off and lock phone", "whatsapp channel", 2),
        Item("Also share the post to my WhatsApp status", "", 2),
        Item("Also forward the post to my groups / contacts", "", 2),
        Item("T1. Add a title on top of every post", "", 2),
        Item("T3. With many titles", "", 2),
        Item("T4. Where the title goes", "", 2),
        Item("Poster image with every post", "The AI's first line becomes the poster headline", 2),
        Item("Make the post image with ChatGPT (instead of the poster)", "Works when the post has an image (command word image, or Poster image with every post): ChatGPT creates the picture, it is saved, then the caption is written in the same chat. If it fails, the poster is used.", 2),
        Item("Less strict picture check (only if the ChatGPT picture is never found)", "Normally only a picture that Android says was saved by ChatGPT is used. If your phone hides who saved it, turn this on: then one single square picture in Pictures named like file_<32 letters/numbers>.png is accepted. If two such pictures are possible, none is taken. Other apps' pictures (WhatsApp, Telegram, camera, screenshots) are never used.", 2),
        Item("U6. Test: play the voice", "", 4),
        Item("A3. Clear AI memory", "", 4),
        Item("+ New schedule", "", 1),
        Item("Shake to open the assistant", "Shake the phone while the screen is on", 3),
        Item("Shakes needed", "", 3),
        Item("Shake strength", "Normal may trigger while walking fast; hard is safer", 3),
        Item("Heads-up notification before a scheduled post", "", 1),
        Item("+ Daily post plan (many days at once)", "", 1),
        Item("+ New routine", "", 3),
        Item("+ New trigger", "", 3),
        Item("+ Scheduled WhatsApp message", "", 1),
        Item("+ Morning briefing (daily, AI writes it)", "", 1),
        Item("N1. Notification access (needed for digest and auto-reply)", "", 3),
        Item("Collect notifications for the digest", "Kept only on this phone; codes and passwords are skipped", 3),
        Item("+ Daily notification digest (AI summary)", "", 1),
        Item("Run the digest now", "", 3),
        Item("Clear the collected notifications", "", 3),
        Item("WhatsApp reply helper (asks you first)", "Notification with quick replies and an AI draft; nothing is sent without your tap", 3),
        Item("N4. Quick reply texts", "", 3),
        Item("Reply helper: skip group chats", "", 3),
        Item("N5. AI auto-reply (answers by itself): key, contacts, style", "", 3),
        Item("Clear post history", "", 2),
        Item("MJ voice wake", "Listens for \"MJ\" while the screen is on", -1),
        Item("Theme", "", -1),
        Item("Post using Facebook or Facebook Lite", "facebook lite", 2, "Post using", 1),
        Item("After a scheduled post: data off and lock phone (Facebook)", "facebook", 2, "After a scheduled post: data off and lock phone", 1),
        Item("Setup and control (page)", "permissions start stop test diagnostics overlay accessibility power button assistant", 0, ""),
        Item("Schedule and plans (page)", "schedule timer alarm reminder plan briefing whatsapp message pin lock unlock battery", 1, ""),
        Item("Posting (page)", "post channel facebook poster title whatsapp status history", 2, ""),
        Item("Automation (page)", "routine trigger shake digest reply helper auto reply notification", 3, ""),
        Item("Phone, voice and AI (page)", "phone lock limit voice ai app usage research model memory", 4, "")
    )

    private val stop = setOf("setting", "settings", "seting", "setings", "setting.", "open", "show", "find", "search", "kholo", "dikhao", "dikha", "batao", "me", "mein", "mai", "ka", "ki", "ke", "ko", "wali", "wala", "the", "my", "a", "of", "for", "to", "in", "on", "option", "options", "menu", "please", "pls", "karo", "kar", "do", "de", "hai", "se", "page")

    fun isQuery(q: String): Boolean = Regex("[a-z]+").findAll(q.lowercase()).any { it.value.startsWith("sett") || it.value.startsWith("seting") }

    fun hasTopic(q: String): Boolean = tokens(q).isNotEmpty()

    private fun tokens(q: String): List<String> =
        Regex("[a-z0-9]+").findAll(q.lowercase()).map { it.value }.filter { it !in stop && it.length > 1 }.toList()

    /** best matches first; every word must match when possible, otherwise any word */
    fun search(q: String): List<Item> {
        val tk = tokens(q)
        if (tk.isEmpty()) return items.filter { it.title.endsWith("(page)") }
        fun score(i: Item, all: Boolean): Int {
            val tl = i.title.lowercase(); val sl = i.sub.lowercase()
            var s = 0; var hit = 0
            for (w in tk) {
                val a = if (tl.contains(w)) 3 else if (sl.contains(w)) 1 else 0
                if (a > 0) hit++
                s += a
            }
            return if (all && hit < tk.size) 0 else s
        }
        var r = items.map { it to score(it, true) }.filter { it.second > 0 }
        if (r.isEmpty()) r = items.map { it to score(it, false) }.filter { it.second > 0 }
        return r.sortedByDescending { it.second }.take(7).map { it.first }
    }
}
