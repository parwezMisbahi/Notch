package com.msam.notchcmd

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Work View: while ZAKI works inside another app (ChatGPT etc.) a full-screen ZAKI card covers that app.
 * The app keeps running underneath (accessibility actions do not care about the cover); the user only sees
 * ZAKI's own action log: "ChatGPT opened", the picture it made, the script/caption text, "Posted".
 * The cover is NOT touchable, so our own accessibility gestures pass straight through it.
 * A small separate Stop button stays touchable.
 */
object WorkView {
    const val PREF = "n"
    const val KEY = "work_view"
    @Volatile var appCtx: Context? = null
    /** set by OverlayService: stops the running command */
    @Volatile var onStop: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var stopBtn: TextView? = null
    private var wm: WindowManager? = null
    private var logBox: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var titleV: TextView? = null
    private val hideRun = Runnable { remove() }

    fun enabled(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(KEY, true)

    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    private fun type(): Int = if (NotchA11y.inst != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    /** called when a chat command starts */
    fun start() {
        val c = appCtx ?: return
        if (!enabled(c)) return
        main.post {
            main.removeCallbacks(hideRun)
            if (root == null) build(c) else { logBox?.removeAllViews(); titleV?.text = "ZAKI is working…" }
        }
    }

    private fun build(c: Context) {
        try {
            val a11 = NotchA11y.inst
            val w = (a11 ?: c).getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val ctx: Context = a11 ?: c
            val r = FrameLayout(ctx).apply { setBackgroundColor(0xF4101418.toInt()) }
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 18), dp(c, 56), dp(c, 18), dp(c, 24)) }
            val title = TextView(ctx).apply { text = "ZAKI is working…"; setTextColor(Color.WHITE); textSize = 20f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
            val sub = TextView(ctx).apply { text = "The other app runs underneath. Only the steps are shown here."; setTextColor(0x99FFFFFF.toInt()); textSize = 12f; setPadding(0, dp(c, 2), 0, dp(c, 14)) }
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val sc = ScrollView(ctx).apply { addView(box); isFillViewport = false }
            col.addView(title); col.addView(sub)
            col.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
            r.addView(col, FrameLayout.LayoutParams(-1, -1))
            val lp = WindowManager.LayoutParams(-1, -1, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
            w.addView(r, lp)

            val stop = TextView(ctx).apply {
                text = "■  Stop"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(c, 18), dp(c, 10), dp(c, 18), dp(c, 10))
                background = GradientDrawable().apply { cornerRadius = dp(c, 24).toFloat(); setColor(0xE6C62828.toInt()) }
                setOnClickListener { onStop?.invoke() }
            }
            val slp = WindowManager.LayoutParams(-2, -2, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(c, 28) }
            w.addView(stop, slp)

            root = r; stopBtn = stop; wm = w; logBox = box; scroll = sc; titleV = title
        } catch (_: Exception) { root = null }
    }

    private fun addRow(v: View) {
        val b = logBox ?: return
        b.addView(v)
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun line(c: Context, t: String, color: Int = 0xFFE8EAED.toInt()): TextView = TextView(root!!.context).apply {
        text = t; setTextColor(color); textSize = 15f; setPadding(0, dp(c, 5), 0, dp(c, 5))
    }

    /** one action step, e.g. "ChatGPT opened" */
    fun step(m: String) {
        val c = appCtx ?: return
        main.post {
            if (root == null) return@post
            // an "...in progress" line replaces the previous in-progress line instead of piling up
            val b = logBox ?: return@post
            val last = b.childCount.takeIf { it > 0 }?.let { b.getChildAt(it - 1) } as? TextView
            val prog = m.endsWith("...") || m.endsWith("…")
            if (last != null && last.tag == "p") b.removeView(last)
            val tv = line(c, if (prog) "⏳ $m" else "✅ $m", if (prog) 0xFFB0BEC5.toInt() else 0xFFE8EAED.toInt())
            if (prog) tv.tag = "p"
            addRow(tv)
        }
    }

    /** text result (script, caption, answer): shown as a card */
    fun text(t: String) {
        val c = appCtx ?: return
        main.post {
            if (root == null) return@post
            val tv = TextView(root!!.context).apply {
                text = t.take(1500); setTextColor(Color.WHITE); textSize = 14f
                setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
                background = GradientDrawable().apply { cornerRadius = dp(c, 14).toFloat(); setColor(0x33FFFFFF) }
            }
            val lp = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 6); bottomMargin = dp(c, 6) }
            tv.layoutParams = lp
            addRow(tv)
        }
    }

    /** the picture that was made, shown inside ZAKI */
    fun image(u: Uri) {
        val c = appCtx ?: return
        Thread {
            val bm = try {
                val o = android.graphics.BitmapFactory.Options().apply { inSampleSize = 2 }
                c.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
            } catch (_: Exception) { null }
            if (bm != null) main.post {
                if (root == null) return@post
                val iv = ImageView(root!!.context).apply { setImageBitmap(bm); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
                iv.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 6); bottomMargin = dp(c, 6) }
                addRow(iv)
            }
        }.start()
    }

    /** run ended: show the result line for a moment, then remove the cover */
    fun done(ok: Boolean, m: String) {
        main.post {
            if (root == null) return@post
            titleV?.text = if (ok) "Done" else "Stopped"
            stopBtn?.visibility = View.GONE
            val c = appCtx
            if (c != null) addRow(line(c, m.lineSequence().firstOrNull().orEmpty().take(200), if (ok) 0xFF81C784.toInt() else 0xFFEF9A9A.toInt()))
            main.removeCallbacks(hideRun)
            main.postDelayed(hideRun, if (ok) 2500L else 1200L)
        }
    }

    fun remove() {
        main.post {
            main.removeCallbacks(hideRun)
            try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
            try { stopBtn?.let { wm?.removeView(it) } } catch (_: Exception) {}
            root = null; stopBtn = null; logBox = null; scroll = null; titleV = null
        }
    }
}
