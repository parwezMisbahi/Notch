package com.msam.notchcmd

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

class NotchA11y : AccessibilityService() {
    companion object { var inst: NotchA11y? = null }
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { stopAuto(); inst = null; return super.onUnbind(i) }
    // ---------- biometric prompt par "Use PIN" dabakar PIN daalna (opt-in) ----------
    private var bioBusy = false
    private var bioLast = 0L
    private var bioTries = 0
    private val credWords = listOf("use pin", "use password", "use screen lock", "use passcode", "use lock screen", "use device password", "use pattern", "पिन का उपयोग", "पासवर्ड का उपयोग")
    private fun credNode(): AccessibilityNodeInfo? = all().firstOrNull { n ->
        !n.isEditable && n.isVisibleToUser && listOfNotNull(n.text, n.contentDescription).any { t ->
            val x = t.toString().lowercase(); x.length < 40 && credWords.any { x.contains(it) } }
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || bioBusy) return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            !(e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && e.packageName?.toString() == "com.android.systemui")) return
        if (!Unlocker.bioOn(this)) return
        val now = android.os.SystemClock.uptimeMillis()
        if (now - bioLast > 120_000) bioTries = 0
        if (bioTries >= 2 && now - bioLast < 600_000) return      // galat PIN se phone lock na ho: 2 koshish ke baad 10 min ruko
        if (now - bioLast < 15_000) return
        val pin = Unlocker.getPin(this) ?: return
        val n = credNode() ?: return
        bioBusy = true; bioLast = now; bioTries++
        tap(n)
        h.postDelayed({
            retry(8, 500, { digitNode(pin[0]) != null }) { found ->
                if (!found) bioBusy = false
                else typePin(pin, 0, { digitNode(pin[0]) != null }) { _ -> bioBusy = false; bioLast = android.os.SystemClock.uptimeMillis() }
            }
        }, 900)
    }

    // Volume Up + Volume Down ek saath dabao -> panel khule (mic tabhi on hoga)
    private var upDown = false; private var downDown = false; private var comboFired = false
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val up = e.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        val down = e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (!up && !down) return false
        val pressed = e.action == KeyEvent.ACTION_DOWN
        if (up) upDown = pressed else downDown = pressed
        if (pressed && upDown && downDown && !comboFired) {
            comboFired = true
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) } catch (_: Exception) {}
            return true
        }
        if (!upDown && !downDown) { val was = comboFired; comboFired = false; return was }
        return comboFired   // combo ke dauran volume nahi badlega
    }
    override fun onInterrupt() {}

    fun fgPkg(): String = rootInActiveWindow?.packageName?.toString() ?: ""

    // ---------- "scroll karte raho": jab tak stop/ruko na bolo ----------
    var autoOn = false
    private var autoDown = true
    private val autoRun = object : Runnable {
        override fun run() { if (!autoOn) return; scroll(autoDown); h.postDelayed(this, 3000) }
    }
    fun startAuto(down: Boolean) { autoDown = down; autoOn = true; h.removeCallbacks(autoRun); h.postDelayed(autoRun, 400) }
    /** Stop button: forget every pending step of a running command (retries, waits, loops) */
    fun cancelAll() { autoOn = false; h.removeCallbacksAndMessages(null) }

    fun stopAuto(): Boolean { val was = autoOn; autoOn = false; h.removeCallbacks(autoRun); return was }

    private fun all(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        val r = rootInActiveWindow
        if (r != null) walk(r) else windows.forEach { w -> w.root?.let { walk(it) } }
        return out
    }
    private fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) { if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.parent }
        return false
    }
    private fun tapXY(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }
    /** pehle normal click, na ho to screen par us jagah gesture-tap */
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        if (click(n)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        tapXY(r.exactCenterX(), r.exactCenterY()); return true
    }
    private fun setText(n: AccessibilityNodeInfo, s: String) = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
        Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s) })
    private fun retry(t: Int, d: Long, f: () -> Boolean, done: (Boolean) -> Unit) {
        if (f()) done(true) else if (t <= 1) done(false) else h.postDelayed({ retry(t - 1, d, f, done) }, d)
    }
    private fun isSearch(n: AccessibilityNodeInfo): Boolean {
        if (n.isEditable) return false
        val s = (n.contentDescription ?: n.text)?.toString()?.lowercase() ?: return false
        return s.length < 40 && (s.contains("search") || s.contains("खोज") || s.contains("سرچ"))
    }

    // ---------- poori screen ka control ----------
    fun act(name: String) {
        when (name) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "shot" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            "scrolldown" -> scroll(true)
            "scrollup" -> scroll(false)
            "autodown" -> startAuto(true)
            "autoup" -> startAuto(false)
            "stopauto" -> stopAuto()
            "lock" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            "qs" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "swl" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.85f, m.heightPixels * 0.5f, m.widthPixels * 0.15f, m.heightPixels * 0.5f) }
            "swr" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.15f, m.heightPixels * 0.5f, m.widthPixels * 0.85f, m.heightPixels * 0.5f) }
            "swu" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.5f, m.heightPixels * 0.7f, m.widthPixels * 0.5f, m.heightPixels * 0.3f) }
            "swd" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.5f, m.heightPixels * 0.3f, m.widthPixels * 0.5f, m.heightPixels * 0.7f) }
            "doubletap" -> { val m = resources.displayMetrics; val x = m.widthPixels / 2f; val y = m.heightPixels / 2f; tapXY(x, y); h.postDelayed({ tapXY(x, y) }, 130) }
        }
    }
    private fun scroll(down: Boolean) {
        val ok = all().firstOrNull { it.isScrollable }?.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false
        if (!ok) {
            val m = resources.displayMetrics; val x = m.widthPixels / 2f; val a = m.heightPixels * 0.7f; val b = m.heightPixels * 0.3f
            if (down) swipe(x, a, x, b) else swipe(x, b, x, a)
        }
    }

    // ---------- lock screen: swipe up + PIN ----------
    private fun digitNode(d: Char): AccessibilityNodeInfo? = all().firstOrNull { n ->
        !n.isEditable && n.isVisibleToUser && (
            Regex("^\\s*$d(\\s|$)").containsMatchIn(n.text?.toString() ?: "") ||
            n.contentDescription?.toString()?.trim() == d.toString() ||
            n.viewIdResourceName?.endsWith("key$d") == true)
    }
    private fun enterNode(): AccessibilityNodeInfo? = all().firstOrNull { n ->
        val cd = n.contentDescription?.toString()?.trim()?.lowercase() ?: ""
        val tx = n.text?.toString()?.trim()?.lowercase() ?: ""
        n.isVisibleToUser && (n.viewIdResourceName?.endsWith("key_enter") == true || n.viewIdResourceName?.endsWith("enter") == true ||
            cd in setOf("enter", "ok", "confirm", "done") || tx in setOf("ok", "enter", "done"))
    }
    private fun swipeUpUnlock() {
        val m = resources.displayMetrics
        swipe(m.widthPixels * 0.5f, m.heightPixels * 0.85f, m.widthPixels * 0.5f, m.heightPixels * 0.25f)
    }

    /** Lock ho to swipe-up karke PIN daalta hai. cb(true) = ab unlock hai */
    fun unlock(pin: String, stillLocked: () -> Boolean, cb: (Boolean) -> Unit) {
        if (!stillLocked()) { cb(true); return }
        swipeUpUnlock()
        h.postDelayed({
            if (!stillLocked()) { cb(true); return@postDelayed }
            var swipes = 1
            retry(8, 500, {
                if (digitNode(pin[0]) != null) true
                else { if (swipes < 3) { swipes++; swipeUpUnlock() }; false }
            }) { found ->
                if (!found) cb(!stillLocked()) else typePin(pin, 0, stillLocked, cb)
            }
        }, 1000)
    }
    private fun typePin(pin: String, i: Int, stillLocked: () -> Boolean, cb: (Boolean) -> Unit) {
        if (i >= pin.length) {
            h.postDelayed({
                if (stillLocked()) enterNode()?.let { tap(it) }
                h.postDelayed({ cb(!stillLocked()) }, 1500)
            }, 500)
            return
        }
        val n = digitNode(pin[i])
        if (n != null) tap(n)
        h.postDelayed({ typePin(pin, i + 1, stillLocked, cb) }, 280)
    }
    /** Diagnostic: abhi screen par accessibility ko kya dikh raha hai (text / description / id / clickable) */
    fun dump(): String {
        val sb = StringBuilder()
        val ws = windows
        sb.append("windows=").append(ws.size).append(" root=").append(rootInActiveWindow?.packageName).append("\n")
        val seen = HashSet<String>()
        for (n in all()) {
            if (!n.isVisibleToUser) continue
            val t = n.text?.toString()?.take(40) ?: ""
            val d = n.contentDescription?.toString()?.take(40) ?: ""
            val id = n.viewIdResourceName?.substringAfter(":id/") ?: ""
            if (t.isEmpty() && d.isEmpty() && id.isEmpty() && !n.isClickable) continue   // unnamed buttons/icons are shown too
            val bb = Rect(); n.getBoundsInScreen(bb)
            val line = "t=[$t] d=[$d] id=[$id]" + (if (n.isClickable) " CLICK" else "") + (if (n.isEditable) " EDIT" else "") +
                (if (n.isEnabled) "" else " DISABLED") + (if (n.isSelected) " SEL" else "") +
                " b=[${bb.left},${bb.top},${bb.right},${bb.bottom}] " + (n.className?.toString()?.substringAfterLast('.') ?: "")
            if (seen.add(line)) sb.append(line).append("\n")
        }
        val ime = imeNodes().filter { it.isVisibleToUser }
        if (ime.isNotEmpty()) {
            sb.append("--- keyboard ---\n")
            for (n in ime) {
                val t = n.text?.toString()?.take(40) ?: ""
                val d = n.contentDescription?.toString()?.take(40) ?: ""
                val id = n.viewIdResourceName?.substringAfter(":id/") ?: ""
                if (t.isEmpty() && d.isEmpty() && id.isEmpty()) continue
                val line = "KB t=[$t] d=[$d] id=[$id]" + (if (n.isClickable) " CLICK" else "")
                if (seen.add(line)) sb.append(line).append("\n")
            }
        }
        return sb.toString()
    }


    /** keyboard (IME) window ke saare nodes: Gboard ka mic yahin milta hai */
    private fun imeNodes(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        try { windows.filter { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }.forEach { w -> walk(w.root) } } catch (_: Exception) {}
        return out
    }

    /** Gboard ka voice-typing mic khud dabao (keyboard khulne ke baad) */
    fun tapKeyboardMic(cb: (Boolean) -> Unit) {
        val alts = listOf("voice typing", "voice input", "microphone", "बोलकर", "आवाज़ से", "आवाज से", "वॉइस")
        retry(8, 400, {
            imeNodes().firstOrNull { nd ->
                nd.isVisibleToUser && (
                    alts.any { a -> nd.contentDescription?.toString()?.lowercase()?.contains(a) == true || nd.text?.toString()?.lowercase()?.contains(a) == true } ||
                    nd.viewIdResourceName?.lowercase()?.contains("voice") == true)
            }?.let { tap(it) } ?: false
        }, cb)
    }

    /** screen par jo text/description match kare use dabao */
    fun tapText(q: String, cb: (Boolean) -> Unit) {
        val alts = q.lowercase().split("|").filter { it.isNotBlank() }   // "a|b|c" = koi bhi ek
        retry(6, 500, {
            all().firstOrNull { nd -> !nd.isEditable && alts.any { a ->
                nd.text?.toString()?.lowercase()?.contains(a) == true || nd.contentDescription?.toString()?.lowercase()?.contains(a) == true } }?.let { tap(it) } ?: false
        }, cb)
    }

    // ---------- Quick Settings tiles (Wi-Fi, Bluetooth, Airplane, Data, Hotspot, DND, Rotate) ----------
    private fun tileState(n: AccessibilityNodeInfo): Boolean? {
        var c: AccessibilityNodeInfo? = n
        var i = 0
        while (c != null && i < 3) {
            if (c.isCheckable) return c.isChecked
            val sd = if (Build.VERSION.SDK_INT >= 30) c.stateDescription?.toString() ?: "" else ""
            val txt = (sd + " " + (c.contentDescription ?: "")).lowercase()
            if (Regex("\\boff\\b").containsMatchIn(txt)) return false
            if (Regex("\\bon\\b").containsMatchIn(txt)) return true
            c = c.parent; i++
        }
        return null
    }

    /** want: 1 = on, 0 = off, -1 = toggle */
    fun toggleTile(labels: String, want: Int, cb: (Boolean) -> Unit) {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        val alts = labels.lowercase().split("|").filter { it.isNotBlank() }
        h.postDelayed({
            retry(8, 500, {
                val nodes = all()
                var hit: AccessibilityNodeInfo? = null
                for (a in alts) {
                    hit = nodes.firstOrNull { nd -> !nd.isEditable && (nd.text?.toString()?.lowercase()?.contains(a) == true ||
                        nd.contentDescription?.toString()?.lowercase()?.contains(a) == true) }
                    if (hit != null) break
                }
                val nd = hit
                if (nd == null) false else {
                    val st = tileState(nd)
                    if (want >= 0 && st != null && st == (want == 1)) true else tap(nd)
                }
            }) { ok -> h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK); cb(ok) }, 500) }
        }, 900)
    }
    /** screen par n-wa item (upar se neeche, phir left se right). q="video" to jis node ke text/description mein "video" ho */
    fun tapNth(n: Int, q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        val dm = resources.displayMetrics
        retry(8, 600, {
            val found = mutableListOf<Pair<Rect, AccessibilityNodeInfo>>()
            for (nd in all()) {
                if (nd.isEditable) continue
                val r = Rect(); nd.getBoundsInScreen(r)
                if (r.isEmpty || r.bottom <= 0 || r.top >= dm.heightPixels || r.right <= 0 || r.left >= dm.widthPixels) continue
                if (r.height() < 120) continue
                val t = ((nd.text ?: "").toString() + " " + (nd.contentDescription ?: "")).lowercase()
                val ok = if (ql.isEmpty()) nd.isClickable else t.contains(ql)
                if (ok) found.add(Pair(r, nd))
            }
            val top = found.filter { a -> found.none { b -> b !== a && b.first != a.first && b.first.contains(a.first) } }
                .sortedWith(compareBy({ it.first.top }, { it.first.left }))
            top.getOrNull(n - 1)?.let { tap(it.second) } ?: false
        }, cb)
    }
    fun typeText(t: String, cb: (Boolean) -> Unit) {
        retry(6, 400, {
            val n = all()
            (n.firstOrNull { it.isFocused && it.isEditable } ?: n.firstOrNull { it.isEditable })?.let { setText(it, t) } ?: false
        }, cb)
    }

    // ---------- kisi bhi app ke andar search ----------
    private fun searchEditable(n: List<AccessibilityNodeInfo>) = n.firstOrNull { e ->
        e.isEditable && listOfNotNull(e.hintText, e.contentDescription, e.viewIdResourceName, e.text).any { it.toString().lowercase().contains("search") }
    }

    fun appSearch(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(6, 500, {
            val n = all()
            val ed = searchEditable(n)
            if (ed != null) { tap(ed); true } else n.firstOrNull { isSearch(it) }?.let { tap(it) } ?: false
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, {
                    val n = all()
                    (n.firstOrNull { it.isFocused && it.isEditable } ?: searchEditable(n) ?: n.firstOrNull { it.isEditable })?.let { setText(it, q) } ?: false
                }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({ submitSearch(ql, cb) }, 900)
                }
            }, 800)
        }
    }

    // ---------- Telegram / chat apps: search karke result (naam) par tap ----------
    fun chatSearch(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(6, 500, {
            val n = all()
            val ed = searchEditable(n)
            if (ed != null) { tap(ed); true } else n.firstOrNull { isSearch(it) }?.let { tap(it) } ?: false
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, {
                    val n = all()
                    (n.firstOrNull { it.isFocused && it.isEditable } ?: searchEditable(n) ?: n.firstOrNull { it.isEditable })?.let { setText(it, q) } ?: false
                }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({ tapChatResult(ql, cb) }, 1300)
                }
            }, 800)
        }
    }

    private fun levA(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) { var prev = dp[0]; dp[0] = i
            for (j in 1..b.length) { val t = dp[j]; dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1); prev = t } }
        return dp[b.length]
    }

    /** result list mein sabse upar wala jo naam se shuru ho (Haris), warna jisme naam aaye.
     *  Pehle us row ki jagah par gesture-tap (Telegram jaise custom rows par ACTION_CLICK akela bharosemand nahi). */
    private fun tapChatResult(ql: String, cb: (Boolean) -> Unit) {
        val word = Regex("^" + Regex.escape(ql) + "(?![\\p{L}\\p{N}])")
        var chosen: AccessibilityNodeInfo? = null
        retry(10, 500, {
            val c = mutableListOf<Triple<Int, String, AccessibilityNodeInfo>>()
            for (nd in all()) {
                if (nd.isEditable || !nd.isVisibleToUser) continue
                val t = listOfNotNull(nd.text, nd.contentDescription).joinToString(" ").lowercase()
                if (!t.contains(ql)) continue
                val r = Rect(); nd.getBoundsInScreen(r)
                if (r.top < 350 || r.isEmpty) continue   // upar ka search box / tabs chhodo
                c.add(Triple(r.top, t, nd))
            }
            val sorted = c.sortedBy { it.first }
            var pick = sorted.firstOrNull { word.containsMatchIn(it.second) } ?: sorted.firstOrNull()
            if (pick == null && ql.length >= 3) {   // naam thoda galat: sabse kareeb wala row
                val lim = maxOf(1, ql.length / 4)
                var bd = 99
                for (nd in all()) {
                    if (nd.isEditable || !nd.isVisibleToUser) continue
                    val t = listOfNotNull(nd.text, nd.contentDescription).joinToString(" ").lowercase()
                    val r = Rect(); nd.getBoundsInScreen(r); if (r.top < 350 || r.isEmpty) continue
                    val d = t.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotBlank() }.minOfOrNull { w -> levA(w, ql) } ?: 99
                    if (d <= lim && d < bd) { bd = d; pick = Triple(r.top, t, nd) }
                }
            }
            if (pick == null) false else {
                val r = Rect(); pick.third.getBoundsInScreen(r)
                chosen = pick.third
                tapXY(r.exactCenterX(), r.exactCenterY()); true
            }
        }) { ok ->
            if (!ok) cb(false) else h.postDelayed({
                // abhi bhi search list khuli hai (chat nahi khuli) to normal click bhi try karo
                val stillSearch = all().any { it.isEditable && (it.text?.toString()?.lowercase()?.contains(ql) == true) }
                if (stillSearch) chosen?.let { tap(it) }
                cb(true)
            }, 1500)
        }
    }

    private fun submitSearch(ql: String, cb: (Boolean) -> Unit) {
        val n = all()
        val ed = n.firstOrNull { it.isFocused && it.isEditable } ?: n.firstOrNull { it.isEditable }
        var ok = false
        if (Build.VERSION.SDK_INT >= 30 && ed != null) ok = ed.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        if (!ok) ok = n.firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { tap(it) } ?: false
        cb(ok)
    }

    // ---------- WhatsApp ----------
    private fun isEntry(n: AccessibilityNodeInfo) = n.isEditable && n.viewIdResourceName?.endsWith("entry") == true

    /** chat khuli ho to pehle back karke chats list par aao (warna compose box mein search type ho jata tha) */
    private fun leaveChat(tries: Int, done: () -> Unit) {
        if (tries > 0 && all().any { isEntry(it) }) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            h.postDelayed({ leaveChat(tries - 1, done) }, 700)
        } else done()
    }

    fun waSearch(q: String, cb: (Boolean) -> Unit) = leaveChat(3) { waSearch2(q, cb) }

    private fun waSearch2(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(8, 500, {
            val n = all(); val s = n.firstOrNull { isSearch(it) }
            if (s != null) { tap(s); true } else n.any { it.isEditable && !isEntry(it) }
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, { all().firstOrNull { it.isEditable && !isEntry(it) }?.let { setText(it, q) } ?: false }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({
                        retry(10, 500, {
                            all().firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { tap(it) } ?: false
                        }, cb)
                    }, 1200)
                }
            }, 800)
        }
    }

    fun sendMsg(t: String, cb: (Boolean) -> Unit) {
        h.postDelayed({
            retry(10, 500, {
                val n = all()
                val e = n.firstOrNull { it.isEditable && it.viewIdResourceName?.endsWith("entry") == true } ?: n.lastOrNull { it.isEditable }
                e?.let { setText(it, t) } ?: false
            }) { ok ->
                if (!ok) cb(false) else h.postDelayed({
                    retry(8, 400, {
                        all().firstOrNull { val c = it.contentDescription?.toString()?.lowercase(); c == "send" || c == "भेजें" || c == "ارسال" }?.let { tap(it) } ?: false
                    }, cb)
                }, 600)
            }
        }, 800)
    }

    // ---------- AI app mein research: sawaal bhejna, jawab poora hone ka intezaar, "Copy" dabana ----------
    private fun label(n: AccessibilityNodeInfo): List<String> =
        listOfNotNull(n.contentDescription, n.text).map { it.toString().lowercase().trim() }

    /** AI app (ChatGPT/Claude/Gemini...) ke message box mein sawaal likh kar Send dabata hai */
    fun askAi(t: String, startDelay: Long = 1200L, cb: (Boolean) -> Unit) {
        val key = t.lowercase().take(25)
        h.postDelayed({
            retry(12, 500, {
                val n = all()
                val e = n.firstOrNull { it.isEditable && it.isFocused } ?: n.lastOrNull { it.isEditable }
                e?.let { setText(it, t) } ?: false
            }) { ok ->
                if (!ok) cb(false) else h.postDelayed({
                    retry(10, 500, {
                        val n = all()
                        // sawaal chala gaya ho (Stop button dikha ya message box khali ho gaya) to Send dobara na dabao
                        val busy = n.any { nd -> label(nd).any { s -> s == "stop" || s.startsWith("stop ") } }
                        val ed = n.firstOrNull { it.isEditable }
                        val cleared = ed != null && ed.text?.toString()?.lowercase()?.contains(key) != true
                        if (busy || cleared) true
                        else n.firstOrNull { nd -> !nd.isEditable && label(nd).any { s -> s == "send" || s.startsWith("send ") || s == "submit" || s == "\u092d\u0947\u091c\u0947\u0902" } }?.let { tap(it) } ?: false
                    }, cb)
                }, 700)
            }
        }, startDelay)
    }

    /**
     * Jawab poora hone tak ruko: screen ka text badalna band ho aur "Stop" button na dikhe (kuch der tak).
     * maxMs ke baad bhi cb(true) - tab bhi Copy try hoga.
     */
    fun waitReplyDone(maxMs: Long, cb: (Boolean) -> Unit) {
        val t0 = System.currentTimeMillis()
        fun sigNow(): Int = all().filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString("|").hashCode()
        val base = sigNow()          // sawaal bhejne ke turant baad ki screen
        var last = base; var same = 0; var changed = false
        val r = object : Runnable {
            override fun run() {
                val n = all()
                val busy = n.any { nd -> label(nd).any { s -> s == "stop" || s.startsWith("stop gen") || s.startsWith("stop stream") || s.startsWith("stop resp") || s == "\u0930\u094b\u0915\u0947\u0902" } }
                val sig = n.filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString("|").hashCode()
                val el = System.currentTimeMillis() - t0
                if (sig != base) changed = true          // naya jawab aana shuru hua
                if (!busy && sig == last && (changed || el > 30000)) same++ else same = 0
                last = sig
                when {
                    same >= 5 && el > 8000 -> cb(true)
                    el > maxMs -> cb(true)
                    else -> h.postDelayed(this, 1200)
                }
            }
        }
        h.postDelayed(r, 4000)
    }

    private fun bigSwipeDown() {
        val m = resources.displayMetrics; val x = m.widthPixels / 2f
        swipe(x, m.heightPixels * 0.80f, x, m.heightPixels * 0.22f)
    }

    /**
     * Jawab ka "Copy" button dabata hai. Lamba jawab ho to jab tak Copy na dikhe neeche scroll karta rehta hai
     * (max ~40 baar). "Copy code" jaise button sirf tab dabata hai jab neeche tak pahunch jaye aur seedha "Copy" na mile.
     */
    fun tapLastCopy(cb: (Boolean) -> Unit) {
        val exact = setOf("copy", "copy message", "copy response", "copy reply", "copy text", "copy answer", "\u0915\u0949\u092a\u0940")
        var tries = 0; var lastSig = 0; var still = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val n = all()
                val copies = n.filter { nd -> !nd.isEditable && label(nd).any { it.length < 24 && (it in exact || it.startsWith("copy") || it.startsWith("\u0915\u0949\u092a\u0940")) } }
                fun top(nd: AccessibilityNodeInfo): Int { val rc = Rect(); nd.getBoundsInScreen(rc); return rc.top }
                val exactHit = copies.filter { nd -> label(nd).any { it in exact } }.maxByOrNull { top(it) }
                val sig = n.filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString("|").hashCode()
                still = if (sig == lastSig) still + 1 else 0
                lastSig = sig
                val atEnd = still >= 2
                val hit = exactHit ?: if (atEnd) copies.maxByOrNull { top(it) } else null
                if (hit != null && tap(hit)) { cb(true); return }
                if (tries >= 40 || still >= 5) { cb(false); return }
                if (tries % 2 == 1) bigSwipeDown() else scroll(true)
                h.postDelayed(this, 900)
            }
        }
        r.run()
    }

    // ---------- the target app's own window (our floating panel may be the "active" window / may cover the app) ----------
    private val fbPk = setOf("com.facebook.katana", "com.facebook.lite")
    private val waPk = setOf("com.whatsapp", "com.whatsapp.w4b")

    /** nodes of the windows that belong to the given apps (popup menus included); falls back to the active window */
    private fun appNodes(pkgs: Set<String>): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        try { for (w in windows) { val r = w.root ?: continue; if (r.packageName?.toString() in pkgs) walk(r) } } catch (_: Exception) {}
        return if (out.isEmpty()) all() else out
    }
    private fun fbAll() = appNodes(fbPk)
    private fun waAll() = appNodes(waPk)

    /** on screen: visible, or at least has real bounds inside the screen (a node under our overlay can report not-visible) */
    private fun shown(n: AccessibilityNodeInfo): Boolean {
        if (n.isVisibleToUser) return true
        val r = Rect(); n.getBoundsInScreen(r)
        val dm = resources.displayMetrics
        return !r.isEmpty && r.right > 0 && r.bottom > 0 && r.left < dm.widthPixels && r.top < dm.heightPixels
    }

    // ---------- WhatsApp Channel post: Updates tab -> channel -> paste -> send ----------
    /** what waOpenUpdates saw in the bottom bar on its last try (shown in the failure message) */
    var waDiag: String = ""

    /**
     * bottom tab "Updates" (older WhatsApp: "Status"; WhatsApp Business: Chats/Calls/Updates/Tools).
     * 1) bottom-bar node whose label is/starts with/contains updates|status (also with a badge, e.g. "Updates, 1 new")
     * 2) fallback: in the bottom bar (Chats + Calls visible) tap the one tab that is none of the known others
     * Backs out of a chat / channel page if the bottom bar is not visible.
     */
    fun waOpenUpdates(cb: (Boolean) -> Unit) {
        val alts = Labels.list(this@NotchA11y, "wa_updates")
        val others = listOf("chats", "chat", "calls", "call", "communities", "community", "you", "tools", "settings", "camera")
        fun isOther(l: String) = others.any { l == it || l.startsWith("$it,") || l.startsWith("$it ") }
        fun isAlt(l: String) = l.length < 40 && alts.any { l == it || l.startsWith(it) || l.contains(it) }
        var tries = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = waAll()
                val hgt = resources.displayMetrics.heightPixels
                fun rect(nd: AccessibilityNodeInfo): Rect { val rc = Rect(); nd.getBoundsInScreen(rc); return rc }
                fun inBottom(nd: AccessibilityNodeInfo) = rect(nd).let { !it.isEmpty && it.top > hgt * 0.72 }
                val visible = nodes.filter { !it.isEditable && shown(it) }
                val bottom = visible.filter { inBottom(it) }
                val byLabel = { list: List<AccessibilityNodeInfo> -> list.firstOrNull { nd -> label(nd).any { isAlt(it) } } }
                val byId = bottom.firstOrNull { nd -> nd.viewIdResourceName?.lowercase()?.let { it.contains("updates") || it.contains("status_tab") } == true }
                var hit = byLabel(bottom) ?: byId
                // fallback: nav bar recognised by Chats + Calls, tap the unknown tab
                val bl = bottom.flatMap { nd -> label(nd).filter { it.length in 2..24 && it.any { c -> c.isLetter() } }.map { nd to it } }
                waDiag = bl.map { it.second }.distinct().take(10).joinToString(", ").ifBlank { "no bottom bar visible" }
                if (hit == null) {
                    val known = bl.count { isOther(it.second) }
                    if (known >= 2) hit = bl.filter { !isOther(it.second) }.minByOrNull { rect(it.first).left }?.first
                }
                // last resort: any visible Updates/Status label (e.g. tab without bounds in the bottom area)
                if (hit == null && bottom.none { nd -> label(nd).any { isOther(it) } }) hit = byLabel(visible)
                if (hit != null && tap(hit)) { cb(true); return }
                if (tries >= 14) { cb(false); return }
                if (tries == 3 || tries == 6 || tries == 9 || tries == 12) performGlobalAction(GLOBAL_ACTION_BACK)
                h.postDelayed(this, 600)
            }
        }
        r.run()
    }

    // ---------- Facebook post: feed composer -> paste -> Post ----------
    /** what the Facebook helpers saw on screen on their last try (shown in failure messages) */
    var fbDiag: String = ""

    private val fbComposerL: List<String> get() = Labels.list(this, "fb_composer")
    private val fbPostL: Set<String> get() = Labels.list(this, "fb_post").toSet()

    private fun isSearchBox(nd: AccessibilityNodeInfo): Boolean =
        label(nd).any { it.contains("search") } || nd.viewIdResourceName?.lowercase()?.contains("search") == true ||
            (Build.VERSION.SDK_INT >= 26 && nd.hintText?.toString()?.lowercase()?.contains("search") == true)
    private fun composerOpen(nodes: List<AccessibilityNodeInfo>) = nodes.any { it.isEditable && shown(it) && !isSearchBox(it) }
    private fun searchOpen(nodes: List<AccessibilityNodeInfo>) = nodes.any { it.isEditable && shown(it) && isSearchBox(it) }
    /** nodes of every window (a popup menu is a window of its own) */
    private fun allWindows(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        try { windows.forEach { w -> walk(w.root) } } catch (_: Exception) {}
        return if (out.isEmpty()) fbAll() else out
    }

    /**
     * Gets to the "write a post" screen. Order: composer already open -> "What's on your mind?" box (Feed) ->
     * Feed / Home tab (by name, else by position: Facebook may open on Reels) -> top "+" button (by name, else by
     * position) -> "Post" in the menu that appears. Leaves a search screen with Back. Never presses Back while the
     * composer is open. A box tap is tried as a normal click, then as a screen tap.
     */
    fun fbOpenComposer(cb: (Boolean) -> Unit) {
        var tries = 0; var plusAt = -99; var feedTaps = 0; var clicks = 0; var tabTries = 0; var plusTries = 0
        val menuPostL = Labels.list(this@NotchA11y, "fb_menu_post").toSet()
        val homeL = Labels.list(this@NotchA11y, "fb_home_tab")
        val createL = Labels.list(this@NotchA11y, "fb_create")
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = fbAll()
                if (composerOpen(nodes)) { cb(true); return }
                if (tries < 45 && fbDismissPopup(nodes)) { h.postDelayed(this, 1200); return }
                val dm = resources.displayMetrics
                val wid = dm.widthPixels; val hgt = dm.heightPixels
                fun rc(nd: AccessibilityNodeInfo): Rect { val x = Rect(); nd.getBoundsInScreen(x); return x }
                val vis = nodes.filter { !it.isEditable && shown(it) }
                val topBar = vis.filter { val x = rc(it); !x.isEmpty && x.top < hgt * 0.17 && x.width() < wid * 0.5 }
                // what is really up there: small items left to right, name (or id) @ x%,y%
                val dump = vis.filter { val x = rc(it); !x.isEmpty && x.width() < wid * 0.3 && x.top < hgt * 0.2 }.sortedBy { rc(it).left }.take(12).map { nd ->
                    val x = rc(nd)
                    (label(nd).firstOrNull()?.take(18) ?: nd.viewIdResourceName?.substringAfterLast('/')?.take(18) ?: nd.className?.toString()?.substringAfterLast('.')?.take(10) ?: "?") +
                        "@" + (x.centerX() * 100 / wid) + "," + (x.centerY() * 100 / hgt) }
                val bodyL = vis.filter { rc(it).top >= hgt * 0.17 }.flatMap { label(it) }.filter { it.length in 3..30 && it.any { c -> c.isLetter() } }.distinct().take(5)
                fbDiag = "header: " + dump.joinToString("; ").ifBlank { "-" } + " | screen: " + bodyL.joinToString(", ").ifBlank { "-" }

                // 0) a search screen opened by mistake
                if (searchOpen(nodes)) { performGlobalAction(GLOBAL_ACTION_BACK); h.postDelayed(this, 1200); return }
                // 1) "What's on your mind?" box
                val box = vis.firstOrNull { nd -> label(nd).any { l -> l.length < 60 && fbComposerL.any { l.contains(it) } } }
                if (box != null) {
                    clicks++
                    if (clicks % 2 == 1) tap(box) else { val x = rc(box); if (!x.isEmpty) tapXY(x.exactCenterX(), x.exactCenterY()) }
                    if (tries >= 45) { cb(false); return }
                    h.postDelayed(this, 1500); return
                }
                // 2) "+" was tapped a moment ago -> the menu (own window) offers Post / Story / Reel / Live
                if (tries - plusAt in 1..9) {
                    val opt = allWindows().firstOrNull { nd -> shown(nd) && !nd.isEditable && label(nd).any { it in menuPostL } }
                    if (opt != null && tap(opt)) { h.postDelayed(this, 1500); return }
                }
                if (tries >= 45) { cb(false); return }
                // 3a) Feed / Home tab by name
                if (feedTaps < 2 && tries >= 2) {
                    val named = topBar.firstOrNull { nd -> (nd.isClickable || label(nd).any { it.contains("tab") }) && label(nd).any { l -> homeL.any { w -> l.startsWith(w) } } }
                    val reelsFirst = topBar.any { nd -> label(nd).any { it.startsWith("reels") || it.startsWith("video") } }
                    val tab = named ?: if (reelsFirst) topBar.firstOrNull { nd -> label(nd).any { it.contains("tab 2 of") } } else null
                    if (tab != null) { feedTaps++; tap(tab); h.postDelayed(this, 1800); return }
                }
                // 3b) tab icons have no readable name: tap by position (6 equal tabs, y~13%): 2nd = Feed (Reels-first bar), then 1st = Home
                if (feedTaps == 0 && tries >= 3 && tabTries < 4) {
                    val idx = if (tabTries % 2 == 0) 1 else 0
                    tapXY((idx + 0.5f) * wid / 6f, hgt * 0.132f); tabTries++
                    h.postDelayed(this, 2000); return
                }
                // 4a) top "+" (Create) by name
                if (tries >= 4 && tries - plusAt > 10) {
                    val plus = topBar.firstOrNull { nd -> label(nd).any { l -> (createL.any { w -> l.contains(w) } || l == "plus" || l == "add") && !l.contains("story") } }
                    if (plus != null) { plusAt = tries; tap(plus); h.postDelayed(this, 1500); return }
                }
                // 4b) "+" by position: it is the 1st (Feed/Home) or the 2nd (Reels) of the three icons at the top right
                if (tries >= 14 && tries - plusAt > 10 && plusTries < 4) {
                    tapXY(wid * (if (plusTries % 2 == 0) 0.675f else 0.80f), hgt * 0.0757f); plusAt = tries; plusTries++
                    h.postDelayed(this, 1500); return
                }
                if (tries % 4 == 0) scroll(false)
                h.postDelayed(this, 700)
            }
        }
        r.run()
    }

    private val fbDismissL: List<String> get() = Labels.list(this, "fb_dismiss")

    /** Facebook pops up suggestions in between ("Add WhatsApp button", notifications, ...): press Not now / Skip. true if one was pressed */
    private fun fbDismissPopup(nodes: List<AccessibilityNodeInfo>): Boolean {
        val hit = nodes.firstOrNull { nd -> nd.isEnabled && shown(nd) && !nd.isEditable &&
            label(nd).any { l -> l.length < 30 && fbDismissL.any { w -> l == w || l.startsWith("$w,") || l.startsWith("$w.") } } } ?: return false
        return tap(hit)
    }

    /** the write-a-post screen is open when a visible message box is on screen */
    fun fbComposerReady(cb: (Boolean) -> Unit) = retry(30, 800, { val n = fbAll(); if (!composerOpen(n)) fbDismissPopup(n); composerOpen(n) }, cb)

    /**
     * Publishing: composer -> [Post / Next] -> (share screen) -> [Share] -> feed. Works on a slow network: every button is
     * pressed only once it is enabled, and each step waits (up to ~60 s in total) for the next screen to load.
     * true when the feed is back after the last button (or the share screen is gone); false on timeout.
     */
    fun fbTapPost(cb: (Boolean) -> Unit) {
        var tries = 0; var stage = 0; var lastTap = -99; var gone = 0
        val shareWords = Labels.list(this@NotchA11y, "fb_share").toSet()
        val nextWords = Labels.list(this@NotchA11y, "fb_next").toSet()
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = fbAll()
                if (tries < 75 && fbDismissPopup(nodes)) { h.postDelayed(this, 1200); return }   // e.g. "Add WhatsApp button" -> Not now
                val hgt = resources.displayMetrics.heightPixels
                val editing = composerOpen(nodes)
                val vis = nodes.filter { !it.isEditable && shown(it) }
                val on = vis.filter { it.isEnabled }
                fun topOf(nd: AccessibilityNodeInfo): Int { val x = Rect(); nd.getBoundsInScreen(x); return x.top }
                val onFeed = vis.any { nd -> label(nd).any { l -> l == "create story" || (l.length < 60 && fbComposerL.any { l.contains(it) }) } }
                fun shareBtn() = on.firstOrNull { nd -> topOf(nd) < hgt * 0.25 && label(nd).any { it in shareWords || it in fbPostL } }
                    ?: on.firstOrNull { nd -> label(nd).any { it == "share now" } }
                fun postBtn() = on.firstOrNull { nd -> label(nd).any { it in fbPostL || it in nextWords } }
                when (stage) {
                    0 -> if (editing) {
                        val b = postBtn()
                        if (b != null && tries - lastTap >= 3 && tap(b)) { stage = 1; lastTap = tries }
                    }
                    1 -> if (editing) {
                        // still on the composer: the button was not ready yet (slow network) -> press again after a while
                        val b = postBtn()
                        if (b != null && tries - lastTap >= 6 && tap(b)) lastTap = tries
                    } else if (onFeed) { cb(true); return }          // Post published straight away
                    else {
                        val b = shareBtn()
                        if (b != null && tries - lastTap >= 2 && tap(b)) { stage = 2; lastTap = tries }
                    }
                    else -> {
                        if (!editing && onFeed) { cb(true); return }
                        val b = shareBtn()
                        if (b == null) { gone++; if (gone >= 3) { cb(true); return } }
                        else { gone = 0; if (tries - lastTap >= 10 && tap(b)) lastTap = tries }   // Share still there: press again
                    }
                }
                if (tries >= 75) { cb(stage >= 2); return }
                h.postDelayed(this, 800)
            }
        }
        r.run()
    }

    // ---------- WhatsApp: forward the newest channel post to My status ----------
    /** what waShareLastToStatus saw on its last try (shown in the failure message) */
    var waShDiag: String = ""

    private fun isOn(nd: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = nd; var i = 0
        while (c != null && i < 5) { if (c.isChecked || c.isSelected) return true; c = c.parent; i++ }
        return false
    }

    /**
     * Channel page (new post at the bottom) -> Forward button under the newest post -> "Forward to..." -> My status -> Send.
     * The forward button is only trusted when it sits right above the message box, so a slow upload can never make it
     * forward the previous post. true once the Forward screen is gone.
     */
    fun waShareLastToStatus(cb: (Boolean) -> Unit) {
        val hgt = resources.displayMetrics.heightPixels
        var tries = 0; var stage = 0; var lastTap = -99; var statusTaps = 0; var gone = 0
        val fwL = Labels.list(this@NotchA11y, "wa_forward")
        val myL = Labels.list(this@NotchA11y, "wa_my_status")
        fun rc(nd: AccessibilityNodeInfo): Rect { val x = Rect(); nd.getBoundsInScreen(x); return x }
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = waAll()
                val vis = nodes.filter { !it.isEditable && shown(it) }
                val onForward = vis.any { nd -> label(nd).any { it.startsWith("forward to") } }
                if (stage == 0 && onForward) stage = 1
                if (stage == 0) {
                    val comp = nodes.firstOrNull { it.isEditable && shown(it) }
                    val compTop = comp?.let { rc(it).top } ?: (hgt * 0.9).toInt()
                    val fw = vis.filter { nd -> val x = rc(nd); x.top > hgt * 0.15 && x.bottom <= compTop + 12 &&
                        label(nd).any { l -> l.length < 30 && fwL.any { w -> l.contains(w) } && !l.startsWith("forward to") } }
                    val last = fw.maxByOrNull { rc(it).bottom }
                    waShDiag = if (last == null) "no Forward button on screen" else "Forward button found, ${if (rc(last).bottom >= compTop - hgt * 0.09) "tapping" else "waiting for the new post to appear"}"
                    if (last != null && rc(last).bottom >= compTop - hgt * 0.09 && tries - lastTap >= 3 && tap(last)) lastTap = tries
                } else if (stage == 1) {
                    val row = vis.firstOrNull { nd -> label(nd).any { l -> myL.any { w -> l.startsWith(w) } } }
                    val send = vis.firstOrNull { nd -> nd.isEnabled && label(nd).any { it == "send" || it.startsWith("send") } }
                    waShDiag = if (!onForward) "Forward screen closed early" else if (row == null) "My status row not found" else "My status tapped, waiting for Send"
                    if (send != null && statusTaps > 0) { if (tap(send)) { stage = 2; lastTap = tries } }
                    else if (row != null && (statusTaps == 0 || (statusTaps < 3 && tries - lastTap >= 6 && send == null && !isOn(row)))) {
                        tap(row); statusTaps++; lastTap = tries
                    }
                } else {
                    if (!onForward) { gone++; if (gone >= 2) { cb(true); return } }
                    else { gone = 0; waShDiag = "Send pressed but the Forward screen is still open"
                        val send = vis.firstOrNull { nd -> nd.isEnabled && label(nd).any { it == "send" || it.startsWith("send") } }
                        if (send != null && tries - lastTap >= 12 && tap(send)) lastTap = tries }
                }
                if (tries >= 50) { cb(false); return }
                h.postDelayed(this, 800)
            }
        }
        r.run()
    }

    // ---------- auto dump, profile switching, shared photos ----------
    /** a post flow failed: keep what the screen looked like (Settings L2 copies it, like D1) */
    fun saveFailDump(tag: String) { try { Labels.saveDump(this, tag, dump()) } catch (_: Exception) {} }

    /** the New post screen names who posts: true when the profile / Page name is on screen (blank name = nothing to check) */
    fun fbShowsName(name: String): Boolean {
        val w = name.trim().lowercase()
        if (w.isEmpty()) return true
        return fbAll().any { nd -> shown(nd) && !nd.isEditable && label(nd).any { it.contains(w) } }
    }

    /**
     * Switches the Facebook app to another profile / Page: Menu tab -> profile switcher -> the wanted name.
     * Best effort (the switcher button's name is in Settings L1: fb_switcher). true after the list item was pressed.
     */
    fun fbSwitchProfile(name: String, cb: (Boolean) -> Unit) {
        val want = name.trim().lowercase()
        val menuL = Labels.list(this, "fb_menu_tab")
        val swL = Labels.list(this, "fb_switcher")
        var tries = 0; var stage = 0; var lastTap = -99; var swTaps = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = fbAll()
                if (tries < 50 && fbDismissPopup(nodes)) { h.postDelayed(this, 1200); return }
                val vis = nodes.filter { !it.isEditable && shown(it) }
                fbDiag = "switch: " + vis.flatMap { label(it) }.filter { it.length in 3..40 }.distinct().take(14).joinToString(", ")
                when (stage) {
                    0 -> {
                        val tab = vis.firstOrNull { nd -> label(nd).any { l -> l.contains("tab") && menuL.any { w -> l.startsWith(w) } } }
                        if (tab != null && tap(tab)) { stage = 1; lastTap = tries }
                    }
                    1 -> if (tries - lastTap >= 2) {
                        val sw = vis.firstOrNull { nd -> label(nd).any { l -> l.length < 60 && swL.any { w -> l.contains(w) } } }
                        if (sw != null && tap(sw)) { stage = 2; lastTap = tries; swTaps++ }
                    }
                    2 -> {
                        val row = vis.firstOrNull { nd -> label(nd).any { it.contains(want) } }
                        if (row != null && tap(row)) { stage = 3; lastTap = tries }
                        else if (tries - lastTap >= 8 && swTaps < 2) stage = 1
                    }
                    else -> if (tries - lastTap >= 4) { cb(true); return }
                }
                if (tries >= 50) { cb(false); return }
                h.postDelayed(this, 900)
            }
        }
        r.run()
    }

    /** after a photo was shared to Facebook: reach the write-a-post screen (popups away; "where to post" -> Feed) */
    fun fbShareReady(cb: (Boolean) -> Unit) {
        val feedL = Labels.list(this, "fb_share_target")
        var tries = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = fbAll()
                if (composerOpen(nodes)) { cb(true); return }
                if (tries < 40 && fbDismissPopup(nodes)) { h.postDelayed(this, 1200); return }
                val opt = nodes.firstOrNull { nd -> shown(nd) && !nd.isEditable && label(nd).any { l -> l.length < 40 && feedL.any { w -> l == w || l.startsWith("$w,") } } }
                if (opt != null && tries >= 3 && tap(opt)) { h.postDelayed(this, 1500); return }
                if (tries >= 40) { cb(false); return }
                h.postDelayed(this, 800)
            }
        }
        r.run()
    }

    /**
     * WhatsApp "Send to..." screen after a shared photo: search the channel, select it, press Send.
     * true when the caption screen (a message box that is not a search box) is up.
     */
    fun waPickChannelForShare(cname: String, cb: (Boolean) -> Unit) {
        val want = cname.trim().lowercase()
        val searchL = Labels.list(this, "wa_search")
        var tries = 0; var stage = 0; var lastTap = -99
        val r = object : Runnable {
            override fun run() {
                tries++
                val vis = waAll().filter { shown(it) }
                val edit = vis.firstOrNull { it.isEditable }
                waDiag = vis.flatMap { label(it) }.filter { it.length in 3..30 }.distinct().take(10).joinToString(", ")
                when (stage) {
                    0 -> if (edit != null && isSearchBox(edit)) { stage = 1 } else {
                        val s = vis.firstOrNull { nd -> !nd.isEditable && label(nd).any { l -> l.length < 30 && searchL.any { w -> l.contains(w) } } }
                        if (s != null && tap(s)) { stage = 1; lastTap = tries }
                    }
                    1 -> if (edit != null) { setText(edit, cname); stage = 2; lastTap = tries } else if (tries - lastTap >= 4) stage = 0
                    2 -> {
                        val row = vis.firstOrNull { nd -> !nd.isEditable && label(nd).any { it.contains(want) } }
                        if (row != null && tries - lastTap >= 2 && tap(row)) { stage = 3; lastTap = tries }
                    }
                    3 -> {
                        val send = vis.firstOrNull { nd -> nd.isEnabled && !nd.isEditable && label(nd).any { it == "send" || it.startsWith("send") } }
                        if (send != null && tries - lastTap >= 2 && tap(send)) { stage = 4; lastTap = tries }
                    }
                    else -> if (edit != null && !isSearchBox(edit) && tries - lastTap >= 2) { cb(true); return }
                }
                if (tries >= 45) { cb(false); return }
                h.postDelayed(this, 900)
            }
        }
        r.run()
    }

    /** channel row in the Updates tab: exact name first, then partial; scrolls the list while searching */
    fun waOpenChannel(name: String, cb: (Boolean) -> Unit) {
        val ql = name.lowercase().trim()
        var tries = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = waAll()
                val hit = nodes.firstOrNull { nd -> !nd.isEditable && label(nd).any { it == ql } }
                    ?: nodes.firstOrNull { nd -> !nd.isEditable && label(nd).any { it.contains(ql) } }
                if (hit != null && tap(hit)) { cb(true); return }
                if (tries >= 16) { cb(false); return }
                scroll(tries < 9)
                h.postDelayed(this, 900)
            }
        }
        h.postDelayed(r, 600)
    }

    /** channel page is open when a message box (editable) is on screen */
    fun waChannelReady(cb: (Boolean) -> Unit) = retry(10, 600, { waAll().any { it.isEditable } }, cb)

    private fun composer(): AccessibilityNodeInfo? {
        var n = all()
        if (n.none { it.isEditable }) n = appNodes(fbPk + waPk)
        return n.firstOrNull { isEntry(it) } ?: n.firstOrNull { it.isFocused && it.isEditable } ?: n.lastOrNull { it.isEditable }
    }

    private fun hasRealText(e: AccessibilityNodeInfo?): Boolean {
        if (e == null) return false
        e.refresh()
        if (Build.VERSION.SDK_INT >= 26 && e.isShowingHintText) return false
        return (e.text?.length ?: 0) > 0
    }

    /** pastes the clipboard (the copied AI answer) into the message box */
    fun pasteClip(cb: (Boolean) -> Unit) {
        h.postDelayed({
            retry(8, 500, {
                val e = composer()
                if (e == null) false else {
                    e.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    e.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    e.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                    true
                }
            }) { found ->
                if (!found) cb(false) else h.postDelayed({
                    val e = composer()
                    if (hasRealText(e)) cb(true) else {
                        val clip = try { (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() } catch (_: Exception) { null }
                        if (e != null && !clip.isNullOrBlank()) cb(setText(e, clip)) else cb(false)
                    }
                }, 800)
            }
        }, 800)
    }

    /** presses the Send button; true once the message box is empty again (or Send was pressed) */
    fun tapSend(cb: (Boolean) -> Unit) {
        val sendL = setOf("send", "\u092d\u0947\u091c\u0947\u0902", "\u0627\u0631\u0633\u0627\u0644")
        retry(10, 500, {
            waAll().firstOrNull { nd -> !nd.isEditable && label(nd).any { it in sendL || it.startsWith("send ") } }?.let { tap(it) } ?: false
        }) { ok -> if (!ok) cb(false) else h.postDelayed({ cb(true) }, 1500) }
    }
}
