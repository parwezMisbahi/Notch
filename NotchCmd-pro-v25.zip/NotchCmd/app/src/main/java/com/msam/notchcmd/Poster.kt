package com.msam.notchcmd

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.util.Random

/** Poster (image post) settings. */
object PosterPrefs {
    private fun p(c: Context) = c.getSharedPreferences("poster", Context.MODE_PRIVATE)

    /** every Facebook / channel / everywhere post gets a poster image (a command word like "image" does it for one post) */
    fun always(c: Context): Boolean = p(c).getBoolean("always", false)
    fun toggleAlways(c: Context): Boolean { val n = !always(c); p(c).edit().putBoolean("always", n).apply(); return n }

    /** small line at the bottom of the poster; empty = your channel name */
    fun footer(c: Context): String = (p(c).getString("footer", "") ?: "").trim().ifBlank { ChannelPrefs.name(c) }
    fun hasFooter(c: Context): Boolean = (p(c).getString("footer", "") ?: "").isNotBlank()
    fun setFooter(c: Context, v: String) { p(c).edit().putString("footer", v.trim()).apply() }

    /** added to the AI prompt so the answer starts with a short poster line */
    const val PROMPT_SUFFIX = "\n\nFormat of your answer: the first line is a short poster headline (maximum 10 words, plain text, no quotes, no emojis, no markdown). Then one empty line. Then the full post text."
}

object PosterBus {
    /** called by PosterActivity with the poster picture (null = could not make it) */
    @Volatile var onDone: ((Uri?) -> Unit)? = null
}

object Poster {
    class Result(val uri: Uri, val caption: String)

    private val palettes = arrayOf(
        intArrayOf(0xFF0B3D2E.toInt(), 0xFF1E8A63.toInt()),   // green
        intArrayOf(0xFF0D1B3E.toInt(), 0xFF2F5FB3.toInt()),   // navy
        intArrayOf(0xFF4A0E1E.toInt(), 0xFFB5424F.toInt()),   // maroon
        intArrayOf(0xFF123B45.toInt(), 0xFF2A9D8F.toInt()),   // teal
        intArrayOf(0xFF2B1B3F.toInt(), 0xFF7B4FB0.toInt()),   // purple
        intArrayOf(0xFF1F1F24.toInt(), 0xFF5A5A66.toInt())    // charcoal
    )

    private fun clean(s: String): String =
        s.replace(Regex("[*#_`>]+"), "").replace("\u201c", "").replace("\u201d", "").replace("\"", "")
            .replace(Regex("(?i)^\\s*(headline|title|poster( line)?|caption)\\s*[:\\-]\\s*"), "").trim()

    /** first line = poster headline, the rest = caption (no separate caption -> the whole text is the caption) */
    fun split(text: String): Pair<String, String> {
        val t = text.trim()
        val lines = t.lines()
        val first = clean(lines.firstOrNull() ?: "")
        val rest = lines.drop(1).joinToString("\n").trim()
        if (first.isNotBlank() && rest.isNotBlank() && first.length <= 120) return Pair(first, rest)
        val head = clean(t.split(Regex("(?<=[.!?\\u0964\\u06d4])\\s")).firstOrNull() ?: t).take(110)
        return Pair(head, t)
    }

    fun make(c: Context, text: String): Result? {
        return try {
            val (head, caption) = split(text)
            if (head.isBlank()) return null
            val size = 1080
            val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bm)
            val pal = palettes[Random(System.nanoTime()).nextInt(palettes.size)]
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            bg.shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), pal[0], pal[1], Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bg)
            val line = Paint(Paint.ANTI_ALIAS_FLAG)
            line.style = Paint.Style.STROKE; line.strokeWidth = 4f; line.color = 0x66FFFFFF
            cv.drawRoundRect(RectF(40f, 40f, size - 40f, size - 40f), 36f, 36f, line)

            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
            tp.color = Color.WHITE
            tp.typeface = Typeface.DEFAULT_BOLD
            val maxW = 880
            val maxH = 700
            var px = 104f
            tp.textSize = px
            var lay = StaticLayout.Builder.obtain(head, 0, head.length, tp, maxW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 1.15f).build()
            while (lay.height > maxH && px > 36f) {
                px -= 4f
                tp.textSize = px
                lay = StaticLayout.Builder.obtain(head, 0, head.length, tp, maxW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 1.15f).build()
            }
            cv.save()
            cv.translate((size - maxW) / 2f, (size - lay.height) / 2f - 20f)
            lay.draw(cv)
            cv.restore()

            val foot = PosterPrefs.footer(c)
            if (foot.isNotBlank()) {
                val fp = TextPaint(Paint.ANTI_ALIAS_FLAG)
                fp.color = 0xCCFFFFFF.toInt(); fp.textSize = 38f; fp.textAlign = Paint.Align.CENTER
                cv.drawLine(size / 2f - 90f, size - 150f, size / 2f + 90f, size - 150f, line)
                cv.drawText(foot.take(40), size / 2f, size - 95f, fp)
            }

            val out = java.io.ByteArrayOutputStream()
            bm.compress(Bitmap.CompressFormat.JPEG, 92, out)
            val bytes = out.toByteArray()
            val dir = File(c.cacheDir, "share").apply { mkdirs() }
            val name = "poster_" + System.currentTimeMillis() + ".jpg"
            File(dir, name).writeBytes(bytes)
            Plugins.saveToGallery(c, bytes, "image/jpeg", "poster_" + System.currentTimeMillis())
            Result(Uri.parse("content://com.msam.notchcmd.share/" + name), caption)
        } catch (_: Throwable) { null }
    }
}

/**
 * Transparent Activity: while it is in front it may read the clipboard (a background service may not).
 * Reads the copied AI answer, draws the poster from its first line, puts the caption back on the clipboard.
 */
class PosterActivity : Activity() {
    private var started = false
    override fun onCreate(b: Bundle?) { super.onCreate(b) }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || started) return
        started = true
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val text = try { cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() } catch (_: Exception) { null }
        if (text.isNullOrBlank()) { deliver(null, null); return }
        Thread {
            val r = Poster.make(this, text)
            Handler(Looper.getMainLooper()).post { deliver(r, cm) }
        }.start()
    }

    private fun deliver(r: Poster.Result?, cm: ClipboardManager?) {
        if (r != null && cm != null) {
            try { cm.setPrimaryClip(ClipData.newPlainText("post", r.caption)) } catch (_: Exception) {}
        }
        val cb = PosterBus.onDone
        PosterBus.onDone = null
        finish()
        cb?.invoke(r?.uri)
    }
}
