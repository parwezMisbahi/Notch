package com.msam.notchcmd

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.os.SystemClock

/**
 * Work View: while ZOKI works inside another app (ChatGPT etc.) a full-screen ZOKI card covers that app.
 * The app keeps running underneath (accessibility actions do not care about the cover); the user only sees
 * ZOKI's own action log: "ChatGPT opened", the picture it made, the script/caption text, "Posted".
 * The cover is NOT touchable, so our own accessibility gestures pass straight through it.
 * A small separate Stop button stays touchable.
 */
object WorkView {
    const val PREF = "n"
    const val KEY = "work_view"
    @Volatile var appCtx: Context? = null
    /** set by OverlayService: stops the running command */
    @Volatile var onStop: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var stopBtn: TextView? = null
    private var wm: WindowManager? = null
    private var logBox: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var titleV: TextView? = null
    private var subV: TextView? = null
    private var barFill: View? = null
    private var barBack: FrameLayout? = null
    private var infoV: TextView? = null
    private var th: Style.T? = null
    private val hideRun = Runnable { remove() }

    // progress / time left: learned from earlier runs of the same command
    private var t0 = 0L
    private var estMs = 45_000L
    private var key = ""
    private var steps = 0
    private var finished = false
    private val tick = object : Runnable {
        override fun run() { if (root == null || finished) return; refresh(); main.postDelayed(this, 500) }
    }

    fun enabled(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(KEY, true)
    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    private fun type(): Int = if (NotchA11y.inst != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private fun mix(a: Int, b: Int, f: Float): Int {
        fun ch(x: Int, s: Int) = (x shr s) and 255
        fun m(s: Int) = (ch(a, s) + (ch(b, s) - ch(a, s)) * f).toInt()
        return (0xFF shl 24) or (m(16) shl 16) or (m(8) shl 8) or m(0)
    }
    private fun keyOf(cmd: String) = cmd.trim().lowercase().split(Regex("\\s+")).take(2).joinToString(" ")

    /** called when a chat command starts */
    fun start(cmd: String = "") {
        val c = appCtx ?: return
        if (!enabled(c)) return
        main.post {
            main.removeCallbacks(hideRun); main.removeCallbacks(tick)
            key = keyOf(cmd); steps = 0; finished = false; t0 = SystemClock.elapsedRealtime()
            estMs = c.getSharedPreferences("workview_eta", Context.MODE_PRIVATE).getLong(key, 45_000L).coerceIn(8_000L, 600_000L)
            if (root == null) build(c) else { logBox?.removeAllViews(); stopBtn?.visibility = View.VISIBLE; titleV?.text = "ZOKI" }
            refresh(); main.postDelayed(tick, 500)
        }
    }

    private fun build(c: Context) {
        try {
            val a11 = NotchA11y.inst
            val ctx: Context = a11 ?: c
            val w = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val t = Style.theme(c); th = t
            // the same look as the chat screen: its background gradient, 100% opaque
            val r = FrameLayout(ctx).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(t.bg1 or (0xFF shl 24), t.bg2 or (0xFF shl 24)))
            }
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 18), dp(c, 52), dp(c, 18), dp(c, 24)) }
            val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val icon = ImageView(ctx).apply { setImageResource(R.drawable.ic_robot_mono); setColorFilter(t.stroke) }
            head.addView(icon, LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)))
            val tc = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 12), 0, 0, 0) }
            val title = TextView(ctx).apply { text = "ZOKI"; setTextColor(t.stroke); textSize = 24f }
            val sub = TextView(ctx).apply { text = "Working inside another app"; setTextColor(t.sub); textSize = 13f }
            tc.addView(title); tc.addView(sub); head.addView(tc)
            col.addView(head)

            // progress bar + info line
            val back = FrameLayout(ctx).apply { background = GradientDrawable().apply { cornerRadius = dp(c, 6).toFloat(); setColor(mix(t.bg2, if (t.light) Color.BLACK else Color.WHITE, 0.15f)) } }
            val fill = View(ctx).apply { background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1 or (0xFF shl 24), t.a2 or (0xFF shl 24))).apply { cornerRadius = dp(c, 6).toFloat() } }
            back.addView(fill, FrameLayout.LayoutParams(0, -1))
            col.addView(back, LinearLayout.LayoutParams(-1, dp(c, 10)).apply { topMargin = dp(c, 18) })
            val info = TextView(ctx).apply { setTextColor(t.text); textSize = 14f; setPadding(0, dp(c, 8), 0, dp(c, 12)) }
            col.addView(info)

            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val sc = ScrollView(ctx).apply { addView(box) }
            col.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
            r.addView(col, FrameLayout.LayoutParams(-1, -1))
            val lp = WindowManager.LayoutParams(-1, -1, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE).apply { gravity = Gravity.TOP or Gravity.START }
            w.addView(r, lp)

            val stop = TextView(ctx).apply {
                text = "\u25A0  Stop"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(c, 18), dp(c, 10), dp(c, 18), dp(c, 10))
                background = GradientDrawable().apply { cornerRadius = dp(c, 24).toFloat(); setColor(0xFFC62828.toInt()) }
                setOnClickListener { onStop?.invoke() }
            }
            val slp = WindowManager.LayoutParams(-2, -2, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(c, 28) }
            w.addView(stop, slp)

            root = r; stopBtn = stop; wm = w; logBox = box; scroll = sc; titleV = title; subV = sub; barFill = fill; barBack = back; infoV = info
        } catch (_: Exception) { root = null }
    }

    private fun refresh() {
        val back = barBack ?: return; val fill = barFill ?: return; val info = infoV ?: return
        val el = SystemClock.elapsedRealtime() - t0
        if (el > estMs * 0.9) estMs = (el * 1.15).toLong()      // taking longer than expected: stretch the estimate
        val frac = (el.toFloat() / estMs).coerceIn(0f, 0.97f)
        val bw = back.width
        if (bw > 0) fill.layoutParams = (fill.layoutParams as FrameLayout.LayoutParams).apply { width = (bw * frac).toInt() }
        fill.requestLayout()
        val left = ((estMs - el) / 1000).coerceAtLeast(1)
        info.text = "${(frac * 100).toInt()}% done  \u00B7  ${el / 1000}s passed  \u00B7  about ${left}s left" + if (steps > 0) "  \u00B7  step $steps" else ""
    }

    private fun bubble(c: Context, v: View, mine: Boolean = false) {
        val t = th ?: return
        v.background = GradientDrawable().apply {
            cornerRadius = dp(c, 18).toFloat()
            setColor(if (mine) mix(t.a1, t.a2, 0.5f) else mix(t.bg2, if (t.light) Color.BLACK else Color.WHITE, 0.14f))
        }
        v.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10))
        v.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(c, 6); bottomMargin = dp(c, 6) }
    }

    private fun addRow(v: View) {
        val b = logBox ?: return
        b.addView(v)
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    /** one action step, e.g. "ChatGPT opened" */
    fun step(m: String) {
        val c = appCtx ?: return
        main.post {
            val b = logBox ?: return@post
            val last = b.childCount.takeIf { it > 0 }?.let { b.getChildAt(it - 1) } as? TextView
            val prog = m.endsWith("...") || m.endsWith("\u2026")
            if (last != null && last.tag == "p") b.removeView(last)
            if (!prog) steps++
            val tv = TextView(root!!.context).apply { text = if (prog) "\u23F3 $m" else "\u2705 $m"; setTextColor(th?.text ?: Color.WHITE); textSize = 15f }
            if (prog) tv.tag = "p"
            bubble(c, tv)
            addRow(tv)
        }
    }

    /** text result (script, caption, answer): shown as a bubble */
    fun text(t: String) {
        val c = appCtx ?: return
        main.post {
            if (root == null) return@post
            val tv = TextView(root!!.context).apply { text = t.take(1500); setTextColor(th?.text ?: Color.WHITE); textSize = 14f }
            bubble(c, tv)
            addRow(tv)
        }
    }

    /** the picture that was made, shown inside ZOKI */
    fun image(u: Uri) {
        val c = appCtx ?: return
        Thread {
            val bm = try {
                val o = android.graphics.BitmapFactory.Options().apply { inSampleSize = 2 }
                c.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
            } catch (_: Exception) { null }
            if (bm != null) main.post {
                if (root == null) return@post
                val iv = ImageView(root!!.context).apply { setImageBitmap(bm); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
                iv.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 6); bottomMargin = dp(c, 6) }
                addRow(iv)
            }
        }.start()
    }

    /** run ended: remember how long it took (for the next estimate), show the result a moment, then remove the cover */
    fun done(ok: Boolean, m: String) {
        main.post {
            if (root == null) return@post
            finished = true; main.removeCallbacks(tick)
            val c = appCtx
            if (ok && c != null && key.isNotEmpty()) {
                val el = SystemClock.elapsedRealtime() - t0
                val sp = c.getSharedPreferences("workview_eta", Context.MODE_PRIVATE)
                val old = sp.getLong(key, 0L)
                sp.edit().putLong(key, if (old == 0L) el else (old + el) / 2).apply()
            }
            titleV?.text = if (ok) "ZOKI \u00B7 Done" else "ZOKI \u00B7 Stopped"
            subV?.text = ""
            stopBtn?.visibility = View.GONE
            if (ok) { barBack?.let { b -> barFill?.layoutParams = (barFill!!.layoutParams as FrameLayout.LayoutParams).apply { width = b.width }; barFill?.requestLayout() } }
            infoV?.text = if (ok) "100% done  \u00B7  ${(SystemClock.elapsedRealtime() - t0) / 1000}s" else "Stopped"
            if (c != null) {
                val tv = TextView(root!!.context).apply { text = m.lineSequence().firstOrNull().orEmpty().take(200); setTextColor(th?.text ?: Color.WHITE); textSize = 15f }
                bubble(c, tv); addRow(tv)
            }
            main.removeCallbacks(hideRun)
            main.postDelayed(hideRun, if (ok) 2500L else 1200L)
        }
    }

    fun remove() {
        main.post {
            main.removeCallbacks(hideRun); main.removeCallbacks(tick)
            try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
            try { stopBtn?.let { wm?.removeView(it) } } catch (_: Exception) {}
            root = null; stopBtn = null; logBox = null; scroll = null; titleV = null; subV = null; barFill = null; barBack = null; infoV = null
        }
    }
}
