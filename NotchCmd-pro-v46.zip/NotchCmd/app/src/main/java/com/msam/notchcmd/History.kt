package com.msam.notchcmd

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject

/** Log of channel / Facebook / everywhere posts (last 100), so a failed post can be retried from the app. */
data class PostEntry(val time: Long, val kind: String, val topic: String, val ok: Boolean, val note: String, val cmd: String, val sched: Boolean)

object PostLog {
    private fun p(c: Context) = c.getSharedPreferences("postlog", Context.MODE_PRIVATE)

    fun load(c: Context): List<PostEntry> {
        val out = ArrayList<PostEntry>()
        try {
            val a = JSONArray(p(c).getString("list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(PostEntry(o.getLong("t"), o.getString("k"), o.getString("topic"), o.getBoolean("ok"), o.optString("note", ""), o.optString("cmd", ""), o.optBoolean("s", false)))
            }
        } catch (_: Exception) {}
        return out
    }

    fun add(c: Context, e: PostEntry) {
        val l = ArrayList(load(c)); l.add(0, e)
        val a = JSONArray()
        l.take(100).forEach { a.put(JSONObject().put("t", it.time).put("k", it.kind).put("topic", it.topic).put("ok", it.ok).put("note", it.note).put("cmd", it.cmd).put("s", it.sched)) }
        p(c).edit().putString("list", a.toString()).apply()
    }

    fun clear(c: Context) { p(c).edit().remove("list").apply() }
}

object Notify {
    const val CH = "notch_alerts"

    fun channel(c: Context) {
        c.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Post alerts", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun openApp(c: Context, code: Int): PendingIntent = PendingIntent.getActivity(c, code,
        Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun show(c: Context, nid: Int, title: String, text: String, skipId: Int = -1) {
        try {
            channel(c)
            val b = android.app.Notification.Builder(c, CH)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title).setContentText(text)
                .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                .setContentIntent(openApp(c, 300000 + nid)).setAutoCancel(true)
            if (skipId >= 0) {
                val skip = PendingIntent.getBroadcast(c, 200000 + skipId,
                    Intent(c, PreReceiver::class.java).putExtra("id", skipId).putExtra("act", "skip"),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                b.addAction(android.app.Notification.Action.Builder(0, "Skip this post", skip).build())
            }
            c.getSystemService(NotificationManager::class.java).notify(nid, b.build())
        } catch (_: Exception) {}
    }

    fun failed(c: Context, topic: String, note: String) =
        show(c, 6000, "Scheduled post failed", topic + (if (note.isNotBlank()) "\n" + note else "") + "\nOpen NotchCmd > Post history to retry.")
}

/** Topics written by the AI app for a new plan: kept here until MainActivity opens the plan dialog with them. */
object PlanDraft {
    private fun p(c: Context) = c.getSharedPreferences("plandraft", Context.MODE_PRIVATE)
    fun put(c: Context, text: String) { p(c).edit().putString("t", text).apply() }
    fun take(c: Context): String? {
        val t = p(c).getString("t", null)
        if (t != null) p(c).edit().remove("t").apply()
        return t?.takeIf { it.isNotBlank() }
    }
}

object TopicsBus {
    /** called by TopicsActivity with the copied AI answer (null = nothing copied) */
    @Volatile var onText: ((String?) -> Unit)? = null
}

/** Transparent Activity: only an activity in front may read the clipboard. Hands the copied AI answer to the service. */
class TopicsActivity : Activity() {
    private var started = false
    override fun onCreate(b: Bundle?) { super.onCreate(b) }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || started) return
        started = true
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val text = try { cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() } catch (_: Exception) { null }
        val cb = TopicsBus.onText
        TopicsBus.onText = null
        finish()
        cb?.invoke(text?.takeIf { it.isNotBlank() })
    }
}
