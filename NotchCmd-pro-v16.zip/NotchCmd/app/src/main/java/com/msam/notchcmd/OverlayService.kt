package com.msam.notchcmd

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.*
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale

sealed class Step {
    data class Open(val q: String) : Step()
    data class Call(val q: String) : Step()
    data class Search(val q: String) : Step()
    data class Msg(val t: String) : Step()
    data class Act(val name: String) : Step()
    data class Tap(val q: String) : Step()
    data class Type(val t: String) : Step()
    data class Dev(val name: String) : Step()
    data class TapN(val n: Int, val q: String) : Step()
    data class Tile(val labels: String, val want: Int) : Step()
    data class Doc(val json: String, val label: String, val retry: Boolean = false) : Step()
    data class Say(val t: String) : Step()
    data class Research(val prompt: String, val topic: String, val ai: String) : Step()
    data class Plugin(val key: String, val text: String, val lang: String?, val img: String?, val ai: String? = null) : Step()
    data class Channel(val topic: String, val prompt: String, val ai: String) : Step()
    data class Facebook(val topic: String, val prompt: String, val ai: String) : Step()
}

class OverlayService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val wm get() = getSystemService(WINDOW_SERVICE) as WindowManager
    private var trigger: View? = null
    private var panel: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelWm: WindowManager? = null
    private val pwm: WindowManager get() = panelWm ?: wm
    private var web: WebView? = null
    private var sr: SpeechRecognizer? = null       // panel ki voice
    private var wake: SpeechRecognizer? = null     // "MJ" sunne wali voice
    private var heard = ""; private var curPartial = ""; private var lastRms = 0L   // bolte waqt jama text; 5 sec chup = run
    private val silenceRun = Runnable { flushHeard() }
    private var wakeOn = false
    private var typing = false
    private var silent = 0
    private var schedRun = false   // current command was started by the Scheduler
    private var noListen = false   // schedule se chali command: mic band rahe jab tak user mic na dabaye
    private var pendingCmd: String? = null
    private var lastPkg = ""
    private var gen = 0                      // "close" par purane callbacks band
    private val queue = ArrayDeque<Step>()   // baaki bache steps
    private var running = false
    private var selPlugin: String? = null     // panel mein chuna plugin chip
    private var pendingImg: String? = null    // panel mein jodi photo (cache file path)
    private var picking = false               // photo chooser khula hai
    private var plugBusy = false
    private val idleClose = Runnable { if (panel != null && !typing && !picking) hidePanel() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i != null && i.hasExtra("wake")) {
            setWake(i.getBooleanExtra("wake", false))
            say(if (wakeOn) "MJ wake word ON — say: \"MJ\"" else "MJ wake word OFF")
        }
        if (i?.getBooleanExtra("show", false) == true) showPanel(null, i?.getBooleanExtra("bottom", false) == true)
        val sched = i?.getBooleanExtra("sched", false) == true
        if (sched) noListen = true   // schedule se chali command: mic on nahi hoga
        if (i?.getBooleanExtra("prep_only", false) == true) Unlocker.prepare(this) { say("Unlock/data check done") }
        i?.getStringExtra("say")?.let { t -> speakWhenReady(t, 0) }
        i?.getStringExtra("cmd")?.let { c ->
            schedRun = sched
            val sayT = sayText(c)
            if (sayT != null && sched) speakWhenReady(sayT, 0)   // "bolo ..." schedule: bina unlock/panel ke seedha bolna (jaise yaad dilana)
            else if (sched) Unlocker.prepare(this) { showPanel(c) }   // lock ho to unlock, data band ho to ON, phir command
            else showPanel(c)
        }
        if (wakeOn && !sched) armWakeWindow()   // permission baad mein mile to bhi mic-listening shuru
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("notch", "NotchCmd", NotificationManager.IMPORTANCE_MIN))
        wakeOn = getSharedPreferences("n", MODE_PRIVATE).getBoolean("wake", true)
        val n = buildNotif()
        if (Build.VERSION.SDK_INT >= 34) {
            try { startForeground(1, n, if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == 0) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) }
            catch (_: Exception) { startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) }   // background (schedule) se start ho to mic type ke bina
        } else startForeground(1, n)

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean { showPanel(); return true }
        })
        val d = resources.displayMetrics.density
        val v = View(this).apply { setBackgroundColor(0x01000000); setOnTouchListener { _, e -> gd.onTouchEvent(e) } }
        val lp = WindowManager.LayoutParams((140 * d).toInt(), (56 * d).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp); trigger = v

        // screen off hote hi mic band, screen on hote hi (agar MJ ON hai) wapas
        val f = android.content.IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) }
        registerReceiver(screenRx, f)
        initTts()
        h.postDelayed(usageLoop, 20_000L)
        if (wakeOn) armWakeWindow()
    }

    private val screenRx = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context?, i: Intent?) {
            if (i?.action == Intent.ACTION_SCREEN_OFF) stopWake()
            else if (i?.action == Intent.ACTION_SCREEN_ON && wakeOn) armWakeWindow()
        }
    }

    private fun buildNotif(): Notification {
        val pi = PendingIntent.getForegroundService(this, 7, Intent(this, OverlayService::class.java).putExtra("wake", !wakeOn),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "notch").setContentTitle("NotchCmd is running")
            .setContentText(if (wakeOn) "MJ listens for only 10 sec, then the mic turns off. Open with Power button / Volume Up+Down / notch double-tap" else "Mic OFF. Double-tap the notch or tap MJ ON below")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(0, if (wakeOn) "MJ OFF (mic off)" else "MJ ON", pi).build()).build()
    }

    /** MJ listening ON/OFF (save bhi hota hai). OFF = mic poori tarah band. */
    private fun setWake(on: Boolean) {
        wakeOn = on
        getSharedPreferences("n", MODE_PRIVATE).edit().putBoolean("wake", on).apply()
        if (on) armWakeWindow() else { h.removeCallbacks(wakeOffRun); stopWake() }
        getSystemService(NotificationManager::class.java).notify(1, buildNotif())
    }

    override fun onDestroy() { h.removeCallbacks(usageLoop); wakeOn = false; stopWake(); try { unregisterReceiver(screenRx) } catch (_: Exception) {}; tts?.shutdown(); hidePanel(); h.removeCallbacksAndMessages(null); trigger?.let { wm.removeView(it) }; super.onDestroy() }

    // ---------- floating panel ----------
    // Panel NOT_FOCUSABLE rehta hai taake neeche wali app focus mein rahe (live control).
    // Sirf jab tum input box par tap karo tab focusable hota hai (keyboard ke liye).
    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private var bottomMode = false
    private fun showPanel(cmd: String? = null, bottom: Boolean = false) {
        if (panel != null) { if (cmd != null) submit(cmd, true); return }
        stopWake()
        if (!noListen) Style.buzz(this, "launch")   // notch / button se khulte hi vibrate (animation ke shake ke saath)
        pendingCmd = cmd; silent = 0; typing = false; bottomMode = bottom
        val d = resources.displayMetrics.density
        val w = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, u: String?) {
                    val c = pendingCmd; pendingCmd = null
                    if (c != null) { js("gotText(${JSONObject.quote(c)})"); submit(c, true) } else if (OfflineVoice.gboard(this@OverlayService) > 0 && !noListen) enterGboard() else startListen()   // mic apne aap on
                }
            }
            loadUrl("file:///android_asset/command.html#" + (if (bottom) "bottom" else "") + "&t=" + Style.cur(this@OverlayService) +
                (if (OfflineVoice.gboard(this@OverlayService) > 0 && !noListen) "&gb=" + OfflineVoice.gboard(this@OverlayService) else ""))
        }
        val f = FrameLayout(this)
        f.addView(w)
        if (bottom) f.setOnApplyWindowInsetsListener { _, ins ->
            if (typing && Build.VERSION.SDK_INT >= 30) {
                val ime = ins.getInsets(WindowInsets.Type.ime()).bottom
                val l = panelLp
                if (ime > 0 && l != null && l.y != ime) { l.y = ime; try { pwm.updateViewLayout(f, l) } catch (_: Exception) {} }
            }
            ins
        }
        // phone lock ho to panel accessibility-overlay banta hai (wo lock screen ke upar bhi dikhta hai)
        val a11 = if (Unlocker.isLocked(this)) NotchA11y.inst else null
        val useWm = if (a11 != null) a11.getSystemService(WINDOW_SERVICE) as WindowManager else wm
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, ((if (bottom) 210 else 180) * d).toInt(),
            if (a11 != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = if (bottom) Gravity.BOTTOM else Gravity.TOP
            softInputMode = (if (!bottom) WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN else if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING else WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE) or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        panelWm = useWm; useWm.addView(f, lp); panel = f; web = w; panelLp = lp
        armIdle()
    }

    private fun hidePanel(resumeWake0: Boolean = true) {
        val resumeWake = resumeWake0 && !noListen
        noListen = false
        h.removeCallbacks(idleClose)
        gen++; queue.clear(); running = false
        selPlugin = null; pendingImg = null; picking = false; PluginBus.onImage = null
        h.removeCallbacks(silenceRun); heard = ""; curPartial = ""
        stopListen(); typing = false; micForced = false
        panel?.let { try { pwm.removeView(it) } catch (_: Exception) {} }
        panelWm = null
        web?.destroy(); web = null; panel = null; panelLp = null
        if (resumeWake && wakeOn) h.postDelayed({ armWakeWindow() }, 600)   // panel band, ab wapas "MJ" sunna
    }

    private fun armIdle() { h.removeCallbacks(idleClose); h.postDelayed(idleClose, if (selPlugin != null || pendingImg != null) 60000L else 20000L) }

    private fun setTyping(on: Boolean) {
        typing = on
        val lp = panelLp ?: return; val p = panel ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (bottomMode) lp.y = if (on) (resources.displayMetrics.heightPixels * 0.40).toInt() else 0   // keyboard ke upar; asli height aate hi theek ho jati hai
        try { pwm.updateViewLayout(p, lp) } catch (_: Exception) {}
        if (on) {
            stopListen(); h.removeCallbacks(idleClose); h.removeCallbacks(silenceRun); heard = ""; curPartial = ""
            web?.requestFocus()
            js("setState('typing')")
            h.postDelayed({ js("focusInput()") }, 120)
        } else armIdle()
    }

    private fun js(c: String) { h.post { web?.evaluateJavascript(c, null) } }
    private var lastSay = ""
    private fun say(m: String) { lastSay = m; h.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }; js("setState('busy',${JSONObject.quote(m)})") }

    inner class Bridge {
        @JavascriptInterface fun listen() { h.post { noListen = false; micForced = true; if (typing) setTyping(false); silent = 0; startListen() } }
        @JavascriptInterface fun startTyping() { h.post { if (!typing) setTyping(true) } }
        @JavascriptInterface fun close() { h.post { NotchA11y.inst?.stopAuto(); try { tts?.stop() } catch (_: Exception) {}; speaking = false; resBusy = false; hidePanel() } }   // ✕: scroll, queue, bolna, sab band
        @JavascriptInterface fun haptic(k: String) { Style.buzz(this@OverlayService, k) }
        @JavascriptInterface fun run(c: String) { h.post { submit(c, false) } }
        @JavascriptInterface fun plugins(): String = Plugins.menuJson()
        @JavascriptInterface fun setPlugin(k: String) { h.post { selPlugin = k.ifBlank { null }; armIdle() } }
        @JavascriptInterface fun clearImage() { h.post { pendingImg = null; armIdle() } }
        @JavascriptInterface fun pickImage() { h.post { startPick() } }
        /** card ki unchai (css px = dp) -> window utni hi badi, taaki neeche ki app par touch na rukey */
        @JavascriptInterface fun resize(cssH: Int) { h.post { fitPanel(cssH) } }
    }

    private fun fitPanel(cssH: Int) {
        val lp = panelLp ?: return; val p = panel ?: return
        val d = resources.displayMetrics.density
        val want = (cssH + (if (bottomMode) 62 else 56)) * d
        val min = (if (bottomMode) 210 else 180) * d
        val nh = maxOf(min, want).toInt()
        if (lp.height != nh) { lp.height = nh; try { pwm.updateViewLayout(p, lp) } catch (_: Exception) {} }
    }

    /** "+" dabaya: transparent PickActivity se photo chuno; tab tak panel chhupa rahe (band na ho) */
    private fun startPick() {
        if (panel == null) return
        picking = true; h.removeCallbacks(idleClose); stopListen()
        panel?.visibility = View.INVISIBLE
        PluginBus.onImage = { path ->
            h.post {
                picking = false
                panel?.visibility = View.VISIBLE
                if (path != null) {
                    pendingImg = path
                    val url = Plugins.thumbDataUrl(path)
                    js("gotImage(${JSONObject.quote(url)})")
                    say("Photo added. Now pick a plugin or just press ▶")
                } else say("No photo selected")
                armIdle()
            }
        }
        try { startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { picking = false; panel?.visibility = View.VISIBLE; PluginBus.onImage = null; say("Could not open the photo chooser") }
    }

    // ---------- voice (English letters: en-IN) ----------
    @Volatile private var bias: List<String> = emptyList()
    private var biasAt = 0L

    /** Google ko hint: command ke shabd + phone ke app naam + contact naam (naam galat sunne se bachata hai) */
    private fun refreshBias() {
        biasAt = System.currentTimeMillis()
        Thread {
            try {
                val set = LinkedHashSet<String>()
                set.addAll(listOf("MJ", "kholo", "call karo", "message bhejo", "search karo", "volume badhao", "volume kam karo", "torch on karo",
                    "wifi on karo", "bluetooth off karo", "brightness badhao", "screenshot", "scroll karo", "swipe", "alarm", "timer", "back", "home"))
                val pm = packageManager
                pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).forEach { set.add(it.loadLabel(pm).toString()) }
                if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) == 0) {
                    contentResolver.query(ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use {
                        var n = 0
                        while (it.moveToNext() && n < 100) { val d = (it.getString(0) ?: continue).trim(); if (d.length in 2..30) { set.add(d); n++ } }
                    }
                }
                bias = set.filter { it.length in 2..40 }.take(150)
            } catch (_: Throwable) {}
        }.start()
    }

    private fun speechIntent(partial: Boolean): Intent {
        val hi = true
        val main = if (hi) "hi-IN" else "en-IN"
        val other = if (hi) "en-IN" else "hi-IN"
        if (System.currentTimeMillis() - biasAt > 600_000L) refreshBias()
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)   // chhoti commands / naamon ke liye behtar
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, main)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, main)
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf(other))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, partial)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 800L)
            if (Build.VERSION.SDK_INT >= 33 && bias.isNotEmpty()) putStringArrayListExtra("android.speech.extra.BIASING_STRINGS", ArrayList(bias))
        }
    }

    /** jo result English letters mein ho wahi lo, warna pehla (parse Hindi ko Roman bana lega) */
    private fun pick(b: Bundle?): String {
        val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return ""
        return l.firstOrNull { s -> s.isNotBlank() && s.none { isDev(it) } } ?: l.firstOrNull() ?: ""
    }

    private fun stopListen() { sr?.destroy(); sr = null }

    /** Saare alternatives mein se pehla jo command ban sake (sirf pehla result lene se galat sunne par fail hota tha) */
    private fun pickBest(b: Bundle?): String {
        val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty().filter { it.isNotBlank() }
        if (l.isEmpty()) return ""
        val ordered = l.filter { s -> s.none { isDev(it) } } + l.filter { s -> s.any { isDev(it) } }
        for (s in ordered) { try { if (parse(findWake(s) ?: s).isNotEmpty()) return s } catch (_: Exception) {} }
        return pick(b)
    }

    /** bolna jaari hai to timer reset; 5 sec khamoshi ke baad flushHeard() command chalata hai */
    private fun bumpSilence() {
        h.removeCallbacks(silenceRun)
        if ((heard + curPartial).isNotBlank()) h.postDelayed(silenceRun, 5000)
    }

    private fun flushHeard() {
        h.removeCallbacks(silenceRun)
        val t = (heard + " " + curPartial).trim()
        heard = ""; curPartial = ""
        if (t.isBlank() || panel == null || typing) return
        stopListen(); silent = 0
        submit(t, true)
    }

    private var micForced = false

    /** Gboard mode: panel khulte hi keyboard khule (typing mode); bolne ke liye Gboard ka 🎤, ruk-ne par command chalti hai (HTML mein) */
    private fun enterGboard() {
        if (panel == null) return
        setTyping(true)
        panelLp?.let { l ->
            l.softInputMode = l.softInputMode or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE   // window focus milte hi keyboard khule
            panel?.let { p -> try { pwm.updateViewLayout(p, l) } catch (_: Exception) {} }
        }
        val show: () -> Unit = {
            val w = web
            if (w != null && panel != null && typing) {
                w.requestFocus(); js("focusInput()")
                try { (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(w, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) } catch (_: Exception) {}
            }
        }
        h.postDelayed({ show() }, 350)
        h.postDelayed({ show() }, 900)
        if (OfflineVoice.gbMic(this)) h.postDelayed({
            if (panel != null && typing) {
                val a = NotchA11y.inst
                if (a == null) say("Turn on Accessibility so the Gboard mic can be pressed automatically")
                else a.tapKeyboardMic { ok -> if (ok) js("voiceOn()") else say("Gboard mic not found. Send the D1 dump, or press the mic yourself") }
            }
        }, 1300)
    }

    private val GBOARD_ONLY = true   // assistant ka apna mic band: sirf Gboard mic ya typing
    private fun startListen() {
        if (GBOARD_ONLY) return
        if (panel == null || typing || speaking || noListen) return
        if (OfflineVoice.gboard(this) > 0 && !micForced) return   // Gboard mode: assistant ka mic nahi, Gboard ka mic
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != 0) { say("Grant the mic permission in the app"); return }
        armIdle()
        stopListen()
        val r = newRecognizer()
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { recSameRetried = false; js(if (running) "setMic(true)" else "setState('listening')") }
            override fun onResults(b: Bundle?) {
                if (sr !== r) return
                val t = romanLine(pickBest(b))
                curPartial = ""
                if (t.isBlank()) { if (heard.isBlank()) retryListen() else h.postDelayed({ startListen() }, 250); return }
                silent = 0
                heard = (heard + " " + t).trim()
                js("gotText(${JSONObject.quote(heard)})")
                bumpSilence()
                h.postDelayed({ startListen() }, 250)   // sunte raho, 5 sec chup par command chalega
            }
            override fun onPartialResults(p: Bundle?) {
                if (sr !== r) return
                val t = romanLine(pick(p))
                if (t.isNotBlank()) {
                    curPartial = t
                    val full = (heard + " " + t).trim()
                    js("gotText(${JSONObject.quote(full)})")
                    bumpSilence()
                }
            }
            override fun onError(e: Int) {
                if (sr !== r) return
                when (e) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        if (curPartial.isNotBlank()) { heard = (heard + " " + curPartial).trim(); curPartial = "" }
                        if (heard.isBlank()) retryListen() else h.postDelayed({ startListen() }, 250)
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> h.postDelayed({ startListen() }, 600)
                    else -> {
                        if (e == 11 && !recSameRetried) { recSameRetried = true; h.postDelayed({ startListen() }, 600) }   // error 11 aksar pehli baar bind mein hota hai: ek baar wahi dobara
                        else if (e != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS && recMode < recServices().size + 1) { recMode++; recSameRetried = false; h.postDelayed({ startListen() }, 300) }   // agla recognizer try
                        else { recMode = 0; recSameRetried = false; js("setState('idle','Voice error $e. Tap the mic or type')") }
                    }
                }
            }
            override fun onBeginningOfSpeech() { js("setState('listening','Hearing you… understanding')") }
            override fun onRmsChanged(v: Float) {
                if (v > 4.5f && (heard + curPartial).isNotBlank()) {
                    val n = System.currentTimeMillis()
                    if (n - lastRms > 400) { lastRms = n; bumpSilence() }
                }
            }
            override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(speechIntent(true))
    }

    private fun retryListen() {
        if (!running) silent++
        if (silent >= 4) { silent = 0; js("setState('idle','Mic off. Tap 🎤 or type')"); return }
        h.postDelayed({ startListen() }, 300)
    }

    // ---------- "MJ" wake word (hands-free) ----------
    // MJ ki har spelling: M.J., M-J, Em Jay, Emjay, M Jay, Am Jay, AMJ, A.J., MJX, MJee ... (normalize karke match)
    private val wakeSet = setOf("mj", "emj", "emjay", "mjay", "amj", "amjay", "aj", "mjx", "mjayx", "emjayx", "mjee", "emjx",
        "एमजे", "एमजय", "अमजय", "ऐमजे", "एमजे", "अमजे")
    private val lead = setOf("hey", "ok", "okay", "hi", "hello", "oye", "arey")
    private val wordRe = Regex("[\\p{L}\\p{M}\\p{N}\\u02B2]+")

    /** wake word bilkul shuru mein ho to uske baad ka text ("" ho sakta hai), warna null */
    private fun findWake(text: String): String? {
        val ms = wordRe.findAll(text).toList()
        val tk = ms.map { it.value.lowercase(Locale.ROOT).replace('\u02B2', 'j') }
        val st = if (tk.isNotEmpty() && tk[0] in lead) 1 else 0
        for (len in 1..3) {
            if (st + len > tk.size) break
            if (tk.subList(st, st + len).joinToString("") in wakeSet) {
                val end = ms[st + len - 1].range.last + 1
                return text.substring(end).trimStart(' ', ',', '.', '-', ':', ';', '!', '?', '_', '•', '×', '|')
            }
        }
        return null
    }

    /** Default assistant NotchCmd banne par system recognizer bhi badal sakta hai; isliye Google ka recognizer seedha chunte hain */
    private var recMode = 0   // 0..n-1 = installed recognizers (Google pehle, NotchCmd ka dummy chhodkar), n = on-device, n+1 = system default
    private var recSameRetried = false
    private fun recServices(): List<android.content.ComponentName> = try {
        val l = packageManager.queryIntentServices(Intent(android.speech.RecognitionService.SERVICE_INTERFACE), 0)
            .map { it.serviceInfo }.filter { it.packageName != packageName }
        (l.filter { it.packageName == "com.google.android.googlequicksearchbox" } + l.filter { it.packageName != "com.google.android.googlequicksearchbox" })
            .map { android.content.ComponentName(it.packageName, it.name) }
    } catch (_: Exception) { emptyList() }

    private fun newRecognizer(): SpeechRecognizer {
        val l = recServices()
        if (recMode < l.size) try { return SpeechRecognizer.createSpeechRecognizer(this, l[recMode]) } catch (_: Exception) {}
        if (recMode == l.size && android.os.Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
            try { return SpeechRecognizer.createOnDeviceSpeechRecognizer(this) } catch (_: Exception) {}
        return SpeechRecognizer.createSpeechRecognizer(this)
    }

    // Mic sirf 10 second ke liye: panel band hone / screen on / service start ke baad "MJ" 10 sec sunta hai, phir mic poori tarah OFF
    private var wakeSuspended = false
    private val wakeOffRun = Runnable { wakeSuspended = true; stopWake() }
    private fun armWakeWindow() {
        wakeSuspended = false
        h.removeCallbacks(wakeOffRun)
        h.postDelayed(wakeOffRun, 10000)
        startWake()
    }

    private fun startWake() {
        if (GBOARD_ONLY) return   // "MJ" wake mic band
        if (!wakeOn || wakeSuspended || panel != null || wake != null) return
        if (!(getSystemService(POWER_SERVICE) as PowerManager).isInteractive) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != 0) return
        val r = newRecognizer()
        wake = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                if (wake !== r) return
                val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                val rest = l.firstNotNullOfOrNull { findWake(it) }
                if (rest == null) { restartWake(300); return }
                val rl = rest.lowercase(Locale.ROOT)
                if (rl in setOf("ruk", "ruko", "रुको", "रुक")) { h.post { if (NotchA11y.inst?.stopAuto() == true) say("Scroll stopped") }; restartWake(300); return }
                if (rl in setOf("close", "klos", "stop", "band", "bas", "cancel")) {
                    if (NotchA11y.inst?.stopAuto() == true) { h.post { say("Scroll stopped") }; restartWake(300); return }
                    h.post { setWake(false); say("MJ OFF, mic off") }; return
                }
                stopWake(); buzz()
                showPanel(if (rest.isBlank()) null else rest)
            }
            override fun onError(e: Int) {
                if (wake !== r) return
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { h.post { stopWake() }; return }
                restartWake(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
            }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(speechIntent(false))
    }

    /** MJ suna gaya: halka sa vibrate (assistant jaisa confirmation) */
    @Suppress("DEPRECATION")
    private fun buzz() { try { (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {} }

    private fun stopWake() { wake?.destroy(); wake = null }
    private fun restartWake(ms: Long) { h.post { stopWake() }; h.postDelayed({ startWake() }, ms) }

    // ---------- Devanagari -> Roman (agar recognizer Hindi script de de) ----------
    private fun isDev(c: Char) = c in '\u0900'..'\u097F'
    private val cons = mapOf('क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n", 'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n", 'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m", 'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh",
        'स' to "s", 'ह' to "h", '\u0958' to "q", '\u0959' to "kh", '\u095A' to "g", '\u095B' to "z", '\u095C' to "d", '\u095D' to "rh", '\u095E' to "f", '\u095F' to "y")
    private val vow = mapOf('अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo", 'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o")
    private val mat = mapOf('ा' to "a", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au", 'ॉ' to "o", 'ॅ' to "e")

    private fun roman(s: String): String {
        if (s.none { isDev(it) }) return s
        val sb = StringBuilder(); var pend = false
        for (c in s) {
            when {
                cons.containsKey(c) -> { if (pend) sb.append('a'); sb.append(cons[c]); pend = true }
                vow.containsKey(c) -> { if (pend) sb.append('a'); pend = false; sb.append(vow[c]) }
                mat.containsKey(c) -> { pend = false; sb.append(mat[c]) }
                c == '\u094D' -> pend = false
                c == '\u093C' -> { if (sb.endsWith("j")) { sb.setLength(sb.length - 1); sb.append('z') } }
                c == 'ं' || c == 'ँ' -> { if (pend) sb.append('a'); pend = false; sb.append('n') }
                c == 'ः' -> { if (pend) sb.append('a'); pend = false; sb.append('h') }
                c in '\u0966'..'\u096F' -> { pend = false; sb.append(c - '\u0966') }
                c == '।' -> { pend = false }
                else -> { pend = false; sb.append(c) }
            }
        }
        return sb.toString()
    }

    /** Hindi (Devanagari) bola hua text Roman mein: "सलमान को कॉल करें" -> "salman ko call karo" */
    private fun romanLine(t: String): String {
        if (t.none { isDev(it) }) return t
        return t.split(Regex("\\s+")).filter { it.isNotBlank() }.joinToString(" ") { w ->
            alias[w] ?: if (w.any { isDev(it) }) fixTypo(roman(w)) else w }
    }

    // ---------- command ko parts mein todna ----------
    private val seps = Regex("\\s*[,،]\\s*|\\s+(?:aur|phir|fir|then|and|और|फिर)\\s+")
    private val cut = setOf("karo", "kar", "karen", "karein", "kare", "kariye", "kijiye", "kholen", "kholiye", "kholo", "khol", "kolo", "khulo", "chalao", "lagao", "dabao", "करो", "खोलो", "चलाओ", "दबाओ")
    private val fill = setOf("open", "kholo", "khol", "kolo", "khulo", "karo", "kar", "karen", "karein", "kare", "kariye", "kijiye", "kholen", "kholiye", "do", "dijiye", "chalao", "chala", "ko", "app", "start", "launch", "ki", "ka", "ke", "par", "pe", "mein", "me",
        "please", "plz", "khud", "khudse", "खोलो", "खोल", "करो", "दो", "चलाओ", "को", "ऐप", "की", "का", "पर", "में")
    private val msgKw = setOf("message", "msg", "maisej", "मैसेज", "likho", "bhejo", "bejo", "bhej", "bhejen", "bhejein", "bhejiye", "send", "भेजो", "लिखो")
    private val callKw = setOf("call", "kol", "kaul", "कॉल", "कोल")
    private val searchKw = setOf("search", "sarch", "surch", "khojo", "dhundo", "सर्च", "खोजो", "ढूंढो")
    private val tapKw = setOf("tap", "click", "klik", "dabao", "press", "दबाओ", "क्लिक")
    private val actKw = mapOf("back" to "back", "wapas" to "back", "vapas" to "back", "peeche" to "back", "peechhe" to "back", "पीछे" to "back", "वापस" to "back",
        "home" to "home", "hom" to "home", "होम" to "home", "recents" to "recents", "recent" to "recents", "notification" to "notif", "notifications" to "notif",
        "screenshot" to "shot", "close" to "close", "klos" to "close", "stop" to "close", "cancel" to "close", "bas" to "close", "band" to "close",
        "lock" to "lock", "lok" to "lock", "लॉक" to "lock", "quick" to "qs", "panel" to "qs",
        "ruk" to "stopauto", "ruko" to "stopauto", "रुको" to "stopauto", "रुक" to "stopauto")
    private val alias = mapOf("यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "कैमरा" to "camera",
        "क्रोम" to "chrome", "सेटिंग" to "settings", "सेटिंग्स" to "settings", "गैलरी" to "gallery", "इंस्टाग्राम" to "instagram",
        "wa" to "whatsapp", "yt" to "youtube", "insta" to "instagram", "fb" to "facebook",
        "yootyoob" to "youtube", "yutyub" to "youtube", "yutub" to "youtube", "yootub" to "youtube", "vhatsaep" to "whatsapp", "vhatsap" to "whatsapp",
        "watsapp" to "whatsapp", "whatsap" to "whatsapp", "krom" to "chrome",
        "skrol" to "scroll", "scrol" to "scroll", "स्क्रॉल" to "scroll", "स्क्रोल" to "scroll", "swaip" to "swipe", "स्वाइप" to "swipe",
        "कॉल" to "call", "करें" to "karo", "करिए" to "karo", "कीजिए" to "karo", "कर" to "kar", "भेजें" to "bhejo", "भेज" to "bhejo", "खोलें" to "kholo", "खोलिए" to "kholo",
        "बंद" to "band", "चालू" to "chalu", "ऑन" to "on", "ऑफ" to "off", "मैसेज" to "message", "सर्च" to "search", "टैप" to "tap")
    private val volKw = setOf("volume", "vol", "sound", "sond", "saund", "awaaz", "aawaz", "avaaz", "awaz", "आवाज", "वॉल्यूम", "साउंड")
    private val brKw = setOf("brightness", "brightnes", "roshni", "roshani", "ब्राइटनेस", "रोशनी")
    private val torchKw = setOf("torch", "tarch", "flashlight", "flash", "light", "lite", "टॉर्च", "फ्लैश", "लाइट")
    private val upKw = setOf("badhao", "badha", "badhaao", "up", "increase", "zyada", "jyada", "tez", "बढ़ाओ", "बढ़ा", "ज्यादा")
    private val downKw = setOf("ghatao", "ghata", "kam", "down", "decrease", "low", "dheema", "घटाओ", "कम")
    private val maxKw = setOf("max", "maximum", "full", "poori", "pura")
    private val minKw = setOf("min", "minimum", "lowest")
    private val muteKw = setOf("mute", "silent", "chup", "म्यूट")
    private val offKw = setOf("off", "band", "bujhao", "bujha", "stop", "disable", "बंद", "ऑफ", "बुझाओ")
    private val openWords = setOf("open", "kholo", "khol", "kolo", "khulo", "kholen", "kholiye", "खोलो", "खोल")
    private val postpos = setOf("par", "pe", "mein", "me", "में", "पर")
    private val dblKw = setOf("double", "dubal", "dabal", "डबल")
    private val autoKw = setOf("raho", "rehna", "karte", "auto", "lagatar", "continuous", "रहो", "करते")
    private val ordMap = mapOf("first" to 1, "1st" to 1, "pehla" to 1, "pehli" to 1, "pahla" to 1, "pahli" to 1, "पहला" to 1, "पहली" to 1,
        "second" to 2, "2nd" to 2, "dusra" to 2, "doosra" to 2, "dusri" to 2, "doosri" to 2, "दूसरा" to 2, "दूसरी" to 2,
        "third" to 3, "3rd" to 3, "teesra" to 3, "tisra" to 3, "teesri" to 3, "तीसरा" to 3, "तीसरी" to 3,
        "fourth" to 4, "4th" to 4, "chautha" to 4, "chauthi" to 4, "चौथा" to 4,
        "fifth" to 5, "5th" to 5, "panchva" to 5, "paanchva" to 5, "पांचवा" to 5)
    private val onKw = setOf("on", "chalu", "enable", "jalao", "chala", "chalao", "start", "ऑन", "चालू", "जलाओ")
    private val wifiKw = setOf("wifi", "wi-fi", "waifai", "vaifai", "wai-fai", "वाईफाई", "वाई-फाई", "वाईफ़ाई")
    private val btKw = setOf("bluetooth", "blutooth", "ब्लूटूथ")
    private val airKw = setOf("airplane", "aeroplane", "flight", "एयरप्लेन")
    private val hotKw = setOf("hotspot", "hotspat", "हॉटस्पॉट")
    private val dndKw = setOf("dnd", "disturb")
    private val rotKw = setOf("rotate", "rotation", "autorotate", "auto-rotate", "रोटेट")
    private val dataKw = setOf("data", "internet", "net", "डेटा", "इंटरनेट")
    private val spkKw = setOf("speaker", "spiker", "loudspeaker", "स्पीकर")
    private val endW = setOf("kaato", "kato", "kaat", "reject", "disconnect", "cut", "decline", "काटो", "कट")
    private val ansW = setOf("uthao", "utha", "receive", "answer", "pick", "उठाओ", "रिसीव")
    private val phoneKw = setOf("phone", "fone", "फोन")
    private val contactKw = setOf("contact", "kontact", "कॉन्टैक्ट")
    private val photoKw = setOf("photo", "foto", "picture", "pic", "selfie", "फोटो", "सेल्फी")
    private val shootKw = setOf("kheencho", "kheench", "khicho", "kheecho", "lo", "le", "click", "capture", "खींचो", "लो")
    private val mNext = setOf("next", "agla", "agle", "badlo", "अगला")
    private val mPrev = setOf("previous", "prev", "pichla", "pichle", "पिछला")
    private val mPause = setOf("pause", "paus", "पॉज")
    private val mPlay = setOf("play", "resume", "प्ले")
    private val mSong = setOf("gaana", "gana", "gaane", "song", "songs", "music", "media", "गाना", "गाने", "म्यूजिक")
    private val medSet = mNext + mPrev + mPause + mPlay + mSong
    private val batKw = setOf("battery", "batri", "bettery", "betri", "बैटरी")
    private val dateKw = setOf("date", "tarikh", "taareekh", "tareekh", "तारीख")
    private val timeKw = setOf("time", "samay", "waqt", "baje", "टाइम", "समय", "वक्त")
    private val timerKw = setOf("timer", "taimar", "टाइमर")
    private val alarmKw = setOf("alarm", "alaram", "अलार्म")
    private val remKw = setOf("reminder", "remind", "yaad", "yad", "रिमाइंडर", "याद")
    private val cancelKw = setOf("cancel", "delete", "hatao", "hata", "हटाओ")
    private val clockWords = setOf("baje", "bje", "am", "pm", "oclock", "o'clock", "बजे", "subah", "morning", "sawere", "dopahar", "afternoon",
        "shaam", "sham", "evening", "raat", "night", "saade", "saadhe", "sawa", "paune", "kal", "aaj", "tomorrow", "at")
    private val minUnit = setOf("minute", "minutes", "min", "mins", "minat", "mint", "मिनट")
    private val hrUnit = setOf("hour", "hours", "hr", "hrs", "ghanta", "ghante", "घंटा", "घंटे")
    private val secUnit = setOf("second", "seconds", "sec", "secs", "sekand", "सेकंड")
    private val labelJunk = setOf("set", "laga", "lagao", "lagana", "baad", "after", "in", "for", "liye", "hai", "tak", "a", "the", "to",
        "yaad", "dilana", "dilao", "daalo", "dikhao", "batao", "show", "find", "dhundo", "dekho", "kya")
    private val numWords = mapOf("ek" to 1, "one" to 1, "do" to 2, "two" to 2, "teen" to 3, "three" to 3, "char" to 4, "four" to 4,
        "paanch" to 5, "panch" to 5, "five" to 5, "chhe" to 6, "che" to 6, "chah" to 6, "six" to 6, "saat" to 7, "seven" to 7,
        "aath" to 8, "eight" to 8, "nau" to 9, "nine" to 9, "das" to 10, "ten" to 10, "gyarah" to 11, "barah" to 12, "terah" to 13,
        "chaudah" to 14, "pandrah" to 15, "fifteen" to 15, "solah" to 16, "satrah" to 17, "atharah" to 18, "unnis" to 19, "bees" to 20,
        "twenty" to 20, "pachees" to 25, "tees" to 30, "thirty" to 30, "chalis" to 40, "forty" to 40, "paintalis" to 45, "pachaas" to 50,
        "fifty" to 50, "saath" to 60, "sixty" to 60)
    private val known: Set<String> by lazy { cut + fill + msgKw + callKw + searchKw + tapKw + actKw.keys + alias.keys +
        volKw + brKw + torchKw + upKw + downKw + maxKw + minKw + muteKw + offKw + openWords + postpos + dblKw + autoKw + ordMap.keys +
        onKw + wifiKw + btKw + airKw + hotKw + dndKw + rotKw + dataKw + spkKw + endW + ansW + phoneKw + contactKw + photoKw + shootKw +
        medSet + batKw + dateKw + timeKw + timerKw + alarmKw + remKw + cancelKw + clockWords + minUnit + hrUnit + secUnit + labelJunk + numWords.keys }

    private fun numOf(t: String): Int? = t.toIntOrNull() ?: numWords[t]

    /** "5 minute", "2 ghante", "aadha ghanta", "dedh ghanta" -> seconds */
    private fun parseDur(tk: List<String>): Int? {
        var total = 0.0; var found = false
        for (i in tk.indices) {
            val t = tk[i]
            val u = when {
                t in minUnit -> 60
                t in hrUnit -> 3600
                t in secUnit -> 1
                else -> 0
            }
            if (u == 0) continue
            val prev = if (i > 0) tk[i - 1] else ""
            val n: Double? = when (prev) {
                "aadha", "adha", "half", "आधा" -> 0.5
                "dedh", "derh", "डेढ़" -> 1.5
                "dhai", "dhaai", "ढाई" -> 2.5
                else -> numOf(prev)?.toDouble()
            }
            if (n != null) { total += n * u; found = true }
        }
        return if (found && total > 0) total.toInt() else null
    }

    /** "6 baje", "subah 6:30", "shaam 5 baje", "saade 6 baje", "7 pm" -> (hour24, minute) */
    private fun parseClock(tk: List<String>): Pair<Int, Int>? {
        var hr = -1; var mn = 0; var suffix = ""
        for (i in tk.indices) {
            val t = tk[i]
            val m1 = Regex("^(\\d{1,2})[:.](\\d{2})(am|pm)?$").find(t)
            val m2 = Regex("^(\\d{1,2})(am|pm)$").find(t)
            if (m1 != null) { hr = m1.groupValues[1].toInt(); mn = m1.groupValues[2].toInt(); suffix = m1.groupValues[3]; break }
            if (m2 != null) { hr = m2.groupValues[1].toInt(); suffix = m2.groupValues[2]; break }
            if (i > 0 && t in setOf("baje", "bje", "बजे", "oclock", "o'clock", "am", "pm")) {
                val n = numOf(tk[i - 1])
                if (n != null) {
                    hr = n
                    if (i >= 2) {
                        when (tk[i - 2]) {
                            "saade", "saadhe" -> mn = 30
                            "sawa" -> mn = 15
                            "paune" -> { hr = if (n == 1) 12 else n - 1; mn = 45 }
                            else -> {}
                        }
                    }
                    if (t == "am" || t == "pm") suffix = t
                    break
                }
            }
        }
        if (hr < 0 || hr > 24 || mn > 59) return null
        val w = tk.toSet()
        val per = when {
            suffix == "am" || "am" in w || "subah" in w || "morning" in w || "sawere" in w -> "am"
            suffix == "pm" || "pm" in w || "shaam" in w || "sham" in w || "evening" in w -> "pm"
            "dopahar" in w || "afternoon" in w -> "noon"
            "raat" in w || "night" in w -> "night"
            else -> ""
        }
        val h24: Int = if (hr >= 13) hr else when (per) {
            "am" -> if (hr == 12) 0 else hr
            "pm" -> if (hr < 12) hr + 12 else hr
            "noon" -> if (hr in 1..6) hr + 12 else hr
            "night" -> if (hr in 6..11) hr + 12 else if (hr == 12) 0 else hr
            else -> {
                val now = java.util.Calendar.getInstance()
                val nowM = now.get(java.util.Calendar.HOUR_OF_DAY) * 60 + now.get(java.util.Calendar.MINUTE)
                val c1 = hr % 12; val c2 = hr % 12 + 12
                if (c1 * 60 + mn > nowM) c1 else if (c2 * 60 + mn > nowM) c2 else c1
            }
        }
        return Pair(h24 % 24, mn)
    }

    private fun swipeDir(p: List<String>): String? = when {
        p.any { it in setOf("left", "baye", "bayen", "bayein", "baayen", "baen", "बाएं", "लेफ्ट") } -> "swl"
        p.any { it in setOf("right", "daye", "dayen", "dayein", "daayen", "daen", "दाएं", "राइट") } -> "swr"
        p.any { it in setOf("up", "upar", "ऊपर") } -> "swu"
        p.any { it in setOf("down", "neeche", "niche", "नीचे") } -> "swd"
        else -> null
    }

    /** command ke lafz mein 1-2 akshar ki galti sudhaarna (message ke beech ke shabd nahi chhoote) */
    private val verbSet: Set<String> by lazy {
        (msgKw + callKw + searchKw + tapKw + actKw.keys + openWords + alarmKw + timerKw + remKw + cut + wifiKw + btKw + torchKw + volKw + brKw)
            .filter { v -> v.length >= 5 && v.all { it in 'a'..'z' } }.toSet()
    }
    private fun fixVerb(t: String): String {
        if (t.length < 5 || t in known || !t.all { it in 'a'..'z' }) return t
        val lim = if (t.length >= 8) 2 else 1
        var best: String? = null; var bd = 99; var tie = false
        for (v in verbSet) {
            if (kotlin.math.abs(v.length - t.length) > lim) continue
            val d = lev(v, t)
            if (d <= lim) { if (d < bd) { bd = d; best = v; tie = false } else if (d == bd && v != best) tie = true }
        }
        return if (best != null && !tie) best else t
    }

    /** alias -> Roman; Hindi script ka anjaan lafz (naam, query, message) Roman ban jata hai */
    private fun norm(t: String): String = alias[t] ?: if (t.any { isDev(it) } && t !in known) roman(t) else fixTypo(t)

    // ---------- typing / bolne ki galti sudharna (offline, bina AI) ----------
    /** Hinglish ki alag alag spelling ek jaisi: ph=f, w=v, ee=i, oo=u, kh=k, th=t, dohre akshar ek */
    private fun ph(s: String): String =
        s.lowercase(Locale.ROOT).replace("ph", "f").replace("w", "v").replace("ee", "i").replace("oo", "u")
            .replace("kh", "k").replace("th", "t").replace("sh", "s").replace(Regex("(.)\\1+"), "$1")
    private val typoCands: List<String> by lazy { known.filter { it.length >= 4 && it.none { c -> isDev(c) || c.isDigit() } } }
    /** "kholoo"->"kholo", "sarch"->"search", "vhatsapp"-jaisa awaaz-galti. Sirf tab jab ek hi saaf jawab ho, warna jaisa hai waisa. */
    private fun fixTypo(t: String): String {
        if (t.length < 4 || t in known || t.any { it.isDigit() || isDev(it) }) return t
        val pt = ph(t)
        var best = Int.MAX_VALUE; var pick: String? = null; var tie = false
        for (k in typoCands) {
            if (k[0] != t[0] && ph(k)[0] != pt[0]) continue
            val d = lev(pt, ph(k))
            if (d < best) { best = d; pick = k; tie = false } else if (d == best && k != pick) tie = true
        }
        val lim = if (t.length <= 7) 1 else 2
        if (pick == null || tie || best > lim) return t
        if (best == 1 && t.length < 5) return t   // chhote shabd (naam) galti se na badlein
        return pick
    }

    // ---------- Docera ko control (Docera ke ContentProvider ko command bhejna) ----------
    private fun callDocera(json: String): Pair<Boolean, String> {
        try {
            if (packageManager.resolveContentProvider("com.docera.parwez.cmd", 0) == null) return Pair(false, "Docera not found (or Docera has no command receiver)")
            val ex = Bundle().apply { putString("json", json) }
            val b = contentResolver.call(android.net.Uri.parse("content://com.docera.parwez.cmd"), "cmd", null, ex)
                ?: return Pair(false, "Docera did not respond")
            return Pair(b.getBoolean("ok"), b.getString("msg") ?: "")
        } catch (e: Exception) { return Pair(false, "Docera error: " + (e.message ?: "")) }
    }

    /** note / page wale commands Docera ko screen par bhi laate hain; block_app chupchap background mein hota hai */
    private fun docUiAction(json: String): Boolean = try {
        JSONObject(json).optString("action") in setOf("new_note", "append_note", "open_note", "open_page")
    } catch (_: Exception) { false }

    private fun openDocera() {
        try {
            packageManager.getLaunchIntentForPackage("com.docera.parwez")?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { startActivity(it) }
        } catch (_: Exception) {}
    }

    /**
     * "research karo <topic>": Settings mein chuna AI app kholo -> sawaal bhejo -> jawab poora hone tak ruko ->
     * jawab ka "Copy" dabao -> Docera mein clipboard se naya note banao.
     */
    private var resBusy = false
    private var resOkAt = 0L
    private var resOkTopic = ""
    private fun resJustDone(topic: String) = topic == resOkTopic && System.currentTimeMillis() - resOkAt < 120_000L

    private fun runResearch(st: Step.Research, a: NotchA11y, done0: (Boolean, Long) -> Unit) {
        if (resBusy || resJustDone(st.topic)) { done0(true, 0L); return }   // wahi research dobara chali to chhod do
        resBusy = true
        val done: (Boolean, Long) -> Unit = { ok, w -> resBusy = false; done0(ok, w) }
        val ai = ResearchPrefs.ALL.firstOrNull { it.key == st.ai } ?: ResearchPrefs.selected(this)
        val li = ResearchPrefs.launchIntent(this, ai)
        if (li == null) { say("${ai.label} is not installed (pick another in Settings R1)"); done(false, 0L); return }
        say("Opening ${ai.label}...")
        startActivity(li)
        a.askAi(st.prompt) { sent ->
            if (!sent) { say("Could not send the question to ${ai.label} (check login / message box)"); done(false, 0L); return@askAi }
            say("${ai.label} is writing the answer, please wait...")
            a.waitReplyDone(150_000L) {
                say("Copying the answer...")
                a.tapLastCopy { copied ->
                    if (!copied) { say("Could not find the Copy button on the answer"); done(false, 0L); return@tapLastCopy }
                    Thread {
                        val j = JSONObject().put("action", "new_note").put("clip", true).put("title", "Research: " + st.topic.take(60))
                        val r = callDocera(j.toString())
                        h.post {
                            if (r.first) { resOkAt = System.currentTimeMillis(); resOkTopic = st.topic; openDocera(); say("Research saved as a Docera note"); done(true, 800L) }
                            else { say(r.second.ifBlank { "Could not create the Docera note" }); done(false, 0L) }
                        }
                    }.start()
                }
            }
        }
    }

    /**
     * Plugin: research jaisa hi raasta - AI app kholo (photo ho to Share se dekar) -> sawal bhejo -> jawab poora hone tak ruko
     * -> Copy dabao -> Docera mein naya note (photo ke saath). Koi API key nahi chahiye.
     * "save" (sirf photo + text) mein AI ki zaroorat nahi.
     */
    private fun runPlugin(st: Step.Plugin, a: NotchA11y?, done0: (Boolean, Long) -> Unit) {
        if (resBusy) { done0(true, 0L); return }
        resBusy = true
        val done: (Boolean, Long) -> Unit = { ok, w -> resBusy = false; done0(ok, w) }
        val label = Plugins.label(st.key)
        val hasImg = st.img != null && java.io.File(st.img).exists()

        fun saveNote(title: String, text: String?, clip: Boolean, okMsg: String) {
            Thread {
                val j = JSONObject().put("action", "new_note").put("title", title)
                if (clip) j.put("clip", true) else j.put("text", text ?: "")
                Plugins.attachToDocera(j, if (hasImg) st.img else null)
                val r = callDocera(j.toString())
                h.post {
                    if (r.first) { openDocera(); say(okMsg); done(true, 800L) }
                    else { say(r.second.ifBlank { "Could not create the Docera note" }); done(false, 0L) }
                }
            }.start()
        }

        if (st.key == "save") {
            saveNote(if (st.text.isNotBlank()) st.text.lines().first().take(50) else "Photo", st.text, false, "Photo saved to a Docera note")
            return
        }
        if (a == null) { say("Turn on the Accessibility service"); done(false, 0L); return }
        val ai = ResearchPrefs.ALL.firstOrNull { it.key == st.ai } ?: ResearchPrefs.selected(this)
        val prompt = Plugins.buildPrompt(st.key, st.text, st.lang, hasImg)
        val title = Plugins.noteTitle(st.key, st.text, st.lang)
        val base = ResearchPrefs.launchIntent(this, ai)
        if (base == null) { say("${ai.label} is not installed (pick another in Settings R1)"); done(false, 0L); return }
        say("Opening ${ai.label}...")
        var shared = false
        if (hasImg) {
            val uri = Plugins.shareUri(this, st.img!!)
            if (uri != null) {
                try {
                    val it = Intent(Intent.ACTION_SEND).setType("image/jpeg").setPackage(ai.pkg)
                        .putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_TEXT, prompt)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    it.clipData = android.content.ClipData.newRawUri("", uri)
                    startActivity(it)
                    shared = true
                } catch (_: Exception) {}
            }
            if (!shared) { say("Could not pass the photo to ${ai.label} (does this app accept shared photos?)"); done(false, 0L); return }
        } else startActivity(base)
        a.askAi(prompt, if (shared) 4500L else 1200L) { sent ->
            if (!sent) { say("Could not send the question to ${ai.label} (check login / message box)"); done(false, 0L); return@askAi }
            say("${ai.label} is writing the answer, please wait...")
            a.waitReplyDone(if (st.key == "image") 240_000L else 150_000L) {
                say("Copying the answer...")
                a.tapLastCopy { copied ->
                    if (copied) saveNote(title, null, true, "$label: saved to a Docera note")
                    else if (st.key == "image") saveNote(title, "Prompt: ${st.text}\n(The image was created in ${ai.label} - save it from there)", false, "Image created in ${ai.label}; only the prompt went into the note")
                    else { say("Could not find the Copy button on the answer"); done(false, 0L) }
                }
            }
        }
    }

    // ---------- WhatsApp Channel post: "channel post <topic>" ----------
    private val chW = setOf("channel", "channels", "chanel", "chaanel", "chennel", "channal", "chanal", "cannel", "\u091a\u0948\u0928\u0932")
    private val chPostW = setOf("post", "posts", "posting", "update", "publish", "share", "upload", "daalo", "dalo", "daal", "dal", "daaldo", "bhejo", "bhej", "likho", "likh", "dedo")
    private val chSkip = setOf("whatsapp", "business", "wa", "on", "to", "in", "at", "par", "pe", "mein", "me", "men", "ko", "karo", "kar", "kardo", "karna", "kariye", "kijiye", "ke", "ka", "ki", "liye",
        "about", "topic", "please", "plz", "a", "an", "the", "my", "apne", "apna", "meri", "mera", "se", "with", "using", "aur", "then", "phir", "and", "for", "of", "new")

    private fun channelFromTopic(topic: String, aiKey: String?): List<Step> {
        if (ChannelPrefs.name(this).isBlank()) return listOf(Step.Say("Set your channel name in Settings (C1) first"))
        // no topic is fine when you saved your own prompt (e.g. a multi-day plan); the default prompt needs a topic
        if (topic.isBlank() && !ChannelPrefs.hasCustomPrompt(this)) return listOf(Step.Say("Which topic should I post to the channel?"))
        val ai = aiKey ?: ResearchPrefs.selected(this).key
        return listOf(Step.Channel(topic.ifBlank { "daily post" }, ChannelPrefs.buildPrompt(this, topic), ai))
    }

    private fun channelSteps(raw0: String): List<Step>? {
        val orig = romanLine(raw0).trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (orig.isEmpty()) return null
        val low = orig.map { it.lowercase(Locale.ROOT).trim(',', '.', '!', '?') }
        val iCh = low.indexOfFirst { it in chW }
        if (iCh < 0) return null
        val iPost = low.indexOfFirst { it in chPostW }
        if (iPost < 0) return null
        val aiW = low.indices.firstOrNull { ResearchPrefs.byWord(low[it]) != null }
        val rest = orig.indices.filter { it != iCh && it != iPost && it != aiW }
        val topic = rest.dropWhile { low[it] in chSkip || low[it] in chPostW }.dropLastWhile { low[it] in chSkip || low[it] in chPostW }
            .joinToString(" ") { orig[it] }.trim()
        return channelFromTopic(topic, aiW?.let { ResearchPrefs.byWord(low[it])?.key })
    }

    /**
     * Channel post: same road as research (AI app -> prompt -> wait -> Copy), then WhatsApp / WhatsApp Business ->
     * Updates tab -> your channel -> paste -> Send. On a scheduled run: afterwards mobile data OFF and phone locked.
     */
    private fun runChannel(st: Step.Channel, a: NotchA11y, done0: (Boolean, Long) -> Unit) {
        if (resBusy) { done0(true, 0L); return }
        val cname = ChannelPrefs.name(this)
        if (cname.isBlank()) { say("Set your channel name in Settings (C1) first"); done0(false, 0L); return }
        val wa = ChannelPrefs.launchIntent(this)
        if (wa == null) { say("WhatsApp is not installed"); done0(false, 0L); return }
        val ai = ResearchPrefs.ALL.firstOrNull { it.key == st.ai } ?: ResearchPrefs.selected(this)
        val li = ResearchPrefs.launchIntent(this, ai)
        if (li == null) { say("${ai.label} is not installed (pick another in Settings R1)"); done0(false, 0L); return }
        resBusy = true
        val done: (Boolean, Long) -> Unit = { ok, w -> resBusy = false; done0(ok, w) }
        val scheduled = schedRun && ChannelPrefs.cleanup(this)
        val waName = ChannelPrefs.label(this)

        fun finish(ok: Boolean) {
            if (!scheduled) { done(ok, 800L); return }
            say(if (ok) "Posted. Turning data off and locking..." else lastSay + " - turning data off and locking...")
            h.postDelayed({
                a.toggleTile("mobile data|internet|data", 0) {
                    h.postDelayed({ a.act("lock"); done(ok, 800L) }, 600)
                }
            }, if (ok) 8000L else 1500L)
        }
        fun fail(m: String) { say(m); finish(false) }

        say("Opening ${ai.label}...")
        startActivity(li)
        a.askAi(st.prompt) { sent ->
            if (!sent) fail("Could not send the prompt to ${ai.label} (check login / message box)")
            else {
                say("${ai.label} is writing the post, please wait...")
                a.waitReplyDone(150_000L) {
                    say("Copying the answer...")
                    a.tapLastCopy { copied ->
                        if (!copied) fail("Could not find the Copy button on the answer")
                        else {
                            say("Opening $waName...")
                            startActivity(wa)
                            h.postDelayed({
                                a.waOpenUpdates { ok1 ->
                                    if (!ok1) fail("Could not find the Updates tab in $waName (bottom bar: ${a.waDiag})")
                                    else h.postDelayed({
                                        a.waOpenChannel(cname) { ok2 ->
                                            if (!ok2) fail("Channel not found: $cname")
                                            else h.postDelayed({
                                                a.waChannelReady { ok3 ->
                                                    if (!ok3) fail("Channel message box not found (are you the channel admin?)")
                                                    else {
                                                        say("Pasting the post...")
                                                        a.pasteClip { ok4 ->
                                                            if (!ok4) fail("Could not paste the post")
                                                            else a.tapSend { ok5 ->
                                                                if (ok5) { say("Posted to $cname"); finish(true) }
                                                                else fail("Send button not found")
                                                            }
                                                        }
                                                    }
                                                }
                                            }, 1500)
                                        }
                                    }, 1500)
                                }
                            }, 3000)
                        }
                    }
                }
            }
        }
    }

    // ---------- Facebook post: "facebook post <topic>" ----------
    private val fbW = setOf("facebook", "fb", "facebok", "facebuk", "fecebook", "faceboook", "\u092b\u0947\u0938\u092c\u0941\u0915", "\u0641\u06cc\u0633 \u0628\u06a9", "\u0641\u06cc\u0633\u0628\u06a9")
    private val fbPostW = chPostW - setOf("update", "share") + setOf("status")
    private val fbSkip = chSkip + setOf("status", "app", "lite")

    private fun fbFromTopic(topic: String, aiKey: String?): List<Step> {
        if (topic.isBlank() && !FbPrefs.hasCustomPrompt(this)) return listOf(Step.Say("Which topic should I post on Facebook?"))
        val ai = aiKey ?: ResearchPrefs.selected(this).key
        return listOf(Step.Facebook(topic.ifBlank { "daily post" }, FbPrefs.buildPrompt(this, topic), ai))
    }

    private fun fbSteps(raw0: String): List<Step>? {
        val orig = romanLine(raw0).trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (orig.isEmpty()) return null
        val low = orig.map { it.lowercase(Locale.ROOT).trim(',', '.', '!', '?') }
        val iFb = low.indexOfFirst { it in fbW }
        if (iFb < 0 || iFb > 3) return null          // "research facebook post ideas" etc. must not post
        if (low.firstOrNull() in setOf("block", "unblock", "research", "translate", "summarize", "explain")) return null
        val iPost = low.indexOfFirst { it in fbPostW }
        if (iPost < 0) return null
        val aiW = low.indices.firstOrNull { ResearchPrefs.byWord(low[it]) != null }
        val rest = orig.indices.filter { it != iFb && it != iPost && it != aiW }
        val topic = rest.dropWhile { low[it] in fbSkip || low[it] in fbPostW }.dropLastWhile { low[it] in fbSkip || low[it] in fbPostW }
            .joinToString(" ") { orig[it] }.trim()
        return fbFromTopic(topic, aiW?.let { ResearchPrefs.byWord(low[it])?.key })
    }

    /**
     * Facebook post: same road as the channel post (AI app -> prompt -> wait -> Copy), then Facebook ->
     * home feed -> \"What's on your mind?\" -> paste -> Post. Posts as whichever profile is active in the app
     * (switch to your Page profile in Facebook first if it should go to a Page).
     * On a scheduled run: afterwards mobile data OFF and phone locked.
     */
    private fun runFacebook(st: Step.Facebook, a: NotchA11y, done0: (Boolean, Long) -> Unit) {
        if (resBusy) { done0(true, 0L); return }
        val fb = FbPrefs.launchIntent(this)
        if (fb == null) { say("Facebook is not installed"); done0(false, 0L); return }
        val ai = ResearchPrefs.ALL.firstOrNull { it.key == st.ai } ?: ResearchPrefs.selected(this)
        val li = ResearchPrefs.launchIntent(this, ai)
        if (li == null) { say("${ai.label} is not installed (pick another in Settings R1)"); done0(false, 0L); return }
        resBusy = true
        val done: (Boolean, Long) -> Unit = { ok, w -> resBusy = false; done0(ok, w) }
        val scheduled = schedRun && FbPrefs.cleanup(this)
        val fbName = FbPrefs.label(this)

        fun finish(ok: Boolean) {
            if (!scheduled) { done(ok, 800L); return }
            say(if (ok) "Posted. Turning data off and locking..." else lastSay + " - turning data off and locking...")
            h.postDelayed({
                a.toggleTile("mobile data|internet|data", 0) {
                    h.postDelayed({ a.act("lock"); done(ok, 800L) }, 600)
                }
            }, if (ok) 8000L else 1500L)
        }
        fun fail(m: String) { say(m); finish(false) }

        say("Opening ${ai.label}...")
        startActivity(li)
        a.askAi(st.prompt) { sent ->
            if (!sent) fail("Could not send the prompt to ${ai.label} (check login / message box)")
            else {
                say("${ai.label} is writing the post, please wait...")
                a.waitReplyDone(150_000L) {
                    say("Copying the answer...")
                    a.tapLastCopy { copied ->
                        if (!copied) fail("Could not find the Copy button on the answer")
                        else {
                            say("Opening $fbName...")
                            startActivity(fb)
                            h.postDelayed({
                                a.fbOpenComposer { ok1 ->
                                    if (!ok1) fail("Could not find \"What's on your mind?\" in $fbName (screen: ${a.fbDiag})")
                                    else h.postDelayed({
                                        a.fbComposerReady { ok2 ->
                                            if (!ok2) fail("The Facebook post box did not open")
                                            else {
                                                say("Pasting the post...")
                                                a.pasteClip { ok3 ->
                                                    if (!ok3) fail("Could not paste the post")
                                                    else a.fbTapPost { ok4 ->
                                                        if (ok4) { say("Posted on Facebook"); finish(true) }
                                                        else fail("Post button not found or the post did not go - please check Facebook")
                                                    }
                                                }
                                            }
                                        }
                                    }, 1800)
                                }
                            }, 3500)
                        }
                    }
                }
            }
        }
    }

    private fun runDoc(st: Step.Doc, attempt: Int, done: (Boolean, Long) -> Unit) {
        h.postDelayed({
            Thread {
                val r = callDocera(st.json)
                h.post {
                    if (!r.first && st.retry && attempt < 3 && r.second.contains("screenshot", true)) runDoc(st, attempt + 1, done)
                    else {
                        if (r.first && docUiAction(st.json)) openDocera()
                        say(r.second.ifBlank { if (r.first) "Docera: done" else "Docera: failed" }); done(r.first, 800L)
                    }
                }
            }.start()
        }, if (st.retry) 1500L else 0L)
    }

    /**
     * docera mein <naam> pdf kholo | docera pdfs dikhao | docera library/notes/settings kholo
     * docera note likho <text> | docera <naam> note mein <text> jodo | docera <naam> note kholo
     * screenshot note mein daalo | screenshot <naam> note mein daalo
     */
    // ---------- awaaz ke jawab, "bolo", mobile limit ke yaad dilane ----------
    private var ranAny = false
    private val lastAlert = HashMap<String, Long>()

    /** Awaaz tab bolo jab setting ON ho aur phone silent/vibrate par na ho */
    private fun canTalk(): Boolean =
        UsageGuard.voiceOn(this) && (getSystemService(AUDIO_SERVICE) as android.media.AudioManager).ringerMode == android.media.AudioManager.RINGER_MODE_NORMAL

    private fun speakWhenReady(t: String, n: Int) {
        if (ttsReady) speak(t) else if (n < 12) h.postDelayed({ speakWhenReady(t, n + 1) }, 400)
    }

    private fun sayText(c: String): String? =
        Regex("^(?:bolo|bol|say|speak)\\s+(.+)$", RegexOption.IGNORE_CASE).find(c.trim())?.groupValues?.get(1)?.trim()

    private fun parseSay(raw: String): List<Step>? {
        val t = sayText(romanLine(raw)) ?: return null
        return if (t.isBlank()) null else listOf(Step.Say(t))
    }

    private fun fmtMin(m: Long): String = if (m >= 60) "${m / 60} hours ${m % 60} minutes" else "$m minutes"

    private fun alert(key: String, gapMs: Long, first: String, next: String) {
        val day = java.text.SimpleDateFormat("yyyyMMdd", Locale.ENGLISH).format(java.util.Date())
        val k = "$key|$day"
        val now = System.currentTimeMillis()
        val last = lastAlert[k]
        if (last != null && now - last < gapMs) return
        lastAlert[k] = now
        Style.buzz(this, "heavy")
        val text = if (last == null) first else next
        if (canTalk()) speak(text) else say(text)
    }

    private val usageLoop = object : Runnable {
        override fun run() {
            try { usageTick() } catch (_: Exception) {}
            h.postDelayed(this, 30_000L)
        }
    }

    private fun usageTick() {
        val lim = UsageGuard.limits(this)
        val screenLim = UsageGuard.screenLimit(this)
        if (lim.isEmpty() && screenLim <= 0) return
        if (!UsageGuard.hasAccess(this)) return
        if (!(getSystemService(POWER_SERVICE) as android.os.PowerManager).isInteractive) return
        if (speaking) return
        val snap = UsageGuard.snapshot(this) ?: return
        val me = UsageGuard.userName(this)
        val fg = snap.fg
        if (fg != null) {
            val l = lim[fg]
            if (l != null && l > 0) {
                val used = (snap.perApp[fg] ?: 0L) / 60_000L
                if (used >= l) {
                    val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(fg, 0)).toString() } catch (_: Exception) { fg }
                    alert("app:$fg", 5 * 60_000L,
                        "$me, you have used $label for ${fmtMin(used)}; your limit was ${fmtMin(l.toLong())}. Please close it now.",
                        "$me, $label is still open. Please close it now.")
                    return
                }
            }
        }
        if (screenLim > 0) {
            val total = snap.total / 60_000L
            if (total >= screenLim) {
                alert("screen", 15 * 60_000L,
                    "$me, you have used your phone for ${fmtMin(total)} today; your limit was ${fmtMin(screenLim.toLong())}. Please put the phone down now.",
                    "$me, you are over your phone limit. Take a break.")
            }
        }
    }

    private fun parseDocera(raw0: String): List<Step>? {
        val orig = romanLine(raw0).trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (orig.isEmpty()) return null
        val low = orig.map { it.lowercase(Locale.ROOT).trim(',', '.', '!', '?') }
        fun near(t: String, w: String) = t.length >= 4 && lev(ph(t), ph(w)) <= (if (w.length >= 7) 2 else 1)
        val noteW = setOf("note", "notes", "nots", "noat", "nout")
        val addW = setOf("daalo", "dalo", "daal", "upload", "add", "lagao", "jodo", "jod", "save", "rakho", "attach", "daalna", "dalna")
        val writeW = setOf("likho", "likh", "likhna", "write", "jodo", "jod", "add", "daalo", "dalo", "naya", "nayi", "new", "banao", "bana", "create", "save")
        val skip = setOf("mein", "me", "men", "par", "pe", "ko", "ka", "ki", "ke", "app", "ek", "please", "plz", "kholo", "khol", "kholen", "kholiye", "karo", "kar", "do", "dijiye", "open", "show", "dikhao")
        val pdfW = setOf("pdf", "pdfs", "book", "books", "kitab", "kitaab", "file", "files")
        val listW = setOf("list", "sab", "saare", "sabhi", "kaunse", "batao")
        val pageW = mapOf("home" to "home", "library" to "library", "lib" to "library", "liberary" to "library", "laibrary" to "library", "bookshelf" to "library",
            "folders" to "folders", "folder" to "folders", "settings" to "settings", "setting" to "settings", "more" to "more",
            "trash" to "trash", "favorites" to "favorites", "favourite" to "favorites", "favorite" to "favorites", "fav" to "favorites")
        fun doc(o: JSONObject, label: String, retry: Boolean = false) = Step.Doc(o.toString(), label, retry)
        fun J(a: String) = JSONObject().put("action", a)

        val iNote = low.indexOfFirst { it in noteW }
        val iShot = low.indexOfFirst { near(it, "screenshot") }
        // ---- screenshot ko note mein daalna ----
        if (iShot >= 0 && iNote >= 0 && low.any { it in addW }) {
            val name = if (iShot < iNote) orig.subList(iShot + 1, iNote).filterIndexed { i, _ -> low[iShot + 1 + i] !in skip && low[iShot + 1 + i] !in addW }.joinToString(" ") else ""
            val o = J("attach_screenshot"); if (name.isNotBlank()) o.put("note", name)
            return listOf(Step.Act("shot"), doc(o, "screenshot -> Docera note", true))
        }
        // ---- app block: "facebook block karo", "docera mein instagram do ghante ke liye block karo" ----
        if (low.any { it == "unblock" || it == "unblok" || it == "anblock" }) {
            if (low.any { near(it, "docera") }) return listOf(Step.Say("Removing a Docera block midway is not allowed"))
        }
        val blockW = setOf("block", "blok", "blocks", "bloc", "blaak", "blauk", "blocked")
        val iBlk = low.indexOfFirst { it in blockW }
        if (iBlk >= 0 && !(iNote >= 0 && low.any { it in writeW })) {
            val dayUnit = setOf("din", "day", "days", "dino")
            var total = 0.0; val used = mutableSetOf<Int>()
            for (i in low.indices) {
                val t = low[i]
                val u = when { t in minUnit -> 1.0; t in hrUnit -> 60.0; t in dayUnit -> 1440.0; else -> 0.0 }
                if (u == 0.0) continue
                used.add(i)
                if (i == 0) continue
                val pv = low[i - 1]
                val n: Double? = when (pv) {
                    "aadha", "adha", "half" -> 0.5; "dedh", "derh" -> 1.5; "dhai", "dhaai" -> 2.5
                    else -> numOf(pv)?.toDouble()
                }
                if (n != null) { total += n * u; used.add(i - 1) }
            }
            val mins = if (total > 0) total.toInt().coerceIn(1, 10080) else 30
            val blkSkip = skip + setOf("karo", "kar", "kardo", "karna", "kariye", "kijiye", "dena", "de", "dedo", "ko", "ke", "liye", "tak", "for", "ka", "ki", "block", "blok",
                "blocks", "bloc", "blaak", "blauk", "blocked", "docera", "please", "plz", "sirf", "abhi", "now", "isko", "isse", "apps", "the", "my", "meri", "mera", "se", "aur", "and")
            val appName = orig.indices.filter { it !in used && it != iBlk && low[it] !in blkSkip && !near(low[it], "docera") }.joinToString(" ") { low[it] }
            if (appName.isBlank()) return listOf(Step.Say("Which app should be blocked?"))
            val pkg = findApp(appName) ?: return listOf(Step.Say("App not found: $appName"))
            val lbl = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { appName }
            val o = J("block_app").put("app", lbl).put("pkg", pkg).put("minutes", mins)
            return listOf(doc(o, "Docera: $lbl blocked for ${fmtMin(mins.toLong())}"))
        }

        // ---- research: "research karo <topic>", "claude mein research karo <topic>" ----
        val rsW = setOf("research", "risarch", "risurch", "risearch", "resarch", "reserch", "risarcha", "reseach")
        val iRs = low.indexOfFirst { it in rsW }
        if (iRs >= 0 && !(iNote in 0 until iRs && low.any { near(it, "docera") })) {
            val aiW = low.indices.firstOrNull { ResearchPrefs.byWord(low[it]) != null }
            val ai = aiW?.let { ResearchPrefs.byWord(low[it]) } ?: ResearchPrefs.selected(this)
            val rsSkip = skip + setOf("karo", "kar", "kardo", "karna", "kariye", "kijiye", "dijiye", "dedo", "ke", "bare", "baare", "baarein", "barein", "about", "on", "ka", "ki", "liye", "topic",
                "se", "pe", "par", "chat", "is", "iske", "iska", "isko", "uske", "research", "please", "plz", "aur", "then", "phir", "docera", "note", "notes", "banao", "bana", "me", "mein", "men")
            val before = (0 until iRs).filter { it != aiW && low[it] !in rsSkip && !near(low[it], "docera") }.joinToString(" ") { orig[it] }
            val after = (iRs + 1 until orig.size).toList().filter { it != aiW }
                .dropWhile { low[it] in rsSkip }.dropLastWhile { low[it] in rsSkip }.joinToString(" ") { orig[it] }
            val topic = listOf(before, after).filter { it.isNotBlank() }.joinToString(" ").trim()
            if (topic.isBlank()) return listOf(Step.Say("Which topic should I research?"))
            val prompt = "Research this topic in detail and give a clear, well-organized answer: $topic"
            return listOf(Step.Research(prompt, topic, ai.key))
        }

        val iDoc = low.indexOfFirst { near(it, "docera") }
        if (iDoc < 0) return null
        val keep = orig.indices.filter { it != iDoc }
        fun words(ex: Set<String>) = keep.filter { low[it] !in skip && low[it] !in ex }.joinToString(" ") { orig[it] }

        val iPdf = low.indexOfFirst { it in pdfW }
        if (iPdf >= 0 && (iNote < 0 || iPdf < iNote)) {
            val name = words(pdfW + listW)
            if (low.any { it in listW } && name.isBlank()) return listOf(doc(J("list_pdfs"), "Docera PDF list"))
            if (name.isBlank()) return listOf(doc(J("open_page").put("page", "library"), "Docera library"))
            return listOf(doc(J("open_pdf").put("name", name), "Docera PDF: $name"))
        }
        if (iNote >= 0) {
            val hasWrite = low.any { it in writeW }
            if (!hasWrite) {
                val name = words(noteW)
                if (name.isBlank()) return listOf(doc(J("open_page").put("page", "notes"), "Docera notes"))
                return listOf(doc(J("open_note").put("name", name), "Docera note: $name"))
            }
            val before = (0 until iNote).filter { it != iDoc && low[it] !in skip && low[it] !in writeW }.joinToString(" ") { orig[it] }
            val tail = (iNote + 1 until orig.size).toList()
                .dropWhile { low[it] in skip || low[it] in writeW }
                .dropLastWhile { low[it] in skip || low[it] in writeW }
            val text = tail.joinToString(" ") { orig[it] }
            if (before.isNotBlank()) {
                if (text.isBlank()) return null
                return listOf(doc(J("append_note").put("name", before).put("text", text), "Write into Docera note \"$before\""))
            }
            return listOf(doc(J("new_note").put("text", text), "Docera: new note"))
        }
        val pg = low.firstNotNullOfOrNull { pageW[it] }
        if (pg != null) return listOf(doc(J("open_page").put("page", pg), "Docera: $pg"))
        return null
    }

    private fun parse(raw: String): List<Step> {
        val out = mutableListOf<Step>()
        for (chunk in raw.lowercase(Locale.ROOT).trim().split(seps)) {
            val base = chunk.split(Regex("\\s+")).filter { it.isNotBlank() }.map { norm(it) }
            val tokens = base.mapIndexed { i, t -> if (i == 0 || i == base.size - 1) fixVerb(t) else t }   // typo: "bhejoo"->"bhejo", "kholu"->"kholo" (sirf shuru/aakhir ka shabd)
            // timer / alarm / reminder: poori line ek saath (kyunki "karo" se line toot jati hai)
            if (tokens.any { it in timerKw || it in alarmKw || it in remKw }) {
                val hasAlarm = tokens.any { it in alarmKw }
                val isCancel = tokens.any { it in offKw || it in cancelKw } && tokens.none { it in remKw }
                val dur = parseDur(tokens)
                val clk = if (dur == null) parseClock(tokens) else null
                val label = tokens.filter { t -> t !in fill && t !in labelJunk && t !in timerKw && t !in alarmKw && t !in remKw &&
                    t !in clockWords && t !in minUnit && t !in hrUnit && t !in secUnit && !t.first().isDigit() && numOf(t) == null }.joinToString(" ")
                when {
                    isCancel -> out.add(Step.Dev(if (hasAlarm) "showalarms" else "showtimers"))
                    dur != null -> out.add(Step.Dev("timer|$dur|$label"))
                    clk != null -> out.add(Step.Dev("alarm|${clk.first}|${clk.second}|$label"))
                    else -> out.add(Step.Dev("needtime"))
                }
                continue
            }
            // "search arijit singh" / "call ali" / "tap play video" (verb pehle) bhi chalega
            val f0 = tokens.firstOrNull()
            if (f0 != null && tokens.size > 1 && (f0 in searchKw || (f0 in callKw && tokens.none { it in endW || it in ansW }) || (f0 in tapKw && tokens.none { it in ordMap }))) {
                val q = tokens.drop(1).filter { it !in fill }.joinToString(" ")
                out.add(if (f0 in searchKw) Step.Search(q) else if (f0 in callKw) Step.Call(q) else Step.Tap(q))
                continue
            }
            val parts = mutableListOf<List<String>>(); var acc = mutableListOf<String>()
            for ((i, t) in tokens.withIndex()) {
                acc.add(t)
                if (t in cut && i < tokens.size - 1 && acc.none { it in msgKw }) { parts.add(acc); acc = mutableListOf() }
            }
            if (acc.isNotEmpty()) parts.add(acc)
            for (pp in parts) {
                var p = pp
                // "yt par first video par click karo" -> pehle app kholo, phir baaki
                val oi0 = p.indexOfFirst { it in ordMap }
                if (oi0 > 1) {
                    val k = p.indexOfFirst { it in postpos }
                    if (k in 1 until oi0) {
                        val pre = p.take(k).filter { it !in fill }.joinToString(" ")
                        if (pre.isNotEmpty() && findApp(pre) != null) { out.add(Step.Open(pre)); p = p.drop(k + 1) }
                    }
                }
                val mi = p.indexOfFirst { it in msgKw }; val ci = p.indexOfFirst { it in callKw }
                val si = p.indexOfFirst { it in searchKw }; val ti = p.indexOfFirst { it in tapKw }
                val ty = p.indexOf("type"); val sc = p.indexOf("scroll"); val ai = p.indexOfFirst { it in actKw }
                val sw = p.indexOf("swipe")
                val oi = p.indexOfFirst { it in ordMap }
                val openish = p.any { it in openWords }
                val hasVol = p.any { it in volKw }; val hasBr = p.any { it in brKw }; val hasTorch = p.any { it in torchKw }
                val upW = p.any { it in upKw }; val downW = p.any { it in downKw }; val offW = p.any { it in offKw }
                val ordOk = oi >= 0 && (ti >= 0 || (oi < p.size - 1 && p[oi + 1] !in fill && p[oi + 1] !in cut))
                val devName: String? = if (openish) null else when {
                    p.any { it in muteKw } && (hasVol || p.size <= 2) -> "mute"
                    hasVol -> when {
                        p.any { it in maxKw } -> "volmax"
                        downW -> "voldown"
                        upW -> "volup"
                        else -> "volshow"
                    }
                    hasBr -> when {
                        p.any { it in minKw } -> "brmin"
                        p.any { it in maxKw } -> "brmax"
                        downW -> "brdown"
                        else -> "brup"
                    }
                    hasTorch && (upW || downW) && p.any { it == "light" || it == "lite" || it == "लाइट" } -> if (downW) "brdown" else "brup"
                    hasTorch -> if (offW) "torchoff" else "torchon"
                    else -> null
                }
                val onW = p.any { it in onKw }
                val isPhone = ci >= 0 || p.any { it in phoneKw }
                val callDev: String? = when {
                    isPhone && p.any { it in endW } -> "endcall"
                    isPhone && p.any { it in ansW } -> "answercall"
                    else -> null
                }
                val spk = p.any { it in spkKw }
                val tileLabels: String? = if (openish) null else when {
                    p.any { it in wifiKw } -> "wi-fi|wifi|wlan"
                    p.any { it in btKw } -> "bluetooth"
                    p.any { it in airKw } -> "airplane|aeroplane|flight mode"
                    p.any { it in hotKw } -> "hotspot|tethering"
                    p.any { it in dndKw } -> "do not disturb|dnd"
                    p.any { it in rotKw } -> "auto-rotate|auto rotate|rotation|rotate"
                    p.any { it in dataKw } && (onW || offW) -> "mobile data|internet|data"
                    else -> null
                }
                val tileWant = if (onW) 1 else if (offW) 0 else -1
                val contactIdx = p.indexOfFirst { it in contactKw }
                val contactName = if (openish || contactIdx < 0) "" else
                    p.filterIndexed { i, _ -> i != contactIdx }.filter { it !in fill && it !in labelJunk }.joinToString(" ")
                val photoName: String? = if (openish) null else when {
                    p.any { it == "selfie" || it == "सेल्फी" } -> "selfie"
                    p.any { it in photoKw } && p.any { it in shootKw } -> "photo"
                    else -> null
                }
                val medWords = p.filter { it in medSet }
                val medOnly = medWords.isNotEmpty() && p.all { it in medSet || it in fill || it in offKw || it in onKw }
                val mediaName: String? = if (!medOnly || openish) null else when {
                    p.any { it in mNext } -> "mnext"
                    p.any { it in mPrev } -> "mprev"
                    p.any { it in mPause } || (p.any { it in mSong } && offW) -> "mpause"
                    else -> "mplay"
                }
                val infoName: String? = if (openish) null else when {
                    p.any { it in batKw } -> "ibat"
                    p.any { it in dateKw } -> "idate"
                    p.any { it in timeKw } && p.none { numOf(it) != null } -> "itime"
                    else -> null
                }
                fun rest(skip: Int) = p.filterIndexed { i, _ -> i != skip }.filter { it !in fill }.joinToString(" ")
                if (mi >= 0) {
                    val before = p.take(mi).filter { it !in fill }.joinToString(" ")
                    val after = p.drop(mi + 1).dropWhile { it in fill }.joinToString(" ")
                    if (after.isNotEmpty()) { if (before.isNotEmpty()) out.add(Step.Search(before)); out.add(Step.Msg(after)) }
                    else if (before.isNotEmpty()) out.add(Step.Msg(before))   // "hi bejo"
                } else if (callDev != null) out.add(Step.Dev(callDev))
                else if (spk) out.add(Step.Tap("speaker|loudspeaker"))
                else if (ci >= 0) out.add(Step.Call(rest(ci)))
                else if (si >= 0) out.add(Step.Search(rest(si)))
                else if (tileLabels != null) out.add(Step.Tile(tileLabels, tileWant))
                else if (devName != null) out.add(Step.Dev(devName))
                else if (contactName.isNotEmpty()) out.add(Step.Dev("contact|$contactName"))
                else if (photoName != null) out.add(Step.Dev(photoName))
                else if (mediaName != null) out.add(Step.Dev(mediaName))
                else if (infoName != null) out.add(Step.Dev(infoName))
                else if (p.any { it in dblKw }) out.add(Step.Act("doubletap"))
                else if (ordOk && ty < 0) out.add(Step.TapN(ordMap[p[oi]]!!,
                    p.filterIndexed { i, _ -> i != oi }.filter { it !in fill && it !in tapKw && it !in cut }.joinToString(" ")))
                else if (ti >= 0) out.add(Step.Tap(rest(ti)))
                else if (ty >= 0) out.add(Step.Type(p.drop(ty + 1).joinToString(" ")))
                else if (sw >= 0 && swipeDir(p) != null) out.add(Step.Act(swipeDir(p)!!))
                else if (sc >= 0) {
                    val upw = p.any { it in setOf("up", "upar", "ऊपर") }; val au = p.any { it in autoKw }
                    out.add(Step.Act(if (au) (if (upw) "autoup" else "autodown") else (if (upw) "scrollup" else "scrolldown")))
                }
                else if (ai >= 0) out.add(Step.Act(actKw[p[ai]]!!))
                else out.add(Step.Open(p.filter { it !in fill }.joinToString(" ")))
            }
        }
        return out.filter { s -> when (s) {
            is Step.Open -> s.q.isNotEmpty(); is Step.Call -> s.q.isNotEmpty(); is Step.Search -> s.q.isNotEmpty()
            is Step.Tap -> s.q.isNotEmpty(); is Step.Type -> s.t.isNotEmpty(); is Step.Msg -> s.t.isNotEmpty(); is Step.Act -> true
            is Step.Dev -> true; is Step.TapN -> true; is Step.Tile -> true; is Step.Doc -> true; is Step.Say -> true; is Step.Research -> true; is Step.Plugin -> true; is Step.Channel -> true; is Step.Facebook -> true } }
    }

    // ---------- commands ki line (queue): ek khatam hote hi agla shuru ----------
    /** voice=true: mic chalta rehta hai, bolte jao, commands line mein lagte jate hain.
     *  voice=false (typed): poora hone tak mic off, phir wapas on. */
    /**
     * Ek hi line mein kai kaam ("facebook block karo aur whatsapp kholo"): agar usme block / research wala hissa ho
     * to har hissa (",", "aur", "phir" se kata hua) alag samjha jata hai, warna purana tareeka.
     */
    /** panel mein chuna plugin / jodi photo. Plugin chip ho ya photo, to command yahin se plugin step banti hai. */
    private fun attachSteps(raw: String): List<Step>? {
        val sel = selPlugin; val img = pendingImg
        if (sel == null && img == null) return null
        selPlugin = null; pendingImg = null; js("clearAttach()")
        val req: Plugins.Req? = if (sel != null) Plugins.parse(raw, sel, img != null) else Plugins.parse(raw, null, true)
        val key = req?.key ?: "save"
        val text = req?.text ?: raw.trim()
        if (sel == "channel") return channelFromTopic(raw.trim(), null)
        if (sel == "facebook") return fbFromTopic(raw.trim(), null)
        if (key == "research" && img == null) {
            if (text.isBlank()) return listOf(Step.Say("Which topic should I research?"))
            return parseDocera("research karo $text") ?: listOf(Step.Research("Research this topic in detail and give a clear, well-organized answer: $text", text, ResearchPrefs.selected(this).key))
        }
        if (img == null && text.isBlank()) return listOf(Step.Say(noTextMsg(key)))
        return listOf(Step.Plugin(key, text, req?.lang, img, req?.ai))
    }

    private fun noTextMsg(key: String) = when (key) {
        "image" -> "What image should I create? Type or say it"
        "translate" -> "What should I translate? Type, or add a photo"
        "summarize" -> "What should I summarize? Type, or add a photo"
        "ocr" -> "Add a photo to extract its text"
        else -> "Type, or add a photo"
    }

    /** bina chip ke, seedha likhi/boli baat: "translate karo ...", "image banao ...", "photo ka summary" */
    private fun pluginTyped(raw: String): List<Step>? {
        val req = Plugins.parse(raw, null, false) ?: return null
        if (req.text.isBlank()) return listOf(Step.Say(noTextMsg(req.key)))
        return listOf(Step.Plugin(req.key, req.text, req.lang, null, req.ai))
    }

    private fun planSteps(raw: String): List<Step> {
        channelSteps(raw)?.let { return it }
        fbSteps(raw)?.let { return it }
        val chunks = raw.split(seps).map { it.trim() }.filter { it.isNotEmpty() }
        if (chunks.isNotEmpty() && Plugins.parse(chunks[0], null, false) != null) pluginTyped(raw)?.let { return it }
        if (chunks.size > 1) {
            val per = chunks.map { parseDocera(it) ?: pluginTyped(it) }
            // "docera note likho doodh, ande, bread" -> note ka text hai, tukde nahi karne
            val firstNoteWrite = per[0]?.any { st -> st is Step.Doc && (st.json.contains("\"new_note\"") || st.json.contains("\"append_note\"")) } == true
            if (per.any { it != null } && !firstNoteWrite) {
                val out = mutableListOf<Step>()
                for (i in chunks.indices) out.addAll(per[i] ?: parseSay(chunks[i]) ?: parse(chunks[i]))
                return out
            }
        }
        return parseDocera(raw) ?: pluginTyped(raw) ?: parseSay(raw) ?: parse(raw)
    }

    private fun submit(raw0: String, voice: Boolean) {
        val wasTyping = typing
        if (wasTyping) setTyping(false)
        h.removeCallbacks(idleClose); h.removeCallbacks(silenceRun); heard = ""; curPartial = ""
        val raw = findWake(raw0) ?: raw0            // "mj youtube kholo" -> "youtube kholo"
        if (isSelfCheck(raw)) { stopListen(); runSelfCheck(); return }
        val steps0 = attachSteps(raw) ?: planSteps(raw)
        // idhar-udhar ki baat ("is isamen") ko app ka naam samajhkar kholne ki koshish na ho
        val steps: List<Step> = if (looksLikeStrayOpen(raw, steps0)) emptyList() else steps0
        if (steps.isEmpty()) {
            // rule se na samjhe to offline AI se poochho (agar model download + ON ho)
            if (LlmBrain.usable(this) && !LlmBrain.downloading) { askAi(raw, voice); return }
            say("Could not understand the command"); if (voice) h.postDelayed({ startListen() }, 300) else afterRun(); return
        }
        LlmBrain.noteTurn(raw)     // agli chhoti baat ("aur badhao") ke liye
        if (steps.any { it is Step.Act && it.name == "close" } && NotchA11y.inst?.stopAuto() == true) {
            say("Scrolling stopped"); armIdle()
            if (voice) h.postDelayed({ if (panel != null && !typing) startListen() }, 250) else afterRun()
            return
        }
        if (steps.any { it is Step.Act && it.name == "close" }) { setWake(false); say("Closed, mic OFF"); hidePanel(false); return }
        val steps2 = steps.filter { st -> !(st is Step.Research && (resBusy || queue.any { it is Step.Research } || resJustDone(st.topic))) }
        if (steps2.isEmpty()) { if (voice) h.postDelayed({ if (panel != null && !typing) startListen() }, 250) else afterRun(); return }
        queue.addAll(steps2)
        if (voice) h.postDelayed({ if (panel != null && !typing) startListen() }, 250) else stopListen()
        if (!running) {
            running = true
            val g = gen
            h.postDelayed({ if (g == gen) pump() }, if (wasTyping) 500L else 0L)
        }
    }

    private val strayOpenWords = setOf("open", "kholo", "khol", "kolo", "khulo", "kholen", "kholiye", "start", "launch", "chalao", "chala", "खोलो", "खोल", "चलाओ")

    /** Sirf ek "Open" step, na koi kholo/open jaisa shabd, na koi app match -> ye command nahi, bas shor/baatcheet hai */
    private fun looksLikeStrayOpen(raw: String, steps: List<Step>): Boolean {
        val s = steps.singleOrNull() as? Step.Open ?: return false
        if (s.q.contains(".")) return false
        val t = wordRe.findAll(raw.lowercase(Locale.ROOT)).map { it.value }.toList()
        if (t.any { it in strayOpenWords }) return false
        return findApp(s.q) == null
    }

    /** Offline AI: khuli baat ko commands mein badalna. AI ke lines ko wahi purana parser jaanchta hai. */
    private fun askAi(raw: String, voice: Boolean) {
        stopListen(); say("AI is thinking...")
        Thread {
            val cached = LlmBrain.cached(this, raw)
            val lines = if (cached != null) cached.split("\n").filter { it.isNotBlank() } else LlmBrain.think(this, raw)
            h.post {
                val steps = ArrayList<Step>()
                for (l in lines) steps.addAll(parseDocera(l) ?: pluginTyped(l) ?: parseSay(l) ?: parse(l))
                if (steps.isEmpty()) {
                    say("AI could not understand either"); if (voice) h.postDelayed({ startListen() }, 300) else afterRun()
                } else {
                    if (cached == null) LlmBrain.remember(this, raw, lines.joinToString("\n"))
                    LlmBrain.noteTurn(lines.joinToString("; "))
                    queue.addAll(steps)
                    if (!running) { running = true; val g = gen; h.post { if (g == gen) pump() } }
                }
            }
        }.start()
    }

    /** queue khatam / fail -> panel khula ho to mic dobara sunne lage (agar pehle se sun raha ho to kuch nahi) */
    private fun afterRun() {
        if (panel == null) return
        armIdle()
        if (sr == null) h.postDelayed({ if (panel != null && !typing && sr == null && !running && !speaking) startListen() }, 900)
    }

    private fun pump() {
        val st = queue.removeFirstOrNull()
        if (st == null) {
            running = false
            if (ranAny) { ranAny = false; if (!speaking && canTalk()) speak("Done") }
            afterRun(); return
        }
        running = true; ranAny = true
        val g = gen
        if (needsUnlock(st) && Unlocker.isLocked(this)) {
            ensureUnlocked { ok ->
                if (g != gen) return@ensureUnlocked
                if (ok) { queue.addFirst(st); running = false; pump() }
                else { queue.clear(); running = false; ranAny = false; say("Phone is locked and could not be unlocked"); if (!speaking && canTalk()) speak("Could not unlock the phone"); afterRun() }
            }
            return
        }
        exec(st) { ok, wait ->
            if (g == gen) {
                if (ok) h.postDelayed({ if (g == gen) pump() }, wait)
                else {
                    queue.clear(); running = false; ranAny = false
                    if (!speaking && canTalk()) speak("Could not finish the task. " + lastSay)
                    afterRun()
                }
            }
        }
    }

    /** Lock par bhi chalne wale kaam: awaaz, brightness, torch, timer, alarm, bolna. Baaki sab ke liye pehle unlock. */
    private fun needsUnlock(st: Step): Boolean = when (st) {
        is Step.Say -> false
        is Step.Dev -> !(st.name.startsWith("timer|") || st.name.startsWith("alarm|") ||
            st.name in setOf("volup", "voldown", "volshow", "volmax", "mute", "brup", "brdown", "brmax", "brmin", "torchon", "torchoff", "mplay", "mpause"))
        else -> true
    }

    /** Lock ho to swipe-up + PIN (Unlocker), phir cb(true). Ek baar mein ek hi koshish chalti hai. */
    private fun ensureUnlocked(cb: (Boolean) -> Unit) {
        val a = NotchA11y.inst; val pin = Unlocker.getPin(this)
        if (!Unlocker.isLocked(this)) { cb(true); return }
        if (a == null || pin == null || !Unlocker.unlockOn(this)) { cb(false); return }
        a.unlock(pin, { Unlocker.isLocked(this) }) { ok -> h.postDelayed({ cb(ok && !Unlocker.isLocked(this)) }, 1200) }
    }

    private fun exec(st: Step, done: (Boolean, Long) -> Unit) {
        val a = NotchA11y.inst
        val need = { say("Turn on the Accessibility service"); done(false, 0L) }
        val fail: (String) -> Unit = { m -> say(m); done(false, 0L) }
        say(when (st) {
            is Step.Open -> "open ${st.q}"; is Step.Call -> "call ${st.q}"; is Step.Search -> "search ${st.q}"; is Step.Msg -> "message ${st.t}"
            is Step.Act -> st.name; is Step.Tap -> "tap ${st.q}"; is Step.Type -> "type ${st.t}"
            is Step.Dev -> st.name; is Step.TapN -> "tap #${st.n} ${st.q}"
            is Step.Tile -> "toggle ${st.labels.substringBefore('|')}"; is Step.Doc -> st.label; is Step.Say -> "bolo ${st.t}"; is Step.Research -> "research: ${st.topic}"; is Step.Plugin -> "${Plugins.label(st.key)}..."; is Step.Channel -> "channel post: ${st.topic}"; is Step.Facebook -> "facebook post: ${st.topic}" })
        when (st) {
            is Step.Open -> if (openApp(st.q)) done(true, 3000L) else fail("App not found: ${st.q}")
            is Step.Call -> if (doCall(st.q)) done(true, 800L) else done(false, 0L)
            is Step.Search -> doSearch(st.q) { ok -> if (ok) done(true, 800L) else fail("Search failed: ${st.q}") }
            is Step.Msg -> if (a == null) need() else a.sendMsg(st.t) { ok -> if (ok) { say("Message sent"); done(true, 800L) } else fail("Message not sent") }
            is Step.Act -> if (a == null) need() else { a.act(st.name); done(true, 800L) }
            is Step.Tap -> if (a == null) need() else a.tapText(st.q) { ok -> if (ok) done(true, 800L) else fail("Not found on screen: ${st.q}") }
            is Step.Type -> if (a == null) need() else a.typeText(st.t) { ok -> if (ok) done(true, 800L) else fail("Text box not found") }
            is Step.Dev -> when (st.name) {
                "photo", "selfie" -> if (a == null) need() else shoot(st.name == "selfie", a, done)
                else -> { runDev(st.name); done(true, 400L) }
            }
            is Step.Doc -> runDoc(st, 0, done)
            is Step.Say -> { speak(st.t); done(true, 1200L) }
            is Step.Research -> if (a == null) need() else runResearch(st, a, done)
            is Step.Plugin -> if (st.key != "save" && a == null) need() else runPlugin(st, a, done)
            is Step.Channel -> if (a == null) need() else runChannel(st, a, done)
            is Step.Facebook -> if (a == null) need() else runFacebook(st, a, done)
            is Step.Tile -> if (a == null) need() else a.toggleTile(st.labels, st.want) { ok -> if (ok) done(true, 800L) else fail("${st.labels.substringBefore('|')} tile not found in Quick Settings") }
            is Step.TapN -> if (a == null) need() else a.tapNth(st.n, st.q) { ok -> if (ok) done(true, 800L) else fail("Could not find ${st.q} number ${st.n}") }
        }
    }

    // ---------- phone control: volume, brightness, torch ----------
    private var torchOn = false

    private fun runDev(n: String) {
        if (n.startsWith("timer|")) { val a = n.split("|"); setTimer(a[1].toInt(), a.getOrElse(2) { "" }); return }
        if (n.startsWith("alarm|")) { val a = n.split("|"); setAlarm(a[1].toInt(), a[2].toInt(), a.getOrElse(3) { "" }); return }
        if (n.startsWith("contact|")) { openContact(n.substringAfter("|")); return }
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        val st = android.media.AudioManager.STREAM_MUSIC
        val ui = android.media.AudioManager.FLAG_SHOW_UI
        when (n) {
            "volup" -> { am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_RAISE, 0); am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_RAISE, ui) }
            "voldown" -> { am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_LOWER, 0); am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_LOWER, ui) }
            "volshow" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_SAME, ui)
            "volmax" -> am.setStreamVolume(st, am.getStreamMaxVolume(st), ui)
            "mute" -> am.setStreamVolume(st, 0, ui)
            "brup", "brdown", "brmax", "brmin" -> setBright(n)
            "torchon" -> setTorch(true)
            "torchoff" -> setTorch(false)
            "mplay" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            "mpause" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
            "mnext" -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            "mprev" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            "answercall" -> callCtl(true)
            "endcall" -> callCtl(false)
            "showalarms" -> try { startActivity(Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            "showtimers" -> try { startActivity(Intent(android.provider.AlarmClock.ACTION_SHOW_TIMERS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            "needtime" -> say("Please give a time too, e.g. 5 minutes or 6 am")
            "itime" -> speak("Time is " + java.text.SimpleDateFormat("h:mm a", Locale.ENGLISH).format(java.util.Date()))
            "idate" -> speak("Today is " + java.text.SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(java.util.Date()))
            "ibat" -> {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                speak("Battery is " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent" + (if (bm.isCharging) ", charging" else ""))
            }
        }
    }

    private fun setBright(n: String) {
        if (!android.provider.Settings.System.canWrite(this)) {
            say("Allow NotchCmd under Modify system settings")
            try { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            return
        }
        try {
            val cr = contentResolver
            val cur = android.provider.Settings.System.getInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS, 128)
            val v = when (n) { "brup" -> cur + 60; "brdown" -> cur - 60; "brmax" -> 255; else -> 10 }.coerceIn(5, 255)
            android.provider.Settings.System.putInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE, android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            android.provider.Settings.System.putInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS, v)
            say("Brightness " + (v * 100 / 255) + "%")
        } catch (_: Exception) { say("Could not change brightness") }
    }

    private fun setTorch(on: Boolean) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { say("Flash not found"); return }
            cm.setTorchMode(id, on); torchOn = on
            say(if (on) "Torch ON" else "Torch OFF")
        } catch (_: Exception) { say("Could not turn the torch on") }
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    @Suppress("DEPRECATION")
    private fun callCtl(answer: Boolean) {
        if (checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) != 0) { say("Grant the phone call permission (app button 2)"); return }
        try {
            val tm = getSystemService(TELECOM_SERVICE) as android.telecom.TelecomManager
            if (answer) tm.acceptRingingCall() else tm.endCall()
        } catch (_: Exception) { say("Could not control the call") }
    }

    private fun fmtDur(sec: Int): String {
        val hh = sec / 3600; val mm = (sec % 3600) / 60; val ss = sec % 60
        return listOfNotNull(if (hh > 0) "$hh hours" else null, if (mm > 0) "$mm minutes" else null, if (ss > 0) "$ss seconds" else null).joinToString(" ")
    }

    private fun setTimer(sec: Int, label: String) {
        try {
            startActivity(Intent(android.provider.AlarmClock.ACTION_SET_TIMER)
                .putExtra(android.provider.AlarmClock.EXTRA_LENGTH, sec.coerceIn(1, 86400))
                .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Timer" })
                .putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            say("Timer set: " + fmtDur(sec))
        } catch (_: Exception) { say("Could not set the timer") }
    }

    private fun setAlarm(hh: Int, mm: Int, label: String) {
        try {
            startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
                .putExtra(android.provider.AlarmClock.EXTRA_HOUR, hh).putExtra(android.provider.AlarmClock.EXTRA_MINUTES, mm)
                .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Alarm" })
                .putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            say("Alarm set: " + String.format(Locale.ROOT, "%02d:%02d", hh, mm))
        } catch (_: Exception) { say("Could not set the alarm") }
    }

    private fun openContact(name: String) {
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != 0) { say("Grant the contacts permission"); return }
        contentResolver.query(ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.LOOKUP_KEY),
            ContactsContract.Contacts.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null)?.use {
            if (it.moveToFirst()) {
                val uri = ContactsContract.Contacts.getLookupUri(it.getLong(0), it.getString(1))
                try { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { say("Could not open the contact") }
                return
            }
        }
        val q = name.lowercase(Locale.ROOT).trim(); val lim = maxOf(1, q.length / 4)
        var bestD = 99; var bestUri: Uri? = null
        contentResolver.query(ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.LOOKUP_KEY, ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use {
            while (it.moveToNext()) {
                val dn = (it.getString(2) ?: continue).lowercase(Locale.ROOT)
                val d = minOf(lev(dn, q), dn.split(" ").minOf { w -> lev(w, q) }, lev(ph(dn), ph(q)), dn.split(" ").minOf { w -> lev(ph(w), ph(q)) })
                if (d <= lim && d < bestD) { bestD = d; bestUri = ContactsContract.Contacts.getLookupUri(it.getLong(0), it.getString(1)) }
            }
        }
        bestUri?.let { u -> try { startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { say("Could not open the contact") }; return }
        say("Contact not found: $name")
    }

    /** camera kholo, (selfie ho to front camera), shutter dabao */
    private fun shoot(selfie: Boolean, a: NotchA11y, done: (Boolean, Long) -> Unit) {
        try { startActivity(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { say("Could not open the camera"); done(false, 0L); return }
        val g = gen
        h.postDelayed({
            if (g == gen) {
                val snap = { a.tapText("shutter|capture|take photo|take picture") { ok -> done(ok, 1200L) } }
                if (selfie) a.tapText("switch|flip|selfie|front") { snap() } else snap()
            }
        }, 2500)
    }

    // ---------- bolkar jawab (time / battery / date) ----------
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false

    private fun initTts() {
        tts = android.speech.tts.TextToSpeech(this) { st ->
            h.post {
                if (st == android.speech.tts.TextToSpeech.SUCCESS) {
                    tts?.language = Locale("en", "IN")
                    tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { h.post { endSpeak() } }
                        @Suppress("OVERRIDE_DEPRECATION")
                        override fun onError(id: String?) { h.post { endSpeak() } }
                    })
                    ttsReady = true
                }
            }
        }
    }

    private fun speak(t: String) {
        say(t)
        val e = tts
        if (!ttsReady || e == null) return
        speaking = true; stopListen()
        e.speak(t, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "n1")
        h.postDelayed({ endSpeak() }, 7000)
    }

    private fun endSpeak() {
        if (!speaking) return
        speaking = false
        if (panel != null && !typing && sr == null) startListen()
    }

    // ---------- "check app" : poore app ki jaanch ----------
    private val chkKw = setOf("check", "chek", "chk", "test", "jaanch", "janch", "jach", "diagnose", "diagnostic", "selfcheck", "चेक", "टेस्ट", "जांच", "जाँच")
    private val allKw2 = setOf("app", "sab", "sabhi", "sara", "saara", "pura", "poora", "all", "everything", "system", "full", "एप", "ऐप", "सब", "सारा", "पूरा")

    private fun isSelfCheck(raw: String): Boolean {
        val t = wordRe.findAll(raw.lowercase(Locale.ROOT)).map { it.value }.toList()
        return t.size <= 5 && t.any { it in chkKw } && t.any { it in allKw2 }
    }

    private fun runSelfCheck() {
        val bad = ArrayList<String>()
        var total = 0
        fun chk(ok: Boolean, fix: String) { total++; if (!ok) bad.add(fix) }
        fun perm(p: String) = checkSelfPermission(p) == 0
        chk(android.provider.Settings.canDrawOverlays(this), "Overlay permission: turn on 'Display over other apps' in Settings")
        chk(perm(android.Manifest.permission.RECORD_AUDIO), "No mic permission: press button 2 in the app")
        chk(perm(android.Manifest.permission.READ_CONTACTS), "No contacts permission (call/contact will not work)")
        chk(perm(android.Manifest.permission.CALL_PHONE), "No call permission")
        chk(perm(android.Manifest.permission.ANSWER_PHONE_CALLS), "No permission to answer/end calls")
        if (Build.VERSION.SDK_INT >= 33) chk(perm(android.Manifest.permission.POST_NOTIFICATIONS), "No notification permission")
        chk(android.provider.Settings.System.canWrite(this), "Turn on 'Modify system settings' for brightness (2b)")
        chk(NotchA11y.inst != null, "Accessibility is off: turn on NotchCmd in Settings (try off, then on)")
        chk(Scheduler.canExact(this), "Schedule: turn on the 'Alarms & reminders' permission in Settings")
        chk(SpeechRecognizer.isRecognitionAvailable(this), "No speech recognizer on the phone (enable/update the Google app)")
        chk(ttsReady, "Text-to-speech is not ready")
        chk((getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName), "Battery optimization is on: the app may stop (set to Unrestricted)")
        val asst = try { android.provider.Settings.Secure.getString(contentResolver, "assistant") ?: "" } catch (_: Exception) { "" }
        chk(asst.contains(packageName), "Power button: NotchCmd is not the default digital assistant (button 3b)")
        chk(try { findApp("settings") != null } catch (_: Exception) { false }, "App list not available (needed for open-app commands)")
        // parser test
        val tests = listOf<Pair<String, (Step) -> Boolean>>(
            "youtube kholo" to { st -> st is Step.Open }, "ammi ko call karo" to { st -> st is Step.Call }, "back" to { st -> st is Step.Act },
            "volume badhao" to { _ -> true }, "torch on karo" to { _ -> true })
        fun passes(c: String, okFn: (Step) -> Boolean): Boolean = try { val r = parse(c); r.isNotEmpty() && okFn(r.first()) } catch (_: Exception) { false }
        val badCmd = tests.filter { !passes(it.first, it.second) }.map { it.first }
        chk(badCmd.isEmpty(), "Command parser failed: ${badCmd.joinToString()}")
        val msg = if (bad.isEmpty()) "✅ All good ($total/$total checks passed)"
        else "❌ ${bad.size} problem(s) (out of $total):\n" + bad.take(3).joinToString("\n") { "• $it" } + (if (bad.size > 3) "\n…and ${bad.size - 3} more" else "")
        js("setState('idle',${JSONObject.quote(msg)})")
        armIdle()
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }
    /** thoda galat suna gaya naam (jaise "whatsap") bhi app se mil jaye */
    private fun fuzzy(n: String, q: String): Boolean {
        val lim = (q.length + 1) / 4
        if (lim == 0) return false
        return lev(n, q) <= lim || n.split(" ").any { it.length >= 4 && lev(it, q) <= lim } ||
            lev(ph(n), ph(q)) <= lim || n.split(" ").any { it.length >= 4 && lev(ph(it), ph(q)) <= lim }
    }

    private fun findApp(q0: String): String? {
        val pm = packageManager
        val q = q0.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) return null
        val toks = q.split(" ")
        fun rank(n: String): Int = when {
            n == q -> 0
            n.contains(q) -> 1
            toks.all { n.contains(it) } -> 2
            n.length >= 4 && q.contains(n) -> 3
            n.length >= 4 && q.length >= 4 && fuzzy(n, q) -> 4
            else -> 9
        }
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Pair(it.loadLabel(pm).toString().lowercase(Locale.ROOT), it.activityInfo.packageName) }
            .map { Pair(it, rank(it.first)) }.filter { it.second < 9 }
            .minWithOrNull(compareBy({ it.second }, { it.first.first.length }))?.first?.second
    }

    private fun openApp(q0: String): Boolean {
        val pm = packageManager
        val q = q0.trim()
        if (q.contains(".") && !q.contains(" ")) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(if (q.startsWith("http")) q else "https://$q")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
        }
        val toks = q.split(" ")
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Triple(it.loadLabel(pm).toString().lowercase(Locale.ROOT), it.activityInfo.packageName, 0) }
        fun rank(n: String): Int = when {
            n == q -> 0
            n.contains(q) -> 1
            toks.all { n.contains(it) } -> 2
            n.length >= 4 && q.contains(n) -> 3
            n.length >= 4 && q.length >= 4 && fuzzy(n, q) -> 4
            else -> 9
        }
        val hit = apps.map { Pair(it, rank(it.first)) }.filter { it.second < 9 }
            .minWithOrNull(compareBy({ it.second }, { it.first.first.length }))?.first ?: return false
        val intent = pm.getLaunchIntentForPackage(hit.second)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return false
        lastPkg = hit.second
        startActivity(intent); return true
    }

    private fun homePkg(): String = packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName ?: ""

    private fun openUrl(u: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    /** Jo app abhi khuli hai usi ke andar search: WhatsApp / YouTube / koi bhi app. Koi app khuli na ho (ya browser) to Google. */
    private fun doSearch(q: String, cb: (Boolean) -> Unit) {
        val a = NotchA11y.inst
        val fg = if (a != null) a.fgPkg() else lastPkg
        val web = fg.isEmpty() || fg == packageName || fg == homePkg() || fg.startsWith("com.android.systemui") ||
            listOf("chrome", "browser", "firefox", "opera", "brave", "edge").any { fg.contains(it) }
        when {
            q.startsWith("youtube ") -> { openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q.removePrefix("youtube "))); cb(true) }
            fg.startsWith("org.telegram") -> if (a == null) { say("Turn on the Accessibility service"); cb(false) } else a.chatSearch(q, cb)
            fg.startsWith("com.whatsapp") -> if (a == null) { say("Turn on the Accessibility service"); cb(false) } else a.waSearch(q, cb)
            fg.contains("youtube") -> { openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q)); cb(true) }
            web -> { openUrl("https://www.google.com/search?q=" + Uri.encode(q)); cb(true) }
            a == null -> { say("Turn on the Accessibility service"); cb(false) }
            else -> a.appSearch(q, cb)
        }
    }

    private fun findNumber(name: String): String? {
        if (name.matches(Regex("[+0-9 ]{5,}"))) return name.replace(" ", "")
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != 0) return null
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        contentResolver.query(uri, arrayOf(numCol), "$nameCol LIKE ?", arrayOf("%$name%"), null)?.use { if (it.moveToFirst()) return it.getString(0) }
        // naam thoda galat bola/likha gaya ("harsi" -> "Haris"): sabse kareeb wala contact
        val q = name.lowercase(Locale.ROOT).trim(); val lim = maxOf(1, q.length / 4)
        var bestD = 99; var bestNum: String? = null
        contentResolver.query(uri, arrayOf(nameCol, numCol), null, null, null)?.use {
            while (it.moveToNext()) {
                val dn = (it.getString(0) ?: continue).lowercase(Locale.ROOT)
                val d = minOf(lev(dn, q), dn.split(" ").minOf { w -> lev(w, q) })
                if (d <= lim && d < bestD) { bestD = d; bestNum = it.getString(1) }
            }
        }
        return bestNum
    }

    private fun doCall(name: String): Boolean {
        val num = findNumber(name)
        if (num == null) { say("Contact not found: $name"); return false }
        val act = if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) == 0) Intent.ACTION_CALL else Intent.ACTION_DIAL
        startActivity(Intent(act, Uri.parse("tel:" + Uri.encode(num))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }
}
