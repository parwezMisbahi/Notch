package com.msam.notchcmd

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

class NotchA11y : AccessibilityService() {
    companion object { var inst: NotchA11y? = null }
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { stopAuto(); inst = null; return super.onUnbind(i) }
    // ---------- biometric prompt par "Use PIN" dabakar PIN daalna (opt-in) ----------
    private var bioBusy = false
    private var bioLast = 0L
    private var bioTries = 0
    private val credWords = listOf("use pin", "use password", "use screen lock", "use passcode", "use lock screen", "use device password", "use pattern", "पिन का उपयोग", "पासवर्ड का उपयोग")
    private fun credNode(): AccessibilityNodeInfo? = all().firstOrNull { n ->
        !n.isEditable && n.isVisibleToUser && listOfNotNull(n.text, n.contentDescription).any { t ->
            val x = t.toString().lowercase(); x.length < 40 && credWords.any { x.contains(it) } }
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || bioBusy) return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            !(e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && e.packageName?.toString() == "com.android.systemui")) return
        if (!Unlocker.bioOn(this)) return
        val now = android.os.SystemClock.uptimeMillis()
        if (now - bioLast > 120_000) bioTries = 0
        if (bioTries >= 2 && now - bioLast < 600_000) return      // galat PIN se phone lock na ho: 2 koshish ke baad 10 min ruko
        if (now - bioLast < 15_000) return
        val pin = Unlocker.getPin(this) ?: return
        val n = credNode() ?: return
        bioBusy = true; bioLast = now; bioTries++
        tap(n)
        h.postDelayed({
            retry(8, 500, { digitNode(pin[0]) != null }) { found ->
                if (!found) bioBusy = false
                else typePin(pin, 0, { digitNode(pin[0]) != null }) { _ -> bioBusy = false; bioLast = android.os.SystemClock.uptimeMillis() }
            }
        }, 900)
    }

    // Volume Up + Volume Down ek saath dabao -> panel khule (mic tabhi on hoga)
    private var upDown = false; private var downDown = false; private var comboFired = false
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val up = e.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        val down = e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (!up && !down) return false
        val pressed = e.action == KeyEvent.ACTION_DOWN
        if (up) upDown = pressed else downDown = pressed
        if (pressed && upDown && downDown && !comboFired) {
            comboFired = true
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) } catch (_: Exception) {}
            return true
        }
        if (!upDown && !downDown) { val was = comboFired; comboFired = false; return was }
        return comboFired   // combo ke dauran volume nahi badlega
    }
    override fun onInterrupt() {}

    fun fgPkg(): String = rootInActiveWindow?.packageName?.toString() ?: ""

    // ---------- "scroll karte raho": jab tak stop/ruko na bolo ----------
    var autoOn = false
    private var autoDown = true
    private val autoRun = object : Runnable {
        override fun run() { if (!autoOn) return; scroll(autoDown); h.postDelayed(this, 3000) }
    }
    fun startAuto(down: Boolean) { autoDown = down; autoOn = true; h.removeCallbacks(autoRun); h.postDelayed(autoRun, 400) }
    fun stopAuto(): Boolean { val was = autoOn; autoOn = false; h.removeCallbacks(autoRun); return was }

    private fun all(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        val r = rootInActiveWindow
        if (r != null) walk(r) else windows.forEach { w -> w.root?.let { walk(it) } }
        return out
    }
    private fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) { if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.parent }
        return false
    }
    private fun tapXY(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }
    /** pehle normal click, na ho to screen par us jagah gesture-tap */
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        if (click(n)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        tapXY(r.exactCenterX(), r.exactCenterY()); return true
    }
    private fun setText(n: AccessibilityNodeInfo, s: String) = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
        Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s) })
    private fun retry(t: Int, d: Long, f: () -> Boolean, done: (Boolean) -> Unit) {
        if (f()) done(true) else if (t <= 1) done(false) else h.postDelayed({ retry(t - 1, d, f, done) }, d)
    }
    private fun isSearch(n: AccessibilityNodeInfo): Boolean {
        if (n.isEditable) return false
        val s = (n.contentDescription ?: n.text)?.toString()?.lowercase() ?: return false
        return s.length < 40 && (s.contains("search") || s.contains("खोज") || s.contains("سرچ"))
    }

    // ---------- poori screen ka control ----------
    fun act(name: String) {
        when (name) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "shot" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            "scrolldown" -> scroll(true)
            "scrollup" -> scroll(false)
            "autodown" -> startAuto(true)
            "autoup" -> startAuto(false)
            "stopauto" -> stopAuto()
            "lock" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            "qs" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "swl" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.85f, m.heightPixels * 0.5f, m.widthPixels * 0.15f, m.heightPixels * 0.5f) }
            "swr" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.15f, m.heightPixels * 0.5f, m.widthPixels * 0.85f, m.heightPixels * 0.5f) }
            "swu" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.5f, m.heightPixels * 0.7f, m.widthPixels * 0.5f, m.heightPixels * 0.3f) }
            "swd" -> { val m = resources.displayMetrics; swipe(m.widthPixels * 0.5f, m.heightPixels * 0.3f, m.widthPixels * 0.5f, m.heightPixels * 0.7f) }
            "doubletap" -> { val m = resources.displayMetrics; val x = m.widthPixels / 2f; val y = m.heightPixels / 2f; tapXY(x, y); h.postDelayed({ tapXY(x, y) }, 130) }
        }
    }
    private fun scroll(down: Boolean) {
        val ok = all().firstOrNull { it.isScrollable }?.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false
        if (!ok) {
            val m = resources.displayMetrics; val x = m.widthPixels / 2f; val a = m.heightPixels * 0.7f; val b = m.heightPixels * 0.3f
            if (down) swipe(x, a, x, b) else swipe(x, b, x, a)
        }
    }

    // ---------- lock screen: swipe up + PIN ----------
    private fun digitNode(d: Char): AccessibilityNodeInfo? = all().firstOrNull { n ->
        !n.isEditable && n.isVisibleToUser && (
            Regex("^\\s*$d(\\s|$)").containsMatchIn(n.text?.toString() ?: "") ||
            n.contentDescription?.toString()?.trim() == d.toString() ||
            n.viewIdResourceName?.endsWith("key$d") == true)
    }
    private fun enterNode(): AccessibilityNodeInfo? = all().firstOrNull { n ->
        val cd = n.contentDescription?.toString()?.trim()?.lowercase() ?: ""
        val tx = n.text?.toString()?.trim()?.lowercase() ?: ""
        n.isVisibleToUser && (n.viewIdResourceName?.endsWith("key_enter") == true || n.viewIdResourceName?.endsWith("enter") == true ||
            cd in setOf("enter", "ok", "confirm", "done") || tx in setOf("ok", "enter", "done"))
    }
    private fun swipeUpUnlock() {
        val m = resources.displayMetrics
        swipe(m.widthPixels * 0.5f, m.heightPixels * 0.85f, m.widthPixels * 0.5f, m.heightPixels * 0.25f)
    }

    /** Lock ho to swipe-up karke PIN daalta hai. cb(true) = ab unlock hai */
    fun unlock(pin: String, stillLocked: () -> Boolean, cb: (Boolean) -> Unit) {
        if (!stillLocked()) { cb(true); return }
        swipeUpUnlock()
        h.postDelayed({
            if (!stillLocked()) { cb(true); return@postDelayed }
            var swipes = 1
            retry(8, 500, {
                if (digitNode(pin[0]) != null) true
                else { if (swipes < 3) { swipes++; swipeUpUnlock() }; false }
            }) { found ->
                if (!found) cb(!stillLocked()) else typePin(pin, 0, stillLocked, cb)
            }
        }, 1000)
    }
    private fun typePin(pin: String, i: Int, stillLocked: () -> Boolean, cb: (Boolean) -> Unit) {
        if (i >= pin.length) {
            h.postDelayed({
                if (stillLocked()) enterNode()?.let { tap(it) }
                h.postDelayed({ cb(!stillLocked()) }, 1500)
            }, 500)
            return
        }
        val n = digitNode(pin[i])
        if (n != null) tap(n)
        h.postDelayed({ typePin(pin, i + 1, stillLocked, cb) }, 280)
    }
    /** Diagnostic: abhi screen par accessibility ko kya dikh raha hai (text / description / id / clickable) */
    fun dump(): String {
        val sb = StringBuilder()
        val ws = windows
        sb.append("windows=").append(ws.size).append(" root=").append(rootInActiveWindow?.packageName).append("\n")
        val seen = HashSet<String>()
        for (n in all()) {
            if (!n.isVisibleToUser) continue
            val t = n.text?.toString()?.take(40) ?: ""
            val d = n.contentDescription?.toString()?.take(40) ?: ""
            val id = n.viewIdResourceName?.substringAfter(":id/") ?: ""
            if (t.isEmpty() && d.isEmpty() && id.isEmpty()) continue
            val line = "t=[$t] d=[$d] id=[$id]" + (if (n.isClickable) " CLICK" else "") + (if (n.isEditable) " EDIT" else "")
            if (seen.add(line)) sb.append(line).append("\n")
        }
        val ime = imeNodes().filter { it.isVisibleToUser }
        if (ime.isNotEmpty()) {
            sb.append("--- keyboard ---\n")
            for (n in ime) {
                val t = n.text?.toString()?.take(40) ?: ""
                val d = n.contentDescription?.toString()?.take(40) ?: ""
                val id = n.viewIdResourceName?.substringAfter(":id/") ?: ""
                if (t.isEmpty() && d.isEmpty() && id.isEmpty()) continue
                val line = "KB t=[$t] d=[$d] id=[$id]" + (if (n.isClickable) " CLICK" else "")
                if (seen.add(line)) sb.append(line).append("\n")
            }
        }
        return sb.toString()
    }


    /** keyboard (IME) window ke saare nodes: Gboard ka mic yahin milta hai */
    private fun imeNodes(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        try { windows.filter { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }.forEach { w -> walk(w.root) } } catch (_: Exception) {}
        return out
    }

    /** Gboard ka voice-typing mic khud dabao (keyboard khulne ke baad) */
    fun tapKeyboardMic(cb: (Boolean) -> Unit) {
        val alts = listOf("voice typing", "voice input", "microphone", "बोलकर", "आवाज़ से", "आवाज से", "वॉइस")
        retry(8, 400, {
            imeNodes().firstOrNull { nd ->
                nd.isVisibleToUser && (
                    alts.any { a -> nd.contentDescription?.toString()?.lowercase()?.contains(a) == true || nd.text?.toString()?.lowercase()?.contains(a) == true } ||
                    nd.viewIdResourceName?.lowercase()?.contains("voice") == true)
            }?.let { tap(it) } ?: false
        }, cb)
    }

    /** screen par jo text/description match kare use dabao */
    fun tapText(q: String, cb: (Boolean) -> Unit) {
        val alts = q.lowercase().split("|").filter { it.isNotBlank() }   // "a|b|c" = koi bhi ek
        retry(6, 500, {
            all().firstOrNull { nd -> !nd.isEditable && alts.any { a ->
                nd.text?.toString()?.lowercase()?.contains(a) == true || nd.contentDescription?.toString()?.lowercase()?.contains(a) == true } }?.let { tap(it) } ?: false
        }, cb)
    }

    // ---------- Quick Settings tiles (Wi-Fi, Bluetooth, Airplane, Data, Hotspot, DND, Rotate) ----------
    private fun tileState(n: AccessibilityNodeInfo): Boolean? {
        var c: AccessibilityNodeInfo? = n
        var i = 0
        while (c != null && i < 3) {
            if (c.isCheckable) return c.isChecked
            val sd = if (Build.VERSION.SDK_INT >= 30) c.stateDescription?.toString() ?: "" else ""
            val txt = (sd + " " + (c.contentDescription ?: "")).lowercase()
            if (Regex("\\boff\\b").containsMatchIn(txt)) return false
            if (Regex("\\bon\\b").containsMatchIn(txt)) return true
            c = c.parent; i++
        }
        return null
    }

    /** want: 1 = on, 0 = off, -1 = toggle */
    fun toggleTile(labels: String, want: Int, cb: (Boolean) -> Unit) {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        val alts = labels.lowercase().split("|").filter { it.isNotBlank() }
        h.postDelayed({
            retry(8, 500, {
                val nodes = all()
                var hit: AccessibilityNodeInfo? = null
                for (a in alts) {
                    hit = nodes.firstOrNull { nd -> !nd.isEditable && (nd.text?.toString()?.lowercase()?.contains(a) == true ||
                        nd.contentDescription?.toString()?.lowercase()?.contains(a) == true) }
                    if (hit != null) break
                }
                val nd = hit
                if (nd == null) false else {
                    val st = tileState(nd)
                    if (want >= 0 && st != null && st == (want == 1)) true else tap(nd)
                }
            }) { ok -> h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK); cb(ok) }, 500) }
        }, 900)
    }
    /** screen par n-wa item (upar se neeche, phir left se right). q="video" to jis node ke text/description mein "video" ho */
    fun tapNth(n: Int, q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        val dm = resources.displayMetrics
        retry(8, 600, {
            val found = mutableListOf<Pair<Rect, AccessibilityNodeInfo>>()
            for (nd in all()) {
                if (nd.isEditable) continue
                val r = Rect(); nd.getBoundsInScreen(r)
                if (r.isEmpty || r.bottom <= 0 || r.top >= dm.heightPixels || r.right <= 0 || r.left >= dm.widthPixels) continue
                if (r.height() < 120) continue
                val t = ((nd.text ?: "").toString() + " " + (nd.contentDescription ?: "")).lowercase()
                val ok = if (ql.isEmpty()) nd.isClickable else t.contains(ql)
                if (ok) found.add(Pair(r, nd))
            }
            val top = found.filter { a -> found.none { b -> b !== a && b.first != a.first && b.first.contains(a.first) } }
                .sortedWith(compareBy({ it.first.top }, { it.first.left }))
            top.getOrNull(n - 1)?.let { tap(it.second) } ?: false
        }, cb)
    }
    fun typeText(t: String, cb: (Boolean) -> Unit) {
        retry(6, 400, {
            val n = all()
            (n.firstOrNull { it.isFocused && it.isEditable } ?: n.firstOrNull { it.isEditable })?.let { setText(it, t) } ?: false
        }, cb)
    }

    // ---------- kisi bhi app ke andar search ----------
    private fun searchEditable(n: List<AccessibilityNodeInfo>) = n.firstOrNull { e ->
        e.isEditable && listOfNotNull(e.hintText, e.contentDescription, e.viewIdResourceName, e.text).any { it.toString().lowercase().contains("search") }
    }

    fun appSearch(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(6, 500, {
            val n = all()
            val ed = searchEditable(n)
            if (ed != null) { tap(ed); true } else n.firstOrNull { isSearch(it) }?.let { tap(it) } ?: false
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, {
                    val n = all()
                    (n.firstOrNull { it.isFocused && it.isEditable } ?: searchEditable(n) ?: n.firstOrNull { it.isEditable })?.let { setText(it, q) } ?: false
                }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({ submitSearch(ql, cb) }, 900)
                }
            }, 800)
        }
    }

    // ---------- Telegram / chat apps: search karke result (naam) par tap ----------
    fun chatSearch(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(6, 500, {
            val n = all()
            val ed = searchEditable(n)
            if (ed != null) { tap(ed); true } else n.firstOrNull { isSearch(it) }?.let { tap(it) } ?: false
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, {
                    val n = all()
                    (n.firstOrNull { it.isFocused && it.isEditable } ?: searchEditable(n) ?: n.firstOrNull { it.isEditable })?.let { setText(it, q) } ?: false
                }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({ tapChatResult(ql, cb) }, 1300)
                }
            }, 800)
        }
    }

    private fun levA(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) { var prev = dp[0]; dp[0] = i
            for (j in 1..b.length) { val t = dp[j]; dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1); prev = t } }
        return dp[b.length]
    }

    /** result list mein sabse upar wala jo naam se shuru ho (Haris), warna jisme naam aaye.
     *  Pehle us row ki jagah par gesture-tap (Telegram jaise custom rows par ACTION_CLICK akela bharosemand nahi). */
    private fun tapChatResult(ql: String, cb: (Boolean) -> Unit) {
        val word = Regex("^" + Regex.escape(ql) + "(?![\\p{L}\\p{N}])")
        var chosen: AccessibilityNodeInfo? = null
        retry(10, 500, {
            val c = mutableListOf<Triple<Int, String, AccessibilityNodeInfo>>()
            for (nd in all()) {
                if (nd.isEditable || !nd.isVisibleToUser) continue
                val t = listOfNotNull(nd.text, nd.contentDescription).joinToString(" ").lowercase()
                if (!t.contains(ql)) continue
                val r = Rect(); nd.getBoundsInScreen(r)
                if (r.top < 350 || r.isEmpty) continue   // upar ka search box / tabs chhodo
                c.add(Triple(r.top, t, nd))
            }
            val sorted = c.sortedBy { it.first }
            var pick = sorted.firstOrNull { word.containsMatchIn(it.second) } ?: sorted.firstOrNull()
            if (pick == null && ql.length >= 3) {   // naam thoda galat: sabse kareeb wala row
                val lim = maxOf(1, ql.length / 4)
                var bd = 99
                for (nd in all()) {
                    if (nd.isEditable || !nd.isVisibleToUser) continue
                    val t = listOfNotNull(nd.text, nd.contentDescription).joinToString(" ").lowercase()
                    val r = Rect(); nd.getBoundsInScreen(r); if (r.top < 350 || r.isEmpty) continue
                    val d = t.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotBlank() }.minOfOrNull { w -> levA(w, ql) } ?: 99
                    if (d <= lim && d < bd) { bd = d; pick = Triple(r.top, t, nd) }
                }
            }
            if (pick == null) false else {
                val r = Rect(); pick.third.getBoundsInScreen(r)
                chosen = pick.third
                tapXY(r.exactCenterX(), r.exactCenterY()); true
            }
        }) { ok ->
            if (!ok) cb(false) else h.postDelayed({
                // abhi bhi search list khuli hai (chat nahi khuli) to normal click bhi try karo
                val stillSearch = all().any { it.isEditable && (it.text?.toString()?.lowercase()?.contains(ql) == true) }
                if (stillSearch) chosen?.let { tap(it) }
                cb(true)
            }, 1500)
        }
    }

    private fun submitSearch(ql: String, cb: (Boolean) -> Unit) {
        val n = all()
        val ed = n.firstOrNull { it.isFocused && it.isEditable } ?: n.firstOrNull { it.isEditable }
        var ok = false
        if (Build.VERSION.SDK_INT >= 30 && ed != null) ok = ed.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        if (!ok) ok = n.firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { tap(it) } ?: false
        cb(ok)
    }

    // ---------- WhatsApp ----------
    private fun isEntry(n: AccessibilityNodeInfo) = n.isEditable && n.viewIdResourceName?.endsWith("entry") == true

    /** chat khuli ho to pehle back karke chats list par aao (warna compose box mein search type ho jata tha) */
    private fun leaveChat(tries: Int, done: () -> Unit) {
        if (tries > 0 && all().any { isEntry(it) }) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            h.postDelayed({ leaveChat(tries - 1, done) }, 700)
        } else done()
    }

    fun waSearch(q: String, cb: (Boolean) -> Unit) = leaveChat(3) { waSearch2(q, cb) }

    private fun waSearch2(q: String, cb: (Boolean) -> Unit) {
        val ql = q.lowercase()
        retry(8, 500, {
            val n = all(); val s = n.firstOrNull { isSearch(it) }
            if (s != null) { tap(s); true } else n.any { it.isEditable && !isEntry(it) }
        }) { ok1 ->
            if (!ok1) cb(false) else h.postDelayed({
                retry(8, 400, { all().firstOrNull { it.isEditable && !isEntry(it) }?.let { setText(it, q) } ?: false }) { ok2 ->
                    if (!ok2) cb(false) else h.postDelayed({
                        retry(10, 500, {
                            all().firstOrNull { !it.isEditable && it.text?.toString()?.lowercase()?.contains(ql) == true }?.let { tap(it) } ?: false
                        }, cb)
                    }, 1200)
                }
            }, 800)
        }
    }

    fun sendMsg(t: String, cb: (Boolean) -> Unit) {
        h.postDelayed({
            retry(10, 500, {
                val n = all()
                val e = n.firstOrNull { it.isEditable && it.viewIdResourceName?.endsWith("entry") == true } ?: n.lastOrNull { it.isEditable }
                e?.let { setText(it, t) } ?: false
            }) { ok ->
                if (!ok) cb(false) else h.postDelayed({
                    retry(8, 400, {
                        all().firstOrNull { val c = it.contentDescription?.toString()?.lowercase(); c == "send" || c == "भेजें" || c == "ارسال" }?.let { tap(it) } ?: false
                    }, cb)
                }, 600)
            }
        }, 800)
    }

    // ---------- AI app mein research: sawaal bhejna, jawab poora hone ka intezaar, "Copy" dabana ----------
    private fun label(n: AccessibilityNodeInfo): List<String> =
        listOfNotNull(n.contentDescription, n.text).map { it.toString().lowercase().trim() }

    /** AI app (ChatGPT/Claude/Gemini...) ke message box mein sawaal likh kar Send dabata hai */
    fun askAi(t: String, startDelay: Long = 1200L, cb: (Boolean) -> Unit) {
        val key = t.lowercase().take(25)
        h.postDelayed({
            retry(12, 500, {
                val n = all()
                val e = n.firstOrNull { it.isEditable && it.isFocused } ?: n.lastOrNull { it.isEditable }
                e?.let { setText(it, t) } ?: false
            }) { ok ->
                if (!ok) cb(false) else h.postDelayed({
                    retry(10, 500, {
                        val n = all()
                        // sawaal chala gaya ho (Stop button dikha ya message box khali ho gaya) to Send dobara na dabao
                        val busy = n.any { nd -> label(nd).any { s -> s == "stop" || s.startsWith("stop ") } }
                        val ed = n.firstOrNull { it.isEditable }
                        val cleared = ed != null && ed.text?.toString()?.lowercase()?.contains(key) != true
                        if (busy || cleared) true
                        else n.firstOrNull { nd -> !nd.isEditable && label(nd).any { s -> s == "send" || s.startsWith("send ") || s == "submit" || s == "\u092d\u0947\u091c\u0947\u0902" } }?.let { tap(it) } ?: false
                    }, cb)
                }, 700)
            }
        }, startDelay)
    }

    /**
     * Jawab poora hone tak ruko: screen ka text badalna band ho aur "Stop" button na dikhe (kuch der tak).
     * maxMs ke baad bhi cb(true) - tab bhi Copy try hoga.
     */
    fun waitReplyDone(maxMs: Long, cb: (Boolean) -> Unit) {
        val t0 = System.currentTimeMillis()
        fun sigNow(): Int = all().filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString("|").hashCode()
        val base = sigNow()          // sawaal bhejne ke turant baad ki screen
        var last = base; var same = 0; var changed = false
        val r = object : Runnable {
            override fun run() {
                val n = all()
                val busy = n.any { nd -> label(nd).any { s -> s == "stop" || s.startsWith("stop gen") || s.startsWith("stop stream") || s.startsWith("stop resp") || s == "\u0930\u094b\u0915\u0947\u0902" } }
                val sig = n.filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString("|").hashCode()
                val el = System.currentTimeMillis() - t0
                if (sig != base) changed = true          // naya jawab aana shuru hua
                if (!busy && sig == last && (changed || el > 30000)) same++ else same = 0
                last = sig
                when {
                    same >= 5 && el > 8000 -> cb(true)
                    el > maxMs -> cb(true)
                    else -> h.postDelayed(this, 1200)
                }
            }
        }
        h.postDelayed(r, 4000)
    }

    private fun bigSwipeDown() {
        val m = resources.displayMetrics; val x = m.widthPixels / 2f
        swipe(x, m.heightPixels * 0.80f, x, m.heightPixels * 0.22f)
    }

    /**
     * Jawab ka "Copy" button dabata hai. Lamba jawab ho to jab tak Copy na dikhe neeche scroll karta rehta hai
     * (max ~40 baar). "Copy code" jaise button sirf tab dabata hai jab neeche tak pahunch jaye aur seedha "Copy" na mile.
     */
    fun tapLastCopy(cb: (Boolean) -> Unit) {
        val exact = setOf("copy", "copy message", "copy response", "copy reply", "copy text", "copy answer", "\u0915\u0949\u092a\u0940")
        var tries = 0; var lastSig = 0; var still = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val n = all()
                val copies = n.filter { nd -> !nd.isEditable && label(nd).any { it.length < 24 && (it in exact || it.startsWith("copy") || it.startsWith("\u0915\u0949\u092a\u0940")) } }
                fun top(nd: AccessibilityNodeInfo): Int { val rc = Rect(); nd.getBoundsInScreen(rc); return rc.top }
                val exactHit = copies.filter { nd -> label(nd).any { it in exact } }.maxByOrNull { top(it) }
                val sig = n.filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString("|").hashCode()
                still = if (sig == lastSig) still + 1 else 0
                lastSig = sig
                val atEnd = still >= 2
                val hit = exactHit ?: if (atEnd) copies.maxByOrNull { top(it) } else null
                if (hit != null && tap(hit)) { cb(true); return }
                if (tries >= 40 || still >= 5) { cb(false); return }
                if (tries % 2 == 1) bigSwipeDown() else scroll(true)
                h.postDelayed(this, 900)
            }
        }
        r.run()
    }

    // ---------- WhatsApp Channel post: Updates tab -> channel -> paste -> send ----------
    /** what waOpenUpdates saw in the bottom bar on its last try (shown in the failure message) */
    var waDiag: String = ""

    /**
     * bottom tab "Updates" (older WhatsApp: "Status"; WhatsApp Business: Chats/Calls/Updates/Tools).
     * 1) bottom-bar node whose label is/starts with/contains updates|status (also with a badge, e.g. "Updates, 1 new")
     * 2) fallback: in the bottom bar (Chats + Calls visible) tap the one tab that is none of the known others
     * Backs out of a chat / channel page if the bottom bar is not visible.
     */
    fun waOpenUpdates(cb: (Boolean) -> Unit) {
        val alts = listOf("updates", "update", "status", "\u0905\u092a\u0921\u0947\u091f", "\u0938\u094d\u091f\u0947\u091f\u0938",
            "\u0627\u067e \u0688\u06cc\u0679\u0633", "\u0627\u067e\u0688\u06cc\u0679\u0633", "\u0627\u0633\u0679\u06cc\u0679\u0633", "\u0633\u0679\u06cc\u0679\u0633")
        val others = listOf("chats", "chat", "calls", "call", "communities", "community", "you", "tools", "settings", "camera")
        fun isOther(l: String) = others.any { l == it || l.startsWith("$it,") || l.startsWith("$it ") }
        fun isAlt(l: String) = l.length < 40 && alts.any { l == it || l.startsWith(it) || l.contains(it) }
        var tries = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = all()
                val hgt = resources.displayMetrics.heightPixels
                fun rect(nd: AccessibilityNodeInfo): Rect { val rc = Rect(); nd.getBoundsInScreen(rc); return rc }
                fun inBottom(nd: AccessibilityNodeInfo) = rect(nd).let { !it.isEmpty && it.top > hgt * 0.72 }
                val visible = nodes.filter { !it.isEditable && it.isVisibleToUser }
                val bottom = visible.filter { inBottom(it) }
                val byLabel = { list: List<AccessibilityNodeInfo> -> list.firstOrNull { nd -> label(nd).any { isAlt(it) } } }
                val byId = bottom.firstOrNull { nd -> nd.viewIdResourceName?.lowercase()?.let { it.contains("updates") || it.contains("status_tab") } == true }
                var hit = byLabel(bottom) ?: byId
                // fallback: nav bar recognised by Chats + Calls, tap the unknown tab
                val bl = bottom.flatMap { nd -> label(nd).filter { it.length in 2..24 && it.any { c -> c.isLetter() } }.map { nd to it } }
                waDiag = bl.map { it.second }.distinct().take(10).joinToString(", ").ifBlank { "no bottom bar visible" }
                if (hit == null) {
                    val known = bl.count { isOther(it.second) }
                    if (known >= 2) hit = bl.filter { !isOther(it.second) }.minByOrNull { rect(it.first).left }?.first
                }
                // last resort: any visible Updates/Status label (e.g. tab without bounds in the bottom area)
                if (hit == null && bottom.none { nd -> label(nd).any { isOther(it) } }) hit = byLabel(visible)
                if (hit != null && tap(hit)) { cb(true); return }
                if (tries >= 14) { cb(false); return }
                if (tries == 3 || tries == 6 || tries == 9 || tries == 12) performGlobalAction(GLOBAL_ACTION_BACK)
                h.postDelayed(this, 600)
            }
        }
        r.run()
    }

    // ---------- Facebook post: feed composer -> paste -> Post ----------
    /** what the Facebook helpers saw on screen on their last try (shown in failure messages) */
    var fbDiag: String = ""

    private val fbComposerL = listOf("what's on your mind", "whats on your mind", "on your mind", "write something", "create a post", "create post", "write a post",
        "\u092e\u0928 \u092e\u0947\u0902 \u0915\u094d\u092f\u093e", "\u0938\u094b\u091a \u0930\u0939\u0947", "\u0630\u06c1\u0646 \u0645\u06cc\u06ba")
    private val fbPostL = setOf("post", "\u092a\u094b\u0938\u094d\u091f", "\u067e\u0648\u0633\u0679")

    private fun composerOpen(nodes: List<AccessibilityNodeInfo>) = nodes.any { it.isEditable && it.isVisibleToUser }

    /**
     * Gets to the \"write a post\" screen: if it is already open -> true; else taps the \"What's on your mind?\" box on the
     * Home feed. If the feed is not showing: Home tab, scroll up, Back (never Back while the composer is open).
     */
    fun fbOpenComposer(cb: (Boolean) -> Unit) {
        var tries = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = all()
                if (composerOpen(nodes)) { cb(true); return }
                val vis = nodes.filter { !it.isEditable && it.isVisibleToUser }
                fbDiag = vis.flatMap { label(it) }.filter { it.length in 3..32 && it.any { c -> c.isLetter() } }.distinct().take(8).joinToString(", ").ifBlank { "nothing readable on screen" }
                val hit = vis.firstOrNull { nd -> label(nd).any { l -> l.length < 60 && fbComposerL.any { l.contains(it) } } }
                if (hit != null && tap(hit)) { cb(true); return }
                if (tries >= 18) { cb(false); return }
                when (tries) {
                    3, 8, 13 -> vis.firstOrNull { nd -> label(nd).any { it == "home" || it.startsWith("home,") || it.startsWith("home ") } }?.let { tap(it) }
                    5, 10, 15 -> scroll(false)
                    6, 11, 16 -> performGlobalAction(GLOBAL_ACTION_BACK)
                }
                h.postDelayed(this, 700)
            }
        }
        r.run()
    }

    /** the write-a-post screen is open when a visible message box is on screen */
    fun fbComposerReady(cb: (Boolean) -> Unit) = retry(12, 600, { composerOpen(all()) }, cb)

    /**
     * Presses Post (enabled only after the text is pasted). Some Facebook versions show Next -> Share first.
     * true only when the composer closed afterwards.
     */
    fun fbTapPost(cb: (Boolean) -> Unit) {
        var tries = 0; var nexted = false
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = all()
                val vis = nodes.filter { !it.isEditable && it.isVisibleToUser && it.isEnabled }
                val editing = composerOpen(nodes)
                val post = vis.firstOrNull { nd -> label(nd).any { it in fbPostL } && editing }
                    ?: if (nexted && !editing) vis.firstOrNull { nd -> label(nd).any { it == "share" || it == "share now" || it in fbPostL } } else null
                val next = if (post == null && editing) vis.firstOrNull { nd -> label(nd).any { it == "next" } } else null
                if (post != null && tap(post)) {
                    var chk = 0
                    val c = object : Runnable { override fun run() {
                        chk++
                        if (!composerOpen(all())) { cb(true); return }
                        if (chk >= 12) { cb(false); return }
                        h.postDelayed(this, 700)
                    } }
                    h.postDelayed(c, 1500); return
                }
                if (next != null && !nexted && tap(next)) nexted = true
                if (tries >= 16) { cb(false); return }
                h.postDelayed(this, 700)
            }
        }
        r.run()
    }

    /** channel row in the Updates tab: exact name first, then partial; scrolls the list while searching */
    fun waOpenChannel(name: String, cb: (Boolean) -> Unit) {
        val ql = name.lowercase().trim()
        var tries = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val nodes = all()
                val hit = nodes.firstOrNull { nd -> !nd.isEditable && label(nd).any { it == ql } }
                    ?: nodes.firstOrNull { nd -> !nd.isEditable && label(nd).any { it.contains(ql) } }
                if (hit != null && tap(hit)) { cb(true); return }
                if (tries >= 16) { cb(false); return }
                scroll(tries < 9)
                h.postDelayed(this, 900)
            }
        }
        h.postDelayed(r, 600)
    }

    /** channel page is open when a message box (editable) is on screen */
    fun waChannelReady(cb: (Boolean) -> Unit) = retry(10, 600, { all().any { it.isEditable } }, cb)

    private fun composer(): AccessibilityNodeInfo? {
        val n = all()
        return n.firstOrNull { isEntry(it) } ?: n.firstOrNull { it.isFocused && it.isEditable } ?: n.lastOrNull { it.isEditable }
    }

    private fun hasRealText(e: AccessibilityNodeInfo?): Boolean {
        if (e == null) return false
        e.refresh()
        if (Build.VERSION.SDK_INT >= 26 && e.isShowingHintText) return false
        return (e.text?.length ?: 0) > 0
    }

    /** pastes the clipboard (the copied AI answer) into the message box */
    fun pasteClip(cb: (Boolean) -> Unit) {
        h.postDelayed({
            retry(8, 500, {
                val e = composer()
                if (e == null) false else {
                    e.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    e.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    e.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                    true
                }
            }) { found ->
                if (!found) cb(false) else h.postDelayed({
                    val e = composer()
                    if (hasRealText(e)) cb(true) else {
                        val clip = try { (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() } catch (_: Exception) { null }
                        if (e != null && !clip.isNullOrBlank()) cb(setText(e, clip)) else cb(false)
                    }
                }, 800)
            }
        }, 800)
    }

    /** presses the Send button; true once the message box is empty again (or Send was pressed) */
    fun tapSend(cb: (Boolean) -> Unit) {
        val sendL = setOf("send", "\u092d\u0947\u091c\u0947\u0902", "\u0627\u0631\u0633\u0627\u0644")
        retry(10, 500, {
            all().firstOrNull { nd -> !nd.isEditable && label(nd).any { it in sendL || it.startsWith("send ") } }?.let { tap(it) } ?: false
        }) { ok -> if (!ok) cb(false) else h.postDelayed({ cb(true) }, 1500) }
    }
}
