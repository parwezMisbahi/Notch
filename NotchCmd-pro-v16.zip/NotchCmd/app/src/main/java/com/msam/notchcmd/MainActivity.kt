package com.msam.notchcmd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import android.text.InputType
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(TextView(this).apply { text = "NotchCmd\nDouble-tap the notch or say \"MJ\" → the mic turns on by itself; speak, or tap to type"; textSize = 18f; tag = "title" })
        root.addView(Button(this).apply {
            text = "Change style: " + (Style.labels[Style.cur(this@MainActivity)] ?: "Glass") + "  ▸"
            setOnClickListener { Style.next(this@MainActivity); Style.buzz(this@MainActivity, "heavy"); recreate() }
        })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Overlay permission") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Mic, contacts, call, notification permission") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2b. Brightness permission (Modify system settings)") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        btn("3. Turn on Accessibility (NotchCmd)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3b. Power button: Default digital assistant = NotchCmd") { try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        btn("4. Start (notch button on)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java)) }
        btn("MJ ON (listens while screen is on)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", true)) }
        btn("MJ OFF (mic off)") { startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", false)) }
        btn("Check: full app diagnostics") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("cmd", "check app")) }
        btn("Stop") { stopService(Intent(this, OverlayService::class.java)) }
        btn("Test: open the box now") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) }
        // ---------- Schedule: fix time par command ----------
        root.addView(TextView(this).apply { text = "\nSchedule (run a command at a fixed time, even when locked)"; textSize = 18f })
        btn("S1. Alarms & reminders permission (for exact timing)") { if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
        btn("S2. Battery: set to Unrestricted") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        // ---------- Lock screen: auto-unlock + data ----------
        val pinTv = TextView(this).apply { textSize = 14f }
        fun pinInfo() { val n = Unlocker.pinLen(this); pinTv.text = if (n == 0) "PIN not set" else "PIN set: $n digits" }
        root.addView(pinTv)
        btn("S3. Set phone unlock PIN") {
            val et = EditText(this).apply { hint = "Phone lock PIN (4-16 digits)"; setSingleLine(true)
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
            AlertDialog.Builder(this).setTitle("Unlock PIN").setMessage("The number of digits is detected automatically. The PIN is stored encrypted.").setView(et)
                .setPositiveButton("Save") { _, _ ->
                    val p = et.text.toString().trim()
                    if (p.length in 4..16 && p.all { it.isDigit() }) { Unlocker.setPin(this, p); Toast.makeText(this, "${p.length}-digit PIN saved", Toast.LENGTH_SHORT).show() }
                    else Toast.makeText(this, "PIN must be 4 to 16 digits", Toast.LENGTH_SHORT).show()
                    pinInfo()
                }.setNeutralButton("Remove PIN") { _, _ -> Unlocker.clearPin(this); pinInfo() }
                .setNegativeButton("Cancel", null).show()
        }
        val unlockBtn = Button(this)
        fun unlockLabel() { unlockBtn.text = "S4. Auto-unlock when locked: " + if (Unlocker.unlockOn(this)) "ON" else "OFF" }
        unlockBtn.setOnClickListener { Unlocker.setUnlockOn(this, !Unlocker.unlockOn(this)); unlockLabel() }
        root.addView(unlockBtn)
        val dataBtn = Button(this)
        fun dataLabel() { dataBtn.text = "S5. Turn data ON if it is off: " + if (Unlocker.dataOn(this)) "ON" else "OFF" }
        dataBtn.setOnClickListener { Unlocker.setDataOn(this, !Unlocker.dataOn(this)); dataLabel() }
        root.addView(dataBtn)
        val bioBtn = Button(this)
        fun bioLabel() { bioBtn.text = "S7. \"Use PIN\" + PIN on biometric prompt: " + if (Unlocker.bioOn(this)) "ON" else "OFF" }
        bioBtn.setOnClickListener { Unlocker.setBioOn(this, !Unlocker.bioOn(this)); bioLabel() }
        root.addView(bioBtn)
        val gBtn = Button(this)
        fun gLabel() { gBtn.text = "V3. After speaking with the Gboard mic, the command runs after " + (OfflineVoice.gboard(this) / 1000) + " sec of silence (tap = change). When typing, press ▶" }
        gBtn.setOnClickListener { OfflineVoice.nextGboard(this); gLabel() }
        root.addView(gBtn); gLabel()
        val mBtn = Button(this)
        fun mLabel() { mBtn.text = "V4. Auto-press the Gboard mic: " + if (OfflineVoice.gbMic(this)) "ON" else "OFF" }
        mBtn.setOnClickListener { OfflineVoice.toggleGbMic(this); mLabel() }
        root.addView(mBtn); mLabel()
        btn("D1. Screen dump after 8 sec (open the screen to inspect)") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Turn on Accessibility first", Toast.LENGTH_SHORT).show()
            else {
                Toast.makeText(this, "Open that screen within 8 sec", Toast.LENGTH_LONG).show()
                Handler(Looper.getMainLooper()).postDelayed({
                    val d = a.dump()
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("dump", d))
                    Toast.makeText(this, "Copied (${d.lines().size} lines). Paste it in the chat", Toast.LENGTH_LONG).show()
                }, 8000)
            }
        }
        btn("S6. Test: lock the phone, then try unlock after 6 sec") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Turn on Accessibility first", Toast.LENGTH_SHORT).show()
            else {
                a.act("lock")
                Handler(Looper.getMainLooper()).postDelayed({
                    try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("prep_only", true).putExtra("sched", true)) } catch (_: Exception) {}
                }, 6000)
            }
        }
        pinInfo(); unlockLabel(); dataLabel(); bioLabel()
        // ---------- Mobile limit + awaaz ke jawab ----------
        root.addView(TextView(this).apply { text = "Phone limit and voice"; textSize = 18f })
        fun numDialog(title: String, cur: Int, ok: (Int) -> Unit) {
            val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "minutes"; setSingleLine(true); if (cur > 0) setText(cur.toString()) }
            AlertDialog.Builder(this).setTitle(title).setView(et)
                .setPositiveButton("Save") { _, _ -> ok(et.text.toString().trim().toIntOrNull() ?: 0) }
                .setNegativeButton("Cancel", null).show()
        }
        fun appLabel(pkg: String): String = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        btn("U1. Usage access permission (required for limits)") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        val scrBtn = Button(this)
        fun scrLabel() { val m = UsageGuard.screenLimit(this); scrBtn.text = "U2. Daily screen limit: " + if (m <= 0) "OFF" else "$m minutes" }
        scrBtn.setOnClickListener { numDialog("Daily screen limit (minutes, 0 = OFF)", UsageGuard.screenLimit(this)) { UsageGuard.setScreenLimit(this, it); scrLabel() } }
        root.addView(scrBtn)
        btn("U3. Set an app limit") {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }.filter { it.first != packageName }.sortedBy { it.second.lowercase() }
            AlertDialog.Builder(this).setTitle("Which app?").setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                val (pkg, name) = apps[i]
                numDialog("$name: daily limit (minutes, 0 = remove)", UsageGuard.limits(this)[pkg] ?: 0) {
                    UsageGuard.setLimit(this, pkg, it)
                    Toast.makeText(this, if (it > 0) "$name: $it min/day" else "$name limit removed", Toast.LENGTH_SHORT).show()
                }
            }.show()
        }
        btn("U4. View / remove app limits") {
            val l = UsageGuard.limits(this).entries.sortedBy { appLabel(it.key).lowercase() }
            if (l.isEmpty()) Toast.makeText(this, "No app limits set", Toast.LENGTH_SHORT).show()
            else AlertDialog.Builder(this).setTitle("Tap to remove").setItems(l.map { appLabel(it.key) + "  -  " + it.value + " min/day" }.toTypedArray()) { _, i ->
                UsageGuard.setLimit(this, l[i].key, 0)
                Toast.makeText(this, appLabel(l[i].key) + " limit removed", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Close", null).show()
        }
        val talkBtn = Button(this)
        fun talkLabel() { talkBtn.text = "U5. Voice replies (I'm ready / Done): " + if (UsageGuard.voiceOn(this)) "ON" else "OFF" }
        talkBtn.setOnClickListener { UsageGuard.setVoiceOn(this, !UsageGuard.voiceOn(this)); talkLabel() }
        root.addView(talkBtn)
        val rsBtn = Button(this)
        fun rsLabel() { rsBtn.text = "R1. AI app for research: " + ResearchPrefs.selected(this).label + "  (tap = change)" }
        rsBtn.setOnClickListener {
            val all = ResearchPrefs.ALL
            val names = all.map { it.label + if (ResearchPrefs.installed(this, it)) "" else "  (not installed)" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Which AI app should \"research ...\" use?")
                .setSingleChoiceItems(names, all.indexOfFirst { it.key == ResearchPrefs.selected(this).key }) { d, i ->
                    ResearchPrefs.select(this, all[i].key); rsLabel(); d.dismiss()
                }.setNegativeButton("Close", null).show()
        }
        root.addView(rsBtn)
        // ---------- WhatsApp Channel post ----------
        root.addView(TextView(this).apply { text = "\nWhatsApp Channel post"; textSize = 18f })
        root.addView(TextView(this).apply { text = "Say or type: channel post <topic>  (e.g. channel post good morning quote), or just \"channel post\" if your prompt (C3) needs no topic. Today's date is added to the prompt every time. The AI app from R1 writes it, then it is pasted and sent to your channel. You can schedule the same command below."; textSize = 13f })
        val chNameBtn = Button(this)
        fun chNameLabel() { chNameBtn.text = "C1. Channel name: " + ChannelPrefs.name(this).ifBlank { "(not set)" } }
        chNameBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Channel name exactly as in WhatsApp"; setSingleLine(true); setText(ChannelPrefs.name(this@MainActivity)) }
            AlertDialog.Builder(this).setTitle("Channel name").setView(et)
                .setPositiveButton("Save") { _, _ -> ChannelPrefs.setName(this, et.text.toString()); chNameLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(chNameBtn)
        val chAppBtn = Button(this)
        fun chAppLabel() { chAppBtn.text = "C2. Post using: " + ChannelPrefs.label(this) + "  (tap = change)" }
        chAppBtn.setOnClickListener { ChannelPrefs.toggleBusiness(this); chAppLabel() }
        root.addView(chAppBtn)
        val chPromptBtn = Button(this)
        fun chPromptLabel() { chPromptBtn.text = "C3. Prompt for the AI: " + (if (ChannelPrefs.hasCustomPrompt(this)) "custom" else "default") + "  (tap = edit)" }
        chPromptBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Prompt. Use {topic} and {date} where they should go"; setText(ChannelPrefs.prompt(this@MainActivity)); minLines = 4; gravity = Gravity.TOP }
            AlertDialog.Builder(this).setTitle("Prompt for the AI").setMessage("{topic} is replaced by what you say after \"channel post\" (it can be empty). {date} is replaced by today's date; if you do not write {date}, \"Today's date: ...\" is added at the end automatically. Example for a multi-day plan: Continue our 100-day plan. Today is {date}. Work out which day it is and write only today's WhatsApp channel post. Output ONLY the post text.").setView(et)
                .setPositiveButton("Save") { _, _ -> ChannelPrefs.setPrompt(this, et.text.toString()); chPromptLabel() }
                .setNeutralButton("Reset") { _, _ -> ChannelPrefs.setPrompt(this, ""); chPromptLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(chPromptBtn)
        val chCleanBtn = Button(this)
        fun chCleanLabel() { chCleanBtn.text = "C4. After a scheduled post: data OFF + lock phone: " + if (ChannelPrefs.cleanup(this)) "ON" else "OFF" }
        chCleanBtn.setOnClickListener { ChannelPrefs.toggleCleanup(this); chCleanLabel() }
        root.addView(chCleanBtn)
        chNameLabel(); chAppLabel(); chPromptLabel(); chCleanLabel()
        // ---------- Facebook post ----------
        root.addView(TextView(this).apply { text = "\nFacebook post"; textSize = 18f })
        root.addView(TextView(this).apply { text = "Say or type: facebook post <topic>  (e.g. facebook post good morning quote). The AI app from R1 writes it, then it is pasted and posted from the Facebook home feed. It posts as the profile that is active in the Facebook app (to post to your Page, switch to the Page profile in Facebook first). You can schedule the same command below."; textSize = 13f })
        val fbAppBtn = Button(this)
        fun fbAppLabel() { fbAppBtn.text = "F1. Post using: " + FbPrefs.label(this) + "  (tap = change)" }
        fbAppBtn.setOnClickListener { FbPrefs.toggleLite(this); fbAppLabel() }
        root.addView(fbAppBtn)
        val fbPromptBtn = Button(this)
        fun fbPromptLabel() { fbPromptBtn.text = "F2. Prompt for the AI: " + (if (FbPrefs.hasCustomPrompt(this)) "custom" else "default") + "  (tap = edit)" }
        fbPromptBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Prompt. Use {topic} and {date} where they should go"; setText(FbPrefs.prompt(this@MainActivity)); minLines = 4; gravity = Gravity.TOP }
            AlertDialog.Builder(this).setTitle("Prompt for the AI").setMessage("{topic} is replaced by what you say after \"facebook post\" (it can be empty). {date} is replaced by today's date; if you do not write {date}, \"Today's date: ...\" is added at the end automatically.").setView(et)
                .setPositiveButton("Save") { _, _ -> FbPrefs.setPrompt(this, et.text.toString()); fbPromptLabel() }
                .setNeutralButton("Reset") { _, _ -> FbPrefs.setPrompt(this, ""); fbPromptLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(fbPromptBtn)
        val fbCleanBtn = Button(this)
        fun fbCleanLabel() { fbCleanBtn.text = "F3. After a scheduled post: data OFF + lock phone: " + if (FbPrefs.cleanup(this)) "ON" else "OFF" }
        fbCleanBtn.setOnClickListener { FbPrefs.toggleCleanup(this); fbCleanLabel() }
        root.addView(fbCleanBtn)
        fbAppLabel(); fbPromptLabel(); fbCleanLabel()
        val nameBtn = Button(this)
        fun nameLabel() { nameBtn.text = "U7. What the assistant calls you: " + if (UsageGuard.hasName(this)) UsageGuard.userName(this) else "muhtaram (set a name)" }
        nameBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Your name (empty = muhtaram)"; setSingleLine(true); if (UsageGuard.hasName(this@MainActivity)) setText(UsageGuard.userName(this@MainActivity)) }
            AlertDialog.Builder(this).setTitle("What should the assistant call you?").setMessage("This name is used in voice replies and reminders. Leave empty for \"muhtaram\".").setView(et)
                .setPositiveButton("Save") { _, _ -> UsageGuard.setUserName(this, et.text.toString()); nameLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        root.addView(nameBtn)
        btn("U6. Test: play the voice") {
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("say", "Yes " + UsageGuard.userName(this) + ", I'm ready")) } catch (_: Exception) {}
        }
        scrLabel(); talkLabel(); nameLabel(); rsLabel()
        // ---------- Offline AI model ----------
        root.addView(TextView(this).apply { text = "AI"; textSize = 18f })
        val aiTv = TextView(this).apply { textSize = 13f }
        fun aiInfo() { aiTv.text = "AI: " + LlmBrain.status(this) + "\n" + LlmBrain.onlineStatus(this) + (if (LlmBrain.memoryCount(this) > 0) "\nMemory: ${LlmBrain.memoryCount(this)} items" else "") }
        root.addView(aiTv)
        btn("A3. Clear AI memory") { LlmBrain.forget(this); aiInfo(); Toast.makeText(this, "Memory cleared", Toast.LENGTH_SHORT).show() }
        aiInfo()
        val schedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun dayName(mask: Int): String = if (mask == 0) "Once" else if (mask == 127) "Daily"
            else listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat").filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(",")
        fun refreshSched() {
            schedBox.removeAllViews()
            Scheduler.load(this).forEach { s ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 16) }
                row.addView(TextView(this).apply { text = "%02d:%02d • %s • %s%s".format(s.hh, s.mm, dayName(s.days), s.cmd, if (s.on) "" else "  (off)"); textSize = 15f })
                val br = LinearLayout(this)
                br.addView(Button(this).apply { text = if (s.on) "OFF" else "ON"; setOnClickListener { Scheduler.setOn(this@MainActivity, s.id, !s.on); refreshSched() } })
                br.addView(Button(this).apply { text = "Run now"; setOnClickListener { startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", s.cmd).putExtra("sched", true)) } })
                br.addView(Button(this).apply { text = "Remove"; setOnClickListener { Scheduler.remove(this@MainActivity, s.id); refreshSched() } })
                row.addView(br); schedBox.addView(row)
            }
            Style.skin(this, schedBox)
        }
        btn("+ New schedule") {
            val et = EditText(this).apply { hint = "Command, e.g.: open youtube"; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle("Which command should run?").setView(et)
                .setPositiveButton("Next") { _, _ ->
                    val cmd = et.text.toString().trim()
                    if (cmd.isNotEmpty()) TimePickerDialog(this, { _, hh, mm ->
                        val sel = BooleanArray(7)
                        AlertDialog.Builder(this).setTitle("Which days? (none selected = once only)")
                            .setMultiChoiceItems(arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"), sel) { _, i, c -> sel[i] = c }
                            .setPositiveButton("Save") { _, _ ->
                                var mask = 0
                                sel.forEachIndexed { i, b -> if (b) mask = mask or (1 shl i) }
                                Scheduler.add(this, hh, mm, cmd, mask); refreshSched()
                            }.setNegativeButton("Cancel", null).show()
                    }, 8, 0, false).show()
                }.setNegativeButton("Cancel", null).show()
        }
        root.addView(schedBox)
        Scheduler.armAll(this); refreshSched()
        Style.skin(this, root)
        (root.findViewWithTag<TextView>("title"))?.setTextColor(Style.theme(this).stroke)
        setContentView(ScrollView(this).apply { background = Style.background(this@MainActivity); addView(root) })
        Style.enter(root)
        if (b == null) Style.buzz(this, "launch")
    }

    // App kholte hi (ya permission dene ke baad) service khud chalu: mic sirf "MJ" ke liye sunta rehta hai
    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }
}
