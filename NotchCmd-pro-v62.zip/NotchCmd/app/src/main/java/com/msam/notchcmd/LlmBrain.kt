package com.msam.notchcmd

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * AI dimaag: khuli baat -> assistant ke apne commands.
 * 1) Pehle yaaddasht (cache), 2) online (Gemini/Groq, agar key + net ho), 3) offline model (Qwen/Gemma, MediaPipe).
 * AI sirf command ka text banata hai (JSON); asli kaam wahi purana parser karta hai (jo na samjhe wo chalta hi nahi).
 */
object LlmBrain {
    const val URL_0_5B = "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"
    const val URL_1_5B = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"
    const val URL_3B = "https://huggingface.co/litert-community/Qwen2.5-3B-Instruct/resolve/main/Qwen2.5-3B-Instruct_multi-prefill-seq_q8_ekv1280.task"
    const val URL_GEMMA = "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/gemma3-1b-it-int4.task"

    class Preset(val label: String, val url: String, val needsToken: Boolean)
    val presets = listOf(
        Preset("Qwen 0.5B - fastest, lightweight (~0.6 GB)", URL_0_5B, false),
        Preset("Qwen 1.5B - default, balanced (~1.6 GB)", URL_1_5B, false),
        Preset("Qwen 3B - smarter (~3.2 GB, 6 GB+ RAM)", URL_3B, false),
        Preset("Gemma 3 1B - needs a HuggingFace token (~0.6 GB)", URL_GEMMA, true)
    )

    private fun p(c: Context) = c.getSharedPreferences("llm", Context.MODE_PRIVATE)
    private fun dir(c: Context) = File(c.filesDir, "llm").apply { mkdirs() }
    fun modelFile(c: Context) = File(dir(c), "model.task")
    private fun partFile(c: Context) = File(dir(c), "model.part")

    fun enabled(c: Context) = p(c).getBoolean("on", false)
    fun setEnabled(c: Context, v: Boolean) { p(c).edit().putBoolean("on", v).apply() }
    fun url(c: Context): String = p(c).getString("url", URL_1_5B) ?: URL_1_5B
    fun setUrl(c: Context, u: String) { p(c).edit().putString("url", u.trim()).apply() }
    fun hfToken(c: Context): String = p(c).getString("hf", "") ?: ""
    fun setHfToken(c: Context, t: String) { p(c).edit().putString("hf", t.trim()).apply() }
    fun ready(c: Context) = modelFile(c).let { it.exists() && it.length() > 50_000_000L }
    fun usable(c: Context) = enabled(c) && (ready(c) || onlineReady(c))

    /** naya model chunna: purana model + adhura download hat jata hai, A1 se naya download hoga */
    fun selectPreset(c: Context, u: String) {
        unload()
        modelFile(c).delete(); partFile(c).delete()
        setUrl(c, u)
    }

    @Volatile var downloading = false
    @Volatile var progress = ""
    @Volatile var lastError = ""

    fun status(c: Context): String = when {
        downloading -> "downloading $progress"
        ready(c) -> "model ready (" + (modelFile(c).length() / 1_000_000L) + " MB)" + if (enabled(c)) ", ON" else ", OFF"
        partFile(c).exists() -> "incomplete download (" + (partFile(c).length() / 1_000_000L) + " MB), tap again"
        else -> "no model (download it)"
    }

    fun onlineStatus(c: Context): String =
        if (onlineReady(c)) "Online AI: " + provider(c) + " (" + onlineModel(c) + ")" + (if (lastError.isNotBlank()) "\nLast error: $lastError" else "")
        else "Online AI: off"

    /** Download (resume ke saath). Alag thread mein chalao. */
    fun download(c: Context, onProgress: (String) -> Unit, onDone: (Boolean, String) -> Unit) {
        if (downloading) { onDone(false, "A download is already running"); return }
        downloading = true
        Thread {
            var msg = ""
            var ok = false
            try {
                val part = partFile(c)
                var have = if (part.exists()) part.length() else 0L
                val conn = URL(url(c)).openConnection() as HttpURLConnection
                conn.instanceFollowRedirects = true
                conn.connectTimeout = 20_000; conn.readTimeout = 40_000
                val tok = hfToken(c)
                if (tok.isNotBlank() && url(c).contains("huggingface.co")) conn.setRequestProperty("Authorization", "Bearer $tok")
                if (have > 0) conn.setRequestProperty("Range", "bytes=$have-")
                val code = conn.responseCode
                if (code != 200 && code != 206) {
                    msg = if (code == 401 || code == 403) "Server refused (code $code). This model needs a HuggingFace token + accepted license (A4)"
                          else "Server refused (code $code). Check the link"
                } else {
                    if (code == 200 && have > 0) { part.delete(); have = 0L }   // server resume nahi karta: shuru se
                    val total = have + conn.contentLengthLong.coerceAtLeast(0L)
                    val out = FileOutputStream(part, have > 0)
                    val buf = ByteArray(256 * 1024)
                    var done = have
                    var lastTick = 0L
                    conn.inputStream.use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n); done += n
                            val now = System.currentTimeMillis()
                            if (now - lastTick > 700) {
                                lastTick = now
                                progress = if (total > 0) (done * 100 / total).toString() + "%" else (done / 1_000_000L).toString() + " MB"
                                onProgress(progress)
                            }
                        }
                    }
                    out.flush(); out.close()
                    if (total > 0 && done < total) msg = "Download incomplete, tap again"
                    else {
                        val dest = modelFile(c)
                        if (dest.exists()) dest.delete()
                        ok = part.renameTo(dest)
                        msg = if (ok) "Model downloaded" else "Could not save the model file"
                    }
                }
            } catch (e: Exception) {
                msg = "Download stopped: " + (e.message ?: "check your internet") + " (tap again, it will resume)"
            }
            downloading = false; progress = ""
            onDone(ok, msg)
        }.start()
    }

    fun deleteModel(c: Context) {
        unload()
        modelFile(c).delete(); partFile(c).delete()
        setEnabled(c, false)
    }

    // ---------- online AI (free key): Gemini / Groq ----------
    fun provider(c: Context): String = p(c).getString("prov", "off") ?: "off"
    fun apiKey(c: Context): String = p(c).getString("key", "") ?: ""
    fun defaultModel(prov: String): String = if (prov == "groq") "llama-3.3-70b-versatile" else "gemini-2.5-flash"
    fun onlineModel(c: Context): String = (p(c).getString("omodel", "") ?: "").ifBlank { defaultModel(provider(c)) }
    fun setOnline(c: Context, prov: String, key: String, model: String) {
        p(c).edit().putString("prov", prov).putString("key", key.trim()).putString("omodel", model.trim()).apply()
        lastError = ""
    }
    fun onlineReady(c: Context) = provider(c) != "off" && apiKey(c).isNotBlank()

    private fun netOk(c: Context): Boolean = try {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cap = cm.getNetworkCapabilities(cm.activeNetwork)
        cap != null && cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Exception) { false }

    private fun post(url: String, headers: Map<String, String>, body: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"; conn.connectTimeout = 5_000; conn.readTimeout = 15_000; conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) { lastError = "Online AI error code $code (check the key or model name)"; null }
            else conn.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            lastError = "Online AI unavailable: " + (e.message ?: "check your connection"); null
        } finally { try { conn?.disconnect() } catch (_: Exception) {} }
    }

    /** Plain-text online answer (used by AutoChat). Needs the free Groq/Gemini key. Returns null on any problem (see lastError). */
    fun chatText(c: Context, sys: String, msgs: List<Pair<String, String>>, maxTokens: Int): String? {
        if (!onlineReady(c)) { lastError = "No AI key saved"; return null }
        if (!netOk(c)) { lastError = "No internet connection"; return null }
        val key = apiKey(c); val model = onlineModel(c)
        val text: String? = try {
            if (provider(c) == "groq") {
                val arr = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
                for ((r, t) in msgs) arr.put(JSONObject().put("role", r).put("content", t))
                val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.7).put("max_tokens", maxTokens)
                val res = post("https://api.groq.com/openai/v1/chat/completions", mapOf("Authorization" to "Bearer $key"), body.toString())
                res?.let { JSONObject(it).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content") }
            } else {
                val contents = JSONArray()
                for ((r, t) in msgs) contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t))))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                    .put("contents", contents)
                    .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", maxOf(maxTokens, 1000)))
                val res = post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", mapOf("x-goog-api-key" to key), body.toString())
                res?.let { JSONObject(it).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text") }
            }
        } catch (e: Exception) { lastError = "Could not read the online reply"; null }
        if (text != null) lastError = ""
        return text?.trim()
    }

    private fun thinkOnline(c: Context, user: String): List<String> {
        val sys = system(UsageGuard.userName(c), true)
        val msgs = messages(c, user)
        val key = apiKey(c); val model = onlineModel(c)
        val text: String? = try {
            if (provider(c) == "groq") {
                val arr = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
                for ((r, t) in msgs) arr.put(JSONObject().put("role", r).put("content", t))
                val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.2).put("max_tokens", 400)
                    .put("response_format", JSONObject().put("type", "json_object"))
                val res = post("https://api.groq.com/openai/v1/chat/completions", mapOf("Authorization" to "Bearer $key"), body.toString())
                res?.let { JSONObject(it).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content") }
            } else {
                val contents = JSONArray()
                for ((r, t) in msgs) contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t))))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                    .put("contents", contents)
                    .put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", 1000).put("responseMimeType", "application/json"))
                val res = post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", mapOf("x-goog-api-key" to key), body.toString())
                res?.let { JSONObject(it).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text") }
            }
        } catch (e: Exception) { lastError = "Could not read the online reply"; null }
        if (text == null) return emptyList()
        lastError = ""
        return parseOut(text)
    }

    // ---------- offline model chalana ----------
    // MediaPipe library hata di gayi (APK ka size ~50 MB kam). Phone par model chalane wala engine ab nahi hai;
    // online AI (Groq/Gemini key) aur yaaddasht wese hi rehte hain.
    private val ui = Handler(Looper.getMainLooper())
    private val idleUnload = Runnable { }

    @Synchronized fun unload() { }

    // ---------- yaaddasht (phone mein hi, seekhne ke liye) ----------
    private fun key(t: String) = t.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun hist(c: Context): JSONArray = try { JSONArray(p(c).getString("hist", "[]")) } catch (_: Exception) { JSONArray() }

    fun cached(c: Context, user: String): String? {
        if (isFollowUp(user)) return null          // "aur badhao" jaisi baat pichli command par nirbhar hai
        val k = key(user); val h = hist(c)
        for (i in h.length() - 1 downTo 0) { val o = h.getJSONObject(i); if (o.optString("k") == k) return o.optString("out") }
        return null
    }

    /** Jo AI-command kaam kar gayi use yaad rakho (agli baar turant, bina AI ke) */
    fun remember(c: Context, user: String, out: String) {
        if (isFollowUp(user)) return
        val k = key(user); if (k.isBlank() || out.isBlank()) return
        val old = hist(c); val n = JSONArray()
        for (i in 0 until old.length()) { val o = old.getJSONObject(i); if (o.optString("k") != k) n.put(o) }
        n.put(JSONObject().put("k", k).put("u", user.trim()).put("out", out))
        val keep = JSONArray(); for (i in maxOf(0, n.length() - 40) until n.length()) keep.put(n.get(i))
        p(c).edit().putString("hist", keep.toString()).apply()
    }

    fun forget(c: Context) { p(c).edit().remove("hist").apply() }
    fun memoryCount(c: Context) = hist(c).length()

    private fun recent(c: Context, n: Int): List<Pair<String, String>> {
        val h = hist(c); val l = ArrayList<Pair<String, String>>()
        for (i in maxOf(0, h.length() - n) until h.length()) { val o = h.getJSONObject(i); l.add(o.optString("u") to o.optString("out")) }
        return l
    }

    // ---------- follow-up ("aur badhao", "usko bhi bhej do") ----------
    private val turns = ArrayDeque<String>()
    private var lastTurnAt = 0L
    private val fuWords = setOf("aur", "phir", "fir", "wapas", "usko", "isko", "unko", "again", "more", "thoda", "ulta", "undo", "wahi", "vahi", "repeat", "same")

    /** pichli command yaad rakho taaki agli chhoti baat ("aur badhao") samajh aaye */
    @Synchronized fun noteTurn(t: String) {
        val s = t.trim().take(100); if (s.isBlank()) return
        turns.addLast(s); while (turns.size > 3) turns.removeFirst()
        lastTurnAt = System.currentTimeMillis()
    }

    fun isFollowUp(t: String): Boolean {
        val w = key(t).split(" ").filter { it.isNotBlank() }
        return w.size in 1..5 && w.any { it in fuWords }
    }

    @Synchronized private fun withCtx(user: String): String {
        if (System.currentTimeMillis() - lastTurnAt > 600_000L) turns.clear()
        return if (turns.isNotEmpty() && isFollowUp(user)) "(pichli command: " + turns.takeLast(2).joinToString(" | ") + ") " + user else user
    }

    // ---------- prompt ----------
    private fun js(vararg s: String): String = JSONObject().put("cmds", JSONArray(s.toList())).toString()

    private fun system(name: String, online: Boolean): String =
        "You are the brain of a phone voice assistant (address the user as \"$name\"). Convert the user's request (Hindi/Hinglish/English, may have typos) into assistant commands. " +
        "Reply ONLY with JSON: {\"cmds\":[\"cmd1\",\"cmd2\"]} - max 6 commands in order, no explanations. Command forms: " +
        "<app> kholo | <contact> ko call karo | <contact> ko <message text> bhejo | search <query> karo | alarm 6:30 am | 5 minute ka timer | " +
        "wifi on karo | bluetooth off karo | torch on karo | volume badhao | volume kam karo | back | home | " +
        "docera mein <pdf name> pdf kholo | docera library kholo | docera note likho <text> | screenshot note mein daalo | bolo <text> | " +
        "translate <text> urdu mein karo | <text> ka summary karo | <text> samjhao | image banao <description> | research karo <topic>. " +
        "If the user only chats or asks a question, use ONE command: bolo <short English answer, max " + (if (online) "40" else "20") + " words>. " +
        "A request starting with (pichli command: ...) refers to that earlier command (e.g. \"aur badhao\" = do it again/more). " +
        "Never invent app or contact names; use words the user said."

    private fun shots(name: String): List<Pair<String, String>> = listOf(
        "whatsapp khol do yaar" to js("whatsapp kholo"),
        "subah saade chhe baje uthana hai" to js("alarm 6:30 am"),
        "haris ko bol do main late aaunga" to js("haris ko main late aaunga bhejo"),
        "tum kaun ho" to js("bolo I am your assistant, $name. Tell me what to do."),
        "youtube kholo aur lofi search karo" to js("youtube kholo", "search lofi karo"),
        "(pichli command: volume badhao) aur badhao" to js("volume badhao")
    )

    /** shots + yaaddasht + abhi ki baat, (role, text) jodiyon mein */
    private fun messages(c: Context, user: String): List<Pair<String, String>> {
        val l = ArrayList<Pair<String, String>>()
        val nm = UsageGuard.userName(c)
        for ((u, o) in shots(nm)) { l.add("user" to u); l.add("assistant" to o) }
        for ((u, o) in recent(c, 3)) {
            val cmds = o.split("\n").filter { it.isNotBlank() }.toTypedArray()
            if (cmds.isEmpty()) continue
            l.add("user" to u.take(120)); l.add("assistant" to js(*cmds).take(300))
        }
        l.add("user" to user.take(300))
        return l
    }

    private fun isGemma(c: Context) = url(c).lowercase().contains("gemma")

    /** Qwen = ChatML, Gemma = start_of_turn. Lambai chhoti rakhi hai taaki 1280 token ke andar rahe. */
    private fun render(c: Context, sys: String, msgs: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        if (isGemma(c)) {
            var first = true
            for ((r, t) in msgs) {
                if (r == "user") {
                    sb.append("<start_of_turn>user\n")
                    if (first) { sb.append(sys).append("\n\n"); first = false }
                    sb.append(t).append("<end_of_turn>\n")
                } else sb.append("<start_of_turn>model\n").append(t).append("<end_of_turn>\n")
            }
            sb.append("<start_of_turn>model\n")
        } else {
            sb.append("<|im_start|>system\n").append(sys).append("<|im_end|>\n")
            for ((r, t) in msgs) sb.append("<|im_start|>").append(r).append("\n").append(t).append("<|im_end|>\n")
            sb.append("<|im_start|>assistant\n")
        }
        return sb.toString()
    }

    /** JSON {"cmds":[...]} padho; na mile to purani tarah line-by-line */
    private fun parseOut(raw: String): List<String> {
        val t = raw.replace("<|im_end|>", "\n").replace("<|im_start|>", "\n").replace("<end_of_turn>", "\n").replace("<start_of_turn>", "\n")
        val a = t.indexOf('{'); val b = t.lastIndexOf('}')
        if (a >= 0 && b > a) {
            try {
                val arr = JSONObject(t.substring(a, b + 1)).optJSONArray("cmds")
                if (arr != null) {
                    val l = ArrayList<String>()
                    for (i in 0 until arr.length()) { val s = arr.optString(i).trim(); if (s.isNotBlank()) l.add(s) }
                    if (l.isNotEmpty()) return l.take(6)
                }
            } catch (_: Exception) {}
        }
        if (t.contains("\"cmds\"")) {   // adhura/toota JSON: quotes ke andar ki baatein nikalo
            val l = Regex("\"([^\"]+)\"").findAll(t.substringAfter("\"cmds\"")).map { it.groupValues[1].trim() }.filter { it.isNotBlank() }.toList()
            if (l.isNotEmpty()) return l.take(6)
        }
        return t.split("\n")
            .map { it.trim().trimStart('-', '*', '>', ' ').trim() }
            .filter { it.isNotBlank() && !it.startsWith("assistant", true) && !it.startsWith("user", true) && !it.startsWith("{") && !it.startsWith("}") && !it.startsWith("model", true) }
            .take(6)
    }

    /** Blocking (alag thread se bulao). Command lines ki list lautata hai, ya khali. */
    fun think(c: Context, user: String): List<String> {
        val u = withCtx(user)
        if (onlineReady(c) && netOk(c)) {
            val r = thinkOnline(c, u)
            if (r.isNotEmpty()) return r
        }
        return emptyList()
    }
}
