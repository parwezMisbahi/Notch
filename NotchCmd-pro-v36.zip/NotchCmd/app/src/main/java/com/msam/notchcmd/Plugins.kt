package com.msam.notchcmd

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Plugins = assistant ke AI kaam: translate, summarize, explain, ocr, image banana, research.
 * Panel mein plugin chip chuno ya seedha type/bolo ("translate karo ...", "image banao ...") - dono ka natija ek hi hai:
 * AI kaam karta hai aur jawab (aur photo) Docera mein naye note mein save ho jata hai.
 */
object Plugins {
    class P(val key: String, val label: String, val icon: String, val hint: String)

    val ALL = listOf(
        P("research", "Research", "🔎", "Type a topic; the AI researches it and creates a Docera note"),
        P("translate", "Translate", "🌐", "Type text or add a photo; you can also say a language, e.g. \"in Urdu\""),
        P("summarize", "Summary", "📝", "Summary of text or a photo"),
        P("explain", "Explain", "💡", "Explain a photo or a question"),
        P("ocr", "Extract text", "🔤", "Extract the text written in a photo"),
        P("image", "Create image", "🎨", "Describe the image you want"),
        P("channel", "Channel post", "📣", "Type a topic; the AI writes it and posts it to your WhatsApp channel"),
        P("facebook", "Facebook post", "\uD83D\uDCD8", "Type a topic; the AI writes it and posts it on Facebook"),
        P("everywhere", "Post everywhere", "\uD83D\uDCE3", "Type a topic; the AI writes it once and posts it to your channel and Facebook")
    )

    fun label(key: String): String = when (key) {
        "save" -> "Photo note"; "digest" -> "Notification digest"; "briefing" -> "Morning briefing"
        else -> ALL.firstOrNull { it.key == key }?.label ?: key
    }

    fun menuJson(): String {
        val a = JSONArray()
        for (p in ALL) a.put(JSONObject().put("key", p.key).put("label", p.label).put("icon", p.icon).put("hint", p.hint))
        return a.toString()
    }

    // ---------------------------------------------------------------- bol-chaal ke shabd (typed / voice)
    class Req(val key: String, val text: String, val lang: String?, val ai: String? = null)

    private val KW = mapOf(
        "translate" to setOf("translate", "translation", "translat", "transalte", "tranlate", "translet", "transulate", "tarjuma", "tarjumah", "tarjume", "tarjama", "anuvad", "अनुवाद", "ترجمہ", "ترجمه", "ट्रांसलेट"),
        "summarize" to setOf("summarize", "summarise", "summary", "summry", "sumrize", "khulasa", "khulasah", "khulasaa", "mukhtasar", "saransh", "सारांश", "خلاصہ", "समरी"),
        "explain" to setOf("explain", "explane", "describe", "samjhao", "samjhana", "samjhaiye", "samjha", "tashreeh", "tafseel", "समझाओ", "समझा", "سمجھاؤ"),
        "ocr" to setOf("ocr", "extract")
    )
    private val RS = setOf("research", "risarch", "risurch", "risearch", "resarch", "reserch", "risarcha", "reseach")
    private val OCR_HARD = setOf("ocr", "extract", "text", "nikalo", "nikal", "nikalna", "padho", "padh", "likha", "hua", "copy")
    private val GEN = setOf("banao", "bana", "banado", "banana", "generate", "create", "draw", "bnao", "बनाओ", "बना", "بناؤ")
    private val IMG = setOf("image", "images", "photo", "tasveer", "tasvir", "picture", "pic", "img", "logo", "wallpaper", "poster", "इमेज", "तस्वीर", "تصویر")
    private val SOFT = setOf("karo", "kar", "kardo", "karna", "karke", "krke", "karen", "kariye", "kijiye", "do", "dena", "de", "dedo", "dijiye", "ko", "ka", "ki", "ke", "liye", "ek", "is", "isko", "isse", "ise", "iska", "iske",
        "ye", "yeh", "this", "please", "plz", "wala", "wali", "mera", "meri", "mere", "my", "se", "text", "sentence", "line", "the", "a", "an", "of", "for", "docera", "note", "mein", "me", "men")
    private val CLAUSE = setOf("mein", "me", "men", "par", "pe", "ke", "ko", "ki", "note", "notes", "save", "rakho", "karo", "kar", "kardo", "do", "dena", "likho", "daalo", "dalo", "karna", "baad", "bhi", "please", "plz")
    private val COND = setOf("to", "into", "in", "main", "mein", "me", "men")
    val LANGS = mapOf(
        "urdu" to "Urdu", "urd" to "Urdu", "اردو" to "Urdu", "उर्दू" to "Urdu",
        "hindi" to "Hindi", "हिंदी" to "Hindi", "ہندی" to "Hindi",
        "english" to "English", "inglish" to "English", "angrezi" to "English", "eng" to "English", "अंग्रेजी" to "English", "انگریزی" to "English",
        "arabic" to "Arabic", "arbi" to "Arabic", "अरबी" to "Arabic", "عربی" to "Arabic",
        "farsi" to "Persian", "persian" to "Persian", "فارسی" to "Persian",
        "french" to "French", "spanish" to "Spanish", "german" to "German", "turkish" to "Turkish",
        "bengali" to "Bengali", "bangla" to "Bengali", "tamil" to "Tamil", "gujarati" to "Gujarati", "punjabi" to "Punjabi", "marathi" to "Marathi"
    )

    private fun clean(t: String) = t.lowercase().trim(',', '.', '!', '?', ':', ';', '"', '\'', '(', ')', '،', '؟')

    /** forced = panel mein chuna plugin (null = shabdon se pehchano). Na mile to null. */
    fun parse(raw: String, forced: String?, hasImage: Boolean): Req? {
        var orig = raw.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        var low = orig.map { clean(it) }
        // "docera note likho ... translate ..." jaisi note-likhne wali baat ko plugin na samjho
        if (forced == null && low.any { it.startsWith("docera") || it.startsWith("dosera") } && low.any { it == "likho" || it == "likh" || it == "write" }) return null
        var key = forced
        // "research karo ..." ka apna purana raasta hai (AI app); uske text mein summary/explain jaise shabd aayen to bhi plugin na banao
        if (forced == null && low.any { it in RS }) return null
        if (key == null) {
            key = when {
                low.any { it in KW["translate"]!! } -> "translate"
                low.any { it in KW["summarize"]!! } -> "summarize"
                low.any { it in KW["explain"]!! } -> "explain"
                low.any { it in KW["ocr"]!! } || (low.contains("text") && low.any { it in setOf("nikalo", "nikal", "nikalna", "padho", "padh") }) -> "ocr"
                low.any { it in GEN } && low.any { it in IMG } -> "image"
                else -> null
            }
        }
        if (key == null) return null
        // "... aur docera mein save karo" jaisi baat hukm hai, text nahi: sirf wahi tukda hatao (aage/peeche ka text rakho)
        val dIdx = low.indexOfFirst { it.startsWith("docera") || it.startsWith("dosera") }
        if (dIdx > 0) {
            var from = dIdx
            while (from > 0 && low[from - 1] in setOf("aur", "and", "phir", "fir", "then", "और", "फिर")) from--
            var to = dIdx + 1
            while (to < low.size && low[to] in CLAUSE) to++
            orig = orig.filterIndexed { i, _ -> i < from || i >= to }
            low = low.filterIndexed { i, _ -> i < from || i >= to }
        }
        val hard: Set<String> = when (key) {
            "ocr" -> OCR_HARD
            "image" -> GEN + IMG
            else -> KW[key] ?: emptySet()
        } + LANGS.keys + ResearchPrefs.ALL.flatMap { it.words }
        fun isLang(i: Int) = i in low.indices && (low[i] in LANGS || ResearchPrefs.byWord(low[i]) != null)
        fun soft(i: Int): Boolean {
            val t = low[i]
            if (t in COND) return isLang(i - 1) || isLang(i + 1)
            return t in SOFT
        }
        fun drop(i: Int) = low[i] in hard || soft(i)
        var s = 0; var e = orig.size
        // aage ki chain: shabdon ka wo hissa jo sirf hukm (kw/bhasha/fillers) ho aur kam se kam ek kw/bhasha ho
        var j = 0; var sawHard = false
        while (j < e && drop(j)) { if (low[j] in hard) sawHard = true; j++ }
        if (sawHard) s = j
        var k = e; sawHard = false
        while (k > s && drop(k - 1)) { if (low[k - 1] in hard) sawHard = true; k-- }
        if (sawHard) e = k
        // bhasha: hataye hue hisson mein jo bhi bhasha ka naam tha
        var lang: String? = null
        var aiKey: String? = null
        for (i in orig.indices) if (i < s || i >= e) {
            if (low[i] in LANGS) lang = LANGS[low[i]]
            ResearchPrefs.byWord(low[i])?.let { aiKey = it.key }
        }
        // shabdon se pehchana gaya ho aur kw text ke beech mein reh gaya ho ("... translate karo isko") to wo bhi hatao
        val keep = orig.indices.filter { it in s until e }.toMutableList()
        if (forced == null && key != "image") {
            val kwSet = if (key == "ocr") OCR_HARD else KW[key] ?: emptySet()
            val m = keep.firstOrNull { low[it] in kwSet }
            if (m != null) {
                val at = keep.indexOf(m)
                keep.removeAt(at)
                var nx = m + 1
                while (nx < e && keep.contains(nx) && drop(nx)) { keep.remove(nx); nx++ }
            }
        }
        val text = keep.joinToString(" ") { orig[it] }.trim()
        return Req(key, text, lang, aiKey)
    }

    // ---------------------------------------------------------------- AI app ke liye sawal
    /** AI app (ChatGPT/Claude/Gemini...) mein bhejne wala sawal. Photo ho to wo alag se share hoti hai. */
    fun buildPrompt(key: String, text: String, lang: String?, hasImg: Boolean): String {
        val t = text.trim()
        val note = if (t.isNotBlank()) "\nUser note: $t" else ""
        return when (key) {
            "translate" -> {
                val to = if (lang != null) "into $lang" else "into Urdu (if the text is already Urdu, translate it into English instead)"
                if (hasImg) "Read all the text visible in the attached image and translate it $to. Output ONLY the translation, no notes.$note"
                else "Translate the following text $to. Keep the meaning and tone. Output ONLY the translation, no notes.\n\n$t"
            }
            "summarize" ->
                if (hasImg) "Summarize the content of the attached image clearly in 5-8 short bullet points.$note"
                else "Summarize the following in 5-8 short bullet points, in the same language as the text.\n\n$t"
            "explain" ->
                if (hasImg) "Look at the attached image. Describe what it shows, read any text in it, and explain it simply in plain English.$note"
                else "Explain this clearly and simply in plain English, with a short example if useful:\n\n$t"
            "ocr" -> "Extract ALL text visible in the attached image exactly as written, keeping line breaks. Output ONLY the text.$note"
            "image" -> "Generate an image: $t"
            "digest" -> "Below are my phone notifications from the last day, grouped by app. Summarize them: first the important ones (messages from people, deadlines, payments, delivery or travel updates), then the rest in a few lines. Say who wrote what. Keep it short, in the same language as the notifications. Output ONLY the summary.\n\n$t"
            "briefing" -> "Give me a short morning briefing (at most 10 bullet points) about: $t. Use the latest information you can access and mention dates where it matters. Output ONLY the briefing."
            else /* research */ ->
                "Research this topic in detail and give a clear, well-organized answer with headings: $t" + (if (hasImg) "\n(The attached image is related context.)" else "")
        }
    }

    fun noteTitle(key: String, text: String, lang: String?): String {
        if (key == "digest" || key == "briefing") {
            val d = java.text.SimpleDateFormat("d MMM", java.util.Locale.ENGLISH).format(java.util.Date())
            return (if (key == "digest") "Notification digest " else "Morning briefing ") + d
        }
        val short = text.trim().replace('\n', ' ').take(40)
        val head = when (key) {
            "translate" -> "Translate" + (if (lang != null) " ($lang)" else "")
            "summarize" -> "Summary"; "explain" -> "Explain"; "ocr" -> "Text"; "image" -> "Image"; else -> "Research"
        }
        return head + ": " + (if (short.isNotBlank()) short else "photo")
    }

    // ---------------------------------------------------------------- photo madad
    private fun decode(path: String, maxSide: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            var ss = 1
            while (maxOf(o.outWidth, o.outHeight) / ss > maxSide * 2) ss *= 2
            val bm = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = ss }) ?: return null
            val sc = maxSide.toFloat() / maxOf(bm.width, bm.height)
            if (sc < 1f) Bitmap.createScaledBitmap(bm, (bm.width * sc).toInt().coerceAtLeast(1), (bm.height * sc).toInt().coerceAtLeast(1), true) else bm
        } catch (_: Throwable) { null }
    }

    /** JPEG bytes, lambai-chaudai maxSide tak, size maxBytes se chhota hone tak quality ghata kar */
    fun jpegBytes(path: String, maxSide: Int, maxBytes: Int): ByteArray? {
        var side = maxSide
        var bm = decode(path, side) ?: return null
        var q = 85
        while (true) {
            val bo = ByteArrayOutputStream()
            bm.compress(Bitmap.CompressFormat.JPEG, q, bo)
            if (bo.size() <= maxBytes || (q <= 40 && side <= 400)) return bo.toByteArray()
            if (q > 50) q -= 15 else { side = (side * 0.75).toInt(); bm = decode(path, side) ?: return bo.toByteArray() }
        }
    }

    fun thumbDataUrl(path: String): String {
        val b = jpegBytes(path, 140, 40_000) ?: return ""
        return "data:image/jpeg;base64," + Base64.encodeToString(b, Base64.NO_WRAP)
    }

    /** Docera ke command JSON mein photo jodo (Binder limit ke liye chhoti kar ke) */
    fun attachToDocera(j: JSONObject, path: String?) {
        if (path == null || !File(path).exists()) return
        val b = jpegBytes(path, 1280, 300_000) ?: return
        j.put("image_b64", Base64.encodeToString(b, Base64.NO_WRAP)).put("image_mime", "image/jpeg").put("image_name", File(path).nameWithoutExtension + ".jpg")
    }

    /** AI app ko photo "Share" se dene ke liye: cache mein copy + ShareProvider ka content URI */
    fun shareUri(c: Context, path: String): Uri? {
        return try {
            val d = File(c.cacheDir, "share").apply { mkdirs() }
            d.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3_600_000L) it.delete() }
            val b = jpegBytes(path, 1600, 1_500_000) ?: return null
            val f = File(d, "photo_" + System.currentTimeMillis() + ".jpg"); f.writeBytes(b)
            Uri.parse("content://com.msam.notchcmd.share/" + f.name)
        } catch (_: Throwable) { null }
    }

    fun saveToGallery(c: Context, bytes: ByteArray, mime: String, name: String) {
        if (Build.VERSION.SDK_INT < 29) return
        try {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name + if (mime.contains("png")) ".png" else ".jpg")
                put(MediaStore.Images.Media.MIME_TYPE, mime)
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NotchCmd")
            }
            val u = c.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
            c.contentResolver.openOutputStream(u)?.use { it.write(bytes) }
        } catch (_: Exception) {}
    }

    /** Gallery se chuni photo ko app ki cache mein seedhi karke (EXIF ghuma kar) chhoti copy banao */
    fun importPicked(c: Context, uri: Uri): String? {
        try {
            val tmp = File(c.cacheDir, "pick_raw")
            val ins = c.contentResolver.openInputStream(uri) ?: return null
            ins.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            var bm = decode(tmp.absolutePath, 1600) ?: return null
            val rot = try { when (ExifInterface(tmp.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f } } catch (_: Exception) { 0f }
            if (rot != 0f) bm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(rot) }, true)
            val out = File(c.cacheDir, "pick_" + System.currentTimeMillis() + ".jpg")
            out.outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            tmp.delete()
            return out.absolutePath
        } catch (_: Throwable) { return null }
    }
}

/** Panel se Activity tak ka chhota pul: photo chunne ke baad path wapas service ko */
object PluginBus {
    @Volatile var onImage: ((String?) -> Unit)? = null
}

/** Transparent Activity: system ka photo chooser kholta hai (overlay se seedha file picker nahi khul sakta) */
class PickActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (b != null) return
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "Choose photo"), 71)
        } catch (_: Exception) { deliver(null) }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = if (res == RESULT_OK) data?.data else null
        if (u == null) { deliver(null); return }
        Thread {
            val p = Plugins.importPicked(this, u)
            Handler(Looper.getMainLooper()).post { deliver(p) }
        }.start()
    }

    private fun deliver(path: String?) {
        PluginBus.onImage?.invoke(path)
        PluginBus.onImage = null
        finish()
    }
}

/** Chhoti read-only provider: AI app ko share ki hui photo yahin se padhta hai */
class ShareProvider : android.content.ContentProvider() {
    override fun onCreate() = true
    private fun file(u: Uri): File? {
        val n = u.lastPathSegment ?: return null
        val c = context ?: return null
        return File(File(c.cacheDir, "share"), n).takeIf { it.exists() }
    }
    override fun query(u: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): android.database.Cursor? {
        val f = file(u) ?: return null
        val cur = android.database.MatrixCursor(arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE))
        cur.addRow(arrayOf<Any>(f.name, f.length()))
        return cur
    }
    override fun getType(u: Uri): String = "image/jpeg"
    override fun openFile(u: Uri, mode: String): android.os.ParcelFileDescriptor =
        android.os.ParcelFileDescriptor.open(file(u) ?: throw java.io.FileNotFoundException(), android.os.ParcelFileDescriptor.MODE_READ_ONLY)
    override fun insert(u: Uri, v: ContentValues?): Uri? = null
    override fun delete(u: Uri, s: String?, a: Array<out String>?) = 0
    override fun update(u: Uri, v: ContentValues?, s: String?, a: Array<out String>?) = 0
}
