package com.msam.notchcmd

import android.content.Context
import android.content.Intent

/** WhatsApp Channel posting: settings (channel name, WhatsApp / Business, prompt) kept in SharedPreferences. */
object ChannelPrefs {
    const val WA = "com.whatsapp"
    const val WAB = "com.whatsapp.w4b"
    const val DEFAULT_PROMPT = "Write a ready-to-post WhatsApp channel update about: {topic}. Make it engaging and concise, use short paragraphs and a few fitting emojis. Output ONLY the post text, no intro, no notes."

    private fun p(c: Context) = c.getSharedPreferences("channel", Context.MODE_PRIVATE)

    fun name(c: Context): String = (p(c).getString("name", "") ?: "").trim()
    fun setName(c: Context, v: String) { p(c).edit().putString("name", v.trim()).apply() }

    fun prompt(c: Context): String = (p(c).getString("prompt", "") ?: "").ifBlank { DEFAULT_PROMPT }
    fun hasCustomPrompt(c: Context): Boolean = (p(c).getString("prompt", "") ?: "").isNotBlank()
    fun setPrompt(c: Context, v: String) { p(c).edit().putString("prompt", v.trim()).apply() }

    /** e.g. "Saturday, 3 October 2026" - read fresh every time, so a scheduled run always sends that day's date */
    fun today(): String = java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale.ENGLISH).format(java.util.Date())

    /**
     * {topic} is replaced by the topic (empty topic is fine when the prompt does not need one),
     * {date} by today's date. If the prompt has no {date}, "Today's date: ..." is added at the end,
     * so the AI (with its own memory of a multi-day plan) can tell which day it is.
     */
    fun buildPrompt(c: Context, topic: String): String {
        var t = prompt(c)
        t = if (t.contains("{topic}")) t.replace("{topic}", topic)
            else if (topic.isNotBlank()) t + "\n\nTopic: " + topic else t
        t = if (t.contains("{date}")) t.replace("{date}", today()) else t + "\n\nToday's date: " + today() + "."
        return t
    }

    fun business(c: Context): Boolean = p(c).getBoolean("biz", false)
    fun toggleBusiness(c: Context): Boolean { val n = !business(c); p(c).edit().putBoolean("biz", n).apply(); return n }

    private fun installed(c: Context, pkg: String) = try { c.packageManager.getLaunchIntentForPackage(pkg) != null } catch (_: Exception) { false }

    /** chosen app; if it is not installed, the other one is used */
    fun pkg(c: Context): String {
        val want = if (business(c)) WAB else WA
        val other = if (want == WA) WAB else WA
        return if (installed(c, want) || !installed(c, other)) want else other
    }

    fun label(c: Context): String = if (pkg(c) == WAB) "WhatsApp Business" else "WhatsApp"

    fun launchIntent(c: Context): Intent? = try {
        c.packageManager.getLaunchIntentForPackage(pkg(c))?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    } catch (_: Exception) { null }

    /** after the channel post: also forward the new post to My status */
    fun shareStatus(c: Context): Boolean = p(c).getBoolean("status", false)
    fun toggleShareStatus(c: Context): Boolean { val n = !shareStatus(c); p(c).edit().putBoolean("status", n).apply(); return n }

    /** after a scheduled post: turn mobile data off and lock the phone */
    fun cleanup(c: Context): Boolean = p(c).getBoolean("cleanup", true)
    fun toggleCleanup(c: Context): Boolean { val n = !cleanup(c); p(c).edit().putBoolean("cleanup", n).apply(); return n }
}
