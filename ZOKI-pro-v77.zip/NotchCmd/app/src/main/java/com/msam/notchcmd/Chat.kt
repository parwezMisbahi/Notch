package com.msam.notchcmd

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/** One chat message. role: "u" = you, "a" = assistant */
/** links = tappable settings results: "title<TAB>page<TAB>find<TAB>nth" */
class ChatMsg(val role: String, val text: String, val imgs: List<String>, val ok: Boolean, val ts: Long, val links: List<String> = emptyList())

/** Chat history kept on the phone (last 150 messages) */
object ChatStore {
    private const val MAX = 150
    private fun sp(c: Context) = c.getSharedPreferences("chat", Context.MODE_PRIVATE)
    private fun mode(c: Context) = sp(c).getString("mode", "zoki") ?: "zoki"
    /** the first conversation of each tab keeps the old storage keys, so old history is not lost */
    private fun keyOf(id: String) = when (id) { "zoki" -> "h"; "chat" -> "h_chat"; else -> "h_$id" }

    class Conv(val id: String, val title: String, val mode: String, val ts: Long)

    @Synchronized fun curId(c: Context): String {
        val k = "cur_" + mode(c)
        var id = sp(c).getString(k, null)
        if (id == null) { id = mode(c); sp(c).edit().putString(k, id).apply() }
        return id
    }
    private fun key(c: Context) = keyOf(curId(c))

    private fun convs(c: Context): MutableList<Conv> {
        val out = ArrayList<Conv>()
        try {
            val a = JSONArray(sp(c).getString("convs", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(Conv(o.getString("id"), o.optString("title"), o.optString("mode", "zoki"), o.optLong("ts"))) }
        } catch (_: Exception) {}
        return out
    }
    private fun saveConvs(c: Context, l: List<Conv>) {
        val a = JSONArray()
        for (x in l.sortedByDescending { it.ts }.take(100)) a.put(JSONObject().put("id", x.id).put("title", x.title).put("mode", x.mode).put("ts", x.ts))
        sp(c).edit().putString("convs", a.toString()).apply()
    }
    private fun loadKey(c: Context, k: String): MutableList<ChatMsg> {
        val out = ArrayList<ChatMsg>()
        try {
            val a = JSONArray(sp(c).getString(k, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val im = ArrayList<String>()
                o.optJSONArray("i")?.let { for (n in 0 until it.length()) im.add(it.getString(n)) }
                val lk = ArrayList<String>()
                o.optJSONArray("l")?.let { for (n in 0 until it.length()) lk.add(it.getString(n)) }
                out.add(ChatMsg(o.optString("r"), o.optString("t"), im, o.optBoolean("ok", true), o.optLong("ts"), lk))
            }
        } catch (_: Exception) {}
        return out
    }
    private fun titleOf(l: List<ChatMsg>): String = (l.firstOrNull { it.role == "u" }?.text ?: "New chat").replace("\n", " ").trim().take(40).ifBlank { "New chat" }

    @Synchronized fun load(c: Context): MutableList<ChatMsg> = loadKey(c, key(c))

    @Synchronized fun add(c: Context, m: ChatMsg) {
        val l = load(c); l.add(m)
        val keep = if (l.size > MAX) l.subList(l.size - MAX, l.size) else l
        val a = JSONArray()
        for (x in keep) {
            val im = JSONArray(); x.imgs.forEach { im.put(it) }
            val lk = JSONArray(); x.links.forEach { lk.put(it) }
            a.put(JSONObject().put("r", x.role).put("t", x.text).put("i", im).put("l", lk).put("ok", x.ok).put("ts", x.ts))
        }
        sp(c).edit().putString(key(c), a.toString()).apply()
        // keep the conversation list up to date (title = first message you sent)
        val id = curId(c); val md = mode(c)
        val all = convs(c)
        val old = all.firstOrNull { it.id == id }
        all.removeAll { it.id == id }
        all.add(Conv(id, old?.title?.takeIf { it.isNotBlank() && it != "New chat" } ?: titleOf(keep), md, System.currentTimeMillis()))
        saveConvs(c, all)
    }

    /** conversations of the current tab, newest first (the old pre-history chat is included) */
    @Synchronized fun list(c: Context): List<Conv> {
        val md = mode(c)
        val all = convs(c)
        val legacy = md
        if (all.none { it.id == legacy } && loadKey(c, keyOf(legacy)).isNotEmpty()) {
            val l = loadKey(c, keyOf(legacy))
            all.add(Conv(legacy, titleOf(l), md, l.lastOrNull()?.ts ?: 0L))
        }
        return all.filter { it.mode == md && loadKey(c, keyOf(it.id)).isNotEmpty() }.sortedByDescending { it.ts }
    }

    @Synchronized fun newConv(c: Context): String {
        val id = "c" + System.currentTimeMillis()
        sp(c).edit().putString("cur_" + mode(c), id).apply()
        return id
    }
    @Synchronized fun open(c: Context, id: String) { sp(c).edit().putString("cur_" + mode(c), id).apply() }
    @Synchronized fun rename(c: Context, id: String, t: String) {
        val all = convs(c); val old = all.firstOrNull { it.id == id } ?: Conv(id, "", mode(c), System.currentTimeMillis())
        all.removeAll { it.id == id }; all.add(Conv(id, t.trim().take(60).ifBlank { old.title }, old.mode, old.ts)); saveConvs(c, all)
    }
    @Synchronized fun delete(c: Context, id: String) {
        sp(c).edit().remove(keyOf(id)).apply()
        saveConvs(c, convs(c).filter { it.id != id })
        if (curId(c) == id) newConv(c)
    }
    @Synchronized fun clear(c: Context) { delete(c, curId(c)) }
}

/**
 * Bridge between the chat screen and OverlayService (which actually runs the commands).
 * The service reports every progress line (status) and the end of a run (finish / answer); the chat shows them as replies.
 */
object ChatBus {
    @Volatile var busy = false
    @Volatile var live = ""
    @Volatile var ui: ChatActivity? = null
    @Volatile private var curCmd = ""
    @Volatile private var curPlug = ""
    private val trail = CopyOnWriteArrayList<String>()
    private val main = Handler(Looper.getMainLooper())

    fun begin(cmd: String = "", plug: String = "") { trail.clear(); live = "Starting…"; busy = true; curCmd = cmd; curPlug = plug; if (!isOpenCmd(cmd)) WorkView.start(cmd) }

    fun status(m: String) {
        if (!busy || m.isBlank()) return
        live = m
        if (!m.endsWith("...") && !m.endsWith("…") && trail.lastOrNull() != m) trail.add(m)
        WorkView.step(m)
        main.post { ui?.onStatus(m) }
    }


    // ---- approval before a post, checkpoint for "retry from here", message drafts
    @Volatile var gate: ((Boolean) -> Unit)? = null
    @Volatile var draftTo: String? = null
    @Volatile var resume = false
    fun cmdNow() = curCmd
    fun plugNow() = curPlug
    fun approveOn(c: Context) = c.getSharedPreferences("n", Context.MODE_PRIVATE).getBoolean("chat_approve", true)
    private fun ckp(c: Context) = c.getSharedPreferences("ck", Context.MODE_PRIVATE)

    /** the finished photo + text of a post is saved, so a failed posting step can be retried without making them again */
    fun saveCheckpoint(c: Context, u: android.net.Uri?, caption: String) {
        Thread {
            try {
                var has = false
                if (u != null) {
                    val dir = java.io.File(c.cacheDir, "share").apply { mkdirs() }
                    val f = java.io.File(dir, "ck_last.jpg")
                    c.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    has = f.exists() && f.length() > 0
                }
                ckp(c).edit().putBoolean("img", has).putString("cap", caption).putString("cmd", curCmd).putLong("ts", System.currentTimeMillis()).apply()
            } catch (_: Exception) {}
        }.start()
    }
    /** (picture or null, caption) of the last finished post, only when it belongs to the command now running / retried */
    fun checkpoint(c: Context): Pair<android.net.Uri?, String>? {
        val p = ckp(c)
        if (System.currentTimeMillis() - p.getLong("ts", 0L) > 2 * 3600_000L) return null
        if (p.getString("cmd", "") != curCmd) return null
        val img = if (p.getBoolean("img", false) && java.io.File(c.cacheDir, "share/ck_last.jpg").exists()) android.net.Uri.parse("content://com.msam.notchcmd.share/ck_last.jpg") else null
        return Pair(img, p.getString("cap", "") ?: "")
    }
    fun hasCheckpoint(c: Context): Boolean {
        val p = ckp(c)
        return System.currentTimeMillis() - p.getLong("ts", 0L) <= 2 * 3600_000L && p.getString("cmd", "") == curCmd
    }

    /** pause before posting: the cover goes away, the chat comes to the front with the photo and text and Post / Edit / Cancel */
    fun askApproval(c: Context, caption: String, u: android.net.Uri?, cb: (Boolean) -> Unit) {
        if (!busy) { cb(true); return }
        gate = cb
        main.post { WorkView.remove() }
        Thread {
            var path: String? = null
            try {
                if (u != null) {
                    val dir = java.io.File(c.filesDir, "chat_media").apply { mkdirs() }
                    val dest = java.io.File(dir, "a_" + System.currentTimeMillis() + ".jpg")
                    c.contentResolver.openInputStream(u)?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                    if (dest.exists() && dest.length() > 0) path = dest.path
                }
            } catch (_: Exception) {}
            val txt = "📝 Ready to post:" + (if (caption.isNotBlank()) "\n\n$caption" else "\n\n(the copied text)")
            val msg = ChatMsg("a", txt, listOfNotNull(path), true, System.currentTimeMillis(),
                listOf("✅ Post now\t-110\t\t0", "✏ Edit text\t-112\t\t0", "✖ Cancel\t-111\t\t0"))
            ChatStore.add(c, msg)
            main.post {
                ui?.onExtra(msg)
                try { c.startActivity(Intent(c, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Exception) {}
            }
            main.postDelayed({ val g = gate; if (g != null) { gate = null; g(false) } }, 10 * 60_000L)
        }.start()
    }

    /** the user chose in the chat: go on (true) or stop (false) */
    fun decide(ok: Boolean) {
        val g = gate ?: return
        gate = null
        if (ok) WorkView.start(curCmd)
        g(ok)
    }

    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    /** "open whatsapp" / "youtube kholo": the user wants to stay in that app, so no cover and no jump back to the chat */
    fun isOpenCmd(cmd: String): Boolean {
        val w = cmd.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (w.isEmpty() || w.size > 4) return false
        val openW = setOf("open", "kholo", "khol", "kholna", "launch", "chalu")
        val other = setOf("send", "bhejo", "bhej", "message", "msg", "search", "post", "call", "play", "research", "translate", "type", "tap", "scroll", "photo", "image", "poster", "check", "set", "turn")
        return w.any { it in openW } && w.none { it in other }
    }

    /** a picture made during the run (ChatGPT image / poster): kept in the chat as a normal message, and shown in the cover */
    fun media(c: Context, u: android.net.Uri?) {
        if (!busy || u == null) return
        Thread {
            try {
                val dir = java.io.File(c.filesDir, "chat_media").apply { mkdirs() }
                val dest = java.io.File(dir, "m_" + System.currentTimeMillis() + ".jpg")
                c.contentResolver.openInputStream(u)?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } } ?: return@Thread
                val msg = ChatMsg("a", "", listOf(dest.path), true, System.currentTimeMillis(), listOf("💾 Download\t-116\t${dest.path}\t0"))
                ChatStore.add(c, msg)
                main.post { ui?.onExtra(msg) }
                WorkView.image(android.net.Uri.fromFile(dest))
            } catch (_: Exception) {}
        }.start()
    }

    private fun bringFront(c: Context) {
        if (c.getSharedPreferences("n", Context.MODE_PRIVATE).getBoolean("chat_back", true) && !ChatActivity.visible) {
            main.postDelayed({
                try { c.startActivity(Intent(c, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Exception) {}
            }, 700)
        }
    }

    private fun end(c: Context, msg: ChatMsg, bring: Boolean = true) {
        ChatStore.add(c, msg)
        main.post { ui?.onFinish(msg) }
        if (bring) bringFront(c)
    }

    /** end of a run: ok = everything finished, headline = optional fixed reply text. A failed run gets a Retry button. */
    fun finish(c: Context, ok: Boolean, headline: String? = null) {
        if (!busy) return
        busy = false; live = ""; gate = null; resume = false
        val t = trail.takeLast(8).map { cap(it) }.filter { !it.equals("done", true) }
        trail.clear()
        val text = when {
            headline != null -> headline
            ok && t.size <= 1 -> "✅ " + (t.firstOrNull() ?: "Done")
            // finished: say what the task was and the result, not every step
            ok -> "✅ " + t.last() + (if (curCmd.isNotBlank() && curCmd.length <= 90) ": " + curCmd.trim() else "")
            t.size <= 1 -> "❌ " + (t.firstOrNull() ?: "The task could not be finished")
            else -> "❌ " + t.last() + "\n\nSteps so far:\n" + t.dropLast(1).joinToString("\n") { "• $it" }
        }
        WorkView.done(ok, text)
        val links = if (!ok && curCmd.isNotBlank()) {
            val l = ArrayList<String>()
            if (hasCheckpoint(c)) l.add("↻ Retry from here (photo and text are kept)\t-113\t$curPlug|$curCmd\t0")
            l.add("🔁 Retry\t-100\t$curPlug|$curCmd\t0")
            l
        } else emptyList()
        end(c, ChatMsg("a", text, emptyList(), ok, System.currentTimeMillis(), links), bring = !(ok && isOpenCmd(curCmd)))
    }

    /** an AI answer is the end of the run: show it with Copy / Save buttons */
    fun answer(c: Context, text: String) {
        if (!busy) return
        busy = false; live = ""; trail.clear()
        WorkView.done(true, text)
        val d = draftTo; draftTo = null
        val links = if (d != null) listOf("📤 Send to $d\t-114\t$d|${text.replace("\t", " ")}\t0", "✏ Edit\t-115\t$d|${text.replace("\t", " ")}\t0", "📋 Copy\t-103\t\t0")
            else listOf("📋 Copy\t-103\t\t0", "📝 Save to Docera\t-104\t\t0")
        end(c, ChatMsg("a", text, emptyList(), true, System.currentTimeMillis(), links))
    }

    /** a result that arrives while the run goes on (research / translate text): shown now, the run continues */
    fun preview(c: Context, text: String) {
        if (!busy) return
        WorkView.text(text)
        val msg = ChatMsg("a", text, emptyList(), true, System.currentTimeMillis(), listOf("📋 Copy\t-103\t\t0"))
        ChatStore.add(c, msg)
        main.post { ui?.onExtra(msg) }
    }

    /** question for the AI app, with the last few chat turns so follow-ups make sense */
    fun prompt(c: Context, q: String): String {
        return q.replace("\n", " ").trim()   // exactly what you typed, nothing added
    }
}

/** Main screen: chat with the assistant. Type a command, the assistant runs it and answers here. */
class ChatActivity : Activity() {
    companion object { @Volatile var visible = false; @Volatile var lastFlash = 0L }

    private lateinit var t: Style.T
    private lateinit var msgBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: ImageButton
    private lateinit var attachBar: LinearLayout
    private lateinit var tray: HorizontalScrollView
    private lateinit var trayRow: LinearLayout
    private lateinit var emptyV: View
    private lateinit var banner: TextView
    private lateinit var subT: TextView
    private lateinit var drawer: LinearLayout
    private lateinit var scrim: View
    private var drawerOpen = false
    private var liveRow: View? = null
    private var liveText: TextView? = null
    private var livePulse: android.animation.Animator? = null
    private var selPlugin: String? = null
    private val imgs = ArrayList<String>()
    private var msgCount = 0
    private lateinit var statusCard: TextView
    private lateinit var quickRow: LinearLayout
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeak: String? = null
    private var handsOff = false      // user cancelled the mic: no auto-listening until the mic button is pressed again

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ small view helpers
    private fun round(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(color); if (stroke != 0) setStroke(dp(1), stroke)
    }

    /** every button squeezes a little when touched and springs back */
    private fun press(v: View) {
        v.setOnTouchListener { x, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> x.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(android.view.animation.OvershootInterpolator(3f)).start()
            }
            false
        }
    }

    private fun icon(res: Int, desc: String, size: Int = 44, tint: Int = t.text, onClick: () -> Unit): ImageButton = ImageButton(this).apply {
        setImageResource(res); scaleType = ImageView.ScaleType.CENTER_INSIDE
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, mask)
        setPadding(dp(10), dp(10), dp(10), dp(10)); setColorFilter(tint); contentDescription = desc
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        setOnClickListener { Style.buzz(this@ChatActivity, "tick"); onClick() }
        press(this)
    }

    private fun thumb(path: String, px: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / s > px * 2 && o.outHeight / s > px * 2) s *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (_: Throwable) { null }

    private fun picView(path: String, size: Int, r: Int): ImageView? {
        val bm = thumb(path, dp(size)) ?: return null
        return ImageView(this).apply {
            setImageBitmap(bm); scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(0, 0, dp(6), 0) }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(r).toFloat()) }
            }
            clipToOutline = true
        }
    }

    // ------------------------------------------------------------------ build
    // ------------------------------------------------------------------ Chat / ZOKI tabs, model picker, status flash
    private var chatMode = false
    private lateinit var tabChat: TextView
    private lateinit var tabZoki: TextView
    private lateinit var segInd: View
    private var lastCan = false
    private lateinit var modelChip: TextView
    private val sh = Handler(Looper.getMainLooper())

    private fun pill(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(5), dp(12), dp(5))
        setOnClickListener { Style.buzz(this@ChatActivity, "tick"); onClick() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) }
    }

    private fun styleTab(v: TextView, on: Boolean) {
        if (v === tabChat || v === tabZoki) { v.setTextColor(if (on) t.btnText else t.sub); return }
        if (on) { v.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply { cornerRadius = dp(16).toFloat() }; v.setTextColor(t.btnText) }
        else { v.background = round(if (t.light) 0x14000000 else 0x1AFFFFFF, 16, (t.stroke and 0x00FFFFFF) or 0x44000000); v.setTextColor(t.text) }
    }

    /** Chat tab: every message is a question for the chosen AI model. ZOKI tab: commands and the assistant. */
    private fun setMode(chat: Boolean) {
        if (chat == chatMode) return
        if (ChatBus.busy) { Toast.makeText(this, "A task is running. Stop it first", Toast.LENGTH_SHORT).show(); return }
        chatMode = chat
        getSharedPreferences("chat", MODE_PRIVATE).edit().putString("mode", if (chat) "chat" else "zoki").apply()
        styleTab(tabChat, chat); styleTab(tabZoki, !chat)
        segInd.animate().translationX(if (chat) 0f else dp(72).toFloat()).setDuration(240).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        input.hint = if (chat) "Ask ${ResearchPrefs.selected(this).label}…" else "Message ZOKI…"
        msgBox.animate().alpha(0f).setDuration(110).withEndAction { reloadMsgs(); msgBox.animate().alpha(1f).setDuration(200).start() }.start()
    }

    private fun reloadMsgs() {
        msgBox.removeAllViews(); msgCount = 0; liveRow = null; liveText = null
        ChatStore.load(this).forEach { addMsg(it, false) }
        if (ChatBus.busy) showLive(ChatBus.live.ifBlank { "Working…" })
        updateEmpty(); scrollDown(false)
    }

    // ---- chat history (like Claude): every chat is kept, open one from the menu
    private lateinit var histBox: LinearLayout
    private fun refreshHistory() {
        if (!::histBox.isInitialized) return
        histBox.removeAllViews()
        val cur = ChatStore.curId(this)
        val fmt = SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH)
        val l = ChatStore.list(this).take(25)
        if (l.isEmpty()) histBox.addView(TextView(this).apply { text = "No saved chats yet"; textSize = 12.5f; setTextColor(t.sub); setPadding(dp(6), dp(4), 0, dp(6)) })
        for (cv in l) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; tag = "card"
                setPadding(dp(14), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(3)) }
                if (cv.id == cur) background = round(0x33FFFFFF, 14, t.stroke)
                setOnClickListener {
                    if (ChatBus.busy) { Toast.makeText(this@ChatActivity, "A task is running. Stop it first", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                    ChatStore.open(this@ChatActivity, cv.id); reloadMsgs(); toggleDrawer(false)
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@ChatActivity).setTitle(cv.title).setItems(arrayOf("Rename", "Delete")) { _, w ->
                        if (w == 0) {
                            val et = EditText(this@ChatActivity).apply { setText(cv.title); setSelection(text.length) }
                            AlertDialog.Builder(this@ChatActivity).setTitle("Rename chat").setView(et)
                                .setPositiveButton("Save") { _, _ -> ChatStore.rename(this@ChatActivity, cv.id, et.text.toString()); refreshHistory() }
                                .setNegativeButton("Cancel", null).show()
                        } else {
                            val was = cv.id == ChatStore.curId(this@ChatActivity)
                            ChatStore.delete(this@ChatActivity, cv.id); refreshHistory()
                            if (was) reloadMsgs()
                        }
                    }.show()
                    true
                }
            }
            r.addView(TextView(this).apply { text = cv.title; textSize = 14.5f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setTextColor(t.text) })
            r.addView(TextView(this).apply { text = fmt.format(Date(cv.ts)); textSize = 11f; setTextColor(t.sub) })
            histBox.addView(r)
        }
    }

    private fun updateModelChip() {
        if (!::modelChip.isInitialized) return
        modelChip.text = "🤖 " + ResearchPrefs.selected(this).label + " ▾"
        if (chatMode) input.hint = "Ask ${ResearchPrefs.selected(this).label}…"
    }

    private fun pickModel() {
        val all = ResearchPrefs.ALL
        val cur = all.indexOfFirst { it.key == ResearchPrefs.selected(this).key }
        val labels = all.map { it.label + if (ResearchPrefs.installed(this, it)) "" else "  (not installed)" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Answer with").setSingleChoiceItems(labels, cur) { d, w ->
            ResearchPrefs.select(this, all[w].key); updateModelChip(); d.dismiss()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun isImageReq(txt: String): Boolean {
        val w = Regex("\\p{L}+").findAll(txt.lowercase()).map { it.value }.toList()
        val img = w.any { it in setOf("photo", "image", "images", "pic", "pics", "picture", "tasveer", "tasvir", "foto", "logo", "poster", "wallpaper", "img") }
        val mk = w.any { it.startsWith("bana") || it.startsWith("bnao") || it.startsWith("creat") || it.startsWith("gener") || it.startsWith("draw") || it.startsWith("design") || it in setOf("make", "banado", "chahiye", "do", "dikhao") }
        val no = w.any { it in setOf("send", "bhejo", "bhej", "post") }
        return img && mk && !no
    }

    private fun dispatchImage(txt: String) {
        val i = Intent(this, OverlayService::class.java).putExtra("chat_image", txt)
        ChatBus.begin(txt, "")
        showLive("Starting…")
        updateSend()
        try { startForegroundService(i) } catch (_: Exception) { ChatBus.finish(this, false, "❌ Could not start the assistant service.") }
    }

    private fun saveToGallery(path: String) {
        try {
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "ZOKI_" + System.currentTimeMillis() + ".jpg")
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZOKI")
            }
            val u = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(u)!!.use { o -> java.io.File(path).inputStream().use { it.copyTo(o) } }
            Toast.makeText(this, "Saved in Pictures/ZOKI", Toast.LENGTH_LONG).show()
        } catch (_: Exception) { Toast.makeText(this, "Could not save the picture (allow storage permission)", Toast.LENGTH_LONG).show() }
    }

    /** the schedule / posts card is shown for 3 seconds, once every 10 minutes */
    private fun flashStatus() {
        if (!::statusCard.isInitialized || statusCard.text.isBlank()) return
        lastFlash = System.currentTimeMillis()
        statusCard.visibility = View.VISIBLE
        sh.postDelayed({ if (::statusCard.isInitialized) statusCard.visibility = View.GONE }, 3000)
    }
    private val flashLoop = object : Runnable { override fun run() { refreshStatus(); flashStatus(); sh.postDelayed(this, 600_000L) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        t = Style.theme(this)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        val root = FrameLayout(this).apply { background = Style.background(this@ChatActivity) }
        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ---- header (compact, one row): menu | robot + title | Chat / ZOKI tabs | new chat
        chatMode = getSharedPreferences("chat", MODE_PRIVATE).getString("mode", "zoki") == "chat"
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(2), dp(4), dp(2)) }
        header.addView(icon(R.drawable.ic_menu, "Menu", 38) { toggleDrawer(true) })
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_robot_mono); setColorFilter(t.stroke)
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { setMargins(dp(2), 0, dp(4), 0) }
        })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(TextView(this).apply { text = "ZOKI"; textSize = 15f; tag = "title"; typeface = android.graphics.Typeface.DEFAULT_BOLD })
        subT = TextView(this).apply { text = "Ready"; textSize = 10f; tag = "sub" }
        col.addView(subT)
        header.addView(col)
        // segmented switch: the coloured pill slides between Chat and ZOKI
        val seg = FrameLayout(this).apply {
            background = round(if (t.light) 0x14000000 else 0x1AFFFFFF, 18, (t.stroke and 0x00FFFFFF) or 0x44000000)
            layoutParams = LinearLayout.LayoutParams(dp(148), dp(34)).apply { setMargins(dp(4), 0, dp(4), 0) }
        }
        segInd = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply { cornerRadius = dp(16).toFloat() }
            layoutParams = FrameLayout.LayoutParams(dp(72), dp(30)).apply { setMargins(dp(2), dp(2), 0, 0) }
            translationX = if (chatMode) 0f else dp(72).toFloat()
        }
        val segRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun segLabel(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 13.5f; gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(dp(74), -1)
            setOnClickListener { Style.buzz(this@ChatActivity, "tick"); onClick() }
        }
        tabChat = segLabel("Chat") { setMode(true) }
        tabZoki = segLabel("ZOKI") { setMode(false) }
        segRow.addView(tabChat); segRow.addView(tabZoki)
        seg.addView(segInd); seg.addView(segRow)
        header.addView(seg)
        styleTab(tabChat, chatMode); styleTab(tabZoki, !chatMode)
        header.addView(icon(R.drawable.ic_new, "New chat", 38) { confirmClear() })
        main.addView(header)
        main.addView(View(this).apply { setBackgroundColor((t.stroke and 0x00FFFFFF) or 0x30000000); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) })

        // ---- status card: next schedule + posts of today (tap = open schedule page)
        statusCard = TextView(this).apply {
            textSize = 12f; visibility = View.GONE; maxLines = 2
            setPadding(dp(14), dp(8), dp(14), dp(8)); setTextColor(t.sub)
            background = Style.card(this@ChatActivity, t, 14)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), 0) }
            setOnClickListener { openSettings(1) }
        }
        main.addView(statusCard)

        // ---- setup banner (only while a permission is missing)
        banner = TextView(this).apply {
            textSize = 13f; tag = "chat_banner"; visibility = View.GONE
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = round(0x33FFB020, 14, 0x88FFB020.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), 0) }
            setOnClickListener { openSettings(0) }
        }
        main.addView(banner)

        // ---- messages + empty state
        val frame = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        scroll = ScrollView(this).apply { isFillViewport = false; overScrollMode = View.OVER_SCROLL_NEVER }
        msgBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(14)) }
        scroll.addView(msgBox)
        frame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        emptyV = buildEmpty()
        frame.addView(emptyV, FrameLayout.LayoutParams(-1, -1))
        main.addView(frame)

        // ---- plugin tray (shown when the plug icon is tapped)
        tray = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; visibility = View.GONE; setPadding(dp(10), dp(4), dp(10), dp(4)) }
        trayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tray.addView(trayRow)
        main.addView(tray)

        // ---- quick commands (tap = run or fill, long-press = delete, + = add)
        quickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(4), dp(10), dp(2)) }

        // ---- attachments (chosen plugin + photos)
        attachBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE; setPadding(dp(14), dp(4), dp(14), dp(2)) }
        main.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(attachBar) })

        // ---- input bar: text on top (full width), buttons in a row below: photo | plugins ... mic | send
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Style.card(this@ChatActivity, t, 24)
            setPadding(dp(8), dp(4), dp(8), dp(6))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(10), dp(4), dp(10), dp(10)) }
        }
        input = EditText(this).apply {
            hint = "Message ZOKI…"; textSize = 16f; background = null; maxLines = 6; minLines = 1
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(10), dp(10), dp(10), dp(6)); setTextColor(t.text); setHintTextColor(t.sub)
            layoutParams = LinearLayout.LayoutParams(-1, -2)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { updateSend() }
            })
            setOnClickListener { hideTray() }
        }
        bar.addView(input)
        bar.elevation = dp(6).toFloat()
        input.setOnFocusChangeListener { _, f ->
            bar.background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat(); setColor(if (t.light) 0xCCFFFFFF.toInt() else 0x1AFFFFFF)
                setStroke(dp(if (f) 2 else 1), if (f) t.stroke else (t.stroke and 0x00FFFFFF) or 0x44000000)
            }
        }
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        btns.addView(icon(R.drawable.ic_photo, "Add photo", 42) { pickPhoto() })
        btns.addView(icon(R.drawable.ic_plug, "Plugins", 42) { toggleTray() })
        btns.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        modelChip = TextView(this).apply {
            textSize = 12.5f; setTextColor(t.text); gravity = Gravity.CENTER; maxLines = 1
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = round(if (t.light) 0x14000000 else 0x1AFFFFFF, 16, (t.stroke and 0x00FFFFFF) or 0x44000000)
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(4), 0) }
            setOnClickListener { pickModel() }
        }
        press(modelChip)
        btns.addView(modelChip)
        btns.addView(icon(R.drawable.ic_mic, "Voice", 42) { handsOff = false; listen() })
        sendBtn = ImageButton(this).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE; setColorFilter(t.btnText)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(dp(6), 0, 0, 0) }
            setOnClickListener { Style.buzz(this@ChatActivity, "click"); if (ChatBus.busy) stopRun() else send() }
        }
        press(sendBtn)
        btns.addView(sendBtn)
        bar.addView(btns)
        main.addView(bar)
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        // ---- drawer (settings), hidden to the left
        scrim = View(this).apply { setBackgroundColor(0x99000000.toInt()); alpha = 0f; visibility = View.GONE; setOnClickListener { toggleDrawer(false) } }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        drawer = buildDrawer()
        root.addView(drawer, FrameLayout.LayoutParams(dp(300), -1))
        drawer.translationX = -dp(320).toFloat()

        setContentView(root)
        root.alpha = 0f; root.translationY = dp(18).toFloat()
        root.animate().alpha(1f).translationY(0f).setDuration(300).start()
        Style.skin(this, header); Style.skin(this, drawer); Style.skin(this, input)
        banner.setTextColor(t.text)
        refreshTray(); refreshAttach(); updateSend(); refreshQuick(); updateModelChip()

        val hist = ChatStore.load(this)
        hist.forEach { addMsg(it, false) }
        updateEmpty()
        if (ChatBus.busy) showLive(ChatBus.live)
        scrollDown(false)
    }

    private fun buildEmpty(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(22), dp(10), dp(22), dp(10)) }
        v.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        v.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_robot_mono); setColorFilter(t.stroke)
            layoutParams = LinearLayout.LayoutParams(dp(130), dp(130))
            // the robot floats gently up and down
            ObjectAnimator.ofFloat(this, "translationY", 0f, -dp(10).toFloat()).apply {
                duration = 1600; repeatMode = ObjectAnimator.REVERSE; repeatCount = ObjectAnimator.INFINITE
                interpolator = android.view.animation.AccelerateDecelerateInterpolator(); start()
            }
        })
        v.addView(TextView(this).apply { text = "How can I help?"; textSize = 24f; setTextColor(t.text); gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD })
        v.addView(TextView(this).apply {
            text = "Write a command like you chat with ChatGPT.\nI will run it on your phone and tell you when it is done."
            textSize = 13.5f; setTextColor(t.sub); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(14))
        })
        val ex = listOf("WhatsApp pe Parwez ko assalamualaikum bhejo", "research karo how solar panels work", "image banao a robot flying over a city at night")
        var exI = 0
        for (e in ex) v.addView(TextView(this).apply {
            alpha = 0f; translationY = dp(14).toFloat()
            animate().alpha(1f).translationY(0f).setStartDelay(250L + 90L * (exI++)).setDuration(320).start()
            press(this)
            text = e; textSize = 13.5f; setTextColor(t.text); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), Style.card(this@ChatActivity, t, 16), null)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) }
            setOnClickListener { input.setText(e); input.setSelection(e.length); input.requestFocus(); Style.buzz(this@ChatActivity, "tick") }
        })
        v.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        return v
    }

    private fun buildDrawer(): LinearLayout {
        val sp = getSharedPreferences("n", MODE_PRIVATE)
        val d = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(t.bg1, t.bg2)).apply { setStroke(dp(1), (t.stroke and 0x00FFFFFF) or 0x44000000) }
            elevation = dp(16).toFloat(); isClickable = true
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(40), dp(10), dp(8)) }
        top.addView(TextView(this).apply { text = "Settings"; textSize = 24f; tag = "title"; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        top.addView(icon(R.drawable.ic_menu, "Close menu") { toggleDrawer(false) })
        d.addView(top)
        val sc = ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), dp(20)) }
        sc.addView(list); d.addView(sc)

        fun row(ic: String, title: String, sub: String, onClick: () -> Unit) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = "card"
                setPadding(dp(14), dp(13), dp(12), dp(13))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
                setOnClickListener { Style.buzz(this@ChatActivity, "tick"); onClick() }
            }
            r.addView(TextView(this).apply { text = ic; textSize = 22f; setPadding(0, 0, dp(14), 0) })
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            c.addView(TextView(this).apply { text = title; textSize = 15f })
            if (sub.isNotBlank()) c.addView(TextView(this).apply { text = sub; textSize = 11.5f; tag = "sub" })
            r.addView(c)
            r.addView(TextView(this).apply { text = "›"; textSize = 22f; tag = "back" })
            list.addView(r)
        }
        fun label(s: String) = list.addView(TextView(this).apply { text = s; textSize = 12f; tag = "sec"; setPadding(dp(4), dp(14), 0, dp(2)) })

        label("CHATS  (hold to rename / delete)")
        histBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        list.addView(histBox)
        label("ASSISTANT")
        row("⚙", "Setup and control", "Permissions, start and stop, tests") { openSettings(0) }
        row("🗓", "Schedule and plans", "Timed commands, daily post plans, briefing") { openSettings(1) }
        row("📣", "Posting", "WhatsApp channel, Facebook, poster, history") { openSettings(2) }
        row("⚡", "Automation", "Routines, triggers, shake, digest, reply helper") { openSettings(3) }
        row("🎙", "Phone, voice and AI", "Lock screen, limits, voice, AI app") { openSettings(4) }
        row("☰", "All settings", "MJ voice wake and everything else") { openSettings(-1) }

        label("CHAT")
        fun switchCard(title: String, sub: String, key: String, def: Boolean) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = "card"
                setPadding(dp(14), dp(12), dp(10), dp(12))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            col.addView(TextView(this).apply { text = title; textSize = 15f })
            col.addView(TextView(this).apply { text = sub; textSize = 11.5f; tag = "sub" })
            val s = Switch(this).apply {
                isChecked = sp.getBoolean(key, def)
                setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(key, v).apply(); Style.buzz(this@ChatActivity, "click"); if (key == "chat_voice" && !v) { try { tts?.stop() } catch (_: Exception) {} } }
            }
            card.addView(col); card.addView(s); card.setOnClickListener { s.toggle() }
            list.addView(card)
        }
        switchCard("Ask before posting", "Shows the photo and text in the chat first: Post now / Edit text / Cancel", "chat_approve", true)
        switchCard("Work View cover", "While a command works inside another app, show only ZOKI's steps, photo and text on top", "work_view", true)
        switchCard("Come back to chat when done", "Opens this chat with the answer after a task", "chat_back", true)
        switchCard("Ask before risky commands", "Yes / No buttons before send, call or post commands", "chat_confirm", true)
        switchCard("Speak replies", "The assistant reads its replies; the mic sends by itself", "chat_voice", false)
        switchCard("Hands-free voice", "After each spoken reply the mic listens again. Back on the mic screen stops it", "chat_hands", false)
        row("🗑", "Clear chat", "Delete all messages") { toggleDrawer(false); confirmClear() }

        label("THEME")
        val names = Style.names
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, 0) }
        val cur = Style.cur(this)
        names.forEach { n ->
            strip.addView(TextView(this).apply {
                text = Style.labels[n] ?: n; gravity = Gravity.CENTER; tag = if (n == cur) "chipOn" else "chipOff"
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), dp(8)) }
                setOnClickListener { Style.set(this@ChatActivity, n); Style.buzz(this@ChatActivity, "heavy"); recreate() }
            })
        }
        list.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) })
        list.addView(TextView(this).apply { text = "build v69"; textSize = 11f; tag = "sub"; setPadding(dp(4), dp(16), 0, 0) })
        return d
    }

    // ------------------------------------------------------------------ drawer / navigation
    private fun toggleDrawer(open: Boolean) {
        hideKeyboard(); hideTray()
        drawerOpen = open
        if (open) {
            refreshHistory(); scrim.visibility = View.VISIBLE
            val lst = (drawer.getChildAt(1) as? ScrollView)?.getChildAt(0) as? LinearLayout
            if (lst != null) for (i in 0 until lst.childCount) {
                val cv = lst.getChildAt(i)
                cv.alpha = 0f; cv.translationX = -dp(30).toFloat()
                cv.animate().alpha(1f).translationX(0f).setStartDelay(70L + 22L * minOf(i, 14)).setDuration(240).start()
            }
        }
        scrim.animate().alpha(if (open) 1f else 0f).setDuration(200).withEndAction { if (!drawerOpen) scrim.visibility = View.GONE }.start()
        drawer.animate().translationX(if (open) 0f else -dp(320).toFloat()).setDuration(240).start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) toggleDrawer(false)
        else if (tray.visibility == View.VISIBLE) hideTray()
        else super.onBackPressed()
    }

    private fun openSettings(page: Int, find: String = "", nth: Int = 0) {
        toggleDrawer(false)
        startActivity(Intent(this, MainActivity::class.java).putExtra("page", page).putExtra("find", find).putExtra("nth", nth))
    }

    /** chat message with tappable setting results */
    private fun settingsReply(intro: String, q: String): ChatMsg? {
        val r = SettingsIndex.search(q)
        if (r.isEmpty()) return null
        return ChatMsg("a", intro, emptyList(), true, System.currentTimeMillis(), r.map { it.title.removeSuffix(" (page)") + "\t" + it.page + "\t" + it.find + "\t" + it.nth })
    }
    private var lastUser = ""

    private fun hideKeyboard() {
        try { (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0) } catch (_: Exception) {}
    }

    private fun confirmClear() {
        if (ChatBus.busy) { Toast.makeText(this, "A task is running. Stop it first", Toast.LENGTH_SHORT).show(); return }
        if (ChatStore.load(this).isEmpty()) { Toast.makeText(this, "This is already a new chat", Toast.LENGTH_SHORT).show(); return }
        ChatStore.newConv(this)      // the old chat stays in the history list
        reloadMsgs()
    }

    // ------------------------------------------------------------------ plugins + photos
    private fun toggleTray() { if (tray.visibility == View.VISIBLE) hideTray() else { hideKeyboard(); tray.visibility = View.VISIBLE } }
    private fun hideTray() { tray.visibility = View.GONE }

    private fun refreshTray() {
        trayRow.removeAllViews()
        for (p in Plugins.ALL) {
            val c = TextView(this)
            c.text = p.icon + " " + p.label; c.gravity = Gravity.CENTER
            c.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }
            Style.chip(this, c, t, p.key == selPlugin)
            c.setOnClickListener {
                selPlugin = if (selPlugin == p.key) null else p.key
                Style.buzz(this, "tick"); hideTray(); refreshTray(); refreshAttach(); input.requestFocus()
            }
            trayRow.addView(c)
        }
    }

    private fun refreshAttach() {
        attachBar.removeAllViews()
        val p = Plugins.ALL.firstOrNull { it.key == selPlugin }
        input.hint = p?.hint ?: "Message ZOKI…"
        if (p != null) {
            val c = TextView(this); c.text = p.icon + " " + p.label + "  ✕"
            c.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }
            Style.chip(this, c, t, true)
            c.setOnClickListener { selPlugin = null; refreshTray(); refreshAttach() }
            attachBar.addView(c)
        }
        for (path in imgs.toList()) {
            val v = picView(path, 46, 12) ?: continue
            v.setOnClickListener { imgs.remove(path); refreshAttach() }
            attachBar.addView(v)
        }
        attachBar.visibility = if (attachBar.childCount > 0) View.VISIBLE else View.GONE
        updateSend()
    }

    private fun pickPhoto() {
        hideTray()
        val room = 6 - imgs.size
        if (room <= 0) { Toast.makeText(this, "Maximum 6 photos. Tap a photo to remove it", Toast.LENGTH_SHORT).show(); return }
        PluginBus.onImages = { paths -> runOnUiThread { for (p in paths) if (imgs.size < 6) imgs.add(p); refreshAttach() } }
        try { startActivity(Intent(this, PickActivity::class.java).putExtra("max", room)) } catch (_: Exception) { PluginBus.onImages = null }
    }

    private fun listen() {
        hideTray()
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your command"), 91)
        } catch (_: Exception) { Toast.makeText(this, "Voice input is not available on this phone", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 91 && res != RESULT_OK) handsOff = true
        if (req == 91 && res == RESULT_OK) {
            val s = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            val cur = input.text.toString()
            val n = if (cur.isBlank()) s else "$cur $s"
            input.setText(n); input.setSelection(n.length)
            if (voiceOn() && !ChatBus.busy) send()
            else if (voiceOn()) handsOff = true
        }
    }

    // ------------------------------------------------------------------ sending
    private fun updateSend() {
        if (!::sendBtn.isInitialized) return
        val busy = ChatBus.busy
        val can = busy || input.text.toString().isNotBlank() || imgs.isNotEmpty()
        sendBtn.setImageResource(if (busy) R.drawable.ic_stop else R.drawable.ic_send)
        sendBtn.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply { shape = GradientDrawable.OVAL; setStroke(dp(1), t.stroke) }
        sendBtn.alpha = if (can) 1f else 0.4f
        if (can != lastCan) {   // the send button pops when it becomes ready
            lastCan = can
            if (can) { sendBtn.scaleX = 0.7f; sendBtn.scaleY = 0.7f; sendBtn.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(android.view.animation.OvershootInterpolator(3f)).start() }
        }
        subT.text = if (busy) "Working…" else if (banner.visibility == View.VISIBLE) "Setup needed" else "Ready"
    }

    private fun prefs() = getSharedPreferences("n", MODE_PRIVATE)
    private fun voiceOn() = prefs().getBoolean("chat_voice", false)

    private fun addUser(text: String, imgList: List<String> = emptyList()) {
        val um = ChatMsg("u", text, ArrayList(imgList), true, System.currentTimeMillis())
        ChatStore.add(this, um); addMsg(um, true)
    }

    /** local assistant reply (no service needed) */
    private fun reply(text: String, links: List<String> = emptyList(), ok: Boolean = true) {
        val m = ChatMsg("a", text, emptyList(), ok, System.currentTimeMillis(), links)
        ChatStore.add(this, m); addMsg(m, true); speak(text); updateEmpty()
    }

    private fun send() {
        val txt = input.text.toString().trim()
        if (ChatBus.busy || (txt.isEmpty() && imgs.isEmpty())) return
        hideTray(); hideKeyboard(); stopSpeak()
        val plug = selPlugin
        val imgList = ArrayList(imgs)
        val shown = (plug?.let { Plugins.ALL.firstOrNull { p -> p.key == it }?.let { p -> "${p.icon} ${p.label}\n" } } ?: "") + txt
        addUser(shown.trim(), imgList)
        lastUser = txt
        input.setText(""); imgs.clear(); selPlugin = null; refreshTray(); refreshAttach(); updateEmpty()
        route(txt, plug, imgList, 0)
    }

    // ------------------------------------------------------------------ routing: what to do with a message
    // flags: 1 = contact already chosen, 2 = already confirmed
    private val riskyRe = Regex("\\b(send|bhej\\w*|message|msg|call|post|forward|delete|uninstall)\\b")
    private val cmdWords = setOf("open", "kholo", "khol", "call", "send", "bhejo", "search", "play", "set", "turn", "volume", "torch", "timer", "alarm", "post", "research",
        "translate", "summarize", "message", "msg", "wifi", "bluetooth", "brightness", "screenshot", "lock", "unlock", "scroll", "tap", "type", "photo", "selfie", "image", "poster", "check")
    private val qWords = setOf("kya", "kyun", "kyu", "kyon", "kaise", "kese", "kaun", "kon", "kab", "kitna", "kitne", "kitni", "kahan", "kidhar", "what", "why", "how", "who",
        "when", "where", "which", "explain", "tell", "define", "batao", "bata", "samjhao", "meaning")

    private fun route(txt: String, plug: String?, imgList: List<String>, flags: Int) {
        if (chatMode) {   // Chat tab: everything is a question for the chosen model; a picture request makes the picture
            if (imgList.isEmpty() && isImageReq(txt)) dispatchImage(txt) else dispatch(txt, null, imgList, true)
            return
        }
        val plain = plug == null && imgList.isEmpty()
        if (plain && !ChatBus.busy) {
            // 00. "galib ko shukriya likho": the AI writes a draft, then Send / Edit buttons
            Regex("^(\\p{L}[\\p{L} ]{0,30}?)\\s+ko\\s+(.{2,200}?)\\s+(?:likho|likh\\s*do|likh\\s*de|likhna|likh\\s*kar\\s*do)\\s*$", RegexOption.IGNORE_CASE).find(txt.trim())?.let { dm ->
                val nm = dm.groupValues[1].trim(); val topic = dm.groupValues[2].trim()
                if (nm.lowercase() !in refWords && nm.split(" ").none { it.lowercase() in cmdWords }) {
                    cp().edit().putString("last_name", nm).apply()
                    ChatBus.draftTo = nm
                    dispatch("Write a short, polite message to $nm about: $topic. Use the same language and script I write in (Hinglish / Urdu / English). Reply with ONLY the message text, no quotes, no explanation.", null, emptyList(), true)
                    return
                }
            }
        }
        if (plain) {
            // 0a. short form: "whatsapp pe mbfg ko assalamualaikum bhejo" -> long command
            ShortCmd.expand(txt, cp().getString("last_app", null) ?: "whatsapp", ShortCmd.installed(packageManager))?.let { route(it, null, emptyList(), flags); return }
            // 0b. "phir usi ko bol do ki ..." -> full command with the last person / app
            val fu = followUp(txt)
            if (fu != null) {
                if (fu.isBlank()) return
                route(fu, null, emptyList(), flags)
                return
            }
            // 1. "whatsapp settings" -> tappable settings
            if (SettingsIndex.isQuery(txt) && SettingsIndex.hasTopic(txt)) {
                val lk = settingLinks(txt)
                if (lk.isNotEmpty()) { reply("🔎 Found these settings. Tap one to open it:", lk); return }
            }
            // 2. greetings and small talk are answered right here
            smallTalk(txt)?.let { reply(it); return }
            // 3. "roz subah 8 baje ..." -> schedule (with confirmation)
            parseSchedule(txt)?.let { s ->
                reply("📅 Schedule this?\n\n“" + s.cmd + "”\n" + s.label, listOf("✅ Yes, schedule it\t-106\t${s.hh}|${s.mm}|${s.days}|${s.at}|${s.cmd}\t0", "✖ No\t-102\t\t0"))
                return
            }
            // 4. several contacts with that name -> ask which one
            if ((flags and 1) == 0) contactChoices(txt)?.let { (name, list) ->
                reply("I found ${list.size} contacts for “$name”. Which one?", list.map { full ->
                    val nc = Regex(java.util.regex.Pattern.quote(name), RegexOption.IGNORE_CASE).replaceFirst(txt, full.replace("\t", " "))
                    "$full\t-107\t$nc\t0"
                })
                return
            }
        }
        // 5. risky commands need a Yes
        if ((flags and 2) == 0 && plain && prefs().getBoolean("chat_confirm", true) && riskyRe.containsMatchIn(txt.lowercase())) {
            reply("⚠ Run this command?\n\n“$txt”", listOf("✅ Yes, run\t-101\t|$txt\t0", "✖ No\t-102\t\t0"))
            return
        }
        // 6. a plain question goes to the AI app, the answer comes back here
        if (plain && isQuestion(txt)) { dispatch(txt, null, imgList, true); return }
        dispatch(txt, plug, imgList, false)
    }

    // ---- follow-up: remember the last person and app of a phone command
    private val nameStop = setOf("send", "bhejo", "bhej", "message", "msg", "aur", "phir", "and", "then", "ko", "me", "mein", "par", "pe", "karo", "kar", "do", "bol", "likho", "say", "salam", "whatsapp")
    private val refWords = setOf("usi", "usko", "unko", "wahi", "wohi", "isi", "isko", "inko", "same", "him", "her", "them", "uski", "unki")
    private fun cp() = getSharedPreferences("chat", MODE_PRIVATE)

    private fun extractName(txt: String): String? {
        val m = Regex("search\\s+(?:karo\\s+|for\\s+)?([^,.;]+)", RegexOption.IGNORE_CASE).find(txt)
        if (m != null) {
            val ws = m.groupValues[1].trim().split(Regex("\\s+")).takeWhile { it.lowercase() !in nameStop }.take(3)
            if (ws.isNotEmpty()) return ws.joinToString(" ")
        }
        val k = Regex("(\\p{L}{2,}(?:\\s\\p{L}{2,})?)\\s+ko\\b").find(txt)
        if (k != null) {
            val ws = k.groupValues[1].trim().split(Regex("\\s+")).filter { it.lowercase() !in nameStop && it.lowercase() !in refWords }
            if (ws.isNotEmpty()) return ws.joinToString(" ")
        }
        return null
    }

    private fun extractApp(txt: String): String? {
        val low = txt.lowercase()
        for (a in listOf("whatsapp business", "whatsapp", "telegram", "messages", "instagram", "facebook", "messenger")) if (low.contains(a)) return a
        Regex("^((?:\\p{L}+\\s+){0,2}\\p{L}+)\\s+(?:kholo|khol)\\b").find(low)?.groupValues?.get(1)?.let { if (it.split(" ").first() != "open") return it }
        val m = Regex("(?:open|kholo|khol)\\s+(?:the\\s+)?(\\p{L}+)").find(low)
        val w = m?.groupValues?.get(1)
        return if (w != null && w !in setOf("karo", "kar", "do", "it", "ye", "is")) w else null
    }

    private fun remember(txt: String) {
        val n = extractName(txt); val a = extractApp(txt)
        if (n == null && a == null) return
        val e = cp().edit()
        if (n != null) e.putString("last_name", n)
        if (a != null) e.putString("last_app", a)
        e.apply()
    }

    /** "" = answered here (name unknown), null = not a follow-up, else the full command */
    private fun followUp(txt: String): String? {
        val w = Regex("\\p{L}+").findAll(txt.lowercase()).map { it.value }.toList()
        if (w.none { it in refWords } || w.size > 14) return null
        val isCall = w.any { it in setOf("call", "phone", "dial") }
        val msg = Regex("(?:\\bki\\b|\\bthat\\b)\\s+(.+)$", RegexOption.IGNORE_CASE).find(txt.trim())?.groupValues?.get(1)
            ?: Regex("(?:message\\s+(?:bhejo|bhej do|bhej de|send)|bol do|bol de|bolo|bhejo|bhej do|bhej de|send|likho|likh do)\\s+(.+)$", RegexOption.IGNORE_CASE).find(txt.trim())?.groupValues?.get(1)
        val m = msg?.trim()?.trim('.', '!')?.removePrefix("ki ")?.trim()
        if (!isCall && m.isNullOrBlank()) return null
        val name = cp().getString("last_name", null)
        if (name.isNullOrBlank()) {
            reply("Kis ke liye? Pehle naam ke saath ek command do, jaise \"whatsapp pe parwez ko salam bhejo\", phir main \"usi ko ...\" samajh jaunga.", emptyList(), false)
            return ""
        }
        if (isCall) return "call $name"
        val app = cp().getString("last_app", null) ?: "whatsapp"
        return ShortCmd.build(app, name, m ?: "")
    }

    private fun isQuestion(txt: String): Boolean {
        val w = Regex("\\p{L}+").findAll(txt.lowercase()).map { it.value }.toList()
        if (w.isEmpty() || w.any { it in cmdWords }) return false
        return txt.trim().endsWith("?") || w.first() in qWords
    }

    private fun dispatch(txt: String, plug: String?, imgList: List<String>, ask: Boolean) {
        if (ChatBus.busy) { Toast.makeText(this, "A task is running. Stop it first", Toast.LENGTH_SHORT).show(); return }
        if (!Settings.canDrawOverlays(this)) {
            reply("⚠ I need the overlay permission first. Open the menu ☰ → Setup and control, then try again.", emptyList(), false)
            return
        }
        if (!ask) remember(txt)
        val i = Intent(this, OverlayService::class.java)
        if (ask) i.putExtra("chat_ask", txt)
        else i.putExtra("chat_cmd", txt).putExtra("chat_plugin", plug ?: "").putExtra("chat_imgs", imgList.toTypedArray())
        ChatBus.begin(txt, plug ?: "")
        showLive(if (ask) "Asking the AI…" else "Starting…")
        updateSend()
        try { startForegroundService(i) } catch (_: Exception) { ChatBus.finish(this, false, "❌ Could not start the assistant service.") }
    }

    // ---- 1. small talk
    private fun smallTalk(raw: String): String? {
        val s = raw.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()
        val w = s.split(" ").filter { it.isNotEmpty() }
        if (w.isEmpty() || w.size > 5) return null
        if (w.any { it in setOf("bhejo", "bhej", "send", "message", "msg", "ko", "bol", "likho", "search", "open", "kholo", "call", "post") }) return null
        val name = UsageGuard.userName(this)
        fun has(vararg k: String) = k.any { s == it }
        return when {
            s.contains("salam") || s.contains("salaam") || has("aoa", "slm", "asalam") -> "Wa alaikum assalam $name! Main hazir hoon. Kya kaam karun?"
            has("hi", "hii", "hiii", "hello", "hey", "hlo", "hy", "helo", "namaste", "good morning", "good evening", "good night", "gm") -> "Hi $name! Main hazir hoon. Command likho ya koi sawaal poochho."
            s.contains("kaise ho") || s.contains("kese ho") || s.contains("how are you") || s.contains("kya haal") || s.contains("kaisa hai") -> "Main bilkul theek hoon, shukriya! Aap batao, kya karun?"
            has("thanks", "thank you", "thankyou", "thx", "shukriya", "shukria", "shukriyah") -> "Koi baat nahi $name! 😊"
            s.contains("kaun ho") || s.contains("who are you") || s.contains("tumhara naam") || s.contains("aapka naam") ->
                "Main ZOKI hun, aapka phone assistant. Apps kholna, message bhejna, research, post, schedule aur sawalon ke jawab, sab kar sakta hun."
            s.contains("kitne baje") || has("time") || s.contains("what time") -> "Abhi " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) + " baje hain."
            has("date") || s.contains("aaj ki tarikh") || s.contains("aaj kya tarikh") || s.contains("aaj kaun sa din") || s.contains("today date") ->
                "Aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date()) + " hai."
            has("help") || s.contains("madad") || s.contains("kya kar sakte") || s.contains("what can you do") ->
                "Main ye kar sakta hun:\n• Apps kholna, call, message (\"whatsapp pe parwez ko salam bhejo\")\n• Research, translate, summary, image (🔌 plugins)\n• WhatsApp channel / Facebook post\n• Schedule (\"roz subah 8 baje ...\")\n• Follow-up (\"phir usi ko bol do ki shaam ko aaunga\")\n• Koi bhi sawaal poochho\n• Settings dhoondho (\"whatsapp settings\")"
            else -> null
        }
    }

    // ---- 8. schedule from chat
    private class Sch(val hh: Int, val mm: Int, val days: Int, val at: Long, val cmd: String, val label: String)

    private fun parseSchedule(raw: String): Sch? {
        val low = raw.lowercase()
        val daily = Regex("\\b(roz|rozana|daily|every ?day|everyday)\\b|har roz").containsMatchIn(low)
        val tomorrow = Regex("\\b(kal|tomorrow)\\b").containsMatchIn(low)
        val today = Regex("\\b(aaj|today)\\b").containsMatchIn(low)
        if (!daily && !tomorrow && !today) return null
        val m = Regex("\\b(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|baje|bje|bajay)?\\b").findAll(low).firstOrNull { it.groupValues[2].isNotEmpty() || it.groupValues[3].isNotEmpty() } ?: return null
        var hh = m.groupValues[1].toInt(); val mm = m.groupValues[2].ifEmpty { "0" }.toInt()
        val ap = m.groupValues[3]
        val eve = Regex("\\b(shaam|sham|evening|raat|night|dopahar|dopehar|afternoon)\\b").containsMatchIn(low)
        if (ap == "pm" && hh < 12) hh += 12 else if (ap == "am" && hh == 12) hh = 0 else if (eve && hh < 12 && ap != "am") hh += 12
        if (hh !in 0..23 || mm !in 0..59) return null
        var cmd = low.replaceRange(m.range, " ").toString()
        cmd = cmd.replace(Regex("\\b(roz|rozana|daily|har|every|day|everyday|kal|tomorrow|aaj|today|subah|morning|shaam|sham|evening|raat|night|dopahar|dopehar|afternoon|at|schedule|baje|bje|bajay)\\b"), " ")
        cmd = cmd.replace(Regex("\\s+"), " ").trim(' ', ',', '.')
        if (cmd.isBlank()) return null
        val time = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hh); set(Calendar.MINUTE, mm) }.time)
        if (daily) return Sch(hh, mm, 0, 0L, cmd, "Every day at $time")
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hh); set(Calendar.MINUTE, mm); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        if (tomorrow) cal.add(Calendar.DAY_OF_YEAR, 1)
        if (cal.timeInMillis <= System.currentTimeMillis()) return null
        return Sch(hh, mm, 0, cal.timeInMillis, cmd, (if (tomorrow) "Tomorrow" else "Today") + " at $time")
    }

    private fun doSchedule(payload: String) {
        val f = payload.split("|", limit = 5)
        if (f.size < 5) return
        val hh = f[0].toIntOrNull() ?: return; val mm = f[1].toIntOrNull() ?: return
        val at = f[3].toLongOrNull() ?: 0L; val cmd = f[4]
        try {
            if (at > 0L) {
                val l = Scheduler.load(this)
                val s = Sched((l.maxOfOrNull { it.id } ?: 0) + 1, hh, mm, cmd, 0, true, at)
                l.add(s); Scheduler.save(this, l); Scheduler.arm(this, s)
            } else Scheduler.add(this, hh, mm, cmd, 0)
            reply("✅ Scheduled. You can see or change it in the menu ☰ → Schedule and plans.")
            refreshStatus()
        } catch (_: Exception) { reply("❌ Could not create the schedule.", emptyList(), false) }
    }

    // ---- 2. contacts with the same name
    private fun contactChoices(txt: String): Pair<String, List<String>>? {
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != 0) return null
        val low = txt.lowercase()
        val m = Regex("search\\s+(?:karo\\s+|for\\s+)?(\\p{L}{2,})").find(low) ?: Regex("(\\p{L}{2,})\\s+ko\\b").find(low) ?: return null
        val name = m.groupValues[1]
        if (name in setOf("whatsapp", "google", "youtube", "chrome", "facebook", "message", "ye", "is", "usko", "isko", "kisi", "unko", "inko", "sabko")) return null
        val out = LinkedHashSet<String>()
        try {
            contentResolver.query(ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.DISPLAY_NAME),
                ContactsContract.Contacts.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), ContactsContract.Contacts.DISPLAY_NAME)?.use { cur ->
                while (cur.moveToNext() && out.size < 6) cur.getString(0)?.let { out.add(it) }
            }
        } catch (_: Exception) { return null }
        return if (out.size >= 2) name to out.toList() else null
    }

    // ---- settings search links
    private fun settingLinks(q: String): List<String> =
        SettingsIndex.search(q).map { it.title.removeSuffix(" (page)") + "\t" + it.page + "\t" + it.find + "\t" + it.nth }

    /** a tapped button under an assistant message */
    private fun onLink(f: List<String>, m: ChatMsg) {
        val page = f[1].toIntOrNull() ?: -1
        val data = f[2]
        when (page) {
            -100, -101 -> {
                if (ChatBus.busy) { Toast.makeText(this, "A task is running. Stop it first", Toast.LENGTH_SHORT).show(); return }
                val plug = data.substringBefore("|").ifBlank { null }; val cmd = data.substringAfter("|")
                if (page == -100) addUser("🔁 " + cmd)
                lastUser = cmd
                route(cmd, plug, emptyList(), 3)
            }
            -102 -> reply("Okay, cancelled.")
            -103 -> {
                try { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ZOKI", m.text)); Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show() } catch (_: Exception) {}
            }
            -104 -> {
                try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("chat_save", m.text)); Toast.makeText(this, "Saving to Docera…", Toast.LENGTH_SHORT).show() } catch (_: Exception) {}
            }
            -110 -> { if (ChatBus.gate == null) Toast.makeText(this, "Nothing is waiting", Toast.LENGTH_SHORT).show() else ChatBus.decide(true) }
            -111 -> { if (ChatBus.gate == null) Toast.makeText(this, "Nothing is waiting", Toast.LENGTH_SHORT).show() else ChatBus.decide(false) }
            -112 -> {
                if (ChatBus.gate == null) { Toast.makeText(this, "Nothing is waiting", Toast.LENGTH_SHORT).show(); return }
                val et = EditText(this).apply { setText(PosterBus.lastCaption); setSelection(text.length); minLines = 3; gravity = Gravity.TOP or Gravity.START }
                android.app.AlertDialog.Builder(this).setTitle("Edit the post text").setView(et)
                    .setPositiveButton("Save") { _, _ ->
                        val nt = et.text.toString().trim()
                        PosterBus.lastCaption = nt
                        try { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("post", nt)) } catch (_: Exception) {}
                        Toast.makeText(this, "Text updated. Now tap Post now", Toast.LENGTH_SHORT).show()
                    }.setNegativeButton("Cancel", null).show()
            }
            -113 -> {
                if (ChatBus.busy) { Toast.makeText(this, "A task is running. Stop it first", Toast.LENGTH_SHORT).show(); return }
                val plug = data.substringBefore("|").ifBlank { null }; val cmd = data.substringAfter("|")
                addUser("↻ " + cmd); lastUser = cmd
                ChatBus.resume = true
                route(cmd, plug, emptyList(), 3)
            }
            -114, -115 -> {
                val nm = data.substringBefore("|"); val body = data.substringAfter("|")
                val cmd = ShortCmd.build(cp().getString("last_app", null) ?: "whatsapp", nm, body)
                if (page == -115) {
                    input.setText(cmd); input.setSelection(cmd.length); input.requestFocus()
                    Toast.makeText(this, "Edit the message and send", Toast.LENGTH_SHORT).show()
                } else {
                    if (ChatBus.busy) { Toast.makeText(this, "A task is running. Stop it first", Toast.LENGTH_SHORT).show(); return }
                    addUser("📤 $nm: " + body.take(80)); lastUser = cmd
                    route(cmd, null, emptyList(), 3)
                }
            }
            -116 -> saveToGallery(data)
            -106 -> doSchedule(data)
            -107 -> { lastUser = data; addUser(data); route(data, null, emptyList(), 1) }
            else -> openSettings(page, data, f[3].toIntOrNull() ?: 0)
        }
    }

    // ---- 3. edit a sent message
    private fun editMsg(m: ChatMsg) {
        var txt = m.text; var pk: String? = null
        for (p in Plugins.ALL) {
            val head = p.icon + " " + p.label
            if (txt == head) { pk = p.key; txt = "" }
            else if (txt.startsWith(head + "\n")) { pk = p.key; txt = txt.removePrefix(head + "\n") }
        }
        txt = txt.removePrefix("🔁 ")
        selPlugin = pk; refreshTray(); refreshAttach()
        input.setText(txt); input.setSelection(txt.length); input.requestFocus()
        Toast.makeText(this, "Edit the message and send it again", Toast.LENGTH_SHORT).show()
    }

    // ---- 5. quick commands
    private val defaultQuick = listOf("torch on karo", "volume badhao", "volume kam karo", "check app", "research karo …")

    private fun quickList(): MutableList<String> {
        val sp = getSharedPreferences("chat", MODE_PRIVATE)
        val s = sp.getString("quick", null) ?: return defaultQuick.toMutableList()
        return try { val a = JSONArray(s); MutableList(a.length()) { a.getString(it) } } catch (_: Exception) { defaultQuick.toMutableList() }
    }

    private fun saveQuick(l: List<String>) {
        val a = JSONArray(); l.forEach { a.put(it) }
        getSharedPreferences("chat", MODE_PRIVATE).edit().putString("quick", a.toString()).apply()
    }

    private fun refreshQuick() {
        quickRow.removeAllViews()
        val l = quickList()
        for (q in l) {
            val fill = q.endsWith("…")
            val chip = TextView(this)
            chip.text = if (fill) q else "⚡ $q"; chip.gravity = Gravity.CENTER
            chip.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }
            Style.chip(this, chip, t, false)
            chip.setOnClickListener {
                Style.buzz(this, "tick")
                if (fill) { val s = q.dropLast(1); input.setText(s); input.setSelection(s.length); input.requestFocus() }
                else if (!ChatBus.busy) { input.setText(q); send() }
            }
            chip.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle("Remove shortcut?").setMessage(q)
                    .setPositiveButton("Remove") { _, _ -> val n = quickList(); n.remove(q); saveQuick(n); refreshQuick() }
                    .setNegativeButton("Cancel", null).show(); true
            }
            quickRow.addView(chip)
        }
        val add = TextView(this)
        add.text = "＋"; add.gravity = Gravity.CENTER
        Style.chip(this, add, t, false)
        add.setOnClickListener {
            val et = EditText(this).apply { hint = "e.g. open whatsapp   (end with … to only fill the box)"; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle("New shortcut").setView(et)
                .setPositiveButton("Add") { _, _ ->
                    val s = et.text.toString().trim()
                    if (s.isNotEmpty()) { val n = quickList(); n.add(s); saveQuick(n); refreshQuick() }
                }.setNegativeButton("Cancel", null).show()
        }
        quickRow.addView(add)
    }

    // ---- 6. status card
    private fun refreshStatus() {
        if (!::statusCard.isInitialized) return
        val now = System.currentTimeMillis()
        val list = try { Scheduler.load(this).filter { it.on } } catch (_: Exception) { emptyList() }
        val next = list.map { it to Scheduler.nextTime(it, now) }.filter { it.second > now }.minByOrNull { it.second }
        val day0 = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val posts = try { PostLog.load(this).filter { it.time >= day0 } } catch (_: Exception) { emptyList() }
        val parts = ArrayList<String>()
        if (next != null) parts.add("📅 Next: " + next.first.cmd.substringAfterLast("|").take(28) + " · " + SimpleDateFormat("EEE h:mm a", Locale.ENGLISH).format(Date(next.second)))
        if (list.size > 1) parts.add("${list.size} scheduled")
        if (posts.isNotEmpty()) parts.add("📤 Today: " + posts.count { it.ok } + " posted" + (if (posts.any { !it.ok }) ", " + posts.count { !it.ok } + " failed" else ""))
        statusCard.text = parts.joinToString("   •   ")
    }

    // ---- 9. voice mode (spoken replies)
    /** hands-free: after the reply is spoken, listen again by itself */
    private fun afterSpeak() {
        if (!voiceOn() || !prefs().getBoolean("chat_hands", false) || handsOff || !visible || ChatBus.busy || isFinishing) return
        window.decorView.postDelayed({ if (visible && !ChatBus.busy && !handsOff) listen() }, 450)
    }

    private fun stopSpeak() { try { tts?.stop() } catch (_: Exception) {} }

    private fun speak(s: String) {
        if (!voiceOn()) return
        val clean = s.replace(Regex("[^\\p{L}\\p{N}\\s.,!?'-]"), " ").replace(Regex("\\s+"), " ").trim().take(400)
        if (clean.isBlank()) { afterSpeak(); return }
        if (tts == null) {
            pendingSpeak = clean
            tts = TextToSpeech(this) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    ttsReady = true
                    try { tts?.language = Locale("hi", "IN") } catch (_: Exception) {}
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { runOnUiThread { afterSpeak() } }
                        @Deprecated("Deprecated in Java") override fun onError(id: String?) { runOnUiThread { afterSpeak() } }
                    })
                    pendingSpeak?.let { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "chat") }; pendingSpeak = null
                }
            }
        } else if (ttsReady) tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "chat")
    }

    private fun stopRun() {
        try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("chat_stop", true)) } catch (_: Exception) { ChatBus.finish(this, false, "Stopped.") }
    }

    // ------------------------------------------------------------------ messages
    private fun addMsg(m: ChatMsg, animate: Boolean) {
        val me = m.role == "u"
        val maxW = (resources.displayMetrics.widthPixels * 0.80f).toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = if (me) Gravity.END else Gravity.START
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
        }
        val bubble = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        val flat = !me && m.imgs.isEmpty()          // AI text sits flat on the screen next to a small robot, like a modern chatbot
        val r = dp(20).toFloat(); val s = dp(5).toFloat()
        bubble.background = if (me) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply {
            cornerRadii = floatArrayOf(r, r, r, r, s, s, r, r)
        } else GradientDrawable().apply {
            cornerRadii = floatArrayOf(r, r, r, r, r, r, s, s)
            setColor(if (t.light) 0xCCFFFFFF.toInt() else 0x1AFFFFFF); setStroke(dp(1), (t.stroke and 0x00FFFFFF) or 0x44000000)
        }
        if (flat) { bubble.background = null; bubble.setPadding(dp(2), dp(4), dp(4), dp(4)) }
        val pics = m.imgs.mapNotNull { picView(it, if (me) 84 else 240, 14) }
        if (pics.isNotEmpty()) {
            val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, if (m.text.isNotBlank()) dp(8) else 0) }
            pics.forEach { pr.addView(it) }
            bubble.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(pr) })
        }
        if (m.text.isNotBlank()) bubble.addView(TextView(this).apply {
            text = m.text; textSize = 15f; setTextColor(if (me) t.btnText else t.text); maxWidth = maxW - dp(28)
            if (!me) setTextIsSelectable(true)
            setLineSpacing(0f, 1.08f)
        })
        if (me) {   // swipe right (or tap) = the message goes back into the text box to send again / edit
            var dx0 = 0f; var dy0 = 0f; var drag = false
            bubble.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY; drag = false; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - dx0; val dy = e.rawY - dy0
                        if (!drag && dx > dp(10) && Math.abs(dx) > Math.abs(dy) * 1.5f) { drag = true; v.parent?.requestDisallowInterceptTouchEvent(true) }
                        if (drag) v.translationX = dx.coerceIn(0f, dp(90).toFloat())
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = e.rawX - dx0
                        val go = (drag && dx > dp(60)) || (!drag && Math.abs(dx) < dp(8) && Math.abs(e.rawY - dy0) < dp(8))
                        v.animate().translationX(0f).setDuration(160).start()
                        if (go) { Style.buzz(this@ChatActivity, "click"); editMsg(m) }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> { v.animate().translationX(0f).setDuration(160).start(); true }
                    else -> false
                }
            }
        }
        row.addView(bubble, LinearLayout.LayoutParams(-2, -2))
        val iconPages = mapOf("-103" to R.drawable.ic_copy, "-104" to R.drawable.ic_docera, "-116" to R.drawable.ic_download)
        val iconRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, dp(4), 0, 0) } }
        for (lk in m.links) {
            val f = lk.split("\t")
            val rid = iconPages[f.getOrNull(1)] ?: continue
            if (f.size < 4) continue
            iconRow.addView(icon(rid, f[0], 38, t.sub) { Style.buzz(this, "tick"); onLink(f, m) })
        }
        if (iconRow.childCount > 0) row.addView(iconRow)
        for (lk in m.links) {
            val f = lk.split("\t")
            if (f.size < 4 || iconPages.containsKey(f[1])) continue
            val chip = TextView(this)
            chip.text = "⚙  " + f[0]; chip.gravity = Gravity.CENTER_VERTICAL; chip.maxWidth = maxW
            Style.chip(this, chip, t, false)
            chip.setTextColor(t.text)
            chip.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, dp(6), 0, 0) }
            chip.setOnClickListener { Style.buzz(this, "tick"); onLink(f, m) }
            row.addView(chip)
        }
        val outer: View = if (me) row else LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
            addView(ImageView(this@ChatActivity).apply { setImageResource(R.drawable.ic_robot_mono); setColorFilter(t.stroke); layoutParams = LinearLayout.LayoutParams(dp(26), dp(26)).apply { setMargins(0, dp(5), dp(8), 0) } })
            row.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(row)
        }
        val at = liveRow?.let { msgBox.indexOfChild(it) } ?: -1
        if (at >= 0) msgBox.addView(outer, at) else msgBox.addView(outer)
        msgCount++
        if (animate) {
            outer.alpha = 0f
            if (me) {   // your message flies in from the right with a little bounce
                outer.translationX = dp(56).toFloat(); outer.scaleX = 0.92f; outer.scaleY = 0.92f
                outer.pivotX = resources.displayMetrics.widthPixels.toFloat()
                outer.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f).setDuration(340).setInterpolator(android.view.animation.OvershootInterpolator(1.2f)).start()
            } else {
                outer.translationY = dp(18).toFloat()
                outer.animate().alpha(1f).translationY(0f).setDuration(300).setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
            }
            scrollDown(true)
        }
        updateEmpty()
    }

    private fun showLive(msg: String) {
        if (liveRow == null) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.START
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
            }
            val bubble = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable().apply {
                    val r = dp(20).toFloat(); val s = dp(5).toFloat()
                    cornerRadii = floatArrayOf(r, r, r, r, r, r, s, s)
                    setColor(if (t.light) 0xCCFFFFFF.toInt() else 0x1AFFFFFF); setStroke(dp(1), t.stroke)
                }
            }
            val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, dp(10), 0) }
            val anims = ArrayList<android.animation.Animator>()
            for (k in 0 until 3) {
                val dv = TextView(this).apply { text = "\u25CF"; textSize = 9f; setTextColor(t.stroke); setPadding(dp(1), 0, dp(1), 0) }
                dots.addView(dv)
                anims.add(ObjectAnimator.ofFloat(dv, "translationY", 0f, -dp(5).toFloat(), 0f).apply { duration = 700; startDelay = k * 150L; repeatCount = ObjectAnimator.INFINITE })
            }
            livePulse = android.animation.AnimatorSet().apply { playTogether(anims); start() }
            bubble.addView(dots)
            val tv = TextView(this).apply { textSize = 14.5f; setTextColor(t.text); maxWidth = (resources.displayMetrics.widthPixels * 0.72f).toInt() }
            bubble.addView(tv)
            row.addView(bubble, LinearLayout.LayoutParams(-2, -2))
            msgBox.addView(row); liveRow = row; liveText = tv
            row.alpha = 0f; row.animate().alpha(1f).setDuration(200).start()
            updateEmpty()
        }
        liveText?.text = msg
        scrollDown(true)
    }

    private fun hideLive() {
        livePulse?.cancel(); livePulse = null
        liveRow?.let { msgBox.removeView(it) }
        liveRow = null; liveText = null
    }

    fun onStatus(m: String) { if (ChatBus.busy) showLive(m) }

    fun onFinish(m: ChatMsg) {
        hideLive()
        addMsg(m, true)
        speak(m.text)
        refreshStatus()
        Style.buzz(this, if (m.ok) "click" else "heavy")
        updateSend()
    }

    fun onExtra(m: ChatMsg) { addMsg(m, true) }

    private fun updateEmpty() { emptyV.visibility = if (msgCount == 0 && liveRow == null) View.VISIBLE else View.GONE }

    private fun scrollDown(smooth: Boolean) {
        scroll.post { if (smooth) scroll.smoothScrollTo(0, msgBox.height) else scroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onResume() {
        super.onResume()
        visible = true
        ChatBus.ui = this
        val overlay = Settings.canDrawOverlays(this)
        val a11y = NotchA11y.inst != null
        banner.visibility = if (!overlay || !a11y) View.VISIBLE else View.GONE
        banner.text = if (!overlay) "⚠ Setup needed: overlay permission is off. Tap here to fix it"
            else "⚠ Setup needed: turn on the Accessibility service (ZOKI) so I can control the phone. Tap here"
        if (ChatBus.busy) showLive(ChatBus.live.ifBlank { "Working…" }) else if (liveRow != null) hideLive()
        updateSend(); refreshStatus(); updateModelChip()
        sh.removeCallbacks(flashLoop)
        val wait = lastFlash + 600_000L - System.currentTimeMillis()
        if (wait <= 0) flashStatus()
        sh.postDelayed(flashLoop, if (wait <= 0) 600_000L else wait)
        if (overlay && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == 0) {
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onPause() { super.onPause(); visible = false; sh.removeCallbacks(flashLoop) }

    override fun onDestroy() {
        if (ChatBus.ui === this) ChatBus.ui = null
        livePulse?.cancel()
        try { tts?.shutdown() } catch (_: Exception) {}
        super.onDestroy()
    }
}
