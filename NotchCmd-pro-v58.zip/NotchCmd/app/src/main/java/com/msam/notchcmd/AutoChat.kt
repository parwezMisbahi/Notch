package com.msam.notchcmd

import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.StatusBarNotification
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors

/**
 * AI auto-reply for chosen WhatsApp chats.
 * Start it from the assistant: plugin chip "Auto reply" (type the contact's name) or say/type "auto reply Ali".
 * From then on every new message from that contact is answered by the AI through the notification's reply box,
 * with no tap from you (works while the phone is locked). It stops by itself after a few hours, or via
 * the "Stop" button of the ongoing notification, or "auto reply stop".
 */
object AutoChat {
    private const val NID = 8999
    private const val DEFAULT_HOURS = 8
    private const val MAX_PER_HOUR = 30           // loop / spam safety per contact

    private fun p(c: Context) = c.getSharedPreferences("autochat", Context.MODE_PRIVATE)
    private val worker = Executors.newSingleThreadExecutor()
    private val rnd = java.util.Random()

    // ------------------------------------------------------------ who is covered
    private fun rawNames(c: Context): List<String> = try {
        val a = JSONArray(p(c).getString("n", "[]") ?: "[]")
        (0 until a.length()).map { a.getString(it) }
    } catch (_: Exception) { emptyList() }

    private fun until(c: Context): Long = p(c).getLong("until", 0L)

    /** names currently covered (empty once the time is over) */
    fun names(c: Context): List<String> {
        val l = rawNames(c)
        if (l.isNotEmpty() && System.currentTimeMillis() > until(c)) { clear(c); return emptyList() }
        return l
    }

    fun active(c: Context): Boolean = names(c).isNotEmpty()

    fun start(c: Context, list: List<String>, hours: Int) {
        val l = ArrayList<String>()
        for (x in list) { val n = x.trim(); if (n.isNotEmpty() && l.none { it.equals(n, true) }) l.add(n) }
        p(c).edit().putString("n", JSONArray(l).toString())
            .putLong("until", System.currentTimeMillis() + hours.coerceIn(1, 48) * 3600_000L).apply()
        showStatus(c)
    }

    fun add(c: Context, name: String, hours: Int) {
        val l = ArrayList(names(c)); l.add(name); start(c, l, hours)
    }

    fun clear(c: Context) {
        p(c).edit().putString("n", "[]").putLong("until", 0L).apply()
        showStatus(c)
    }

    fun persona(c: Context): String = p(c).getString("persona", "") ?: ""
    fun setPersona(c: Context, t: String) { p(c).edit().putString("persona", t.trim()).apply() }

    fun matches(c: Context, sender: String): Boolean {
        val s = sender.lowercase(Locale.ROOT).trim()
        if (s.length < 2) return false
        return names(c).any { n0 ->
            val n = n0.lowercase(Locale.ROOT).trim()
            n == "*" || (n.length >= 2 && (s.contains(n) || n.contains(s)))
        }
    }

    fun summary(c: Context): String {
        val l = names(c)
        if (l.isEmpty()) return "Auto reply is OFF"
        val left = ((until(c) - System.currentTimeMillis()) / 60_000L).coerceAtLeast(1)
        return "Auto reply is ON for: " + l.joinToString(", ").replace("*", "everyone") +
            " (" + (if (left >= 90) "${left / 60} h" else "$left min") + " left)"
    }

    // ------------------------------------------------------------ ongoing notification with Stop
    fun showStatus(c: Context) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (!active(c)) { nm.cancel(NID); return }
            Notify.channel(c)
            val stop = PendingIntent.getBroadcast(c, 410001,
                Intent(c, ReplyReceiver::class.java).putExtra("id", -1).putExtra("act", "autostop"),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val b = Notification.Builder(c, Notify.CH)
                .setSmallIcon(R.drawable.ic_stat_robot)
                .setContentTitle("Auto reply is ON")
                .setContentText(summary(c).substringAfter(": "))
                .setOngoing(true)
                .addAction(Notification.Action.Builder(0, "Stop", stop).build())
            nm.notify(NID, b.build())
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ memory of the chats (RAM only)
    private val hist = HashMap<String, ArrayList<Pair<String, String>>>()
    private val lastSent = HashMap<String, String>()
    private val seen = LinkedHashSet<String>()
    private val stamps = HashMap<String, ArrayList<Long>>()
    private var warnedKey = false

    @Synchronized private fun firstTime(k: String): Boolean {
        if (!seen.add(k)) return false
        while (seen.size > 80) seen.remove(seen.first())
        return true
    }

    @Synchronized private fun allow(sender: String): Boolean {
        val now = System.currentTimeMillis()
        val l = stamps.getOrPut(sender.lowercase(Locale.ROOT)) { ArrayList() }
        l.removeAll { now - it > 3600_000L }
        if (l.size >= MAX_PER_HOUR) return false
        l.add(now); return true
    }

    @Synchronized private fun turns(sender: String): ArrayList<Pair<String, String>> =
        hist.getOrPut(sender.lowercase(Locale.ROOT)) { ArrayList() }

    // ------------------------------------------------------------ what we never answer ourselves
    private val human = listOf("otp", "password", "passcode", "cvv", "pin code", "emergency", "urgent", "hospital", "accident",
        "police", "bank", "loan", "transfer", "send money", "paise", "paisa", "paisay", "udhar", "account number",
        "\u0636\u0631\u0648\u0631\u06CC", "\u091C\u0930\u0942\u0930\u0940", "\u0627\u06CC\u0645\u0631\u062C\u0646\u0633\u06CC")

    private fun needsHuman(t: String): Boolean {
        val low = t.lowercase(Locale.ROOT)
        return human.any { low.contains(it) }
    }

    // ------------------------------------------------------------ the notification hook
    /** true = this message belongs to an auto-reply chat (handled here, the manual helper must not offer it again) */
    fun onMessage(c: Context, sbn: StatusBarNotification, sender: String, text0: String): Boolean {
        if (!active(c) || !matches(c, sender)) return false
        val n = sbn.notification
        val ex = n.extras
        if (n.category != null && n.category != Notification.CATEGORY_MESSAGE) return false
        if (ex.getBoolean("android.isGroupConversation", false)) return false   // groups are never auto-answered

        var text = text0
        var time = 0L
        val last = lastMessage(ex)
        if (last != null) {
            if (last.sender?.equals("You", true) == true) return true   // that is our own message
            text = last.text; time = last.time
        }
        if (text.startsWith("You:")) return true
        if (Regex("^\\d+ new messages?.*", RegexOption.IGNORE_CASE).matches(text.trim())) return true
        if (text == lastSent[sender.lowercase(Locale.ROOT)]) return true            // WhatsApp echoing our own reply
        if (!firstTime(sbn.key + "|" + text + "|" + time)) return true

        var act: Notification.Action? = null
        var ri: RemoteInput? = null
        for (a in n.actions ?: return true) {
            val r = a.remoteInputs
            if (r != null && r.isNotEmpty()) { act = a; ri = r[0]; break }
        }
        if (act == null || ri == null) return true

        if (needsHuman(text)) {
            Notify.show(c, 6300, "Needs you: $sender", text)
            return true
        }
        if (!LlmBrain.onlineReady(c)) {
            if (!warnedKey) {
                warnedKey = true
                Notify.show(c, 6301, "Auto reply needs a free AI key", "Open NotchCmd > Automation > N5 and paste a free Groq or Gemini key.")
            }
            return false
        }
        val a2 = act; val r2 = ri
        worker.execute { job(c, sender, text, a2, r2) }
        return true
    }

    private class Last(val text: String, val time: Long, val sender: String?)

    @Suppress("DEPRECATION")
    private fun lastMessage(ex: Bundle): Last? = try {
        val arr = ex.getParcelableArray("android.messages")
        val b = arr?.lastOrNull() as? Bundle
        val t = b?.getCharSequence("text")?.toString()?.trim()
        if (b == null || t.isNullOrEmpty()) null else Last(t, b.getLong("time", 0L), b.getCharSequence("sender")?.toString())
    } catch (_: Exception) { null }

    private fun job(c: Context, sender: String, msg: String, act: Notification.Action, ri: RemoteInput) {
        try {
            Thread.sleep(3000L + rnd.nextInt(4000))                    // a human does not answer in 0 seconds
            if (!active(c) || !matches(c, sender)) return              // stopped while waiting
            if (!allow(sender)) {
                Notify.show(c, 6302, "Auto reply paused for $sender", "Too many messages in an hour. Reply yourself.")
                return
            }
            val reply = generate(c, sender, msg)
            if (reply == null) {
                Notify.show(c, 6303, "Auto reply failed for $sender", (LlmBrain.lastError.ifBlank { "No answer from the AI" }) + "\n\n" + msg)
                return
            }
            if (!active(c)) return
            if (send(c, act, ri, reply)) {
                lastSent[sender.lowercase(Locale.ROOT)] = reply
                val h = turns(sender)
                synchronized(h) { while (h.size > 12) h.removeAt(0) }
                log(c, sender, msg, reply)
            } else {
                Notify.show(c, 6304, "Could not send the reply to $sender", "The WhatsApp notification is gone. Reply from WhatsApp.\n\n" + msg)
            }
        } catch (_: Exception) {}
    }

    private fun generate(c: Context, sender: String, msg: String): String? {
        val owner = if (UsageGuard.hasName(c)) UsageGuard.userName(c) else "the phone's owner"
        val extra = persona(c)
        val sys = "You are replying on WhatsApp on behalf of $owner, who does not feel like chatting right now. You are talking to $sender.\n" +
            "Write like a relaxed, friendly person texting: 1-2 short sentences, no lists, no emojis unless the other person uses them.\n" +
            "Reply in the same language and script as their last message (Roman Urdu stays Roman Urdu, Hindi stays Hindi, English stays English).\n" +
            "Keep the chat polite and natural, but never promise anything: no meetings, plans, money, favours or deadlines, and never share personal details, addresses, passwords or codes. " +
            "If they need something from $owner personally, say $owner will get back to them soon.\n" +
            "If they sincerely ask whether you are a bot or an AI, do not deny it: say this is an automated reply and $owner will answer personally later.\n" +
            (if (extra.isNotBlank()) "Extra style instructions from $owner: $extra\n" else "") +
            "Output ONLY the message text."
        val h = turns(sender)
        val msgs = ArrayList<Pair<String, String>>()
        synchronized(h) {
            msgs.addAll(h)
            if (msgs.isNotEmpty() && msgs.last().first == "user") { val l = msgs.removeAt(msgs.size - 1); msgs.add("user" to (l.second + "\n" + msg)) }
            else msgs.add("user" to msg)
            h.clear(); h.addAll(msgs)
        }
        var out = LlmBrain.chatText(c, sys, msgs, 200) ?: return null
        out = out.trim().trim('"', '\u201C', '\u201D').trim()
        if (out.startsWith("Reply:", true)) out = out.substring(6).trim()
        if (out.isBlank()) return null
        out = out.take(600)
        synchronized(h) { h.add("assistant" to out) }
        return out
    }

    private fun send(c: Context, act: Notification.Action, ri: RemoteInput, text: String): Boolean = try {
        val i = Intent()
        val b = Bundle()
        b.putCharSequence(ri.resultKey, text)
        RemoteInput.addResultsToIntent(arrayOf(ri), i, b)
        act.actionIntent.send(c, 0, i)
        true
    } catch (_: Exception) { false }

    // ------------------------------------------------------------ what was sent (shown in the settings window)
    private fun log(c: Context, sender: String, inc: String, out: String) {
        try {
            val a = JSONArray(p(c).getString("log", "[]") ?: "[]")
            a.put(JSONObject().put("t", System.currentTimeMillis()).put("s", sender).put("i", inc.take(120)).put("o", out.take(200)))
            val keep = JSONArray()
            for (k in maxOf(0, a.length() - 30) until a.length()) keep.put(a.get(k))
            p(c).edit().putString("log", keep.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun logText(c: Context): String {
        val tf = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH)
        val sb = StringBuilder()
        try {
            val a = JSONArray(p(c).getString("log", "[]") ?: "[]")
            for (k in a.length() - 1 downTo maxOf(0, a.length() - 8)) {
                val o = a.getJSONObject(k)
                sb.append(tf.format(o.optLong("t"))).append("  ").append(o.optString("s")).append("\n  them: ")
                    .append(o.optString("i")).append("\n  AI: ").append(o.optString("o")).append("\n\n")
            }
        } catch (_: Exception) {}
        return if (sb.isEmpty()) "No auto replies sent yet." else sb.toString().trim()
    }

    // ------------------------------------------------------------ typed / spoken command: "auto reply Ali", "auto reply stop"
    private val STOP = setOf("stop", "off", "band", "bandh", "ruk", "ruko", "khatam", "cancel", "disable")
    private val FILL = setOf("auto", "autoreply", "reply", "jawab", "jawaab", "laga", "lagao", "lagado", "laga do", "lagana", "karo", "kar", "kardo", "do", "de",
        "on", "start", "chalu", "for", "ko", "ka", "ki", "ke", "par", "pe", "se", "mein", "me", "with", "to", "please", "plz", "mere", "my", "chat",
        "hours", "hour", "hr", "hrs", "ghanta", "ghante", "ghanty", "tak", "-", "whatsapp")
    private val ALL = setOf("all", "everyone", "everybody", "sab", "sabko", "sabhi", "*")

    fun mentions(raw: String): Boolean {
        val low = raw.lowercase(Locale.ROOT)
        return Regex("auto\\s*-?\\s*(reply|jawab|jawaab)").containsMatchIn(low)
    }

    /** text = what the user typed/said after choosing the chip (or the whole "auto reply ..." phrase) */
    fun command(c: Context, raw: String): String {
        val words = raw.trim().split(Regex("[\\s,]+")).filter { it.isNotBlank() }
        if (words.any { it.lowercase(Locale.ROOT).trim('.', '!', '?') in STOP }) {
            val was = active(c)
            clear(c)
            return if (was) "Auto reply stopped" else "Auto reply was not running"
        }
        var hours = DEFAULT_HOURS
        Regex("(\\d{1,2})\\s*(hours?|hrs?|ghant\\w*)", RegexOption.IGNORE_CASE).find(raw)?.let { hours = it.groupValues[1].toInt().coerceIn(1, 48) }
        val name = words.filter { w ->
            val l = w.lowercase(Locale.ROOT).trim('.', '!', '?')
            l !in FILL && !l.all { it.isDigit() } && !Regex("^\\d+(hours?|hrs?)$").matches(l)
        }.joinToString(" ").trim()
        if (name.isBlank()) return if (active(c)) summary(c) else "Whose chat? Say: auto reply, then the contact's name"
        val who = if (name.lowercase(Locale.ROOT) in ALL) "*" else name
        if (!LlmBrain.onlineReady(c)) {
            add(c, who, hours)
            return "Auto reply is ON for $name, but it needs a free AI key: NotchCmd > Automation > N5"
        }
        add(c, who, hours)
        return "Auto reply is ON for ${if (who == "*") "everyone" else name} for $hours hours. Say: auto reply stop, to end it"
    }

    // ------------------------------------------------------------ settings window (Automation page, button N5)
    fun settingsDialog(a: Activity) {
        val c: Context = a
        val pad = (16 * a.resources.displayMetrics.density).toInt()
        val lay = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        fun label(t: String) = TextView(a).apply { text = t; textSize = 13f; setPadding(0, pad / 2, 0, 0) }
        lay.addView(TextView(a).apply { text = summary(c) + "\n" + LlmBrain.onlineStatus(c); textSize = 14f })
        lay.addView(label("Contacts to auto-reply (comma separated, or * for everyone). Saving restarts the 8 hour timer."))
        val eNames = EditText(a).apply { setText(names(c).joinToString(", ")); hint = "Ali, Ahmed" }
        lay.addView(eNames)
        lay.addView(label("AI provider (free key)"))
        val sp = Spinner(a).apply {
            adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, listOf("Groq (free)", "Gemini (free)"))
            setSelection(if (LlmBrain.provider(c) == "gemini") 1 else 0)
        }
        lay.addView(sp)
        val eKey = EditText(a).apply { hint = if (LlmBrain.apiKey(c).isBlank()) "Paste API key" else "Key saved - leave empty to keep it" }
        lay.addView(eKey)
        lay.addView(label("Style (optional), e.g. \"short replies, call everyone bhai\""))
        val ePersona = EditText(a).apply { setText(persona(c)); minLines = 2 }
        lay.addView(ePersona)
        lay.addView(label("Last replies"))
        lay.addView(TextView(a).apply { text = logText(c); textSize = 12f })
        AlertDialog.Builder(a).setTitle("AI auto-reply").setView(ScrollView(a).apply { addView(lay) })
            .setPositiveButton("Save") { _, _ ->
                val prov = if (sp.selectedItemPosition == 1) "gemini" else "groq"
                val key = eKey.text.toString().trim().ifBlank { LlmBrain.apiKey(c) }
                if (key.isNotBlank()) LlmBrain.setOnline(c, prov, key, "")
                setPersona(c, ePersona.text.toString())
                val l = eNames.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    .map { if (it.lowercase(Locale.ROOT) in ALL) "*" else it }
                if (l.isEmpty()) clear(c) else start(c, l, DEFAULT_HOURS)
            }
            .setNeutralButton("Stop all") { _, _ -> clear(c) }
            .setNegativeButton("Close", null).show()
    }
}
