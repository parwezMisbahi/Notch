package com.msam.notchcmd

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.*

/**
 * The floating robot that the assistant box folds into while a command runs.
 * Everything is drawn here (no images): pulsing rings, a spinning "working" arc, blinking eyes, glowing antenna,
 * a spark burst on landing and a red flash when stopped.
 */
class RobotOrb(ctx: Context, private val accent: Int) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val ink = 0xFF0D0D12.toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var phase = 0f            // 0..1, loops every 2.4 s
    private var burstT = -1f          // 0..1 spark burst, -1 = none
    private var flashT = -1f          // 0..1 red stop flash, -1 = none
    private var popT = 0f             // 0..1 appear
    var working = true
    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    private var burstAnim: ValueAnimator? = null
    private var flashAnim: ValueAnimator? = null

    override fun onAttachedToWindow() { super.onAttachedToWindow(); loop.start() }
    override fun onDetachedFromWindow() { loop.cancel(); burstAnim?.cancel(); flashAnim?.cancel(); super.onDetachedFromWindow() }

    /** little sparkle ring, used when the orb lands */
    fun burst() {
        burstAnim?.cancel()
        burstAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 650; addUpdateListener { burstT = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() { override fun onAnimationEnd(a: android.animation.Animator) { burstT = -1f; invalidate() } })
            start()
        }
    }

    /** red flash + shake: double-tap stop */
    fun flash() {
        flashAnim?.cancel()
        working = false
        flashAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 420; addUpdateListener { flashT = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() { override fun onAnimationEnd(a: android.animation.Animator) { flashT = -1f; invalidate() } })
            start()
        }
        animate().cancel()
        animate().translationX(10 * d).setDuration(50).withEndAction {
            animate().translationX(-10 * d).setDuration(90).withEndAction {
                animate().translationX(6 * d).setDuration(80).withEndAction { animate().translationX(0f).setDuration(70).start() }.start()
            }.start()
        }.start()
    }

    /** springy appear */
    fun pop() {
        scaleX = 0.4f; scaleY = 0.4f; alpha = 0f
        animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(380).setInterpolator(android.view.animation.OvershootInterpolator(2.2f)).start()
    }

    private fun a(c: Int, f: Float): Int = Color.argb((Color.alpha(c) * f.coerceIn(0f, 1f)).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2
        val r = 24 * d                      // badge radius (window is 76dp, badge 48dp)
        val breathe = 1f + 0.045f * sin(phase * 2 * PI).toFloat()

        // soft glow
        for (i in 4 downTo 1) {
            p.style = Paint.Style.FILL; p.color = a(accent, 0.07f * (if (working) 1f else 0.6f))
            c.drawCircle(cx, cy, r * (1f + i * 0.17f) * breathe, p)
        }
        // two pulse rings
        if (working) for (k in 0..1) {
            val t = (phase * 2 + k * 0.5f) % 1f
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d; p.color = a(accent, (1f - t) * 0.75f)
            c.drawCircle(cx, cy, r * (1.02f + t * 0.6f), p)
        }
        // spinning working arc
        if (working) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f * d; p.strokeCap = Paint.Cap.ROUND; p.color = accent
            val rect = RectF(cx - r - 3 * d, cy - r - 3 * d, cx + r + 3 * d, cy + r + 3 * d)
            val ang = phase * 720f
            c.drawArc(rect, ang, 80f, false, p)
            p.color = a(accent, 0.45f); c.drawArc(rect, ang + 180f, 50f, false, p)
        }
        // white badge
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        c.drawCircle(cx, cy, r * breathe, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = a(accent, 0.9f)
        c.drawCircle(cx, cy, r * breathe, p)

        // robot (local units: x -234..234, y -216..215)
        val s = (r * breathe * 1.15f) / 468f * 1.0f
        c.save(); c.translate(cx, cy + 2 * d); c.scale(s, s)
        p.style = Paint.Style.FILL; p.color = ink
        // ears
        val ear = RectF(-233f, 0f, -147f, 112f); c.save(); c.clipRect(-240f, -1f, -190f, 113f); c.drawOval(ear, p); c.restore()
        val ear2 = RectF(147f, 0f, 233f, 112f); c.save(); c.clipRect(191f, -1f, 240f, 113f); c.drawOval(ear2, p); c.restore()
        // antenna: ball glows with the accent while working
        c.drawRect(-14f, -182f, 14f, -108f, p)
        val glow = if (working) (0.5f + 0.5f * sin(phase * 2 * PI * 2).toFloat()) else 0f
        p.color = ink; c.drawCircle(0f, -180f, 36f, p)
        if (glow > 0f) { p.color = a(accent, glow); c.drawCircle(0f, -180f, 22f, p) }
        // head
        p.color = ink; c.drawRoundRect(RectF(-176f, -115f, 177f, 215f), 98f, 98f, p)
        // visor
        p.color = Color.WHITE; c.drawRoundRect(RectF(-128f, -37f, 129f, 96f), 66.5f, 66.5f, p)
        // eyes: blink about every 3 s (phase*0.8 keeps it irregular against the pulse)
        val bt = (phase * 0.8f) % 1f
        val blink = if (bt in 0.90f..0.96f) 0.12f else 1f
        val happy = if (flashT >= 0f) 0.5f else 1f
        p.color = if (flashT in 0f..0.6f) 0xFFE53935.toInt() else ink
        for (ex in floatArrayOf(-61f, 62f)) c.drawOval(RectF(ex - 25f, 29f - 25f * blink * happy, ex + 25f, 29f + 25f * blink * happy), p)
        c.restore()

        // landing sparkles
        if (burstT >= 0f) {
            val n = 10
            for (i in 0 until n) {
                val ang = (i * 360f / n + 14f) * PI.toFloat() / 180f
                val dist = r * (1.15f + burstT * 0.95f)
                val px = cx + cos(ang) * dist; val py = cy + sin(ang) * dist
                p.style = Paint.Style.FILL; p.color = a(if (i % 2 == 0) Color.WHITE else accent, 1f - burstT)
                c.drawCircle(px, py, (3.2f - 2f * burstT) * d, p)
            }
        }
        // stop flash ring
        if (flashT >= 0f) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3.5f * d; p.color = a(0xFFFF4D4D.toInt(), 1f - flashT)
            c.drawCircle(cx, cy, r * (1.05f + flashT * 0.7f), p)
        }
    }
}
