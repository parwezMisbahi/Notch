package com.msam.notchcmd

import android.content.Context
import android.content.Intent

/** Research ke liye kaunsa AI app (ChatGPT, Claude, Gemini...) use ho - Settings mein chuna jata hai. */
object ResearchPrefs {
    class Ai(val key: String, val label: String, val pkg: String, val words: Set<String>)

    val ALL = listOf(
        Ai("chatgpt", "ChatGPT", "com.openai.chatgpt", setOf("chatgpt", "gpt", "chatjpt", "chaatgpt", "chatgipiti", "jipiti", "chaitjipiti", "chatjeepeetee", "chatgp")),
        Ai("claude", "Claude", "com.anthropic.claude", setOf("claude", "clod", "klod", "kloud", "claud")),
        Ai("gemini", "Gemini", "com.google.android.apps.bard", setOf("gemini", "jemini", "jemni", "gemni", "jaimini")),
        Ai("perplexity", "Perplexity", "ai.perplexity.app.android", setOf("perplexity", "perplexi", "perplexty")),
        Ai("grok", "Grok", "ai.x.grok", setOf("grok", "grock")),
        Ai("copilot", "Copilot", "com.microsoft.copilot", setOf("copilot", "kopilot", "co-pilot")),
        Ai("deepseek", "DeepSeek", "com.deepseek.chat", setOf("deepseek", "deepsik", "dipsik"))
    )

    private fun p(c: Context) = c.getSharedPreferences("research", Context.MODE_PRIVATE)

    fun selected(c: Context): Ai = ALL.firstOrNull { it.key == p(c).getString("ai", "chatgpt") } ?: ALL[0]
    fun select(c: Context, key: String) { p(c).edit().putString("ai", key).apply() }

    fun launchIntent(c: Context, ai: Ai): Intent? = try {
        c.packageManager.getLaunchIntentForPackage(ai.pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    } catch (_: Exception) { null }

    fun installed(c: Context, ai: Ai): Boolean = launchIntent(c, ai) != null

    /** Bole hue shabd se AI app: "chatgpt", "claude"... (na mile to null) */
    fun byWord(w: String): Ai? = ALL.firstOrNull { w in it.words }
}
