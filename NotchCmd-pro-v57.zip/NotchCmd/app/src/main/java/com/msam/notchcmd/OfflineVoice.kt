package com.msam.notchcmd

import android.content.Context

/** Ab sirf do tariqe: Gboard mic (bolna) aur keyboard se likhna. Koi offline speech model nahi. */
object OfflineVoice {
    private fun sp(c: Context) = c.getSharedPreferences("offvoice", Context.MODE_PRIVATE)
    /** Gboard mic se bolne ke baad itne ms khamoshi to command apne aap chalegi. Default 4 sec */
    fun gboard(c: Context): Int = sp(c).getInt("gb4", 4000)
    fun nextGboard(c: Context): Int {
        val l = listOf(2000, 3000, 4000, 5000, 8000)
        val n = l[(l.indexOf(gboard(c)) + 1) % l.size]
        sp(c).edit().putInt("gb4", n).apply(); return n
    }
    /** Panel khulte hi Gboard ka mic assistant khud dabaye (default ON) */
    fun gbMic(c: Context): Boolean = sp(c).getBoolean("gbmic", true)
    fun toggleGbMic(c: Context): Boolean { val n = !gbMic(c); sp(c).edit().putBoolean("gbmic", n).apply(); return n }
}
