package com.msam.notchcmd

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** App ke saare styles (theme) + haptic/vibration + launch animation */
object Style {
    val names = listOf("glass", "neon", "aurora", "amoled", "light")
    val labels = mapOf("glass" to "Glass", "neon" to "Neon", "aurora" to "Aurora", "amoled" to "AMOLED", "light" to "Light")

    class T(val bg1: Int, val bg2: Int, val text: Int, val sub: Int, val a1: Int, val a2: Int, val btnText: Int, val stroke: Int, val light: Boolean)

    fun cur(c: Context): String = c.getSharedPreferences("style", Context.MODE_PRIVATE).getString("t", "glass") ?: "glass"
    fun set(c: Context, n: String) { c.getSharedPreferences("style", Context.MODE_PRIVATE).edit().putString("t", n).apply() }
    fun next(c: Context): String { val n = names[(names.indexOf(cur(c)) + 1) % names.size]; set(c, n); return n }

    fun theme(c: Context): T = when (cur(c)) {
        "neon" -> T(0xFF07040F.toInt(), 0xFF1A0833.toInt(), 0xFFE9FFFA.toInt(), 0xFF9FFBEA.toInt(), 0xFF00C9A7.toInt(), 0xFFB0179A.toInt(), Color.WHITE, 0xFF00FFD0.toInt(), false)
        "aurora" -> T(0xFF0B2A36.toInt(), 0xFF2B1259.toInt(), 0xFFF1FFF9.toInt(), 0xFFC9F7E6.toInt(), 0xFF2BB58C.toInt(), 0xFF7A4DE0.toInt(), Color.WHITE, 0xFF7CF4C8.toInt(), false)
        "amoled" -> T(Color.BLACK, 0xFF050505.toInt(), Color.WHITE, 0xFFBDBDBD.toInt(), 0xFF1E1E1E.toInt(), 0xFF2A2A2A.toInt(), Color.WHITE, 0xFF4D8DFF.toInt(), false)
        "light" -> T(0xFFF4F7FF.toInt(), 0xFFDCE6FF.toInt(), 0xFF16213A.toInt(), 0xFF46557A.toInt(), 0xFF6AA0FF.toInt(), 0xFF3B6DFF.toInt(), Color.WHITE, 0xFF3B6DFF.toInt(), true)
        else -> T(0xFF0F1730.toInt(), 0xFF1F2B5E.toInt(), 0xFFEEF4FF.toInt(), 0xFFB9C6E8.toInt(), 0xFF3B6DFF.toInt(), 0xFF6A4DFF.toInt(), Color.WHITE, 0xFF7FB2FF.toInt(), false)
    }

    // ---------- haptic / vibrate ----------
    private fun vib(c: Context): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(VibratorManager::class.java)?.defaultVibrator
        else c.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    } catch (_: Exception) { null }

    /** kind: tick (halka) | click | heavy | launch (3 teji se badhti dhadkan, animation ke shake ke saath) */
    fun buzz(c: Context, kind: String) {
        try {
            val v = vib(c) ?: return
            if (!v.hasVibrator()) return
            val e: VibrationEffect = when (kind) {
                "launch" -> if (v.hasAmplitudeControl())
                    VibrationEffect.createWaveform(longArrayOf(0, 20, 45, 24, 45, 38), intArrayOf(0, 120, 0, 190, 0, 255), -1)
                else VibrationEffect.createWaveform(longArrayOf(0, 20, 45, 24, 45, 38), -1)
                "heavy" -> if (Build.VERSION.SDK_INT >= 29) VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK) else VibrationEffect.createOneShot(35, 255)
                "click" -> if (Build.VERSION.SDK_INT >= 29) VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK) else VibrationEffect.createOneShot(18, 180)
                else -> if (Build.VERSION.SDK_INT >= 29) VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK) else VibrationEffect.createOneShot(9, 120)
            }
            v.vibrate(e)
        } catch (_: Exception) {}
    }

    // ---------- native screens ka style ----------
    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun skin(act: Activity, root: View) {
        val t = theme(act)
        act.window.statusBarColor = t.bg1
        act.window.navigationBarColor = t.bg2
        @Suppress("DEPRECATION")
        act.window.decorView.systemUiVisibility = if (t.light) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
        skinRec(act, root, t)
    }

    fun background(c: Context): GradientDrawable {
        val t = theme(c)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(t.bg1, t.bg2))
    }

    /** rounded translucent card (rows, switches, chip boxes, list items) */
    fun card(c: Context, t: T, radius: Int = 18): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(c, radius).toFloat()
        setColor(if (t.light) 0xCCFFFFFF.toInt() else 0x1AFFFFFF)
        setStroke(dp(c, 1), (t.stroke and 0x00FFFFFF) or 0x44000000)
    }

    /** one option of a chip row: filled with the accent gradient when selected */
    fun chip(c: Context, v: TextView, t: T, on: Boolean) {
        v.textSize = 13f
        v.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        v.setTextColor(if (on) t.btnText else t.text)
        v.background = if (on) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply {
            cornerRadius = dp(c, 20).toFloat(); setStroke(dp(c, 1), t.stroke)
        } else GradientDrawable().apply {
            cornerRadius = dp(c, 20).toFloat()
            setColor(if (t.light) 0x11000000 else 0x14FFFFFF)
            setStroke(dp(c, 1), (t.stroke and 0x00FFFFFF) or 0x33000000)
        }
    }

    fun skinRec(c: Context, v: View, t: T) {
        when (v) {
            is Switch -> {
                val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                v.thumbTintList = ColorStateList(st, intArrayOf(t.stroke, 0xFFCFD4DC.toInt()))
                v.trackTintList = ColorStateList(st, intArrayOf((t.stroke and 0x00FFFFFF) or 0x66000000, 0x55808890))
            }
            is Button -> {
                v.isAllCaps = false; v.textSize = 14f; v.setTextColor(t.btnText)
                v.stateListAnimator = null; v.elevation = 0f
                val primary = v.tag == "primary"
                val horizontal = (v.parent as? LinearLayout)?.orientation == LinearLayout.HORIZONTAL
                if (primary) {
                    val d = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply {
                        cornerRadius = dp(c, 26).toFloat(); setStroke(dp(c, 1), t.stroke)
                    }
                    v.background = RippleDrawable(ColorStateList.valueOf(0x55FFFFFF), d, null)
                    v.gravity = Gravity.CENTER
                } else {
                    v.setTextColor(t.text)
                    v.background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), card(c, t, 16), null)
                    v.gravity = if (horizontal) Gravity.CENTER else (Gravity.START or Gravity.CENTER_VERTICAL)
                }
                v.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12))
                (v.parent as? LinearLayout)?.let { p ->
                    v.layoutParams = if (p.orientation == LinearLayout.VERTICAL)
                        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(c, 5), 0, dp(c, 5)) }
                    else LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(c, 4), dp(c, 4), dp(c, 4), dp(c, 4)) }
                }
                v.setOnTouchListener { vw, ev ->
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> { buzz(c, "tick"); vw.animate().scaleX(.97f).scaleY(.97f).setDuration(90).start() }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> vw.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2f)).start()
                    }
                    false
                }
            }
            is EditText -> { v.setTextColor(t.text); v.setHintTextColor(t.sub) }
            is TextView -> when (v.tag) {
                "chipOn" -> chip(c, v, t, true)
                "chipOff" -> chip(c, v, t, false)
                "sub" -> v.setTextColor(t.sub)
                "title", "back", "sec" -> v.setTextColor(t.stroke)
                else -> v.setTextColor(t.text)
            }
        }
        if (v is LinearLayout && v.tag == "card") v.background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), card(c, t), null)
        if (v is ViewGroup) for (i in 0 until v.childCount) skinRec(c, v.getChildAt(i), t)
    }

    /** launch animation: ek ke baad ek neeche se uchhalkar aate hain + shake */
    fun enter(root: ViewGroup) {
        for (i in 0 until root.childCount) {
            val ch = root.getChildAt(i)
            ch.alpha = 0f; ch.translationY = 70f; ch.scaleX = .94f; ch.scaleY = .94f
            ch.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(minOf(i * 30L, 700L)).setDuration(420).setInterpolator(OvershootInterpolator(1.2f)).start()
        }
        root.translationX = 0f
        root.animate().cancel()
        root.animate().translationX(-9f).setDuration(70).withEndAction {
            root.animate().translationX(9f).setDuration(90).withEndAction {
                root.animate().translationX(-5f).setDuration(80).withEndAction {
                    root.animate().translationX(0f).setDuration(80).start() }.start() }.start() }.start()
    }
}
