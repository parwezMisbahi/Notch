package com.msam.notchcmd

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewAnimationUtils
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The assistant box, 100% native (no WebView): it opens instantly, runs on the GPU and never drops frames.
 * The launch animation starts exactly at the camera hole (display cutout): the robot comes out of the notch,
 * wakes up with a spark burst, the box blooms out of it and the robot settles into the header.
 * Edit field is a plain EditText, so Gboard's mic (voice typing) works in it.
 */
class NativePanel(
    ctx: Context,
    private val bottom: Boolean,
    private val gbMs: Int,
    private val host: Host
) : FrameLayout(ctx) {

    interface Host {
        fun onReady()                       // the robot landed: start voice / run the pending command
        fun onStartTyping()                 // the text box was touched: window must become focusable
        fun onClose()
        fun onRun(text: String)
        fun onSetPlugin(key: String?)
        fun onClearImage()
        fun onPickImage()
        fun onMiniTap()
        fun onMiniDouble()
        fun onFoldDone(cx: Float, cy: Float)    // screen coordinates of the middle of the folded box
    }

    /** the service sets this to move the window above the keyboard (bottom mode) */
    var imeListener: ((WindowInsets) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val t = Style.theme(ctx)
    private val accent = t.stroke
    private fun dp(v: Float) = (v * d).toInt()
    private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)
    private val btnFill = if (t.light) 0x1F3B6DFF else 0x29FFFFFF
    private val inFill = if (t.light) 0x143B6DFF else 0x47000000

    private val MINI_S = 30f / 48f          // badge of the 76dp RobotOrb is 48dp; header robot is 30dp
    private val orbHalf = dp(76f) / 2f

    // ------------------------------------------------------------------ views
    private val card = LinearLayout(ctx)
    private val topRow = LinearLayout(ctx)
    private val miniHolder = FrameLayout(ctx)
    private val miniWrap = FrameLayout(ctx)
    private val mini = RobotOrb(ctx, accent).apply { working = false }
    private val launchOrb = RobotOrb(ctx, accent).apply { working = false }
    private val wave = LinearLayout(ctx)
    private val bars = ArrayList<View>()
    private val status = TextView(ctx)
    private val closeBtn = TextView(ctx)
    private val box = LinearLayout(ctx)
    private val input = android.widget.EditText(ctx)
    private val addBtn = ImageButton(ctx)
    private val plgBtn = ImageButton(ctx)
    private val chips = LinearLayout(ctx)
    private val goBtn = TextView(ctx)
    private val menuScroll = HorizontalScrollView(ctx)
    private val menu = LinearLayout(ctx)
    private val chScroll = HorizontalScrollView(ctx)
    private val chRow = LinearLayout(ctx)

    // ------------------------------------------------------------------ state
    private var sel: String? = null
    private val imgs = ArrayList<String>()
    private var PL = JSONArray()
    private var state = "init"
    private var launched = false
    private var pendingCollapse = false
    private var camX = -1f
    private var camY = -1f
    private var muting = false
    private var typed = false
    private var voiceLatch = false
    private var lastLen = 0
    private var lastAt = 0L
    private var mTimer: Runnable? = null
    private val anims = ArrayList<Animator>()
    private var waveAnim: ValueAnimator? = null
    private val msgTyping = if (gbMs > 0) "Speak (Gboard mic): stay silent ${gbMs / 1000} sec to run.\nTyping: press ▶" else "Type and press ▶"
    private val msgIdle = if (gbMs > 0) msgTyping else "Speak or type. Chain tasks with \"and\"."
    private val hintDefault = if (gbMs > 0) "Speak with Gboard or type" else "Speak, or tap here to type"
    private val gbRun = Runnable { doRun(); afterRun() }

    init {
        clipChildren = false; clipToPadding = false
        try { PL = JSONArray(Plugins.menuJson()) } catch (_: Exception) {}

        // card: translucent gradient + 1.5dp border. No blur / shadow / infinite glow: those were the frame-drop killers.
        val a = when { t.light -> 0xF2; Style.cur(ctx) == "amoled" -> 0xF7; else -> 0xEB }
        card.orientation = LinearLayout.VERTICAL
        card.clipChildren = false
        card.setPadding(dp(14f), dp(14f), dp(14f), dp(14f))
        card.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(alpha(t.bg1, a), alpha(t.bg2, a))).apply {
            cornerRadius = dp(28f).toFloat(); setStroke(dp(1.5f), alpha(accent, 0x8C))
        }
        card.visibility = View.INVISIBLE
        addView(card, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (bottom) Gravity.BOTTOM else Gravity.TOP
            leftMargin = dp(10f); rightMargin = dp(10f)
            if (bottom) bottomMargin = dp(26f) else topMargin = dp(30f)
        })

        // ---- header: robot, wave, status, close
        topRow.orientation = LinearLayout.HORIZONTAL; topRow.gravity = Gravity.CENTER_VERTICAL; topRow.clipChildren = false
        card.addView(topRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(11f) })

        miniHolder.clipChildren = false
        miniWrap.clipChildren = false
        miniWrap.scaleX = MINI_S; miniWrap.scaleY = MINI_S
        miniWrap.addView(mini, FrameLayout.LayoutParams(dp(76f), dp(76f)))
        miniHolder.addView(miniWrap, FrameLayout.LayoutParams(dp(76f), dp(76f), Gravity.CENTER))
        miniHolder.visibility = View.INVISIBLE
        miniHolder.contentDescription = "Assistant robot: tap to fold, double-tap to stop"
        miniHolder.setOnClickListener {
            val pend = mTimer
            if (pend != null) {
                removeCallbacks(pend); mTimer = null
                Style.buzz(context, "heavy"); wiggle(); host.onMiniDouble()
            } else {
                val r = Runnable { mTimer = null; wiggle(); host.onMiniTap() }
                mTimer = r; postDelayed(r, 290)
            }
        }
        topRow.addView(miniHolder, LinearLayout.LayoutParams(dp(34f), dp(34f)))

        wave.orientation = LinearLayout.HORIZONTAL; wave.gravity = Gravity.CENTER_VERTICAL; wave.visibility = View.GONE
        for (i in 0 until 4) {
            val b = View(ctx)
            b.background = GradientDrawable().apply { cornerRadius = dp(2f).toFloat(); setColor(accent) }
            b.scaleY = 0.33f
            bars.add(b)
            wave.addView(b, LinearLayout.LayoutParams(dp(3f), dp(18f)).apply { if (i > 0) leftMargin = dp(3f) })
        }
        topRow.addView(wave, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(18f)).apply { leftMargin = dp(9f) })

        status.setTextColor(t.sub); status.textSize = 13f; status.setLineSpacing(0f, 1.1f)
        topRow.addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(9f); rightMargin = dp(8f) })

        closeBtn.text = "✕"; closeBtn.textSize = 13f; closeBtn.gravity = Gravity.CENTER; closeBtn.setTextColor(t.text)
        closeBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(btnFill); setStroke(dp(1.5f), alpha(accent, 0x8C)) }
        closeBtn.contentDescription = "Close"
        closeBtn.setOnClickListener { Style.buzz(context, "click"); host.onClose() }
        topRow.addView(closeBtn, LinearLayout.LayoutParams(dp(30f), dp(30f)))

        // ---- input box + run button
        val row = LinearLayout(ctx); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
        card.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
        box.minimumHeight = dp(98f)
        box.background = boxBg(false)
        row.addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        input.background = null
        input.setPadding(0, 0, 0, 0)
        input.setTextColor(t.text); input.setHintTextColor(alpha(t.sub, 0xB3)); input.textSize = 16f
        input.hint = hintDefault
        input.gravity = Gravity.TOP or Gravity.START
        input.setHorizontallyScrolling(false)
        input.maxLines = 2; input.minLines = 2
        // plain text field: no "no-suggestions" flags, otherwise Gboard says "Voice input isn't supported here"
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.imeOptions = EditorInfo.IME_ACTION_GO or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        input.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        input.setOnFocusChangeListener { _, f -> box.background = boxBg(f) }
        input.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) { voiceLatch = false; host.onStartTyping() }
            false
        }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO || id == EditorInfo.IME_ACTION_SEND || id == EditorInfo.IME_ACTION_DONE) { doRun(); true } else false
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) { if (!muting && e != null) onEdited(e) }
        })
        box.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44f)))

        val tools = LinearLayout(ctx); tools.orientation = LinearLayout.HORIZONTAL; tools.gravity = Gravity.CENTER_VERTICAL
        box.addView(tools, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32f)).apply { topMargin = dp(6f) })
        styleTool(addBtn, R.drawable.ic_photo, "Add photo")
        addBtn.setOnClickListener { Style.buzz(context, "click"); input.clearFocus(); host.onPickImage() }
        styleTool(plgBtn, R.drawable.ic_plug, "Plugins")
        plgBtn.setOnClickListener {
            Style.buzz(context, "click"); input.clearFocus(); renderMenu()
            menuScroll.visibility = if (menuScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        tools.addView(addBtn, LinearLayout.LayoutParams(dp(30f), dp(30f)))
        tools.addView(plgBtn, LinearLayout.LayoutParams(dp(30f), dp(30f)).apply { leftMargin = dp(6f) })
        val cs = HorizontalScrollView(ctx); cs.isHorizontalScrollBarEnabled = false
        chips.orientation = LinearLayout.HORIZONTAL; chips.gravity = Gravity.CENTER_VERTICAL
        cs.addView(chips, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        tools.addView(cs, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(6f) })

        goBtn.text = "▶"; goBtn.textSize = 18f; goBtn.gravity = Gravity.CENTER; goBtn.setTextColor(t.btnText)
        goBtn.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(t.a1, t.a2)).apply {
            shape = GradientDrawable.OVAL; setStroke(dp(1.5f), alpha(accent, 0x8C))
        }
        goBtn.contentDescription = "Run"
        goBtn.setOnClickListener { voiceLatch = false; doRun() }
        row.addView(goBtn, LinearLayout.LayoutParams(dp(48f), dp(48f)).apply { leftMargin = dp(9f) })

        // ---- plugin menu + channel row
        menuScroll.isHorizontalScrollBarEnabled = false; menuScroll.visibility = View.GONE
        menu.orientation = LinearLayout.HORIZONTAL
        menuScroll.addView(menu, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        card.addView(menuScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(9f) })
        chScroll.isHorizontalScrollBarEnabled = false; chScroll.visibility = View.GONE
        chRow.orientation = LinearLayout.HORIZONTAL; chRow.gravity = Gravity.CENTER_VERTICAL
        chScroll.addView(chRow, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        card.addView(chScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(9f) })

        // ---- the flying robot (used for launch, fold and unfold); lives in the same window, no extra window cost
        launchOrb.alpha = 0f; launchOrb.visibility = View.INVISIBLE
        addView(launchOrb, LayoutParams(dp(76f), dp(76f)))

        renderChips(); setState("idle")

        // camera hole position for the launch + keyboard (ime) forwarding
        setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 28) {
                val c = ins.displayCutout
                if (c != null) for (r in c.boundingRects) {
                    if (r.top <= 2 && r.width() > 0 && !bottom) {
                        camX = r.exactCenterX(); camY = r.exactCenterY()
                        if (!launched) (card.layoutParams as LayoutParams).topMargin = max(dp(30f), r.bottom + dp(10f))
                    }
                }
            }
            imeListener?.invoke(ins)
            ins
        }
    }

    private fun boxBg(focused: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(24f).toFloat(); setColor(inFill)
        setStroke(dp(1.5f), if (focused) accent else alpha(accent, 0x80))
    }

    private fun styleTool(b: ImageButton, res: Int, desc: String) {
        b.setImageResource(res); b.background = null; b.scaleType = ImageView.ScaleType.CENTER_INSIDE
        b.setPadding(dp(6f), dp(6f), dp(6f), dp(6f)); b.contentDescription = desc
        b.setColorFilter(t.text)
    }

    // ------------------------------------------------------------------ public api (what the html page used to offer)
    fun setState(s: String, msg: String? = null) {
        mini.working = (s == "busy")
        setWave(s == "listening" || s == "busy")
        status.text = msg ?: when (s) { "listening" -> "Listening…"; "typing" -> msgTyping; "busy" -> "Working…"; else -> msgIdle }
    }

    fun setMic(on: Boolean) = setWave(on)

    fun gotText(s: String) {
        muting = true; input.setText(s); input.setSelection(s.length); muting = false
        lastLen = s.length; lastAt = System.currentTimeMillis()
    }

    fun voiceOn() { typed = false; voiceLatch = true }

    fun gotImage(path: String) { if (imgs.size < 6) imgs.add(path); renderChips() }

    fun clearAttach() {
        sel = null; imgs.clear(); menuScroll.visibility = View.GONE
        renderMenu(); renderChips()
    }

    fun focusInput() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        fun go() {
            input.requestFocus()
            try { imm?.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) } catch (_: Exception) {}
        }
        go()
        postDelayed({ if (!input.hasWindowFocus() || !input.isFocused) go() }, 160)
        postDelayed({ if (!input.hasWindowFocus() || !input.isFocused) go() }, 420)
    }

    fun release() {
        cancelAnims(); removeCallbacks(gbRun); mTimer?.let { removeCallbacks(it) }; mTimer = null
        waveAnim?.cancel(); waveAnim = null
    }

    override fun onDetachedFromWindow() { cancelAnims(); waveAnim?.cancel(); super.onDetachedFromWindow() }

    // ------------------------------------------------------------------ input behaviour
    private fun doRun() {
        val v = input.text.toString().trim()
        if (v.isNotEmpty() || imgs.isNotEmpty() || sel != null) {
            Style.buzz(context, "click"); input.clearFocus(); host.onRun(v)
        }
    }

    private fun afterRun() {
        removeCallbacks(gbRun)
        postDelayed({ muting = true; input.setText(""); muting = false; lastLen = 0; typed = false }, 400)
    }

    /** same rules the web page had: one char at a time / delete = typing (waits for ▶); several chars at once = Gboard mic (runs after silence) */
    private fun onEdited(e: Editable) {
        var s = e.toString()
        if (s.indexOf('\n') >= 0) {
            s = s.replace(Regex("\\s*\\n+\\s*"), " ").trim()
            muting = true; e.replace(0, e.length, s); muting = false
            doRun(); return
        }
        val dl = s.length - lastLen; val now = System.currentTimeMillis(); val gap = now - lastAt
        lastLen = s.length; lastAt = now
        removeCallbacks(gbRun)
        if (s.isBlank()) { typed = false; return }
        if (voiceLatch) typed = false
        else if (dl < 0 || dl == 1) typed = true
        else if (dl >= 2 && (!typed || gap > 1500)) typed = false
        if (gbMs > 0 && !typed) postDelayed(gbRun, gbMs.toLong())
    }

    // ------------------------------------------------------------------ chips / plugin menu / channels
    private fun plug(k: String): org.json.JSONObject? {
        for (i in 0 until PL.length()) { val o = PL.optJSONObject(i); if (o != null && o.optString("key") == k) return o }
        return null
    }

    private fun renderChips() {
        chips.removeAllViews()
        val k = sel
        if (k != null) {
            val p = plug(k)
            val label = if (p != null) p.optString("icon") + " " + p.optString("label") else "🧩 $k"
            chips.addView(chip(label, null) { Style.buzz(context, "tick"); pickPlugin(null) })
        }
        if (imgs.isNotEmpty()) {
            val label = if (imgs.size > 1) "${imgs.size}/6 photos" else "Photo"
            chips.addView(chip(label, thumb(imgs[0])) { Style.buzz(context, "tick"); imgs.clear(); host.onClearImage(); renderChips() })
        }
        addBtn.setColorFilter(if (imgs.isNotEmpty()) accent else t.text)
        plgBtn.setColorFilter(if (k != null) accent else t.text)
        val p = if (k != null) plug(k) else null
        input.hint = when {
            p != null -> p.optString("icon") + " " + p.optString("label") + ": " + p.optString("hint")
            imgs.isNotEmpty() -> "What should I do with the photo(s)? (or just press ▶)"
            else -> hintDefault
        }
        renderCh()
    }

    private fun chip(text: String, th: Bitmap?, click: () -> Unit): View {
        val c = LinearLayout(context); c.orientation = LinearLayout.HORIZONTAL; c.gravity = Gravity.CENTER_VERTICAL
        c.setPadding(dp(10f), 0, dp(6f), 0)
        c.background = GradientDrawable().apply { cornerRadius = dp(14f).toFloat(); setColor(btnFill); setStroke(dp(1.5f), accent) }
        if (th != null) {
            val iv = ImageView(context); iv.setImageBitmap(th); iv.scaleType = ImageView.ScaleType.CENTER_CROP
            c.addView(iv, LinearLayout.LayoutParams(dp(20f), dp(20f)).apply { rightMargin = dp(6f) })
        }
        val tv = TextView(context); tv.text = text; tv.textSize = 13f; tv.setTextColor(t.text); tv.maxLines = 1; tv.ellipsize = TextUtils.TruncateAt.END
        c.addView(tv)
        val x = TextView(context); x.text = "✕"; x.textSize = 11f; x.gravity = Gravity.CENTER; x.setTextColor(t.text)
        x.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(inFill) }
        c.addView(x, LinearLayout.LayoutParams(dp(20f), dp(20f)).apply { leftMargin = dp(6f) })
        c.setOnClickListener { click() }
        c.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28f)).apply { rightMargin = dp(7f) }
        return c
    }

    private fun thumb(path: String): Bitmap? = try {
        val o = BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeFile(path, o)
        var ss = 1; val want = dp(40f)
        while (o.outWidth / (ss * 2) >= want && o.outHeight / (ss * 2) >= want) ss *= 2
        val o2 = BitmapFactory.Options(); o2.inSampleSize = ss
        BitmapFactory.decodeFile(path, o2)
    } catch (_: Exception) { null }

    private fun pickPlugin(k: String?) {
        sel = k; host.onSetPlugin(k); menuScroll.visibility = View.GONE
        renderMenu(); renderChips()
    }

    private fun pill(text: String, on: Boolean, click: () -> Unit): View {
        val b = TextView(context); b.text = text; b.textSize = 13f; b.setTextColor(t.text); b.gravity = Gravity.CENTER
        b.setPadding(dp(14f), 0, dp(14f), 0)
        b.background = GradientDrawable().apply {
            cornerRadius = dp(19f).toFloat(); setColor(btnFill)
            setStroke(if (on) dp(2f) else dp(1.5f), if (on) accent else alpha(accent, 0x66))
        }
        b.setOnClickListener { click() }
        b.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38f)).apply { rightMargin = dp(8f) }
        return b
    }

    private fun renderMenu() {
        menu.removeAllViews()
        for (i in 0 until PL.length()) {
            val p = PL.optJSONObject(i) ?: continue
            val k = p.optString("key")
            menu.addView(pill(p.optString("icon") + " " + p.optString("label"), k == sel) {
                Style.buzz(context, "click"); pickPlugin(if (k == sel) null else k)
            })
        }
    }

    /** channel names: shown when Channel post / Post everywhere is picked; tap = on/off, "All" = every channel */
    private fun renderCh() {
        chRow.removeAllViews()
        val k = sel
        if (k != "channel" && k != "everywhere") { chScroll.visibility = View.GONE; return }
        val all: List<String> = try { ChannelPrefs.allChannels(context) } catch (_: Exception) { emptyList() }
        val on: List<String> = try { ChannelPrefs.selected(context) } catch (_: Exception) { emptyList() }
        if (all.isEmpty()) { chScroll.visibility = View.GONE; return }
        if (all.size > 1) chRow.addView(pill("All", on.size == all.size) {
            Style.buzz(context, "click"); try { ChannelPrefs.setSelected(context, ArrayList(all)) } catch (_: Exception) {}; renderCh()
        })
        all.forEachIndexed { i, n ->
            chRow.addView(pill("📣 " + n + (if (i == 0) " (main)" else ""), on.contains(n)) {
                Style.buzz(context, "click")
                val s = ArrayList(on)
                if (s.contains(n)) s.remove(n) else s.add(n)
                if (s.isEmpty()) s.add(all[0])
                try { ChannelPrefs.setSelected(context, s) } catch (_: Exception) {}
                renderCh()
            })
        }
        if (all.size == 1) {
            val h = TextView(context); h.text = "more channels: Settings C7"; h.textSize = 12f; h.setTextColor(t.sub); h.alpha = .7f
            chRow.addView(h)
        }
        chScroll.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------------ animation helpers
    private fun cancelAnims() { val l = ArrayList(anims); anims.clear(); for (a in l) try { a.cancel() } catch (_: Exception) {} }

    private fun run01(dur: Long, ip: TimeInterpolator, upd: (Float) -> Unit, end: (Boolean) -> Unit): ValueAnimator {
        val v = ValueAnimator.ofFloat(0f, 1f)
        v.duration = dur; v.interpolator = ip
        var cancelled = false
        v.addUpdateListener { upd(it.animatedValue as Float) }
        v.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(a: Animator) { cancelled = true }
            override fun onAnimationEnd(a: Animator) { anims.remove(a); end(cancelled) }
        })
        anims.add(v); v.start()
        return v
    }

    private fun setWave(on: Boolean) {
        wave.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            if (waveAnim == null) {
                waveAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = android.view.animation.LinearInterpolator()
                    addUpdateListener {
                        val p = it.animatedValue as Float
                        for (i in bars.indices) bars[i].scaleY = 0.33f + 0.67f * (0.5f + 0.5f * sin(2.0 * Math.PI * (p - i * 0.17f)).toFloat())
                    }
                    start()
                }
            }
        } else { waveAnim?.cancel(); waveAnim = null }
    }

    private fun wiggle() {
        miniHolder.animate().cancel()
        miniHolder.rotation = 0f
        miniHolder.animate().rotation(-14f).scaleX(1.2f).scaleY(1.2f).setDuration(110).withEndAction {
            miniHolder.animate().rotation(10f).setDuration(120).withEndAction {
                miniHolder.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(140).start()
            }.start()
        }.start()
    }

    private fun placeOrb(x: Float, y: Float, s: Float, a: Float) {
        launchOrb.visibility = View.VISIBLE
        launchOrb.translationX = x - orbHalf; launchOrb.translationY = y - orbHalf
        launchOrb.scaleX = s; launchOrb.scaleY = s; launchOrb.alpha = a
    }

    private fun cardCx() = card.left + card.width / 2f
    private fun cardCy() = card.top + card.height / 2f

    private fun miniCenter(): FloatArray {
        val a = IntArray(2); val b = IntArray(2)
        miniHolder.getLocationInWindow(a); getLocationInWindow(b)
        return floatArrayOf(a[0] - b[0] + miniHolder.width / 2f, a[1] - b[1] + miniHolder.height / 2f)
    }

    private fun kids(): List<View> = listOf(topRow, box, goBtn)

    // ------------------------------------------------------------------ launch: robot out of the camera hole -> wakes up -> box blooms -> robot settles in the header
    override fun onLayout(changed: Boolean, l: Int, tp: Int, r: Int, b: Int) {
        super.onLayout(changed, l, tp, r, b)
        if (!launched && width > 0 && card.height > 0) { launched = true; post { launch() } }
    }

    private fun launch() {
        if (!isAttachedToWindow) return
        state = "launching"
        val cx = cardCx(); val cy = cardCy()
        val sx = if (bottom) cx else (if (camX >= 0f) camX else width / 2f)
        val sy = if (bottom) height + dp(40f).toFloat() else (if (camY >= 0f) camY else dp(6f).toFloat())
        val ip = OvershootInterpolator(0.9f)
        placeOrb(sx, sy, 0.25f, 0f)
        run01(560, ip, { p ->
            placeOrb(sx + (cx - sx) * p, sy + (cy - sy) * p, 0.25f + 0.75f * p, min(1f, p * 6f))
        }) { cancelled ->
            if (!cancelled && state == "launching") {
                launchOrb.burst(); Style.buzz(context, "tick")
                state = "unfolding"
                host.onReady()
                bloom()
            }
        }
    }

    /** the box grows out of the middle (GPU circular reveal), the contents fade in one by one, the robot flies into the header */
    private fun bloom() {
        card.alpha = 1f; card.scaleX = 1f; card.scaleY = 1f; card.visibility = View.VISIBLE
        val endR = hypot(card.width.toFloat(), card.height.toFloat())
        try {
            val rv = ViewAnimationUtils.createCircularReveal(card, card.width / 2, card.height / 2, dp(24f).toFloat(), endR)
            rv.setDuration(420); rv.setInterpolator(DecelerateInterpolator(1.4f))
            anims.add(rv); rv.start()
        } catch (_: Exception) {}
        kids().forEachIndexed { i, k ->
            k.animate().cancel()
            k.alpha = 0f; k.translationY = dp(10f).toFloat()
            k.animate().alpha(1f).translationY(0f).setStartDelay(120L + i * 50L).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        }
        postDelayed({ if (state == "unfolding") flyToMini() }, 240)
    }

    private fun flyToMini() {
        val m = miniCenter()
        val fx = launchOrb.translationX + orbHalf; val fy = launchOrb.translationY + orbHalf
        val fs = launchOrb.scaleX
        run01(360, DecelerateInterpolator(1.3f), { p ->
            val arc = sin(Math.PI * p).toFloat() * dp(18f)
            placeOrb(fx + (m[0] - fx) * p, fy + (m[1] - fy) * p - arc, fs + (MINI_S - fs) * p, 1f)
        }) { cancelled ->
            if (!cancelled) {
                launchOrb.visibility = View.INVISIBLE; launchOrb.alpha = 0f
                miniHolder.visibility = View.VISIBLE; mini.pop()
                state = "open"
                if (pendingCollapse) { pendingCollapse = false; collapse() }
            }
        }
    }

    // ------------------------------------------------------------------ fold into the robot while a command runs / unfold when it is done
    fun collapse() {
        if (state == "launching" || state == "unfolding") { pendingCollapse = true; return }
        if (state != "open") return
        state = "folding"
        val m = miniCenter(); val cx = cardCx(); val cy = cardCy()
        miniHolder.visibility = View.INVISIBLE
        placeOrb(m[0], m[1], MINI_S, 1f)
        card.pivotX = card.width / 2f; card.pivotY = card.height / 2f
        val ks = kids()
        run01(460, AccelerateDecelerateInterpolator(), { p ->
            val kp = min(1f, p * 2.2f)
            for (k in ks) k.alpha = 1f - kp
            val cp = ((p - 0.15f) / 0.85f).coerceIn(0f, 1f)
            val s = 1f - 0.45f * cp
            card.scaleX = s; card.scaleY = s; card.alpha = 1f - cp
            val arc = sin(Math.PI * p).toFloat() * dp(24f)
            placeOrb(m[0] + (cx - m[0]) * p, m[1] + (cy - m[1]) * p - arc, MINI_S + (1f - MINI_S) * p, 1f)
        }) { cancelled ->
            if (!cancelled && state == "folding") {
                card.visibility = View.INVISIBLE
                state = "mini"
                val loc = IntArray(2); getLocationOnScreen(loc)
                host.onFoldDone(loc[0] + cx, loc[1] + cy)
            }
        }
    }

    fun expand() {
        pendingCollapse = false
        if (state != "mini" && state != "folding") return
        cancelAnims()
        state = "unfolding"
        miniHolder.visibility = View.INVISIBLE
        placeOrb(cardCx(), cardCy(), 1f, 1f)
        launchOrb.burst(); Style.buzz(context, "click")
        bloom()
    }
}
