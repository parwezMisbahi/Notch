# WebView ka JS bridge (command.html -> Android.xxx): in methods ke naam badalne ya hataye na jayen
-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.msam.notchcmd.OverlayService$Bridge { *; }
