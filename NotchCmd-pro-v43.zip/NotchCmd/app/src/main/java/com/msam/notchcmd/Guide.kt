package com.msam.notchcmd

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.OutputStream

/**
 * NotchCmd user guide: one button makes a PDF (Downloads/NotchCmd-Guide.pdf) with setup,
 * every command, settings, and problem fixes, in a clear order. No outside library needed.
 */
object Guide {
    private class Sec(val title: String, val lines: List<String>)

    // "# " = sub heading, "- " = bullet, "$ " = command example (monospace), anything else = paragraph
    private val SECTIONS: List<Sec> = listOf(
        Sec("1. What is NotchCmd", listOf(
            "NotchCmd is a voice and text assistant that controls your phone and other apps (WhatsApp, YouTube, Facebook, Docera, your AI app) through the Accessibility service.",
            "# Three ways to open the command box",
            "- Double-tap the notch (the small button at the top of the screen).",
            "- Say the wake word \"MJ\" (works while the screen is on and MJ voice wake is ON).",
            "- Shake the phone (if \"Shake to open the assistant\" is ON), or hold the power button if NotchCmd is the default assistant.",
            "# Voice or typing",
            "- The mic starts by itself. Tap the input box to switch to typing.",
            "- While one command runs, keep talking: new commands wait in a queue and run one after another.",
            "- Typed commands keep the mic off until they finish.",
            "- Say \"MJ close\" (or just: close / stop / band) to stop everything and close the box."
        )),
        Sec("2. First-time setup (do in this order)", listOf(
            "Open the app, go to Setup and control, and finish the buttons from top to bottom. A tick means done, a cross means pending.",
            "- 1. Overlay permission: allow \"Display over other apps\" (needed for the notch button and box).",
            "- 2. Mic, contacts, call, notification permission: press Allow on every popup.",
            "- 2b. Brightness permission (Modify system settings): needed for brightness commands.",
            "- 3. Turn on Accessibility (NotchCmd): Settings > Accessibility > NotchCmd > ON. This is what taps and types inside other apps.",
            "- 3b. Power button: choose NotchCmd as the Default digital assistant (optional).",
            "- 4. Start (notch button on): starts the assistant service.",
            "- Check: full app diagnostics: tells you exactly what is missing and how to fix it.",
            "- Schedule page: S1 Alarms and reminders permission, S2 Battery set to Unrestricted (needed so timed commands run on time).",
            "- Usage access (U1) is needed only for screen-time and app limits.",
            "Tip: after installing a new build, turn Accessibility OFF and ON once."
        )),
        Sec("3. Open apps and basic actions", listOf(
            "Commands work in English, Roman Hindi/Urdu (Hinglish) and Hindi script. Join several with: aur, phir, then, and, or a comma.",
            "$ youtube kholo",
            "$ whatsapp open karo aur ammi ko message bhejo hi",
            "$ chrome kholo, search karo cricket score",
            "# Navigation",
            "$ back / wapas / peeche",
            "$ home",
            "$ recents",
            "$ notification",
            "$ quick panel",
            "$ screenshot",
            "$ lock",
            "$ swipe left / right / up / down",
            "$ double tap",
            "# Scrolling",
            "$ scroll down / scroll up",
            "$ scroll down karte raho (keeps scrolling by itself)",
            "$ ruko (stops auto scroll)",
            "# Tap, type, search",
            "$ tap play video",
            "$ first video par click karo",
            "$ type hello how are you",
            "$ search arijit singh (searches inside whichever app is open)"
        )),
        Sec("4. Calls, messages and contacts", listOf(
            "$ ali ko call karo",
            "$ call ammi",
            "$ phone uthao / call receive karo (answer)",
            "$ call kaato / call reject karo (end or decline)",
            "$ speaker on karo",
            "$ whatsapp kholo, ahmed search karo aur message karo hi",
            "$ hi bhejo (sends in the open chat)",
            "$ ali contact kholo (opens the contact)",
            "- A call needs the Call permission (button 2). Names are matched with your phone contacts, so keep names spelled the same way.",
            "- Scheduled WhatsApp message: Schedule page > + Scheduled WhatsApp message."
        )),
        Sec("5. Phone controls", listOf(
            "# Volume and brightness",
            "$ volume badhao / volume ghatao / volume max / mute",
            "$ brightness badhao / kam karo / max / min",
            "# Torch and quick tiles",
            "$ torch on karo / torch off karo",
            "$ wifi on / wifi band karo",
            "$ bluetooth on / off",
            "$ airplane mode on",
            "$ hotspot on",
            "$ dnd on",
            "$ rotate on / off",
            "$ mobile data on / off",
            "# Photos and music",
            "$ photo kheencho / selfie lo",
            "$ gaana pause karo / next gaana / pichla gaana / play",
            "# Information",
            "$ battery kitni hai",
            "$ date kya hai",
            "$ time kya hai",
            "# Timer, alarm, reminder",
            "$ 5 minute ka timer lagao",
            "$ alarm 7 baje subah",
            "$ alarm cancel karo (shows your alarms)",
            "$ doodh lene ka reminder 6 baje",
            "$ bolo <text> (the assistant speaks the text)"
        )),
        Sec("6. Docera commands", listOf(
            "NotchCmd can fully control the Docera app. Say the word \"docera\" in the command.",
            "# Notes",
            "$ docera note likho doodh, ande, bread (new note)",
            "$ shopping note mein likho paneer (adds text to the note named shopping)",
            "$ docera note kholo (opens notes)",
            "$ screenshot lo aur docera note mein daalo",
            "# PDFs and pages",
            "$ docera pdf list batao",
            "$ docera mein <pdf name> kholo",
            "$ docera library / folders / settings / favorites / trash",
            "# App blocker",
            "$ facebook block karo (default 30 minutes)",
            "$ instagram do ghante ke liye block karo (follows the spoken time)",
            "$ docera mein youtube 45 minute block karo",
            "- You cannot remove a Docera block midway: this is on purpose."
        )),
        Sec("7. AI commands (Research, Translate, Summary...)", listOf(
            "Pick the AI app you use (ChatGPT, Claude, Gemini, Perplexity, Grok, Copilot, DeepSeek) in the settings. NotchCmd opens it, sends the prompt, copies the answer and saves it as a Docera note.",
            "$ research karo solar energy",
            "$ claude mein research karo electric cars",
            "$ translate karo <text> in Urdu",
            "$ summary karo <text>",
            "$ explain karo <question or photo>",
            "$ extract text (reads text from a photo)",
            "$ image banao red rose logo",
            "$ screen summarize / screen translate / screen explain (works on what is on screen)",
            "- In the command box you can also tap a plugin chip, or attach photos, then type the text.",
            "# Photos (up to 6 at once)",
            "- Tap the photo button in the command box and select up to 6 photos. A chip shows how many are added (for example 3/6 photos); tap the chip to remove them all.",
            "- Photos with a plugin (Explain, Summary, Translate, Extract text) are sent together to your AI app.",
            "- Photos with no plugin are saved as Docera notes (one note per photo).",
            "# Share photos and text from other apps",
            "- In Gallery, WhatsApp or any app: Share > NotchCmd. Photos (up to 6) open the command box with the photos attached; then pick a plugin or just speak or type what to do.",
            "- Share text or a link to NotchCmd: choose Summarize, Translate, Explain, Research, post to channel/Facebook/everywhere, or Open in the command box.",
            "- Online AI (Gemini/Groq key) and an offline model can understand free-style sentences and turn them into commands."
        )),
        Sec("8. Posting: WhatsApp channel, Facebook, everywhere", listOf(
            "First set your names in Posting settings: C1 channel name, F4 Facebook Page name, F5 profile name.",
            "$ channel post <topic> (AI writes it, copies it, opens WhatsApp > Updates > your channel, pastes and sends)",
            "$ facebook post <topic>",
            "$ facebook page post <topic> / facebook profile post <topic>",
            "$ post everywhere <topic> (channel and Facebook together)",
            "$ channel post <topic> with image (adds a poster)",
            "$ chatgpt channel post <topic> (choose the AI by name)",
            "- C3 and F2: your own prompt for the AI (leave default if unsure).",
            "- Option: also share the new post to your WhatsApp status (on/off switch).",
            "- Option: also forward the new post to several groups and contacts: turn on \"Also forward the post to my groups / contacts\", then C6 > write each name on its own line, exactly as WhatsApp shows it. WhatsApp allows 5 chats per Forward, so a longer list is sent in rounds of 5.",
            "- Use full names (for example Ali Raza, not Ali), so the right chat is selected. The result message tells you how many chats got the post and which names were not found.",
            "- Option: poster image with every post, and I2 poster footer line.",
            "- Option: image from ChatGPT. Turn on \"Make the post image with ChatGPT\" (Poster image section) and allow Photos permission (Setup 2c). With an image command (for example: channel post image <topic>) the app asks ChatGPT to create the picture, waits, opens it and presses Save, finds it in your gallery, then asks for the caption in the same chat and posts the picture with that caption. I3 is your own image prompt.",
            "- If ChatGPT fails at any step (limit reached, button not found), the normal poster is used and the message tells you why.",
            "- After a scheduled post the app can turn mobile data off and lock the phone.",
            "- Post history shows what was posted; Clear post history removes it."
        )),
        Sec("9. Schedule, plans, routines and triggers", listOf(
            "# Schedule",
            "- Schedule page > + New schedule: run any command at a fixed time, even when the phone is locked.",
            "- + Daily post plan: many days of posts at once, one topic per day.",
            "- + Morning briefing: the AI writes a daily news summary.",
            "# Routines",
            "- + New routine: save many commands under one name, then say: routine <name>.",
            "$ routine morning",
            "# Triggers",
            "- + New trigger: run a command when something happens (for example Wi-Fi turns on or off).",
            "# Notifications",
            "- N1 Notification access: needed for digest and reply helper.",
            "$ digest (AI summary of collected notifications)",
            "- WhatsApp reply helper asks you first, can skip group chats, and uses N4 quick reply texts.",
            "# Waiting",
            "$ wait 5 (pause 5 seconds inside a chain of commands)"
        )),
        Sec("10. Screen time, app limits, lock screen and safety", listOf(
            "- U2 daily screen limit, U3 set an app limit, U4 view or remove app limits (needs U1 Usage access).",
            "- U7 the name the assistant uses for you, Voice replies switch, U6 test the voice.",
            "- S3 phone unlock PIN: used by Auto-unlock before scheduled commands. It is stored encrypted.",
            "- Touch guard: blocks touches during scheduled runs; only the X button works.",
            "- Lock when run ends, Pickup/movement alarm, Charger unplug alarm, Safety timer (5 to 20 min): the phone locks by itself if something goes wrong.",
            "- Gboard mic: press the mic by itself and run the command after a silence of 2 to 8 seconds."
        )),
        Sec("11. Problems and fixes", listOf(
            "# The command box does not open",
            "- Turn on Overlay permission (step 1), press 4. Start, then use Test: open the box now.",
            "- Set Battery to Unrestricted (S2) so Android does not stop the service.",
            "# Nothing taps or types in other apps",
            "- Accessibility is off. Turn NotchCmd OFF then ON in Accessibility settings.",
            "- Use D1 Screen dump (opens after 8 seconds), then send the copied text to your developer.",
            "# Voice comes in Hindi script or is wrong",
            "- The app converts Hindi script to Roman letters itself. Speak slowly and clearly, or type the command.",
            "- Make sure the Google app is updated (speech recognizer).",
            "# \"Could not understand the command\"",
            "- Say the command in a simpler form: app name plus action (for example: youtube kholo).",
            "- Turn on the AI (offline model or online key) so free-style sentences work.",
            "# MJ wake word does not react",
            "- Turn on MJ voice wake on the home screen and allow the mic permission. It listens only while the screen is on.",
            "# Call or contact does not work",
            "- Allow Contacts and Call permissions (button 2). Check the name matches the contact.",
            "# NotchCmd is missing in the Share menu or photos do not arrive",
            "- Give the Overlay permission (step 1) first. If the share list is long, scroll or search for NotchCmd.",
            "- At most 6 photos are used; extra ones are ignored.",
            "# Brightness does not change",
            "- Turn on Modify system settings (2b).",
            "# Scheduled command did not run",
            "- Allow Alarms and reminders (S1), set Battery Unrestricted (S2), keep Accessibility on.",
            "- If the phone is locked, set the PIN (S3) and turn Auto-unlock on.",
            "# WhatsApp channel post fails",
            "- The tab is called Updates in new WhatsApp versions. Update NotchCmd to the latest build.",
            "- Check channel name (C1) is exactly the same as in WhatsApp. If a button is not found, add its name in L1.",
            "- After a failure use L2 to copy the last saved screen and send it for a fix.",
            "# ChatGPT image did not work",
            "- Allow Photos permission (Setup 2c) and choose Allow all (not Selected photos).",
            "- Free ChatGPT accounts have a daily image limit. When it is reached, the poster is used.",
            "- If the message says Save button not found, add the right name in L1 (gpt_save). Use D1 on the full-screen image and send the dump for a fix.",
            "- Keep the screen untouched while ChatGPT works; a new image can take up to 2 minutes.",
            "# Forward to groups / contacts did not work",
            "- Names must match WhatsApp (C6). Urdu, Hindi and English names work; small spelling-mark differences are ignored, and if the full name finds nothing the app searches with the first two words, then the first word.",
            "- The result message lists names that were not found and what the screen showed at that time. A screen dump is also saved: Settings L2 copies it.",
            "- If it says the search button was not found, add the button name to L1 (wa_search). If Forward is not found, add it to wa_forward.",
            "- Do not touch the screen while it forwards. Use L2 to copy the screen after a failure and send it for a fix.",
            "# Facebook post fails or is slow",
            "- Slow internet makes screens load late: try again on a faster network.",
            "- Check Page name (F4) and profile name (F5).",
            "# APK says \"App not installed\"",
            "- It conflicts with an older build that used a different signing key. Uninstall the old app once, then install. Later builds use one fixed key and update directly.",
            "# Wi-Fi/Bluetooth tile commands do nothing",
            "- Quick settings tile names differ by phone. Add the names used on your phone in L1.",
            "# Run the self-test",
            "- Say or type \"check app\": it lists every missing permission with the fix."
        ))
    )

    fun fileName() = "NotchCmd-Guide.pdf"

    /** builds the PDF and saves it in Downloads; returns a short message for the user */
    fun save(c: Context): String {
        val pdf = build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val r = c.contentResolver
                // replace an old copy so you never get "Guide (1).pdf"
                try { r.delete(MediaStore.Downloads.EXTERNAL_CONTENT_URI, MediaStore.Downloads.DISPLAY_NAME + "=?", arrayOf(fileName())) } catch (_: Exception) {}
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName())
                    put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val u: Uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return "Could not create the PDF file"
                r.openOutputStream(u)?.use { write(pdf, it) } ?: return "Could not write the PDF"
                "PDF saved: Downloads/" + fileName()
            } else {
                val dir = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: c.filesDir
                val f = File(dir, fileName())
                f.outputStream().use { write(pdf, it) }
                "PDF saved: " + f.absolutePath
            }
        } catch (e: Exception) { "PDF failed: " + (e.message ?: "unknown error") }
    }

    private fun write(pdf: PdfDocument, o: OutputStream) { pdf.writeTo(o); pdf.close() }

    // ---------------- drawing ----------------
    private const val W = 595; private const val H = 842; private const val M = 40f

    private fun build(): PdfDocument {
        val doc = PdfDocument()
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f; color = Color.parseColor("#222222") }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11.5f; typeface = Typeface.DEFAULT_BOLD; color = Color.parseColor("#0B3D91") }
        val h1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; color = Color.WHITE }
        val mono = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; typeface = Typeface.MONOSPACE; color = Color.parseColor("#0A5C36") }
        val monoBg = Paint().apply { color = Color.parseColor("#EEF6F0") }
        val bar = Paint().apply { color = Color.parseColor("#0B3D91") }
        val grey = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8.5f; color = Color.GRAY }
        val maxW = W - 2 * M
        var pageNo = 0
        lateinit var page: PdfDocument.Page
        var cv = android.graphics.Canvas()
        var y = 0f

        fun footer() { cv.drawText("NotchCmd Guide  -  page $pageNo", M, H - 18f, grey) }
        fun newPage() {
            if (pageNo > 0) { footer(); doc.finishPage(page) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            cv = page.canvas; y = M
        }
        fun need(h: Float) { if (y + h > H - 40f) newPage() }
        fun wrap(t: String, p: Paint, width: Float): List<String> {
            val out = ArrayList<String>(); var line = ""
            for (w in t.split(" ")) {
                val tr = if (line.isEmpty()) w else "$line $w"
                if (p.measureText(tr) <= width) line = tr
                else { if (line.isNotEmpty()) out.add(line); line = w
                    while (p.measureText(line) > width && line.length > 1) {   // very long word
                        var n = line.length; while (n > 1 && p.measureText(line.substring(0, n)) > width) n--
                        out.add(line.substring(0, n)); line = line.substring(n) } }
            }
            if (line.isNotEmpty()) out.add(line)
            return out
        }

        newPage()
        // cover
        cv.drawRect(0f, 0f, W.toFloat(), 150f, bar)
        val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 30f; typeface = Typeface.DEFAULT_BOLD; color = Color.WHITE }
        cv.drawText("NotchCmd", M, 70f, big)
        cv.drawText("Complete guide: setup, every command, settings and fixes", M, 100f, Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f; color = Color.WHITE })
        cv.drawText("Wake word: MJ   |   Open: double-tap the notch, shake, or power button", M, 122f, Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; color = Color.parseColor("#CFE0FF") })
        y = 175f
        cv.drawText("Contents", M, y, bold); y += 18f
        for (s in SECTIONS) { cv.drawText(s.title, M + 10f, y, body); y += 15f }
        y += 8f
        for (l in wrap("How to read this guide: lines in green boxes are commands you can say or type exactly like that. Words in <angle brackets> are replaced by your own text. Commands also work in Hinglish and Hindi script.", body, maxW)) { cv.drawText(l, M, y, body); y += 14f }
        newPage()

        for (s in SECTIONS) {
            need(60f)
            cv.drawRect(M, y, W - M, y + 26f, bar)
            cv.drawText(s.title, M + 8f, y + 18f, h1); y += 38f
            for (raw in s.lines) {
                when {
                    raw.startsWith("# ") -> { need(34f); y += 6f; cv.drawText(raw.substring(2), M, y + 10f, bold); y += 20f }
                    raw.startsWith("$ ") -> {
                        val ls = wrap(raw.substring(2), mono, maxW - 22f)
                        need(ls.size * 13f + 8f)
                        cv.drawRect(M + 8f, y - 2f, W - M, y + ls.size * 13f + 1f, monoBg)
                        for (l in ls) { cv.drawText(l, M + 14f, y + 9f, mono); y += 13f }
                        y += 5f
                    }
                    raw.startsWith("- ") -> {
                        val ls = wrap(raw.substring(2), body, maxW - 24f)
                        need(ls.size * 13.5f + 4f)
                        cv.drawText("•", M + 8f, y + 9f, body)
                        for (l in ls) { cv.drawText(l, M + 22f, y + 9f, body); y += 13.5f }
                        y += 3f
                    }
                    else -> {
                        val ls = wrap(raw, body, maxW)
                        need(ls.size * 13.5f + 4f)
                        for (l in ls) { cv.drawText(l, M, y + 9f, body); y += 13.5f }
                        y += 4f
                    }
                }
            }
            y += 14f
        }
        footer(); doc.finishPage(page)
        return doc
    }
}
