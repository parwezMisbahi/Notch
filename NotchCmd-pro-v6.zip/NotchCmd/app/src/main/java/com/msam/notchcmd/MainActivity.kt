package com.msam.notchcmd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import android.text.InputType
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(TextView(this).apply { text = "NotchCmd\nNotch par double-tap ya bolo \"MJ\" → mic apne aap on, bolo ya tap karke likho"; textSize = 18f; tag = "title" })
        root.addView(Button(this).apply {
            text = "Style badlo: " + (Style.labels[Style.cur(this@MainActivity)] ?: "Glass") + "  ▸"
            setOnClickListener { Style.next(this@MainActivity); Style.buzz(this@MainActivity, "heavy"); recreate() }
        })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Overlay permission") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2. Mic, contacts, call, notification permission") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2b. Brightness permission (Modify system settings)") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        btn("3. Accessibility on karo (NotchCmd)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3b. Power button: Default digital assistant = NotchCmd") { try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        btn("4. Start (notch button on)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java)) }
        btn("MJ ON (screen on par sunega)") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", true)) }
        btn("MJ OFF (mic band)") { startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", false)) }
        btn("Check: pura app ki jaanch") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("cmd", "check app")) }
        btn("Stop") { stopService(Intent(this, OverlayService::class.java)) }
        btn("Test: box abhi kholo") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) }
        // ---------- Schedule: fix time par command ----------
        root.addView(TextView(this).apply { text = "\nSchedule (fix time par command, lock hone par bhi)"; textSize = 18f })
        btn("S1. Alarms & reminders permission (theek waqt ke liye)") { if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
        btn("S2. Battery: Unrestricted karo") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        // ---------- Lock screen: auto-unlock + data ----------
        val pinTv = TextView(this).apply { textSize = 14f }
        fun pinInfo() { val n = Unlocker.pinLen(this); pinTv.text = if (n == 0) "PIN set nahi hai" else "PIN set: $n digit" }
        root.addView(pinTv)
        btn("S3. Phone unlock PIN set karo") {
            val et = EditText(this).apply { hint = "Phone ka lock PIN (4-16 digit)"; setSingleLine(true)
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
            AlertDialog.Builder(this).setTitle("Unlock PIN").setMessage("Digit apne aap gin liye jayenge. PIN encrypted rakha jata hai.").setView(et)
                .setPositiveButton("Save") { _, _ ->
                    val p = et.text.toString().trim()
                    if (p.length in 4..16 && p.all { it.isDigit() }) { Unlocker.setPin(this, p); Toast.makeText(this, "${p.length} digit PIN save", Toast.LENGTH_SHORT).show() }
                    else Toast.makeText(this, "PIN 4 se 16 digit ka hona chahiye", Toast.LENGTH_SHORT).show()
                    pinInfo()
                }.setNeutralButton("PIN hatao") { _, _ -> Unlocker.clearPin(this); pinInfo() }
                .setNegativeButton("Raddh", null).show()
        }
        val unlockBtn = Button(this)
        fun unlockLabel() { unlockBtn.text = "S4. Lock hone par auto-unlock: " + if (Unlocker.unlockOn(this)) "ON" else "OFF" }
        unlockBtn.setOnClickListener { Unlocker.setUnlockOn(this, !Unlocker.unlockOn(this)); unlockLabel() }
        root.addView(unlockBtn)
        val dataBtn = Button(this)
        fun dataLabel() { dataBtn.text = "S5. Data band ho to ON karo: " + if (Unlocker.dataOn(this)) "ON" else "OFF" }
        dataBtn.setOnClickListener { Unlocker.setDataOn(this, !Unlocker.dataOn(this)); dataLabel() }
        root.addView(dataBtn)
        val bioBtn = Button(this)
        fun bioLabel() { bioBtn.text = "S7. Biometric prompt par \"Use PIN\" + PIN: " + if (Unlocker.bioOn(this)) "ON" else "OFF" }
        bioBtn.setOnClickListener { Unlocker.setBioOn(this, !Unlocker.bioOn(this)); bioLabel() }
        root.addView(bioBtn)
        val gBtn = Button(this)
        fun gLabel() { gBtn.text = "V3. Gboard mic se bolne ke " + (OfflineVoice.gboard(this) / 1000) + " sec baad command chalegi (tap = badlo). Likhne par ▶ dabao" }
        gBtn.setOnClickListener { OfflineVoice.nextGboard(this); gLabel() }
        root.addView(gBtn); gLabel()
        val mBtn = Button(this)
        fun mLabel() { mBtn.text = "V4. Gboard ka mic khud dabana: " + if (OfflineVoice.gbMic(this)) "ON" else "OFF" }
        mBtn.setOnClickListener { OfflineVoice.toggleGbMic(this); mLabel() }
        root.addView(mBtn); mLabel()
        btn("D1. Screen dump: 8 sec baad (tab dekhni wali screen kholo)") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Pehle Accessibility on karo", Toast.LENGTH_SHORT).show()
            else {
                Toast.makeText(this, "8 sec mein wo screen kholo", Toast.LENGTH_LONG).show()
                Handler(Looper.getMainLooper()).postDelayed({
                    val d = a.dump()
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("dump", d))
                    Toast.makeText(this, "Copy ho gaya (${d.lines().size} lines). Chat mein paste karo", Toast.LENGTH_LONG).show()
                }, 8000)
            }
        }
        btn("S6. Test: phone lock karke 6 sec baad unlock try") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Pehle Accessibility on karo", Toast.LENGTH_SHORT).show()
            else {
                a.act("lock")
                Handler(Looper.getMainLooper()).postDelayed({
                    try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("prep_only", true).putExtra("sched", true)) } catch (_: Exception) {}
                }, 6000)
            }
        }
        pinInfo(); unlockLabel(); dataLabel(); bioLabel()
        // ---------- Mobile limit + awaaz ke jawab ----------
        root.addView(TextView(this).apply { text = "Mobile limit aur awaaz"; textSize = 18f })
        fun numDialog(title: String, cur: Int, ok: (Int) -> Unit) {
            val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "minute"; setSingleLine(true); if (cur > 0) setText(cur.toString()) }
            AlertDialog.Builder(this).setTitle(title).setView(et)
                .setPositiveButton("Save") { _, _ -> ok(et.text.toString().trim().toIntOrNull() ?: 0) }
                .setNegativeButton("Raddh", null).show()
        }
        fun appLabel(pkg: String): String = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        btn("U1. Usage access permission (limit ke liye zaroori)") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        val scrBtn = Button(this)
        fun scrLabel() { val m = UsageGuard.screenLimit(this); scrBtn.text = "U2. Roz ka screen limit: " + if (m <= 0) "OFF" else "$m minute" }
        scrBtn.setOnClickListener { numDialog("Roz ka screen limit (minute, 0 = OFF)", UsageGuard.screenLimit(this)) { UsageGuard.setScreenLimit(this, it); scrLabel() } }
        root.addView(scrBtn)
        btn("U3. App ka limit lagao") {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }.filter { it.first != packageName }.sortedBy { it.second.lowercase() }
            AlertDialog.Builder(this).setTitle("Kaunsa app?").setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                val (pkg, name) = apps[i]
                numDialog("$name: roz ka limit (minute, 0 = hatao)", UsageGuard.limits(this)[pkg] ?: 0) {
                    UsageGuard.setLimit(this, pkg, it)
                    Toast.makeText(this, if (it > 0) "$name: $it minute/din" else "$name ka limit hata diya", Toast.LENGTH_SHORT).show()
                }
            }.show()
        }
        btn("U4. App limits dekho / hatao") {
            val l = UsageGuard.limits(this).entries.sortedBy { appLabel(it.key).lowercase() }
            if (l.isEmpty()) Toast.makeText(this, "Koi app limit nahi lagi", Toast.LENGTH_SHORT).show()
            else AlertDialog.Builder(this).setTitle("Tap karke hatao").setItems(l.map { appLabel(it.key) + "  -  " + it.value + " min/din" }.toTypedArray()) { _, i ->
                UsageGuard.setLimit(this, l[i].key, 0)
                Toast.makeText(this, appLabel(l[i].key) + " ka limit hata diya", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Band", null).show()
        }
        val talkBtn = Button(this)
        fun talkLabel() { talkBtn.text = "U5. Awaaz ke jawab (Ji main hazir hoon / Kaam ho gaya): " + if (UsageGuard.voiceOn(this)) "ON" else "OFF" }
        talkBtn.setOnClickListener { UsageGuard.setVoiceOn(this, !UsageGuard.voiceOn(this)); talkLabel() }
        root.addView(talkBtn)
        val rsBtn = Button(this)
        fun rsLabel() { rsBtn.text = "R1. Research ke liye AI app: " + ResearchPrefs.selected(this).label + "  (tap = badlo)" }
        rsBtn.setOnClickListener {
            val all = ResearchPrefs.ALL
            val names = all.map { it.label + if (ResearchPrefs.installed(this, it)) "" else "  (install nahi)" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("\"research karo ...\" kis AI app mein ho?")
                .setSingleChoiceItems(names, all.indexOfFirst { it.key == ResearchPrefs.selected(this).key }) { d, i ->
                    ResearchPrefs.select(this, all[i].key); rsLabel(); d.dismiss()
                }.setNegativeButton("Band", null).show()
        }
        root.addView(rsBtn)
        val nameBtn = Button(this)
        fun nameLabel() { nameBtn.text = "U7. Assistant aapko kya bulaye: " + if (UsageGuard.hasName(this)) UsageGuard.userName(this) else "muhtaram (naam set karo)" }
        nameBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Aapka naam (khali = muhtaram)"; setSingleLine(true); if (UsageGuard.hasName(this@MainActivity)) setText(UsageGuard.userName(this@MainActivity)) }
            AlertDialog.Builder(this).setTitle("Assistant aapko kya bulaye?").setMessage("Yeh naam awaaz ke jawab aur yaad dilane mein bola jayega. Khali chhodo to \"muhtaram\".").setView(et)
                .setPositiveButton("Save") { _, _ -> UsageGuard.setUserName(this, et.text.toString()); nameLabel() }
                .setNegativeButton("Raddh", null).show()
        }
        root.addView(nameBtn)
        btn("U6. Test: awaaz bulao") {
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("say", "Ji " + UsageGuard.userName(this) + ", main hazir hoon")) } catch (_: Exception) {}
        }
        scrLabel(); talkLabel(); nameLabel(); rsLabel()
        // ---------- Offline AI model ----------
        root.addView(TextView(this).apply { text = "Offline AI (khuli baat samajhna)"; textSize = 18f })
        val aiTv = TextView(this).apply { textSize = 13f }
        fun aiInfo() { aiTv.text = "AI: " + LlmBrain.status(this) + "\n" + LlmBrain.onlineStatus(this) + (if (LlmBrain.memoryCount(this) > 0) "\nYaaddasht: ${LlmBrain.memoryCount(this)} baatein" else "") }
        root.addView(aiTv)
        val dlBtn = Button(this)
        fun dlLabel() { dlBtn.text = if (LlmBrain.ready(this)) "A1. AI model: taiyar (hatane ke liye tap)" else "A1. AI model download karo (WiFi par)" }
        dlBtn.setOnClickListener {
            if (LlmBrain.ready(this)) {
                AlertDialog.Builder(this).setTitle("AI model hatao?").setMessage("Jagah khali hogi. Dobara download karna padega.")
                    .setPositiveButton("Hatao") { _, _ -> LlmBrain.deleteModel(this); aiInfo(); dlLabel() }.setNegativeButton("Raddh", null).show()
            } else if (LlmBrain.downloading) Toast.makeText(this, "Download chal raha hai: " + LlmBrain.progress, Toast.LENGTH_SHORT).show()
            else {
                Toast.makeText(this, "Download shuru. App khula rakho aur WiFi on rakho", Toast.LENGTH_LONG).show()
                LlmBrain.download(this, { p -> runOnUiThread { aiTv.text = "AI: download $p" } }) { ok, m ->
                    runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); if (ok) LlmBrain.setEnabled(this, true); aiInfo(); dlLabel() }
                }
            }
        }
        root.addView(dlBtn)
        val aiBtn = Button(this)
        fun aiLabel() { aiBtn.text = "A2. AI se command samajhna: " + if (LlmBrain.enabled(this)) "ON" else "OFF" }
        aiBtn.setOnClickListener {
            if (!LlmBrain.enabled(this) && !LlmBrain.ready(this) && !LlmBrain.onlineReady(this)) Toast.makeText(this, "Pehle A1 se model download karo ya A5 se online key daalo", Toast.LENGTH_SHORT).show()
            else { LlmBrain.setEnabled(this, !LlmBrain.enabled(this)); if (!LlmBrain.enabled(this)) LlmBrain.unload(); aiInfo(); aiLabel() }
        }
        root.addView(aiBtn)
        btn("A3. AI ki yaaddasht saaf karo") { LlmBrain.forget(this); aiInfo(); Toast.makeText(this, "Yaaddasht saaf", Toast.LENGTH_SHORT).show() }
        btn("A0. Offline model chuno (Qwen 0.5B / 1.5B / 3B / Gemma)") {
            val ps = LlmBrain.presets
            AlertDialog.Builder(this).setTitle("Kaun sa model?")
                .setItems(ps.map { it.label }.toTypedArray()) { _, i ->
                    val pr = ps[i]
                    if (pr.url == LlmBrain.url(this)) Toast.makeText(this, "Ye pehle se chuna hua hai", Toast.LENGTH_SHORT).show()
                    else AlertDialog.Builder(this).setTitle("Model badlein?")
                        .setMessage("Purana model hat jayega, naya download karna padega (WiFi par)." + (if (pr.needsToken) "\n\nIsko HuggingFace token chahiye (A4 mein daalo)." else ""))
                        .setPositiveButton("Chuno") { _, _ ->
                            LlmBrain.selectPreset(this, pr.url); aiInfo(); dlLabel(); aiLabel()
                            Toast.makeText(this, "Ab A1 dabakar download karo", Toast.LENGTH_LONG).show()
                        }.setNegativeButton("Raddh", null).show()
                }.setNegativeButton("Raddh", null).show()
        }
        btn("A4. Model link / HuggingFace token (advanced)") {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 10, 40, 0) }
            val et = EditText(this).apply { setSingleLine(true); hint = ".task model ka link"; setText(LlmBrain.url(this@MainActivity)) }
            val tk = EditText(this).apply { setSingleLine(true); hint = "HuggingFace token (sirf Gemma jaise gated model ke liye)"; setText(LlmBrain.hfToken(this@MainActivity)) }
            box.addView(et); box.addView(tk)
            AlertDialog.Builder(this).setTitle("Model setting").setMessage("Naya link lagane se pehle purana model hata dena.").setView(box)
                .setPositiveButton("Save") { _, _ -> LlmBrain.setUrl(this, et.text.toString()); LlmBrain.setHfToken(this, tk.text.toString()) }
                .setNeutralButton("Default") { _, _ -> LlmBrain.setUrl(this, LlmBrain.URL_1_5B) }
                .setNegativeButton("Raddh", null).show()
        }
        btn("A5. Online AI (free Gemini / Groq key) - hybrid") {
            val names = arrayOf("Band (sirf offline)", "Google Gemini (free key)", "Groq (free key)")
            val ids = arrayOf("off", "gemini", "groq")
            AlertDialog.Builder(this).setTitle("Online AI kaun sa?")
                .setItems(names) { _, i ->
                    val pv = ids[i]
                    if (pv == "off") {
                        LlmBrain.setOnline(this, "off", "", ""); aiInfo()
                        Toast.makeText(this, "Online AI band", Toast.LENGTH_SHORT).show()
                    } else {
                        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 10, 40, 0) }
                        val kEt = EditText(this).apply { setSingleLine(true); hint = "API key"; setText(LlmBrain.apiKey(this@MainActivity)) }
                        val mEt = EditText(this).apply { setSingleLine(true); hint = "Model ka naam"; setText(if (LlmBrain.provider(this@MainActivity) == pv) LlmBrain.onlineModel(this@MainActivity) else LlmBrain.defaultModel(pv)) }
                        box.addView(kEt); box.addView(mEt)
                        AlertDialog.Builder(this).setTitle(names[i])
                            .setMessage("Key sirf is phone mein save hoti hai. Online mode mein aapki boli hui baat Google/Groq ko jaati hai. Net na ho ya fail ho to offline model chalega. Model ka naam error de to badal dena.").setView(box)
                            .setPositiveButton("Save") { _, _ ->
                                LlmBrain.setOnline(this, pv, kEt.text.toString(), mEt.text.toString())
                                if (!LlmBrain.enabled(this)) LlmBrain.setEnabled(this, true)
                                aiInfo(); aiLabel()
                            }.setNegativeButton("Raddh", null).show()
                    }
                }.setNegativeButton("Raddh", null).show()
        }
        aiInfo(); dlLabel(); aiLabel()
        val schedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun dayName(mask: Int): String = if (mask == 0) "Ek baar" else if (mask == 127) "Roz"
            else listOf("Ravi", "Som", "Mangal", "Budh", "Guru", "Shukra", "Shani").filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(",")
        fun refreshSched() {
            schedBox.removeAllViews()
            Scheduler.load(this).forEach { s ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 16) }
                row.addView(TextView(this).apply { text = "%02d:%02d • %s • %s%s".format(s.hh, s.mm, dayName(s.days), s.cmd, if (s.on) "" else "  (band)"); textSize = 15f })
                val br = LinearLayout(this)
                br.addView(Button(this).apply { text = if (s.on) "OFF" else "ON"; setOnClickListener { Scheduler.setOn(this@MainActivity, s.id, !s.on); refreshSched() } })
                br.addView(Button(this).apply { text = "Abhi chalao"; setOnClickListener { startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", s.cmd).putExtra("sched", true)) } })
                br.addView(Button(this).apply { text = "Hatao"; setOnClickListener { Scheduler.remove(this@MainActivity, s.id); refreshSched() } })
                row.addView(br); schedBox.addView(row)
            }
            Style.skin(this, schedBox)
        }
        btn("+ Naya schedule") {
            val et = EditText(this).apply { hint = "Command, jaise: youtube kholo"; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle("Kaun si command chalani hai?").setView(et)
                .setPositiveButton("Aage") { _, _ ->
                    val cmd = et.text.toString().trim()
                    if (cmd.isNotEmpty()) TimePickerDialog(this, { _, hh, mm ->
                        val sel = BooleanArray(7)
                        AlertDialog.Builder(this).setTitle("Kin dino? (kuch na chuno = sirf ek baar)")
                            .setMultiChoiceItems(arrayOf("Ravivar", "Somvar", "Mangalvar", "Budhvar", "Guruvar", "Shukravar", "Shanivar"), sel) { _, i, c -> sel[i] = c }
                            .setPositiveButton("Save") { _, _ ->
                                var mask = 0
                                sel.forEachIndexed { i, b -> if (b) mask = mask or (1 shl i) }
                                Scheduler.add(this, hh, mm, cmd, mask); refreshSched()
                            }.setNegativeButton("Raddh", null).show()
                    }, 8, 0, false).show()
                }.setNegativeButton("Raddh", null).show()
        }
        root.addView(schedBox)
        Scheduler.armAll(this); refreshSched()
        Style.skin(this, root)
        (root.findViewWithTag<TextView>("title"))?.setTextColor(Style.theme(this).stroke)
        setContentView(ScrollView(this).apply { background = Style.background(this@MainActivity); addView(root) })
        Style.enter(root)
        if (b == null) Style.buzz(this, "launch")
    }

    // App kholte hi (ya permission dene ke baad) service khud chalu: mic sirf "MJ" ke liye sunta rehta hai
    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }
}
