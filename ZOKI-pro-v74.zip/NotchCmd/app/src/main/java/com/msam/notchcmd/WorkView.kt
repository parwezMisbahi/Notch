package com.msam.notchcmd

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.animation.ObjectAnimator
import android.os.SystemClock

/**
 * Work View: while ZOKI works inside another app, a copy of the chat screen (same background, header, bubbles,
 * input bar) covers that app at 100% opacity. It shows the conversation and, like an AI "thinking", a live bubble
 * with the current step, seconds passed and about how many are left. Photos and text that come out of the work
 * appear as normal chat bubbles. The cover is NOT touchable (our accessibility gestures pass through);
 * only the round stop button, placed exactly on the send button, is touchable.
 */
object WorkView {
    const val PREF = "n"
    const val KEY = "work_view"
    @Volatile var appCtx: Context? = null
    /** set by OverlayService: stops the running command */
    @Volatile var onStop: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var stopBtn: View? = null
    private var sendSpot: View? = null
    private var wm: WindowManager? = null
    private var msgBox: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var subV: TextView? = null
    private var liveRow: View? = null
    private var liveText: TextView? = null
    private var liveInfo: TextView? = null
    private var livePulse: ObjectAnimator? = null
    private var th: Style.T? = null
    private val hideRun = Runnable { remove() }

    // time left: learned from earlier runs of the same command
    private var t0 = 0L
    private var estMs = 45_000L
    private var key = ""
    private var steps = 0
    private var finished = false
    private val tick = object : Runnable {
        override fun run() { if (root == null || finished) return; refresh(); main.postDelayed(this, 500) }
    }

    fun enabled(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(KEY, true)
    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    private fun type(): Int = if (NotchA11y.inst != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private fun keyOf(cmd: String) = cmd.trim().lowercase().split(Regex("\\s+")).take(2).joinToString(" ")
    private fun sysDim(c: Context, name: String): Int {
        val id = c.resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) c.resources.getDimensionPixelSize(id) else 0
    }

    /** called when a chat command starts */
    fun start(cmd: String = "") {
        val c = appCtx ?: return
        if (!enabled(c)) return
        main.post {
            main.removeCallbacks(hideRun); main.removeCallbacks(tick)
            key = keyOf(cmd); steps = 0; finished = false; t0 = SystemClock.elapsedRealtime()
            estMs = c.getSharedPreferences("workview_eta", Context.MODE_PRIVATE).getLong(key, 45_000L).coerceIn(8_000L, 600_000L)
            remove0()
            build(c)
            if (root != null) { liveShow("Starting…"); refresh(); main.postDelayed(tick, 500) }
        }
    }

    private fun round(c: Context, color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        cornerRadius = dp(c, r).toFloat(); setColor(color); if (stroke != 0) setStroke(dp(c, 1), stroke)
    }

    private fun build(c: Context) {
        try {
            val a11 = NotchA11y.inst
            val ctx: Context = a11 ?: c
            val w = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val t = Style.theme(c); th = t
            val r = FrameLayout(ctx).apply { background = Style.background(c) }
            val mainL = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, sysDim(c, "status_bar_height"), 0, sysDim(c, "navigation_bar_height")) }

            // header: same as the chat screen
            val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(c, 6), dp(c, 8), dp(c, 6), dp(c, 6)) }
            header.addView(ImageView(ctx).apply { setImageResource(R.drawable.ic_menu); setColorFilter(t.text); setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 10)); layoutParams = LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)) })
            header.addView(ImageView(ctx).apply {
                setImageResource(R.drawable.ic_robot_mono); setColorFilter(t.stroke)
                layoutParams = LinearLayout.LayoutParams(dp(c, 50), dp(c, 50)).apply { setMargins(dp(c, 2), 0, 0, 0) }
            })
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            col.addView(TextView(ctx).apply { text = "ZOKI"; textSize = 19f; setTextColor(t.stroke); typeface = android.graphics.Typeface.DEFAULT_BOLD })
            val sub = TextView(ctx).apply { text = "Working…"; textSize = 11.5f; setTextColor(t.sub) }
            col.addView(sub); header.addView(col)
            header.addView(ImageView(ctx).apply { setImageResource(R.drawable.ic_new); setColorFilter(t.text); setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 10)); layoutParams = LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)) })
            mainL.addView(header)
            mainL.addView(View(ctx).apply { setBackgroundColor((t.stroke and 0x00FFFFFF) or 0x30000000); layoutParams = LinearLayout.LayoutParams(-1, dp(c, 1)) })

            // messages: the last chat messages (the command just typed is the last one)
            val sc = ScrollView(ctx).apply { isFillViewport = false; overScrollMode = View.OVER_SCROLL_NEVER; layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 14)) }
            sc.addView(box); mainL.addView(sc)

            // input bar: looks like the chat's, with the stop button where send is
            val bar = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                background = Style.card(c, t, 24)
                setPadding(dp(c, 8), dp(c, 4), dp(c, 8), dp(c, 6))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 10)) }
            }
            bar.addView(TextView(ctx).apply { text = "ZOKI is working…"; textSize = 16f; setTextColor(t.sub); setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 6)) })
            val btns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            fun ic(res: Int) = ImageView(ctx).apply { setImageResource(res); setColorFilter(t.text); alpha = 0.5f; setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 10)); layoutParams = LinearLayout.LayoutParams(dp(c, 42), dp(c, 42)) }
            btns.addView(ic(R.drawable.ic_photo)); btns.addView(ic(R.drawable.ic_plug))
            btns.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
            btns.addView(ic(R.drawable.ic_mic))
            val spot = ImageView(ctx).apply {
                setImageResource(R.drawable.ic_stop); setColorFilter(t.btnText); setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 10))
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply { shape = GradientDrawable.OVAL }
                layoutParams = LinearLayout.LayoutParams(dp(c, 42), dp(c, 42)).apply { setMargins(dp(c, 6), 0, 0, 0) }
            }
            btns.addView(spot); bar.addView(btns); mainL.addView(bar)
            r.addView(mainL, FrameLayout.LayoutParams(-1, -1))

            // truly full screen: the real display size, from y = 0, behind the status bar and the cutout too
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") w.defaultDisplay.getRealMetrics(dm)
            val lp = WindowManager.LayoutParams(dm.widthPixels, dm.heightPixels, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE).apply {
                gravity = Gravity.TOP or Gravity.START; x = 0; y = 0
                if (android.os.Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                if (android.os.Build.VERSION.SDK_INT >= 30) setFitInsetsTypes(0)
            }
            w.addView(r, lp)

            // invisible touchable stop button laid exactly over the send circle
            val stop = View(ctx)
            stop.setOnClickListener { onStop?.invoke() }
            val slp = WindowManager.LayoutParams(dp(c, 48), dp(c, 48), type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
            w.addView(stop, slp)
            spot.post {
                try {
                    val loc = IntArray(2); spot.getLocationOnScreen(loc)
                    slp.x = loc[0] - dp(c, 3); slp.y = loc[1] - dp(c, 3)
                    w.updateViewLayout(stop, slp)
                } catch (_: Exception) {}
            }

            // earlier messages (like the chat shows them)
            val hist = try { ChatStore.load(c).takeLast(8) } catch (_: Exception) { emptyList() }
            root = r; stopBtn = stop; sendSpot = spot; wm = w; msgBox = box; scroll = sc; subV = sub
            hist.forEach { m -> bubble(c, m.role == "u", m.text) }
        } catch (_: Exception) { root = null }
    }

    private fun scrollDown() { scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) } }

    /** a normal chat bubble (same shapes and colors as the chat screen) */
    private fun bubble(c: Context, me: Boolean, text: String, pic: android.graphics.Bitmap? = null) {
        val box = msgBox ?: return; val t = th ?: return
        val ctx = root?.context ?: return
        val maxW = (c.resources.displayMetrics.widthPixels * 0.80f).toInt()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = if (me) Gravity.END else Gravity.START
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(c, 5), 0, dp(c, 5)) }
        }
        val b = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10)) }
        val rr = dp(c, 20).toFloat(); val ss = dp(c, 5).toFloat()
        b.background = if (me) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(t.a1, t.a2)).apply { cornerRadii = floatArrayOf(rr, rr, rr, rr, ss, ss, rr, rr) }
        else GradientDrawable().apply {
            cornerRadii = floatArrayOf(rr, rr, rr, rr, rr, rr, ss, ss)
            setColor(if (t.light) 0xCCFFFFFF.toInt() else 0x1AFFFFFF); setStroke(dp(c, 1), (t.stroke and 0x00FFFFFF) or 0x44000000)
        }
        if (pic != null) b.addView(ImageView(ctx).apply { setImageBitmap(pic); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; maxHeight = dp(c, 320) }, LinearLayout.LayoutParams(maxW - dp(c, 28), -2))
        if (text.isNotBlank()) b.addView(TextView(ctx).apply {
            this.text = text.take(1500); textSize = 15f; setTextColor(if (me) t.btnText else t.text); maxWidth = maxW - dp(c, 28); setLineSpacing(0f, 1.08f)
        })
        row.addView(b, LinearLayout.LayoutParams(-2, -2))
        val at = liveRow?.let { box.indexOfChild(it) } ?: -1
        if (at >= 0) box.addView(row, at) else box.addView(row)
        scrollDown()
    }

    /** the live "thinking" bubble: pulsing dot + current step, and a small line with percent / seconds */
    private fun liveShow(msg: String) {
        val c = appCtx ?: return; val box = msgBox ?: return; val t = th ?: return
        val ctx = root?.context ?: return
        if (liveRow == null) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.START; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(c, 5), 0, dp(c, 5)) } }
            val b = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10))
                background = GradientDrawable().apply {
                    val rr = dp(c, 20).toFloat(); val ss = dp(c, 5).toFloat()
                    cornerRadii = floatArrayOf(rr, rr, rr, rr, rr, rr, ss, ss)
                    setColor(if (t.light) 0xCCFFFFFF.toInt() else 0x1AFFFFFF); setStroke(dp(c, 1), t.stroke)
                }
            }
            b.addView(TextView(ctx).apply { text = "●"; textSize = 14f; setTextColor(t.stroke); setPadding(0, 0, dp(c, 10), 0) }.also {
                livePulse = ObjectAnimator.ofFloat(it, "alpha", 1f, 0.2f).apply { duration = 650; repeatMode = ObjectAnimator.REVERSE; repeatCount = ObjectAnimator.INFINITE; start() }
            })
            val tc = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val tv = TextView(ctx).apply { textSize = 14.5f; setTextColor(t.text); maxWidth = (c.resources.displayMetrics.widthPixels * 0.72f).toInt() }
            val inf = TextView(ctx).apply { textSize = 11.5f; setTextColor(t.sub); setPadding(0, dp(c, 3), 0, 0) }
            tc.addView(tv); tc.addView(inf); b.addView(tc)
            row.addView(b, LinearLayout.LayoutParams(-2, -2))
            box.addView(row); liveRow = row; liveText = tv; liveInfo = inf
        }
        liveText?.text = msg
        scrollDown()
    }

    private fun refresh() {
        val inf = liveInfo ?: return
        val el = SystemClock.elapsedRealtime() - t0
        if (el > estMs * 0.9) estMs = (el * 1.15).toLong()      // taking longer than expected: stretch the estimate
        val pct = ((el.toFloat() / estMs).coerceIn(0f, 0.97f) * 100).toInt()
        val left = ((estMs - el) / 1000).coerceAtLeast(1)
        inf.text = "$pct%  ·  ${el / 1000}s passed  ·  about ${left}s left"
    }

    /** one action step: replaces the text of the live bubble, like the chat's "thinking" */
    fun step(m: String) {
        main.post {
            if (root == null || finished) return@post
            if (!(m.endsWith("...") || m.endsWith("…"))) steps++
            liveShow(m)
        }
    }

    /** text result (script, caption, answer): a chat bubble above the live one */
    fun text(t: String) {
        val c = appCtx ?: return
        main.post { if (root != null) bubble(c, false, t) }
    }

    /** the picture that was made: a chat bubble with the picture */
    fun image(u: Uri) {
        val c = appCtx ?: return
        Thread {
            val bm = try {
                val o = android.graphics.BitmapFactory.Options().apply { inSampleSize = 2 }
                c.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
            } catch (_: Exception) { null }
            if (bm != null) main.post { if (root != null) bubble(c, false, "", bm) }
        }.start()
    }

    /** run ended: remember the time, show the final reply bubble for a moment, then remove the cover */
    fun done(ok: Boolean, m: String) {
        main.post {
            if (root == null) return@post
            finished = true; main.removeCallbacks(tick)
            val c = appCtx
            if (ok && c != null && key.isNotEmpty()) {
                val el = SystemClock.elapsedRealtime() - t0
                val sp = c.getSharedPreferences("workview_eta", Context.MODE_PRIVATE)
                val old = sp.getLong(key, 0L)
                sp.edit().putLong(key, if (old == 0L) el else (old + el) / 2).apply()
            }
            livePulse?.cancel(); livePulse = null
            liveRow?.let { msgBox?.removeView(it) }; liveRow = null; liveText = null; liveInfo = null
            subV?.text = if (ok) "Ready" else "Stopped"
            stopBtn?.visibility = View.GONE
            if (c != null) bubble(c, false, m)
            main.removeCallbacks(hideRun)
            main.postDelayed(hideRun, if (ok) 2500L else 1200L)
        }
    }

    private fun remove0() {
        try { livePulse?.cancel() } catch (_: Exception) {}
        try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { stopBtn?.let { wm?.removeView(it) } } catch (_: Exception) {}
        root = null; stopBtn = null; sendSpot = null; msgBox = null; scroll = null; subV = null; liveRow = null; liveText = null; liveInfo = null; livePulse = null
    }

    fun remove() {
        main.post { main.removeCallbacks(hideRun); main.removeCallbacks(tick); remove0() }
    }
}
