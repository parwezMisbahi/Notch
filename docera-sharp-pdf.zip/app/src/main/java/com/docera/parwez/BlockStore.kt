package com.docera.parwez

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.Settings
import org.json.JSONObject

/**
 * Stores which apps are blocked and until when. There is deliberately NO remove/unblock
 * function here: an entry only disappears when its time has run out.
 *
 * Time is measured with elapsedRealtime() while the phone has not rebooted, so changing the
 * system clock does not shorten a block. After a reboot it falls back to the wall clock.
 */
object BlockStore {
    private const val PREFS = "docera_blocker"
    private const val KEY = "blocks"
    const val MAX_MINUTES = 7 * 24 * 60
    const val DEF_EM_MIN = 5
    const val DEF_EM_MAX = 2
    const val MAX_EM_MIN = 30
    const val MAX_EM_COUNT = 5

    /**
     * emMin / emMax are the emergency-pass settings chosen when the block was created (minutes per
     * pass, number of passes) and can not be changed later. emUsed counts passes already used;
     * pass* describe the pass that is running now (passMs = 0 -> none).
     */
    data class Entry(
        val pkg: String,
        val durationMs: Long,
        val startElapsed: Long,
        val startWall: Long,
        val boot: Int,
        val emMin: Int = DEF_EM_MIN,
        val emMax: Int = DEF_EM_MAX,
        val emUsed: Int = 0,
        val passMs: Long = 0L,
        val passStartElapsed: Long = 0L,
        val passStartWall: Long = 0L,
        val passBoot: Int = -1
    )

    private fun bootCount(ctx: Context): Int = try {
        Settings.Global.getInt(ctx.contentResolver, "boot_count", -1)
    } catch (_: Exception) {
        -1
    }

    private fun read(ctx: Context): MutableMap<String, Entry> {
        val out = mutableMapOf<String, Entry>()
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return out
        try {
            val o = JSONObject(raw)
            for (k in o.keys()) {
                val j = o.getJSONObject(k)
                out[k] = Entry(
                    k, j.getLong("d"), j.getLong("e"), j.getLong("w"), j.getInt("b"),
                    j.optInt("em", DEF_EM_MIN), j.optInt("en", DEF_EM_MAX), j.optInt("eu", 0),
                    j.optLong("pd", 0L), j.optLong("pe", 0L), j.optLong("pw", 0L), j.optInt("pb", -1)
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun write(ctx: Context, map: Map<String, Entry>) {
        val o = JSONObject()
        for ((k, v) in map) {
            o.put(
                k,
                JSONObject().put("d", v.durationMs).put("e", v.startElapsed)
                    .put("w", v.startWall).put("b", v.boot)
                    .put("em", v.emMin).put("en", v.emMax).put("eu", v.emUsed)
                    .put("pd", v.passMs).put("pe", v.passStartElapsed)
                    .put("pw", v.passStartWall).put("pb", v.passBoot)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun remainingMs(ctx: Context, e: Entry): Long {
        val nowEl = SystemClock.elapsedRealtime()
        val boot = bootCount(ctx)
        val rem = if (boot != -1 && boot == e.boot && nowEl >= e.startElapsed) {
            e.durationMs - (nowEl - e.startElapsed)
        } else {
            e.startWall + e.durationMs - System.currentTimeMillis()
        }
        return rem.coerceAtMost(e.durationMs)
    }

    fun remainingFor(ctx: Context, pkg: String): Long {
        val e = read(ctx)[pkg] ?: return 0L
        return remainingMs(ctx, e).coerceAtLeast(0L)
    }

    /** Time left of a running emergency pass (0 = no pass running). */
    private fun passRemaining(ctx: Context, e: Entry): Long {
        if (e.passMs <= 0L) return 0L
        val nowEl = SystemClock.elapsedRealtime()
        val boot = bootCount(ctx)
        val rem = if (boot != -1 && boot == e.passBoot && nowEl >= e.passStartElapsed) {
            e.passMs - (nowEl - e.passStartElapsed)
        } else {
            e.passStartWall + e.passMs - System.currentTimeMillis()
        }
        return rem.coerceIn(0L, e.passMs)
    }

    /**
     * What the cover screens use: time left of the block, or 0 while an emergency pass is running
     * (the app may be used) or when the app is not blocked at all.
     */
    fun blockedRemaining(ctx: Context, pkg: String): Long {
        val e = read(ctx)[pkg] ?: return 0L
        val rem = remainingMs(ctx, e)
        if (rem <= 0L) return 0L
        if (passRemaining(ctx, e) > 0L) return 0L
        return rem
    }

    /** True if any emergency pass is running right now (the service keeps watching to re-cover the app when it ends). */
    fun anyPass(ctx: Context): Boolean = read(ctx).values.any { passRemaining(ctx, it) > 0L }

    fun emergencyLeft(ctx: Context, pkg: String): Int {
        val e = read(ctx)[pkg] ?: return 0
        return (e.emMax - e.emUsed).coerceAtLeast(0)
    }

    fun emergencyMinutes(ctx: Context, pkg: String): Int = read(ctx)[pkg]?.emMin ?: DEF_EM_MIN

    /** Uses one emergency pass: the app opens for emMin minutes, the block itself keeps running. Returns "ok", "none_left", "running" or "no_block". */
    @Synchronized
    fun useEmergency(ctx: Context, pkg: String): String {
        val map = read(ctx)
        val e = map[pkg] ?: return "no_block"
        if (remainingMs(ctx, e) <= 0L) return "no_block"
        if (passRemaining(ctx, e) > 0L) return "running"
        if (e.emUsed >= e.emMax) return "none_left"
        map[pkg] = e.copy(
            emUsed = e.emUsed + 1,
            passMs = e.emMin * 60_000L,
            passStartElapsed = SystemClock.elapsedRealtime(),
            passStartWall = System.currentTimeMillis(),
            passBoot = bootCount(ctx)
        )
        write(ctx, map)
        return "ok"
    }

    /** Pass info for the UI: remaining pass ms (0 if none). */
    fun passLeftMs(ctx: Context, e: Entry): Long = passRemaining(ctx, e)

    /** Blocks that are still running (expired ones are cleaned out). */
    @Synchronized
    fun active(ctx: Context): List<Pair<Entry, Long>> {
        val map = read(ctx)
        val res = ArrayList<Pair<Entry, Long>>()
        var changed = false
        val it = map.entries.iterator()
        while (it.hasNext()) {
            val e = it.next().value
            val rem = remainingMs(ctx, e)
            if (rem <= 0L) {
                it.remove()
                changed = true
            } else {
                res.add(e to rem)
            }
        }
        if (changed) write(ctx, map)
        return res
    }

    /**
     * Starts (or extends) a block. An existing longer block is never shortened. When a block is
     * extended, its emergency passes already used (and its pass settings) are kept, so extending
     * can not be used to get fresh passes.
     */
    @Synchronized
    fun add(
        ctx: Context, pkgs: Collection<String>, durationMs: Long,
        emMin: Int = DEF_EM_MIN, emMax: Int = DEF_EM_MAX
    ) {
        val map = read(ctx)
        val nowEl = SystemClock.elapsedRealtime()
        val wall = System.currentTimeMillis()
        val boot = bootCount(ctx)
        for (p in pkgs) {
            val old = map[p]
            if (old != null && remainingMs(ctx, old) >= durationMs) continue
            map[p] = if (old != null && remainingMs(ctx, old) > 0L) {
                old.copy(durationMs = durationMs, startElapsed = nowEl, startWall = wall, boot = boot)
            } else {
                Entry(p, durationMs, nowEl, wall, boot, emMin, emMax)
            }
        }
        write(ctx, map)
    }

    /** Apps that can never be blocked, so the phone always stays usable (calls, emergency, settings, home). */
    fun protectedPackages(ctx: Context): Set<String> {
        val s = mutableSetOf(
            ctx.packageName,
            "com.android.settings",
            "com.android.systemui",
            "com.android.phone",
            "com.android.server.telecom",
            "com.android.dialer",
            "com.google.android.dialer",
            "com.samsung.android.dialer",
            "com.samsung.android.incallui",
            "com.android.emergency",
            "com.google.android.apps.safetyhub"
        )
        val pm = ctx.packageManager
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.queryIntentActivities(home, 0).forEach { s.add(it.activityInfo.packageName) }
            pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.let { s.add(it) }
        } catch (_: Exception) {
        }
        try {
            pm.resolveActivity(Intent(Intent.ACTION_DIAL), PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.let { s.add(it) }
        } catch (_: Exception) {
        }
        return s
    }

    /**
     * Turns the blocker service back on by itself (no manual off/on in Accessibility settings).
     * Works only after the one-time permission grant:
     *   adb shell pm grant com.docera.parwez android.permission.WRITE_SECURE_SETTINGS
     * Returns true if the service is running or was switched on.
     */
    fun tryEnableService(ctx: Context): Boolean {
        if (AppBlockService.connected) return true
        if (ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val me = android.content.ComponentName(ctx, AppBlockService::class.java).flattenToString()
            val cur = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val others = cur.split(':').filter { it.isNotBlank() && it != me }
            // Remove then add again so Android re-binds the service even if it thinks it is "on".
            Settings.Secure.putString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, others.joinToString(":"))
            Settings.Secure.putString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, (others + me).joinToString(":"))
            Settings.Secure.putInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun format(ms: Long): String {
        val totalMin = (ms + 59_999L) / 60_000L
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }
}
