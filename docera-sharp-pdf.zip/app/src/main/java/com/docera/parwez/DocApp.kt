package com.docera.parwez

import android.app.Application
import java.io.PrintWriter
import java.io.StringWriter

/** Remembers the last crash so the App Blocker screen can show why the service stopped. */
class DocApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                getSharedPreferences("docera_diag", MODE_PRIVATE).edit()
                    .putString("crash", sw.toString().take(1500))
                    .putLong("crash_t", System.currentTimeMillis())
                    .commit()
            } catch (_: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }
}
