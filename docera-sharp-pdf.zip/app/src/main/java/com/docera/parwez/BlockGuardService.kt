package com.docera.parwez

import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat

/**
 * Main blocker (StayFocused style): a foreground service (small notification) that keeps running
 * even after Docera is swiped from Recent apps. It uses Usage Access to see which app is in front
 * and, when that app is blocked, covers the screen with a "Blocked by Docera" screen and sends the
 * user home. Needs: Usage access + Display over other apps.
 *
 * If the Accessibility blocker (AppBlockService) is running it does the work instead (it can also
 * cover floating windows), and this service just waits and takes over if that one stops.
 */
class BlockGuardService : Service() {

    companion object {
        @Volatile
        var running: Boolean = false

        private const val CHANNEL = "docera_blocker"
        private const val NOTIF_ID = 4101
        private const val POLL_MS = 500L
        private const val ACTIVE_CHECK_MS = 3000L
        private const val EV_RESUMED = 1 // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND

        fun start(ctx: Context) {
            try {
                val i = Intent(ctx, BlockGuardService::class.java)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Throwable) {
            }
        }

        @Suppress("DEPRECATION")
        fun hasUsageAccess(ctx: Context): Boolean = try {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            } else {
                ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Throwable) {
            false
        }

        fun hasOverlay(ctx: Context): Boolean = try {
            Settings.canDrawOverlays(ctx)
        } catch (_: Throwable) {
            false
        }

        fun ready(ctx: Context): Boolean = hasUsageAccess(ctx) && hasOverlay(ctx)
    }

    private val handler = Handler(Looper.getMainLooper())
    private var cover: View? = null
    private var coverTime: TextView? = null
    private var coverEm: Button? = null
    private var coverPkg: String? = null
    private var emArmedAt = 0L
    private var fg: String? = null
    private var lastQuery = 0L
    private var lastActiveCheck = 0L
    private var lastToast = 0L
    private var protectedCache: Set<String> = emptySet()
    private var protectedAt = 0L

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (_: Throwable) {
            }
            handler.postDelayed(this, POLL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showForeground()
        if (!running) {
            running = true
            handler.removeCallbacks(tick)
            handler.post(tick)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeCover()
        super.onDestroy()
    }

    private fun showForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "App Blocker", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Docera App Blocker is running")
            .setContentText("Blocked apps stay blocked until their time ends.")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun protectedSet(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (protectedCache.isEmpty() || now - protectedAt > 60_000L) {
            protectedCache = BlockStore.protectedPackages(this)
            protectedAt = now
        }
        return protectedCache
    }

    private fun step() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastActiveCheck > ACTIVE_CHECK_MS) {
            lastActiveCheck = now
            if (BlockStore.active(this).isEmpty()) {
                removeCover()
                stopForeground(true)
                stopSelf()
                return
            }
        }
        // The accessibility blocker (if running) handles everything, including floating windows.
        if (AppBlockService.connected) {
            removeCover()
            return
        }
        if (!ready(this)) {
            removeCover()
            return
        }

        updateForeground()
        val p = fg
        if (p == null || p == packageName || p in protectedSet()) {
            removeCover()
            return
        }
        val rem = BlockStore.blockedRemaining(this, p)
        if (rem <= 0L) {
            removeCover()
            return
        }
        val created = cover == null
        coverPkg = p
        showCover(rem)
        updateEmButton()
        if (created) {
            if (now - lastToast > 2500L) {
                lastToast = now
                Toast.makeText(this, "Blocked by Docera · ${BlockStore.format(rem)} left", Toast.LENGTH_SHORT).show()
            }
            goHome()
        }
    }

    /** Reads new usage events and remembers the app that was most recently brought to the front. */
    private fun updateForeground() {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val nowMs = System.currentTimeMillis()
        val begin = if (lastQuery == 0L) nowMs - 60_000L else lastQuery - 1000L
        val ev = usm.queryEvents(begin, nowMs)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == EV_RESUMED) fg = e.packageName
        }
        lastQuery = nowMs
    }

    private fun goHome() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Throwable) {
        }
    }

    private fun buildCover(): View {
        val dp = resources.displayMetrics.density
        val title = TextView(this).apply {
            text = "Blocked by Docera"
            setTextColor(Color.WHITE)
            textSize = 22f
            gravity = Gravity.CENTER
        }
        val time = TextView(this).apply {
            setTextColor(0xFFD4A857.toInt())
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, (8 * dp).toInt(), 0, (16 * dp).toInt())
        }
        coverTime = time
        val btn = Button(this).apply {
            text = "Go home"
            setOnClickListener { goHome() }
        }
        val em = Button(this).apply {
            text = "Emergency open"
            setOnClickListener { onEmergencyTap() }
        }
        coverEm = em
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF111111.toInt())
            isClickable = true
            addView(title)
            addView(time)
            addView(btn)
            addView(em)
        }
    }

    @Suppress("DEPRECATION")
    private fun showCover(remMs: Long) {
        if (cover == null) {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val type = if (Build.VERSION.SDK_INT >= 26) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE
            )
            lp.gravity = Gravity.TOP or Gravity.START
            val v = buildCover()
            wm.addView(v, lp)
            cover = v
        }
        coverTime?.text = "${BlockStore.format(remMs)} left"
    }

    private fun updateEmButton() {
        val b = coverEm ?: return
        val p = coverPkg ?: return
        val left = BlockStore.emergencyLeft(this, p)
        val mins = BlockStore.emergencyMinutes(this, p)
        val armed = emArmedAt != 0L && SystemClock.elapsedRealtime() - emArmedAt < 4000L
        if (!armed) emArmedAt = 0L
        if (left <= 0) {
            b.text = "No emergency opens left"
            b.isEnabled = false
        } else {
            b.isEnabled = true
            b.text = if (armed) "Tap again to open for $mins min" else "Emergency open · $mins min ($left left)"
        }
    }

    /** Two taps (within 4 s) so it can not happen by accident; the block keeps running underneath. */
    private fun onEmergencyTap() {
        val p = coverPkg ?: return
        val now = SystemClock.elapsedRealtime()
        if (emArmedAt == 0L || now - emArmedAt >= 4000L) {
            emArmedAt = now
            updateEmButton()
            return
        }
        emArmedAt = 0L
        if (BlockStore.useEmergency(this, p) == "ok") {
            removeCover()
            Toast.makeText(
                this,
                "Emergency: open for ${BlockStore.emergencyMinutes(this, p)} min · ${BlockStore.emergencyLeft(this, p)} left",
                Toast.LENGTH_LONG
            ).show()
        } else updateEmButton()
    }

    private fun removeCover() {
        val v = cover ?: return
        cover = null
        coverTime = null
        coverEm = null
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Throwable) {
        }
    }
}
