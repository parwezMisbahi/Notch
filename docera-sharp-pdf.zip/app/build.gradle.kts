plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
}

// Values can be overridden from the GitHub workflow (-PappId=... -PappName=...)
val appIdValue = (findProperty("appId") as String?) ?: "com.docera.parwez"
val appNameValue = (findProperty("appName") as String?) ?: "Docera"

android {
  namespace = "com.docera.parwez"
  compileSdk = 36

  defaultConfig {
    applicationId = appIdValue
    minSdk = 24
    targetSdk = 36
    versionCode = (findProperty("verCode") as String?)?.toIntOrNull() ?: 3
    versionName = "1.0.9"
    manifestPlaceholders["appLabel"] = appNameValue
    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  // A fixed signing key (created once by the GitHub workflow and reused) so every new
  // build installs as an UPDATE over the previous one without losing app data.
  val ks = rootProject.file("docera.jks")
  signingConfigs {
    if (ks.exists()) {
      create("docera") {
        storeFile = ks
        storePassword = "docera123"
        keyAlias = "docera"
        keyPassword = "docera123"
      }
    }
  }

  buildTypes {
    debug {
      if (ks.exists()) signingConfig = signingConfigs.getByName("docera")
    }
    release {
      if (ks.exists()) signingConfig = signingConfigs.getByName("docera")
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures { compose = true }
  testOptions { unitTests { isIncludeAndroidResources = true } }
}

dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.core.ktx)
  implementation("androidx.core:core-splashscreen:1.0.1")
  implementation("androidx.biometric:biometric:1.1.0")
  implementation("androidx.fragment:fragment-ktx:1.8.5")
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.robolectric)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
}
