package com.msam.notchcmd

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Offline AI (Qwen, MediaPipe LLM Inference): khuli baat -> assistant ke apne commands.
 * AI sirf command ka text banata hai; asli kaam wahi purana parser karta hai (jo na samjhe wo chalta hi nahi).
 */
object LlmBrain {
    const val URL_1_5B = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"

    private fun p(c: Context) = c.getSharedPreferences("llm", Context.MODE_PRIVATE)
    private fun dir(c: Context) = File(c.filesDir, "llm").apply { mkdirs() }
    fun modelFile(c: Context) = File(dir(c), "model.task")
    private fun partFile(c: Context) = File(dir(c), "model.part")

    fun enabled(c: Context) = p(c).getBoolean("on", false)
    fun setEnabled(c: Context, v: Boolean) { p(c).edit().putBoolean("on", v).apply() }
    fun url(c: Context): String = p(c).getString("url", URL_1_5B) ?: URL_1_5B
    fun setUrl(c: Context, u: String) { p(c).edit().putString("url", u.trim()).apply() }
    fun ready(c: Context) = modelFile(c).let { it.exists() && it.length() > 50_000_000L }
    fun usable(c: Context) = enabled(c) && ready(c)

    @Volatile var downloading = false
    @Volatile var progress = ""

    fun status(c: Context): String = when {
        downloading -> "download ho raha hai $progress"
        ready(c) -> "model taiyar (" + (modelFile(c).length() / 1_000_000L) + " MB)" + if (enabled(c)) ", ON" else ", OFF"
        partFile(c).exists() -> "adhura download (" + (partFile(c).length() / 1_000_000L) + " MB), dobara dabao"
        else -> "model nahi hai (download karo)"
    }

    /** Download (resume ke saath). Alag thread mein chalao. */
    fun download(c: Context, onProgress: (String) -> Unit, onDone: (Boolean, String) -> Unit) {
        if (downloading) { onDone(false, "Download pehle se chal raha hai"); return }
        downloading = true
        Thread {
            var msg = ""
            var ok = false
            try {
                val part = partFile(c)
                var have = if (part.exists()) part.length() else 0L
                var conn = URL(url(c)).openConnection() as HttpURLConnection
                conn.instanceFollowRedirects = true
                conn.connectTimeout = 20_000; conn.readTimeout = 40_000
                if (have > 0) conn.setRequestProperty("Range", "bytes=$have-")
                val code = conn.responseCode
                if (code != 200 && code != 206) {
                    msg = "Server ne mana kiya (code $code). Link check karo"
                } else {
                    if (code == 200 && have > 0) { part.delete(); have = 0L }   // server resume nahi karta: shuru se
                    val total = have + conn.contentLengthLong.coerceAtLeast(0L)
                    val out = FileOutputStream(part, have > 0)
                    val buf = ByteArray(256 * 1024)
                    var done = have
                    var lastTick = 0L
                    conn.inputStream.use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n); done += n
                            val now = System.currentTimeMillis()
                            if (now - lastTick > 700) {
                                lastTick = now
                                progress = if (total > 0) (done * 100 / total).toString() + "%" else (done / 1_000_000L).toString() + " MB"
                                onProgress(progress)
                            }
                        }
                    }
                    out.flush(); out.close()
                    if (total > 0 && done < total) msg = "Download adhura reh gaya, dobara dabao"
                    else {
                        val dest = modelFile(c)
                        if (dest.exists()) dest.delete()
                        ok = part.renameTo(dest)
                        msg = if (ok) "Model download ho gaya" else "Model file save nahi hui"
                    }
                }
            } catch (e: Exception) {
                msg = "Download rukk gaya: " + (e.message ?: "internet check karo") + " (dobara dabao, wahin se shuru hoga)"
            }
            downloading = false; progress = ""
            onDone(ok, msg)
        }.start()
    }

    fun deleteModel(c: Context) {
        unload()
        modelFile(c).delete(); partFile(c).delete()
        setEnabled(c, false)
    }

    // ---------- model chalana ----------
    private var engine: LlmInference? = null

    @Synchronized private fun load(c: Context): LlmInference? {
        engine?.let { return it }
        if (!ready(c)) return null
        return try {
            val o = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile(c).absolutePath)
                .setMaxTokens(1024)
                .build()
            LlmInference.createFromOptions(c.applicationContext, o).also { engine = it }
        } catch (_: Throwable) { null }
    }

    @Synchronized fun unload() { try { engine?.close() } catch (_: Throwable) {}; engine = null }

    // ---------- yaaddasht (phone mein hi, seekhne ke liye) ----------
    private fun key(t: String) = t.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun hist(c: Context): JSONArray = try { JSONArray(p(c).getString("hist", "[]")) } catch (_: Exception) { JSONArray() }

    fun cached(c: Context, user: String): String? {
        val k = key(user); val h = hist(c)
        for (i in h.length() - 1 downTo 0) { val o = h.getJSONObject(i); if (o.optString("k") == k) return o.optString("out") }
        return null
    }

    /** Jo AI-command kaam kar gayi use yaad rakho (agli baar turant, bina AI ke) */
    fun remember(c: Context, user: String, out: String) {
        val k = key(user); if (k.isBlank() || out.isBlank()) return
        val old = hist(c); val n = JSONArray()
        for (i in 0 until old.length()) { val o = old.getJSONObject(i); if (o.optString("k") != k) n.put(o) }
        n.put(JSONObject().put("k", k).put("u", user.trim()).put("out", out))
        val keep = JSONArray(); for (i in maxOf(0, n.length() - 40) until n.length()) keep.put(n.get(i))
        p(c).edit().putString("hist", keep.toString()).apply()
    }

    fun forget(c: Context) { p(c).edit().remove("hist").apply() }
    fun memoryCount(c: Context) = hist(c).length()

    private fun recent(c: Context, n: Int): List<Pair<String, String>> {
        val h = hist(c); val l = ArrayList<Pair<String, String>>()
        for (i in maxOf(0, h.length() - n) until h.length()) { val o = h.getJSONObject(i); l.add(o.optString("u") to o.optString("out")) }
        return l
    }

    private fun system(name: String): String = "You are the brain of a phone voice assistant (address the user as \"$name\"). Convert the user's request (Hindi/Hinglish/English, may have typos) into assistant commands. " +
        "Output ONLY commands, one per line, max 4 lines, no explanations, no numbering. Command forms: " +
        "<app> kholo | <contact> ko call karo | <contact> ko <message text> bhejo | search <query> karo | alarm 6:30 am | 5 minute ka timer | " +
        "wifi on karo | bluetooth off karo | torch on karo | volume badhao | volume kam karo | back | home | " +
        "docera mein <pdf name> pdf kholo | docera library kholo | docera note likho <text> | screenshot note mein daalo | bolo <text>. " +
        "If the user only chats or asks a question, output ONE line: bolo <short Hinglish answer, max 20 words>. Never invent app or contact names; use words the user said."

    private fun shots(name: String) = listOf(
        "whatsapp khol do yaar" to "whatsapp kholo",
        "subah saade chhe baje uthana hai" to "alarm 6:30 am",
        "haris ko bol do main late aaunga" to "haris ko main late aaunga bhejo",
        "tum kaun ho" to "bolo Main aapka assistant hoon, $name. Bolo kya karna hai.",
        "youtube kholo aur lofi search karo" to "youtube kholo\nsearch lofi karo"
    )

    /** ChatML prompt (Qwen). Lambai chhoti rakhi hai taaki 1280 token ke andar rahe. */
    private fun prompt(c: Context, user: String): String {
        val sb = StringBuilder()
        val nm = UsageGuard.userName(c)
        sb.append("<|im_start|>system\n").append(system(nm)).append("<|im_end|>\n")
        for ((u, o) in shots(nm)) sb.append("<|im_start|>user\n").append(u).append("<|im_end|>\n<|im_start|>assistant\n").append(o).append("<|im_end|>\n")
        for ((u, o) in recent(c, 4)) sb.append("<|im_start|>user\n").append(u.take(120)).append("<|im_end|>\n<|im_start|>assistant\n").append(o.take(200)).append("<|im_end|>\n")
        sb.append("<|im_start|>user\n").append(user.take(300)).append("<|im_end|>\n<|im_start|>assistant\n")
        return sb.toString()
    }

    /** topK/temperature/seed ab session options mein hote hain (mediapipe 0.10.27). */
    private fun generate(eng: LlmInference, text: String): String? {
        return try {
            val so = LlmInferenceSession.LlmInferenceSessionOptions.builder()
                .setTopK(20)
                .setTemperature(0.2f)
                .setRandomSeed(7)
                .build()
            val session = LlmInferenceSession.createFromOptions(eng, so)
            try {
                session.addQueryChunk(text)
                session.generateResponse()
            } finally {
                try { session.close() } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {
            try { eng.generateResponse(text) } catch (_: Throwable) { null }
        }
    }

    /** Blocking (alag thread se bulao). Command lines ki list lautata hai, ya khali. */
    fun think(c: Context, user: String): List<String> {
        val eng = load(c) ?: return emptyList()
        val raw = generate(eng, prompt(c, user)) ?: return emptyList()
        return raw.replace("<|im_end|>", "\n").replace("<|im_start|>", "\n").split("\n")
            .map { it.trim().trimStart('-', '*', '>', ' ').trim() }
            .filter { it.isNotBlank() && !it.startsWith("assistant", true) && !it.startsWith("user", true) }
            .take(4)
    }
}
