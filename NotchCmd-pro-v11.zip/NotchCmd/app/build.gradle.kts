plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.msam.notchcmd"
    compileSdk = 34
    defaultConfig { applicationId = "com.msam.notchcmd"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    // Hamesha ek hi signing key: ab naya APK purane ke upar seedha update ho jayega
    signingConfigs {
        create("fixed") {
            storeFile = file("notch.keystore"); storePassword = "notch123"
            keyAlias = "notch"; keyPassword = "notch123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
}
