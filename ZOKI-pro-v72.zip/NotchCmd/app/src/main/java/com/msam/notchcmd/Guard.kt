package com.msam.notchcmd

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Security guard for scheduled / triggered runs (phone may auto-unlock while the owner sleeps).
 * Layers: touch shield with X (stop + lock), lock when the run ends, pickup/movement alarm,
 * charger-unplug alarm, and a dead-man timer (AlarmManager) that locks the phone even if the app dies.
 */
object Guard {
    private fun p(c: Context) = c.getSharedPreferences("guard", Context.MODE_PRIVATE)
    fun on(c: Context) = p(c).getBoolean("on", true)
    fun setOn(c: Context, v: Boolean) { p(c).edit().putBoolean("on", v).apply() }
    fun lockEnd(c: Context) = p(c).getBoolean("lockEnd", true)
    fun setLockEnd(c: Context, v: Boolean) { p(c).edit().putBoolean("lockEnd", v).apply() }
    fun motion(c: Context) = p(c).getBoolean("motion", true)
    fun setMotion(c: Context, v: Boolean) { p(c).edit().putBoolean("motion", v).apply() }
    fun unplug(c: Context) = p(c).getBoolean("unplug", true)
    fun setUnplug(c: Context, v: Boolean) { p(c).edit().putBoolean("unplug", v).apply() }
    /** 0 = low, 1 = medium, 2 = high */
    fun sens(c: Context) = p(c).getInt("sens", 1)
    fun setSens(c: Context, v: Int) { p(c).edit().putInt("sens", v).apply() }
    fun timeoutMin(c: Context) = p(c).getInt("timeout", 10)
    fun setTimeoutMin(c: Context, v: Int) { p(c).edit().putInt("timeout", v).apply() }

    /** OverlayService hooks in here; NotchA11y calls it around its own gestures so they pass through the shield */
    @Volatile var passFn: ((Long) -> Unit)? = null
    @Volatile var passEndFn: (() -> Unit)? = null
    fun pass(ms: Long) { passFn?.invoke(ms) }
    fun passEnd() { passEndFn?.invoke() }

    // ---- dead-man timer: if the run never ends cleanly (crash, hang, app killed), the phone locks by itself ----
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, 9900, Intent(c, GuardReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun arm(c: Context) {
        p(c).edit().putBoolean("armed", true).apply()
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = System.currentTimeMillis() + timeoutMin(c) * 60_000L
        try {
            if (Scheduler.canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c))
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c))
        } catch (_: Exception) {}
    }

    fun disarm(c: Context) {
        p(c).edit().putBoolean("armed", false).apply()
        try { (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c)) } catch (_: Exception) {}
    }

    fun armed(c: Context) = p(c).getBoolean("armed", false)
}

/** Dead-man timer fired: the run did not finish in time, so lock the phone */
class GuardReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Guard.armed(c)) return
        Guard.disarm(c)
        NotchA11y.inst?.act("lock")
        Notify.show(c, 6200, "Phone locked for safety", "A scheduled run did not finish in time, so ZOKI locked the phone.")
    }
}
