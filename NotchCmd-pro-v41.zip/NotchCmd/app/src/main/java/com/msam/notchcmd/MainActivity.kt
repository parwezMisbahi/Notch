package com.msam.notchcmd

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.DatePickerDialog
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.Spinner
import android.widget.Switch
import android.widget.HorizontalScrollView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import android.text.InputType
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private var scrollV: ScrollView? = null
    private var homeV: View? = null
    private var onHome = true
    private var permFn: (() -> Unit)? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showPage(p: View) {
        val sc = scrollV ?: return
        sc.removeAllViews(); sc.addView(p); sc.scrollTo(0, 0)
        onHome = (p === homeV)
        p.alpha = 0f; p.animate().alpha(1f).setDuration(180).start()
        Style.buzz(this, "tick")
    }

    private fun showHome() { homeV?.let { showPage(it) } }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (!onHome) showHome() else super.onBackPressed() }

    /** on/off setting shown as a card with a switch */
    private fun switchRow(title: String, sub: String, get: () -> Boolean, set: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = "card"
            setPadding(dp(16), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(TextView(this).apply { text = title; textSize = 15f })
        if (sub.isNotBlank()) col.addView(TextView(this).apply { text = sub; textSize = 12f; tag = "sub" })
        val sw = Switch(this)
        sw.isChecked = get()
        sw.setOnCheckedChangeListener { _, v -> set(v); Style.buzz(this, "click") }
        row.addView(col); row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        return row
    }

    /** one choice out of a few, shown as chips inside a card */
    private fun chipRow(title: String, sub: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; tag = "card"
            setPadding(dp(16), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
        }
        box.addView(TextView(this).apply { text = title; textSize = 15f })
        if (sub.isNotBlank()) box.addView(TextView(this).apply { text = sub; textSize = 12f; tag = "sub" })
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        val chips = ArrayList<TextView>()
        var sel = selected
        fun paint() {
            chips.forEachIndexed { i, c -> c.tag = if (i == sel) "chipOn" else "chipOff"; Style.skinRec(this, c, Style.theme(this)) }
        }
        options.forEachIndexed { i, o ->
            val c = TextView(this)
            c.text = o; c.gravity = Gravity.CENTER
            c.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }
            c.setOnClickListener { sel = i; paint(); onSelect(i); Style.buzz(this, "tick") }
            chips.add(c); strip.addView(c)
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(strip)
        box.addView(hs)
        paint()
        return box
    }

    private var pickCb: ((String) -> Unit)? = null

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 77 && res == RESULT_OK) {
            val u = data?.data ?: return
            try {
                contentResolver.query(u, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use { cur ->
                    if (cur.moveToFirst()) pickCb?.invoke(cur.getString(0) ?: "")
                }
            } catch (_: Exception) {}
        }
    }

    private var openPlanFn: ((String) -> Unit)? = null
    private var refreshHistFn: (() -> Unit)? = null

    /** every day of a plan; tap a day to edit its topic, skip it, remove it or push the plan later */
    private fun showPlanDays(g: String, refresh: () -> Unit) {
        val dFmt = SimpleDateFormat("d MMM", Locale.ENGLISH)
        val now = System.currentTimeMillis()
        val items = Scheduler.load(this).filter { it.grp == g }.sortedBy { it.at }
        if (items.isEmpty()) return
        val rows = items.map { x ->
            val st = if (x.on) "" else if (x.at < now) "[done] " else "[off] "
            st + dFmt.format(x.at) + "  " + Scheduler.splitCmd(x.cmd).second
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle(g + " (tap a day)").setItems(rows) { _, which ->
            val x = items[which]
            val future = x.at > System.currentTimeMillis()
            val acts = mutableListOf("Edit topic")
            if (future) { acts.add(if (x.on) "Skip this day (leave a gap)" else "Turn this day back on"); acts.add("Remove day, move later posts one day earlier"); acts.add("Postpone this and later posts by one day") }
            AlertDialog.Builder(this).setTitle(dFmt.format(x.at) + ": " + Scheduler.splitCmd(x.cmd).second.take(40))
                .setItems(acts.toTypedArray()) { _, k ->
                    when (acts[k]) {
                        "Edit topic" -> {
                            val et = EditText(this).apply { setText(Scheduler.splitCmd(x.cmd).second) }
                            AlertDialog.Builder(this).setTitle("Topic").setView(et)
                                .setPositiveButton("Save") { _, _ ->
                                    val t = et.text.toString().trim()
                                    if (t.isNotEmpty()) { Scheduler.editTopic(this, x.id, t); refresh() }
                                }.setNegativeButton("Cancel", null).show()
                        }
                        "Skip this day (leave a gap)", "Turn this day back on" -> { Scheduler.setOn(this, x.id, !x.on); refresh() }
                        "Remove day, move later posts one day earlier" -> {
                            Scheduler.remove(this, x.id); Scheduler.shiftPlan(this, g, x.at + 1, -1); refresh()
                        }
                        else -> { Scheduler.shiftPlan(this, g, x.at, 1); refresh() }
                    }
                }.setNegativeButton("Cancel", null).show()
        }.setPositiveButton("Close", null).show()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val scroll = ScrollView(this).apply { background = Style.background(this@MainActivity); isFillViewport = true }
        scrollV = scroll
        fun newPage(title: String): LinearLayout {
            val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(44), dp(18), dp(28)) }
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(10)) }
            head.addView(TextView(this).apply { text = "‹"; textSize = 32f; setPadding(dp(2), 0, dp(18), dp(4)); tag = "back"; setOnClickListener { showHome() } })
            head.addView(TextView(this).apply { text = title; textSize = 22f; tag = "title" })
            p.addView(head)
            return p
        }
        val pSetup = newPage("Setup and control")
        val pSched = newPage("Schedule and plans")
        val pPost = newPage("Posting")
        val pAuto = newPage("Automation")
        val pPhone = newPage("Phone, voice and AI")
        var cur: LinearLayout = pSetup
        fun btn(t: String, primary: Boolean = false, f: () -> Unit) = cur.addView(Button(this).apply { text = t; if (primary) tag = "primary"; setOnClickListener { f() } })
        val permRefresh = ArrayList<() -> Unit>()
        fun perm(label: String, ok: () -> Boolean, f: () -> Unit) {
            val bt = Button(this)
            fun upd() { bt.text = (if (ok()) "✓  " else "✗  ") + label }
            bt.setOnClickListener { f() }
            permRefresh.add { upd() }; upd()
            cur.addView(bt)
        }
        permFn = { permRefresh.forEach { it() } }
        perm("1. Overlay permission", { Settings.canDrawOverlays(this) }) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        perm("2. Mic, contacts, call, notification permission", { checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0 }) {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        perm("2c. Photos permission (to use the image ChatGPT saves)", { GptImage.hasPerm(this) }) {
            requestPermissions(arrayOf(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE), 2)
        }
        perm("2b. Brightness permission (Modify system settings)", { Settings.System.canWrite(this) }) { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        perm("3. Turn on Accessibility (NotchCmd)", { NotchA11y.inst != null }) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3b. Power button: Default digital assistant = NotchCmd") { try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        btn("4. Start (notch button on)", true) { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java)) }
        btn("Check: full app diagnostics") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("cmd", "check app")) }
        btn("Stop") { stopService(Intent(this, OverlayService::class.java)) }
        btn("📄 Download guide PDF (all commands, steps and fixes)") { Toast.makeText(this, Guide.save(this), Toast.LENGTH_LONG).show() }
        btn("Test: open the box now") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).putExtra("show", true)) }
        // ---------- Schedule: fix time par command ----------
        cur = pSched
        cur.addView(TextView(this).apply { text = "\nSchedule (run a command at a fixed time, even when locked)"; textSize = 18f; tag = "sec" })
        btn("S1. Alarms & reminders permission (for exact timing)") { if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
        btn("S2. Battery: set to Unrestricted") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        // ---------- Lock screen: auto-unlock + data ----------
        cur = pPhone
        val pinTv = TextView(this).apply { textSize = 14f }
        fun pinInfo() { val n = Unlocker.pinLen(this); pinTv.text = if (n == 0) "PIN not set" else "PIN set: $n digits" }
        cur.addView(pinTv)
        btn("S3. Set phone unlock PIN") {
            val et = EditText(this).apply { hint = "Phone lock PIN (4-16 digits)"; setSingleLine(true)
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
            AlertDialog.Builder(this).setTitle("Unlock PIN").setMessage("The number of digits is detected automatically. The PIN is stored encrypted.").setView(et)
                .setPositiveButton("Save") { _, _ ->
                    val p = et.text.toString().trim()
                    if (p.length in 4..16 && p.all { it.isDigit() }) { Unlocker.setPin(this, p); Toast.makeText(this, "${p.length}-digit PIN saved", Toast.LENGTH_SHORT).show() }
                    else Toast.makeText(this, "PIN must be 4 to 16 digits", Toast.LENGTH_SHORT).show()
                    pinInfo()
                }.setNeutralButton("Remove PIN") { _, _ -> Unlocker.clearPin(this); pinInfo() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(switchRow("Auto-unlock when locked", "Wakes the screen and enters your PIN before scheduled commands", { Unlocker.unlockOn(this) }) { Unlocker.setUnlockOn(this, it) })
        cur.addView(switchRow("Touch guard during scheduled runs", "Blocks all touches while a scheduled command runs; only the X button works and it stops the run and locks the phone", { Guard.on(this) }) { Guard.setOn(this, it) })
        cur.addView(switchRow("Lock the phone when a scheduled run ends", "Locks right after the command finishes or fails", { Guard.lockEnd(this) }) { Guard.setLockEnd(this, it) })
        cur.addView(switchRow("Pickup / movement alarm", "If the phone is lifted or shaken during a scheduled run, stop and lock it (turn off if you hold the phone at that time)", { Guard.motion(this) }) { Guard.setMotion(this, it) })
        cur.addView(chipRow("Movement sensitivity", "High reacts to small movements", listOf("Low", "Medium", "High"), Guard.sens(this)) { Guard.setSens(this, it) })
        cur.addView(switchRow("Charger unplug alarm", "If the phone was charging and the charger is pulled during a scheduled run, stop and lock it", { Guard.unplug(this) }) { Guard.setUnplug(this, it) })
        val gtVals = listOf(5, 10, 15, 20)
        cur.addView(chipRow("Safety timer", "If a scheduled run is not finished by then, the phone locks by itself, even if the app crashes", gtVals.map { "$it min" }, gtVals.indexOf(Guard.timeoutMin(this)).coerceAtLeast(1)) { Guard.setTimeoutMin(this, gtVals[it]) })
        cur.addView(switchRow("Turn mobile data on if it is off", "Used before scheduled commands and posts", { Unlocker.dataOn(this) }) { Unlocker.setDataOn(this, it) })
        cur.addView(switchRow("Use PIN on the biometric prompt", "Presses \"Use PIN\" and enters the PIN", { Unlocker.bioOn(this) }) { Unlocker.setBioOn(this, it) })
        val gbVals = listOf(2000, 3000, 4000, 5000, 8000)
        cur.addView(chipRow("Gboard mic: run the command after silence of", "When typing, press the send arrow instead", gbVals.map { (it / 1000).toString() + " sec" }, gbVals.indexOf(OfflineVoice.gboard(this))) { i ->
            var n = 0
            while (OfflineVoice.gboard(this) != gbVals[i] && n++ < 6) OfflineVoice.nextGboard(this)
        })
        cur.addView(switchRow("Auto-press the Gboard mic", "Starts Gboard voice typing by itself", { OfflineVoice.gbMic(this) }) { if (it != OfflineVoice.gbMic(this)) OfflineVoice.toggleGbMic(this) })
        cur = pSetup
        btn("D1. Screen dump after 8 sec (open the screen to inspect)") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Turn on Accessibility first", Toast.LENGTH_SHORT).show()
            else {
                Toast.makeText(this, "Open that screen within 8 sec", Toast.LENGTH_LONG).show()
                Handler(Looper.getMainLooper()).postDelayed({
                    val d = a.dump()
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("dump", d))
                    Toast.makeText(this, "Copied (${d.lines().size} lines). Paste it in the chat", Toast.LENGTH_LONG).show()
                }, 8000)
            }
        }
        btn("S6. Test: lock the phone, then try unlock after 6 sec") {
            val a = NotchA11y.inst
            if (a == null) Toast.makeText(this, "Turn on Accessibility first", Toast.LENGTH_SHORT).show()
            else {
                a.act("lock")
                Handler(Looper.getMainLooper()).postDelayed({
                    try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("prep_only", true).putExtra("sched", true)) } catch (_: Exception) {}
                }, 6000)
            }
        }
        cur = pPhone
        pinInfo()
        // ---------- Mobile limit + awaaz ke jawab ----------
        cur.addView(TextView(this).apply { text = "Phone limit and voice"; textSize = 18f; tag = "sec" })
        fun numDialog(title: String, cur: Int, ok: (Int) -> Unit) {
            val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "minutes"; setSingleLine(true); if (cur > 0) setText(cur.toString()) }
            AlertDialog.Builder(this).setTitle(title).setView(et)
                .setPositiveButton("Save") { _, _ -> ok(et.text.toString().trim().toIntOrNull() ?: 0) }
                .setNegativeButton("Cancel", null).show()
        }
        fun appLabel(pkg: String): String = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        btn("U1. Usage access permission (required for limits)") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        val scrBtn = Button(this)
        fun scrLabel() { val m = UsageGuard.screenLimit(this); scrBtn.text = "U2. Daily screen limit: " + if (m <= 0) "OFF" else "$m minutes" }
        scrBtn.setOnClickListener { numDialog("Daily screen limit (minutes, 0 = OFF)", UsageGuard.screenLimit(this)) { UsageGuard.setScreenLimit(this, it); scrLabel() } }
        cur.addView(scrBtn)
        btn("U3. Set an app limit") {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }.filter { it.first != packageName }.sortedBy { it.second.lowercase() }
            AlertDialog.Builder(this).setTitle("Which app?").setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                val (pkg, name) = apps[i]
                numDialog("$name: daily limit (minutes, 0 = remove)", UsageGuard.limits(this)[pkg] ?: 0) {
                    UsageGuard.setLimit(this, pkg, it)
                    Toast.makeText(this, if (it > 0) "$name: $it min/day" else "$name limit removed", Toast.LENGTH_SHORT).show()
                }
            }.show()
        }
        btn("U4. View / remove app limits") {
            val l = UsageGuard.limits(this).entries.sortedBy { appLabel(it.key).lowercase() }
            if (l.isEmpty()) Toast.makeText(this, "No app limits set", Toast.LENGTH_SHORT).show()
            else AlertDialog.Builder(this).setTitle("Tap to remove").setItems(l.map { appLabel(it.key) + "  -  " + it.value + " min/day" }.toTypedArray()) { _, i ->
                UsageGuard.setLimit(this, l[i].key, 0)
                Toast.makeText(this, appLabel(l[i].key) + " limit removed", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Close", null).show()
        }
        cur.addView(switchRow("Voice replies", "Says \"I'm ready\" and \"Done\"", { UsageGuard.voiceOn(this) }) { UsageGuard.setVoiceOn(this, it) })
        cur.addView(chipRow("AI app for research and posts", "Used by research, plugins, channel and Facebook posts, plans and replies",
            ResearchPrefs.ALL.map { it.label + if (ResearchPrefs.installed(this, it)) "" else " ✕" },
            ResearchPrefs.ALL.indexOfFirst { it.key == ResearchPrefs.selected(this).key }) { i -> ResearchPrefs.select(this, ResearchPrefs.ALL[i].key) })
        // ---------- WhatsApp Channel post ----------
        cur = pPost
        cur.addView(TextView(this).apply { text = "\nWhatsApp Channel post"; textSize = 18f; tag = "sec" })
        cur.addView(TextView(this).apply { text = "Say or type: channel post <topic>  (e.g. channel post good morning quote), or just \"channel post\" if your prompt (C3) needs no topic. Today's date is added to the prompt every time. The AI app from R1 writes it, then it is pasted and sent to your channel. You can schedule the same command below."; textSize = 13f; tag = "sub" })
        val chNameBtn = Button(this)
        fun chNameLabel() { chNameBtn.text = "C1. Channel name: " + ChannelPrefs.name(this).ifBlank { "(not set)" } }
        chNameBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Channel name exactly as in WhatsApp"; setSingleLine(true); setText(ChannelPrefs.name(this@MainActivity)) }
            AlertDialog.Builder(this).setTitle("Channel name").setView(et)
                .setPositiveButton("Save") { _, _ -> ChannelPrefs.setName(this, et.text.toString()); chNameLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(chNameBtn)
        cur.addView(chipRow("Post using", "", listOf("WhatsApp", "WhatsApp Business"), if (ChannelPrefs.business(this)) 1 else 0) { i -> if ((i == 1) != ChannelPrefs.business(this)) ChannelPrefs.toggleBusiness(this) })
        val chPromptBtn = Button(this)
        fun chPromptLabel() { chPromptBtn.text = "C3. Prompt for the AI: " + (if (ChannelPrefs.hasCustomPrompt(this)) "custom" else "default") + "  (tap = edit)" }
        chPromptBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Prompt. Use {topic} and {date} where they should go"; setText(ChannelPrefs.prompt(this@MainActivity)); minLines = 4; gravity = Gravity.TOP }
            AlertDialog.Builder(this).setTitle("Prompt for the AI").setMessage("{topic} is replaced by what you say after \"channel post\" (it can be empty). {date} is replaced by today's date; if you do not write {date}, \"Today's date: ...\" is added at the end automatically. Example for a multi-day plan: Continue our 100-day plan. Today is {date}. Work out which day it is and write only today's WhatsApp channel post. Output ONLY the post text.").setView(et)
                .setPositiveButton("Save") { _, _ -> ChannelPrefs.setPrompt(this, et.text.toString()); chPromptLabel() }
                .setNeutralButton("Reset") { _, _ -> ChannelPrefs.setPrompt(this, ""); chPromptLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(chPromptBtn)
        cur.addView(switchRow("After a scheduled post: data off and lock phone", "", { ChannelPrefs.cleanup(this) }) { if (it != ChannelPrefs.cleanup(this)) ChannelPrefs.toggleCleanup(this) })
        cur.addView(switchRow("Also share the post to my WhatsApp status", "", { ChannelPrefs.shareStatus(this) }) { if (it != ChannelPrefs.shareStatus(this)) ChannelPrefs.toggleShareStatus(this) })
        cur.addView(switchRow("Also forward the post to my groups / contacts", "", { ChannelPrefs.shareChats(this) }) { if (it != ChannelPrefs.shareChats(this)) ChannelPrefs.toggleShareChats(this) })
        val chChatsBtn = Button(this)
        fun chChatsLabel() { val n = ChannelPrefs.targets(this).size; chChatsBtn.text = "C6. Groups / contacts to forward to: " + (if (n == 0) "(none)" else "$n chosen") + "  (tap = edit)" }
        chChatsBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "One name per line, exactly as in WhatsApp"; setText(ChannelPrefs.targets(this@MainActivity).joinToString("\n")); minLines = 5; gravity = Gravity.TOP }
            AlertDialog.Builder(this).setTitle("Groups / contacts").setView(et)
                .setMessage("Write each group or contact name on its own line, exactly like WhatsApp shows it (use the full name, so two contacts with a similar name are not mixed up). WhatsApp allows 5 chats at a time, so a longer list is sent in rounds of 5.")
                .setPositiveButton("Save") { _, _ -> ChannelPrefs.setTargets(this, et.text.toString()); chChatsLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(chChatsBtn)
        chNameLabel(); chPromptLabel(); chChatsLabel()
        // ---------- Facebook post ----------
        cur.addView(TextView(this).apply { text = "\nFacebook post"; textSize = 18f; tag = "sec" })
        cur.addView(TextView(this).apply { text = "Say or type: facebook post <topic>  (e.g. facebook post good morning quote). The AI app from R1 writes it, then it is pasted and posted from the Facebook home feed. It posts as the profile that is active in the Facebook app (to post to your Page, switch to the Page profile in Facebook first). You can schedule the same command below."; textSize = 13f; tag = "sub" })
        cur.addView(chipRow("Post using", "", listOf("Facebook", "Facebook Lite"), if (FbPrefs.lite(this)) 1 else 0) { i -> if ((i == 1) != FbPrefs.lite(this)) FbPrefs.toggleLite(this) })
        val fbPromptBtn = Button(this)
        fun fbPromptLabel() { fbPromptBtn.text = "F2. Prompt for the AI: " + (if (FbPrefs.hasCustomPrompt(this)) "custom" else "default") + "  (tap = edit)" }
        fbPromptBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Prompt. Use {topic} and {date} where they should go"; setText(FbPrefs.prompt(this@MainActivity)); minLines = 4; gravity = Gravity.TOP }
            AlertDialog.Builder(this).setTitle("Prompt for the AI").setMessage("{topic} is replaced by what you say after \"facebook post\" (it can be empty). {date} is replaced by today's date; if you do not write {date}, \"Today's date: ...\" is added at the end automatically.").setView(et)
                .setPositiveButton("Save") { _, _ -> FbPrefs.setPrompt(this, et.text.toString()); fbPromptLabel() }
                .setNeutralButton("Reset") { _, _ -> FbPrefs.setPrompt(this, ""); fbPromptLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(fbPromptBtn)
        cur.addView(switchRow("After a scheduled post: data off and lock phone", "", { FbPrefs.cleanup(this) }) { if (it != FbPrefs.cleanup(this)) FbPrefs.toggleCleanup(this) })
        fbPromptLabel()

        // ---------- Facebook: Page / profile to post as ----------
        val fbPageBtn = Button(this)
        fun fbPageLabel() { fbPageBtn.text = "F4. Facebook Page name: " + FbPrefs.pageName(this).ifBlank { "not set" } + "  (tap = edit)" }
        fbPageBtn.setOnClickListener {
            val et = EditText(this); et.setText(FbPrefs.pageName(this)); et.hint = "Name exactly as the New post screen shows it"
            AlertDialog.Builder(this).setTitle("Page name").setMessage("Used by: facebook page post <topic>. The app switches Facebook to this Page first.").setView(et)
                .setPositiveButton("Save") { _, _ -> FbPrefs.setPageName(this, et.text.toString()); FbPrefs.setActive(this, ""); fbPageLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(fbPageBtn)
        val fbProfBtn = Button(this)
        fun fbProfLabel() { fbProfBtn.text = "F5. Facebook profile name: " + FbPrefs.profileName(this).ifBlank { "not set" } + "  (tap = edit)" }
        fbProfBtn.setOnClickListener {
            val et = EditText(this); et.setText(FbPrefs.profileName(this)); et.hint = "Your own profile name"
            AlertDialog.Builder(this).setTitle("Profile name").setMessage("Used by: facebook profile post <topic>. The app switches Facebook to this profile first.").setView(et)
                .setPositiveButton("Save") { _, _ -> FbPrefs.setProfileName(this, et.text.toString()); FbPrefs.setActive(this, ""); fbProfLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(fbProfBtn)
        fbPageLabel(); fbProfLabel()

        // ---------- Poster image + post everywhere ----------
        cur.addView(TextView(this).apply { text = "\nPoster image and post everywhere"; textSize = 18f; tag = "sec" })
        cur.addView(TextView(this).apply { text = "Add the word image or poster to a command (channel post image <topic>, facebook post poster <topic>, post everywhere image <topic>) and the app draws a poster from the AI's first line and posts it with the text as caption. post everywhere <topic> writes once and posts to your channel and Facebook (the channel part also shares to status when C5 is ON)."; textSize = 13f; tag = "sub" })
        cur.addView(switchRow("Poster image with every post", "The AI's first line becomes the poster headline", { PosterPrefs.always(this) }) { if (it != PosterPrefs.always(this)) PosterPrefs.toggleAlways(this) })
        val footBtn = Button(this)
        fun footLabel() { footBtn.text = "I2. Poster footer line: " + (if (PosterPrefs.hasFooter(this)) PosterPrefs.footer(this) else "channel name") + "  (tap = edit)" }
        footBtn.setOnClickListener {
            val et = EditText(this); et.setText(if (PosterPrefs.hasFooter(this)) PosterPrefs.footer(this) else ""); et.hint = "Empty = your channel name"
            AlertDialog.Builder(this).setTitle("Poster footer").setView(et)
                .setPositiveButton("Save") { _, _ -> PosterPrefs.setFooter(this, et.text.toString()); footLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(footBtn)
        footLabel()
        cur.addView(switchRow("Make the post image with ChatGPT (instead of the poster)", "Works when the post has an image (command word image, or Poster image with every post): ChatGPT creates the picture, it is saved, then the caption is written in the same chat. If it fails, the poster is used.", { PosterPrefs.gpt(this) }) { if (it != PosterPrefs.gpt(this)) PosterPrefs.toggleGpt(this) })
        val gptBtn = Button(this)
        fun gptLabel() { gptBtn.text = "I3. Image prompt for ChatGPT: " + (if (PosterPrefs.hasGptPrompt(this)) "custom" else "default") + "  (tap = edit)" }
        gptBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Use {topic} where the topic should go"; setText(PosterPrefs.gptPrompt(this@MainActivity)); minLines = 4; gravity = Gravity.TOP }
            AlertDialog.Builder(this).setTitle("Image prompt for ChatGPT").setView(et)
                .setMessage("{topic} is replaced by what you say after \"channel post\". Example: Create a calm, realistic square photo for a post about: {topic}. No text on the image.")
                .setPositiveButton("Save") { _, _ -> PosterPrefs.setGptPrompt(this, et.text.toString()); gptLabel() }
                .setNeutralButton("Reset") { _, _ -> PosterPrefs.setGptPrompt(this, ""); gptLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(gptBtn)
        gptLabel()

        // ---------- button names + last failure screen ----------
        cur.addView(TextView(this).apply { text = "\nButton names"; textSize = 18f; tag = "sec" })
        cur.addView(TextView(this).apply { text = "If an app update renames a button, change its name here (no new APK needed). When a post fails, the screen is saved automatically: L2 copies it so you can paste it in the chat."; textSize = 13f; tag = "sub" })
        val lblBtn = Button(this)
        lblBtn.text = "L1. Button names the app looks for (tap = edit)"
        lblBtn.setOnClickListener {
            val keys = Labels.NOTES.keys.toList()
            val items = keys.map { k -> (if (Labels.isCustom(this, k)) "* " else "") + (Labels.NOTES[k] ?: k) }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Which button? (* = changed by you)").setItems(items) { _, i ->
                val key = keys[i]
                val et = EditText(this); et.setText(Labels.raw(this, key)); et.minLines = 3; et.gravity = Gravity.TOP
                AlertDialog.Builder(this).setTitle(Labels.NOTES[key] ?: key).setMessage("Names separated by commas. Capital letters do not matter.").setView(et)
                    .setPositiveButton("Save") { _, _ -> Labels.set(this, key, et.text.toString()) }
                    .setNeutralButton("Reset") { _, _ -> Labels.reset(this, key) }
                    .setNegativeButton("Cancel", null).show()
            }.setNeutralButton("Reset all") { _, _ -> Labels.resetAll(this) }.setNegativeButton("Close", null).show()
        }
        cur.addView(lblBtn)
        val dumpBtn = Button(this)
        dumpBtn.text = "L2. Copy the screen saved at the last failure"
        dumpBtn.setOnClickListener {
            val d = Labels.lastDump(this)
            if (d.isBlank()) Toast.makeText(this, "Nothing saved yet", Toast.LENGTH_SHORT).show()
            else {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("dump", d))
                Toast.makeText(this, "Copied (" + d.lines().size + " lines). Paste it in the chat", Toast.LENGTH_LONG).show()
            }
        }
        cur.addView(dumpBtn)
        cur = pPhone
        val nameBtn = Button(this)
        fun nameLabel() { nameBtn.text = "U7. What the assistant calls you: " + if (UsageGuard.hasName(this)) UsageGuard.userName(this) else "muhtaram (set a name)" }
        nameBtn.setOnClickListener {
            val et = EditText(this).apply { hint = "Your name (empty = muhtaram)"; setSingleLine(true); if (UsageGuard.hasName(this@MainActivity)) setText(UsageGuard.userName(this@MainActivity)) }
            AlertDialog.Builder(this).setTitle("What should the assistant call you?").setMessage("This name is used in voice replies and reminders. Leave empty for \"muhtaram\".").setView(et)
                .setPositiveButton("Save") { _, _ -> UsageGuard.setUserName(this, et.text.toString()); nameLabel() }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(nameBtn)
        btn("U6. Test: play the voice") {
            try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("say", "Yes " + UsageGuard.userName(this) + ", I'm ready")) } catch (_: Exception) {}
        }
        scrLabel(); nameLabel()
        // ---------- Offline AI model ----------
        cur.addView(TextView(this).apply { text = "AI"; textSize = 18f; tag = "sec" })
        val aiTv = TextView(this).apply { textSize = 13f; tag = "sub" }
        fun aiInfo() { aiTv.text = "AI: " + LlmBrain.status(this) + "\n" + LlmBrain.onlineStatus(this) + (if (LlmBrain.memoryCount(this) > 0) "\nMemory: ${LlmBrain.memoryCount(this)} items" else "") }
        cur.addView(aiTv)
        btn("A3. Clear AI memory") { LlmBrain.forget(this); aiInfo(); Toast.makeText(this, "Memory cleared", Toast.LENGTH_SHORT).show() }
        aiInfo()
        cur = pSched
        val schedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun dayName(mask: Int): String = if (mask == 0) "Once" else if (mask == 127) "Daily"
            else listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat").filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(",")
        fun refreshSched() {
            schedBox.removeAllViews()
            val all = Scheduler.load(this)
            val dFmt = SimpleDateFormat("d MMM", Locale.ENGLISH)
            all.filter { it.grp.isBlank() }.forEach { s ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); tag = "card"; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) } }
                row.addView(TextView(this).apply { text = "%02d:%02d • %s • %s%s".format(s.hh, s.mm, dayName(s.days), s.cmd, if (s.on) "" else "  (off)"); textSize = 15f })
                val br = LinearLayout(this)
                br.addView(Button(this).apply { text = if (s.on) "OFF" else "ON"; setOnClickListener { Scheduler.setOn(this@MainActivity, s.id, !s.on); refreshSched() } })
                br.addView(Button(this).apply { text = "Run now"; setOnClickListener { startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", s.cmd).putExtra("sched", true)) } })
                br.addView(Button(this).apply { text = "Remove"; setOnClickListener { Scheduler.remove(this@MainActivity, s.id); refreshSched() } })
                row.addView(br); schedBox.addView(row)
            }
            all.filter { it.grp.isNotBlank() }.groupBy { it.grp }.forEach { (g, items) ->
                val pending = items.filter { it.on && it.at > 0L }.sortedBy { it.at }
                val next = pending.firstOrNull()
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); tag = "card"; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) } }
                val info = "Plan: $g\n${items.size} posts • ${pending.size} left" +
                    (if (next != null) "\nNext: " + dFmt.format(next.at) + " %02d:%02d • %s".format(next.hh, next.mm, next.cmd) else "\nFinished or paused")
                row.addView(TextView(this).apply { text = info; textSize = 15f })
                val br = LinearLayout(this)
                val br2 = LinearLayout(this)
                val anyOn = items.any { it.on }
                br.addView(Button(this).apply { text = if (anyOn) "Pause" else "Resume"; setOnClickListener { Scheduler.setPlanOn(this@MainActivity, g, !anyOn); refreshSched() } })
                br.addView(Button(this).apply {
                    text = "View / edit topics"
                    setOnClickListener { showPlanDays(g) { refreshSched() } }
                })
                br2.addView(Button(this).apply {
                    text = "Post next now"
                    setOnClickListener {
                        if (next != null) {
                            Scheduler.setOn(this@MainActivity, next.id, false)
                            startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", next.cmd).putExtra("sched", true))
                            refreshSched()
                        }
                    }
                })
                br2.addView(Button(this).apply { text = "Delete plan"; setOnClickListener { Scheduler.removePlan(this@MainActivity, g); refreshSched() } })
                row.addView(br); row.addView(br2); schedBox.addView(row)
            }
            Style.skin(this, schedBox)
        }
        btn("+ New schedule") {
            val et = EditText(this).apply { hint = "Command, e.g.: open youtube"; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle("Which command should run?").setView(et)
                .setPositiveButton("Next") { _, _ ->
                    val cmd = et.text.toString().trim()
                    if (cmd.isNotEmpty()) TimePickerDialog(this, { _, hh, mm ->
                        val sel = BooleanArray(7)
                        AlertDialog.Builder(this).setTitle("Which days? (none selected = once only)")
                            .setMultiChoiceItems(arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"), sel) { _, i, c -> sel[i] = c }
                            .setPositiveButton("Save") { _, _ ->
                                var mask = 0
                                sel.forEachIndexed { i, b -> if (b) mask = mask or (1 shl i) }
                                Scheduler.add(this, hh, mm, cmd, mask); refreshSched()
                            }.setNegativeButton("Cancel", null).show()
                    }, 8, 0, false).show()
                }.setNegativeButton("Cancel", null).show()
        }
        cur = pAuto
        fun shakeRefresh() { try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("shake_refresh", true)) } catch (_: Exception) {} }
        cur.addView(switchRow("Shake to open the assistant", "Shake the phone while the screen is on", { ShakePrefs.on(this) }) { ShakePrefs.setOn(this, it); shakeRefresh() })
        cur.addView(chipRow("Shakes needed", "", listOf("2", "3", "4", "5", "6"), ShakePrefs.count(this) - 2) { i -> ShakePrefs.setCount(this, i + 2) })
        cur.addView(chipRow("Shake strength", "Normal may trigger while walking fast; hard is safer", listOf("Normal shake", "Hard shake"), if (ShakePrefs.hard(this)) 1 else 0) { i -> ShakePrefs.setHard(this, i == 1) })
        cur = pSched
        val leadVals = intArrayOf(0, 5, 10, 30, 60)
        cur.addView(chipRow("Heads-up notification before a scheduled post", "", listOf("Off", "5 min", "10 min", "30 min", "1 hour"), leadVals.indexOf(Scheduler.lead(this))) { i -> Scheduler.setLead(this, leadVals[i]); Scheduler.armAll(this) })
        fun openPlan(prefill: String) {
            val ctx = this
            val lay = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
            val types = arrayOf("WhatsApp channel", "Facebook", "Both (post everywhere)")
            val prefixes = arrayOf("channel post", "facebook post", "post everywhere")
            val sp = Spinner(ctx).apply { adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, types) }
            val cb = CheckBox(ctx).apply { text = "With poster image" }
            val nameEt = EditText(ctx).apply { hint = "Plan name (optional)"; setSingleLine(true) }
            val et = EditText(ctx).apply {
                hint = "One topic per line.\nLine 1 = day 1, line 2 = day 2 ..."
                setText(prefill)
                minLines = 8; gravity = Gravity.TOP
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            }
            var hh = 8; var mm = 0
            val cal = Calendar.getInstance()
            val dateBtn = Button(ctx); val timeBtn = Button(ctx)
            fun lbl() {
                dateBtn.text = "First post date: " + SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(cal.time)
                timeBtn.text = "Post time every day: %02d:%02d".format(hh, mm)
            }
            dateBtn.setOnClickListener {
                DatePickerDialog(ctx, { _, y, m, d -> cal.set(y, m, d); lbl() }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
            }
            timeBtn.setOnClickListener { TimePickerDialog(ctx, { _, h, mi -> hh = h; mm = mi; lbl() }, hh, mm, false).show() }
            lbl()
            val aiBtn = Button(ctx).apply {
                text = "Let the AI write the topics"
                setOnClickListener {
                    val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
                    val nicheEt = EditText(ctx).apply { hint = "Niche / subject, e.g. healthy habits"; setSingleLine(true) }
                    val daysEt = EditText(ctx).apply { hint = "How many days"; setText("30"); inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(true) }
                    box.addView(nicheEt); box.addView(daysEt)
                    AlertDialog.Builder(ctx).setTitle("AI topics (" + ResearchPrefs.selected(ctx).label + ")").setView(box)
                        .setPositiveButton("Write") { _, _ ->
                            val niche = nicheEt.text.toString().trim()
                            val n = (daysEt.text.toString().trim().toIntOrNull() ?: 30).coerceIn(1, 100)
                            if (niche.isEmpty()) { Toast.makeText(ctx, "Write the niche first", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                            try {
                                startForegroundService(Intent(ctx, OverlayService::class.java).putExtra("topics_niche", niche).putExtra("topics_days", n))
                                Toast.makeText(ctx, "The AI app opens; the topics come back here when it is done", Toast.LENGTH_LONG).show()
                            } catch (_: Exception) {}
                        }.setNegativeButton("Cancel", null).show()
                }
            }
            lay.addView(aiBtn); lay.addView(sp); lay.addView(cb); lay.addView(nameEt); lay.addView(et); lay.addView(dateBtn); lay.addView(timeBtn)
            AlertDialog.Builder(ctx).setTitle("Daily post plan").setView(ScrollView(ctx).apply { addView(lay) })
                .setPositiveButton("Create") { _, _ ->
                    val topics = et.text.toString().lines()
                        .map { it.trim().replace(Regex("^(?i)(day\\s*)?\\d+\\s*[.):\\-]\\s*"), "").trim() }
                        .filter { it.isNotEmpty() }.take(366)
                    if (topics.isEmpty()) { Toast.makeText(ctx, "Add at least one topic", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                    val prefix = prefixes[sp.selectedItemPosition] + (if (cb.isChecked) " image" else "")
                    val name = nameEt.text.toString().trim().ifBlank { "Plan " + SimpleDateFormat("d MMM", Locale.ENGLISH).format(cal.time) }
                    val first = Scheduler.addPlan(ctx, name, hh, mm, cal, prefix, topics)
                    Toast.makeText(ctx, "${topics.size} posts scheduled, first on " + SimpleDateFormat("d MMM, HH:mm", Locale.ENGLISH).format(first), Toast.LENGTH_LONG).show()
                    refreshSched()
                }.setNegativeButton("Cancel", null).show()
        }
        openPlanFn = { t -> openPlan(t) }
        btn("+ Daily post plan (many days at once)") { openPlan("") }
        pSched.addView(schedBox, 1)
        Scheduler.armAll(this); refreshSched()
        // ===================== Automation =====================
        cur = pAuto
        fun listenerOn(): Boolean = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
        fun startCmd(cmd: String) { try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("cmd", cmd)) } catch (_: Exception) {} }
        fun cleanNum(raw: String): String { var d = raw.filter { it.isDigit() }; if (d.startsWith("00")) d = d.substring(2); return d }

        // ---- Routines ----
        cur.addView(TextView(this).apply { text = "\nRoutines (many commands under one name)"; textSize = 18f; tag = "sec" })
        val routineBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun routineDialog(prefName: String, prefLines: String, done: () -> Unit) {
            val ctx = this
            val lay = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
            val nameEt = EditText(ctx).apply { hint = "Routine name, e.g. good night"; setText(prefName); setSingleLine(true) }
            val et = EditText(ctx).apply {
                hint = "One command per line, e.g.\nwifi off\nvolume down\nwait 3\nset alarm 6 am"
                setText(prefLines); minLines = 6; gravity = Gravity.TOP
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            }
            lay.addView(nameEt); lay.addView(et)
            AlertDialog.Builder(ctx).setTitle("Routine").setView(ScrollView(ctx).apply { addView(lay) })
                .setPositiveButton("Save") { _, _ ->
                    val n = nameEt.text.toString().trim()
                    val ls = et.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
                    if (n.isEmpty() || ls.isEmpty()) { Toast.makeText(ctx, "Name and at least one command needed", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                    if (prefName.isNotEmpty() && prefName != n) RoutineStore.remove(ctx, prefName)
                    RoutineStore.put(ctx, n, ls); done()
                }.setNegativeButton("Cancel", null).show()
        }
        fun refreshRoutines() {
            routineBox.removeAllViews()
            val all = RoutineStore.all(this)
            if (all.isEmpty()) routineBox.addView(TextView(this).apply { text = "No routines yet. Say \"routine <name>\" (or just the name) to run one."; textSize = 13f; tag = "sub" })
            all.forEach { (name, lines) ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); tag = "card"; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) } }
                row.addView(TextView(this).apply { text = name + "  (" + lines.size + " steps)\n" + lines.joinToString("\n") { "• $it" }; textSize = 14f })
                val br = LinearLayout(this)
                br.addView(Button(this).apply { text = "Run"; setOnClickListener { startCmd("routine $name") } })
                br.addView(Button(this).apply { text = "Edit"; setOnClickListener { routineDialog(name, lines.joinToString("\n")) { refreshRoutines() } } })
                br.addView(Button(this).apply { text = "Delete"; setOnClickListener { RoutineStore.remove(this@MainActivity, name); refreshRoutines() } })
                row.addView(br); routineBox.addView(row)
            }
            Style.skin(this, routineBox)
        }
        btn("+ New routine") { routineDialog("", "") { refreshRoutines() } }
        cur.addView(routineBox); refreshRoutines()

        // ---- Triggers ----
        cur.addView(TextView(this).apply { text = "\nTriggers (when this happens, do that)"; textSize = 18f; tag = "sec" })
        val trigBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refreshTrig() {
            trigBox.removeAllViews()
            val l = TriggerStore.load(this)
            if (l.isEmpty()) trigBox.addView(TextView(this).apply { text = "No triggers yet"; textSize = 13f; tag = "sub" })
            l.forEach { t ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); tag = "card"; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) } }
                row.addView(TextView(this).apply {
                    text = TriggerStore.label(t.type) + (if (t.type == "battery_low") " (" + t.arg + "%)" else "") + "\n→ " + t.cmd + (if (t.on) "" else "  (off)")
                    textSize = 14f
                })
                val br = LinearLayout(this)
                br.addView(Button(this).apply { text = if (t.on) "OFF" else "ON"; setOnClickListener { TriggerStore.setOn(this@MainActivity, t.type, !t.on); refreshTrig() } })
                br.addView(Button(this).apply { text = "Remove"; setOnClickListener { TriggerStore.remove(this@MainActivity, t.type); refreshTrig() } })
                row.addView(br); trigBox.addView(row)
            }
            Style.skin(this, trigBox)
        }
        btn("+ New trigger") {
            val ctx = this
            val lay = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
            val sp = Spinner(ctx).apply { adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, TriggerStore.TYPES.map { it.second }) }
            val argEt = EditText(ctx).apply { hint = "Low battery % (only for 'Battery drops')"; setText("20"); inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(true) }
            val cmdEt = EditText(ctx).apply { hint = "What to do: any command, e.g. routine night"; setSingleLine(true) }
            lay.addView(sp); lay.addView(argEt); lay.addView(cmdEt)
            AlertDialog.Builder(ctx).setTitle("New trigger (one per event)").setView(ScrollView(ctx).apply { addView(lay) })
                .setPositiveButton("Create") { _, _ ->
                    val cmd = cmdEt.text.toString().trim()
                    if (cmd.isEmpty()) { Toast.makeText(ctx, "Write the command", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                    TriggerStore.set(ctx, TriggerStore.TYPES[sp.selectedItemPosition].first, cmd, (argEt.text.toString().trim().toIntOrNull() ?: 20).coerceIn(1, 99))
                    refreshTrig()
                }.setNegativeButton("Cancel", null).show()
        }
        cur.addView(trigBox); refreshTrig()

        cur = pSched
        // ---- Scheduled WhatsApp message ----
        btn("+ Scheduled WhatsApp message") {
            val ctx = this
            val lay = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
            val numEt = EditText(ctx).apply { hint = "Number with country code, e.g. 923001234567"; inputType = InputType.TYPE_CLASS_PHONE; setSingleLine(true) }
            val pick = Button(ctx).apply {
                text = "Pick from contacts"
                setOnClickListener {
                    pickCb = { n -> numEt.setText(n) }
                    try { startActivityForResult(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI), 77) } catch (_: Exception) {}
                }
            }
            val msgEt = EditText(ctx).apply { hint = "Message"; minLines = 3; gravity = Gravity.TOP; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
            val rep = Spinner(ctx).apply { adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, listOf("Once (next time)", "Every day", "Monday to Friday", "Saturday and Sunday")) }
            var hh = 8; var mm = 0
            val timeBtn = Button(ctx)
            fun lbl() { timeBtn.text = "Send at: %02d:%02d".format(hh, mm) }
            timeBtn.setOnClickListener { TimePickerDialog(ctx, { _, h, mi -> hh = h; mm = mi; lbl() }, hh, mm, false).show() }
            lbl()
            lay.addView(numEt); lay.addView(pick); lay.addView(msgEt); lay.addView(rep); lay.addView(timeBtn)
            AlertDialog.Builder(ctx).setTitle("Scheduled WhatsApp message").setView(ScrollView(ctx).apply { addView(lay) })
                .setPositiveButton("Schedule") { _, _ ->
                    val num = cleanNum(numEt.text.toString())
                    val msg = msgEt.text.toString().trim()
                    if (num.length < 11 || num.startsWith("0")) { Toast.makeText(ctx, "Write the full number with the country code (no leading 0)", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                    if (msg.isEmpty()) { Toast.makeText(ctx, "Write the message", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                    val mask = when (rep.selectedItemPosition) { 1 -> 127; 2 -> 62; 3 -> 65; else -> 0 }
                    Scheduler.add(ctx, hh, mm, "wasend|$num|$msg", mask)
                    Toast.makeText(ctx, "Scheduled", Toast.LENGTH_SHORT).show()
                    refreshSched()
                }.setNegativeButton("Cancel", null).show()
        }

        // ---- Morning briefing ----
        btn("+ Morning briefing (daily, AI writes it)") {
            val ctx = this
            val lay = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
            val et = EditText(ctx).apply { hint = "Topics, e.g. world news, cricket, tech"; minLines = 2; gravity = Gravity.TOP; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
            var hh = 7; var mm = 30
            val timeBtn = Button(ctx)
            fun lbl() { timeBtn.text = "Every day at: %02d:%02d".format(hh, mm) }
            timeBtn.setOnClickListener { TimePickerDialog(ctx, { _, h, mi -> hh = h; mm = mi; lbl() }, hh, mm, false).show() }
            lbl()
            lay.addView(et); lay.addView(timeBtn)
            AlertDialog.Builder(ctx).setTitle("Morning briefing").setView(ScrollView(ctx).apply { addView(lay) })
                .setPositiveButton("Schedule") { _, _ ->
                    val topics = et.text.toString().trim().replace("\n", ", ")
                    if (topics.isEmpty()) { Toast.makeText(ctx, "Write the topics", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                    Scheduler.add(ctx, hh, mm, "briefing|$topics", 127)
                    Toast.makeText(ctx, "Briefing scheduled. It is saved as a Docera note.", Toast.LENGTH_LONG).show()
                    refreshSched()
                }.setNegativeButton("Cancel", null).show()
        }

        cur = pAuto
        // ---- Notification digest ----
        perm("N1. Notification access (needed for digest and auto-reply)", { listenerOn() }) { try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (_: Exception) {} }
        fun digLabel() {}
        cur.addView(switchRow("Collect notifications for the digest", "Kept only on this phone; codes and passwords are skipped", { DigestStore.on(this) }) { v ->
            if (v && !listenerOn()) Toast.makeText(this, "Turn on notification access first (N1)", Toast.LENGTH_LONG).show()
            DigestStore.setOn(this, v)
        })
        cur = pSched
        btn("+ Daily notification digest (AI summary)") {
            TimePickerDialog(this, { _, hh, mm ->
                Scheduler.add(this, hh, mm, "digest", 127)
                Toast.makeText(this, "Digest scheduled. It is saved as a Docera note.", Toast.LENGTH_LONG).show()
                refreshSched()
            }, 21, 0, false).show()
        }
        cur = pAuto
        btn("Run the digest now") { startCmd("digest") }
        btn("Clear the collected notifications") { DigestStore.clear(this); digLabel() }

        // ---- WhatsApp auto-reply (asks you first) ----
        cur.addView(switchRow("WhatsApp reply helper (asks you first)", "Notification with quick replies and an AI draft; nothing is sent without your tap", { AutoReplyPrefs.on(this) }) { v ->
            if (v && !listenerOn()) Toast.makeText(this, "Turn on notification access first (N1)", Toast.LENGTH_LONG).show()
            AutoReplyPrefs.setOn(this, v)
        })
        btn("N4. Quick reply texts") {
            val ctx = this
            val lay = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
            val e1 = EditText(ctx).apply { setText(AutoReplyPrefs.t1(ctx)) }
            val e2 = EditText(ctx).apply { setText(AutoReplyPrefs.t2(ctx)) }
            lay.addView(e1); lay.addView(e2)
            AlertDialog.Builder(ctx).setTitle("Quick replies 1 and 2").setView(ScrollView(ctx).apply { addView(lay) })
                .setPositiveButton("Save") { _, _ -> AutoReplyPrefs.setTexts(ctx, e1.text.toString().trim(), e2.text.toString().trim()) }
                .setNegativeButton("Cancel", null).show()
        }
        cur.addView(switchRow("Reply helper: skip group chats", "", { AutoReplyPrefs.skipGroups(this) }) { AutoReplyPrefs.setSkipGroups(this, it) })

        cur.addView(TextView(this).apply {
            text = "\nTips: select text or a link in any app, tap Share, choose NotchCmd. Say \"summarize screen\" to get the current screen summarized. In a routine, \"wait 5\" pauses 5 seconds."
            textSize = 13f
        })

        cur = pPost
        cur.addView(TextView(this).apply { text = "\nPost history"; textSize = 18f; tag = "sec" })
        val histBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refreshHist() {
            histBox.removeAllViews()
            val l = PostLog.load(this).take(15)
            if (l.isEmpty()) histBox.addView(TextView(this).apply { text = "No posts yet"; textSize = 13f; tag = "sub" })
            val fmt = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH)
            l.forEach { e ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); tag = "card"; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) } }
                row.addView(TextView(this).apply {
                    text = fmt.format(e.time) + " • " + (if (e.ok) "posted" else "FAILED") + " • " + e.kind + (if (e.sched) " (scheduled)" else "") +
                        "\n" + e.topic + (if (!e.ok && e.note.isNotBlank()) "\n" + e.note else "")
                    textSize = 14f
                })
                if (!e.ok && e.cmd.isNotBlank()) row.addView(Button(this).apply {
                    text = "Retry"
                    setOnClickListener {
                        try { startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("cmd", e.cmd)) } catch (_: Exception) {}
                        Toast.makeText(this@MainActivity, "Retrying: " + e.topic, Toast.LENGTH_SHORT).show()
                    }
                })
                histBox.addView(row)
            }
            Style.skin(this, histBox)
        }
        btn("Clear post history") { PostLog.clear(this); refreshHist() }
        cur.addView(histBox)
        refreshHistFn = { refreshHist() }
        refreshHist()
        // ---------- home: categories ----------
        val home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(52), dp(18), dp(28)) }
        homeV = home
        home.addView(TextView(this).apply { text = "NotchCmd"; textSize = 32f; tag = "title" })
        home.addView(TextView(this).apply { text = "build v41  •  double-tap the notch, shake, or say \"MJ\""; textSize = 13f; tag = "sub"; setPadding(0, 0, 0, dp(12)) })
        home.addView(switchRow("MJ voice wake", "Listens for \"MJ\" while the screen is on",
            { getSharedPreferences("n", MODE_PRIVATE).getBoolean("wake", false) }) { v ->
            if (v && !Settings.canDrawOverlays(this)) Toast.makeText(this, "Give the overlay permission first (Setup)", Toast.LENGTH_LONG).show()
            else try { startForegroundService(Intent(this, OverlayService::class.java).putExtra("wake", v)) } catch (_: Exception) {}
        })
        fun category(icon: String, title: String, desc: String, page: LinearLayout) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = "card"
                setPadding(dp(16), dp(16), dp(16), dp(16))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }
                setOnClickListener { showPage(page) }
            }
            row.addView(TextView(this).apply { text = icon; textSize = 28f; setPadding(0, 0, dp(16), 0) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            col.addView(TextView(this).apply { text = title; textSize = 17f })
            col.addView(TextView(this).apply { text = desc; textSize = 12f; tag = "sub" })
            row.addView(col)
            row.addView(TextView(this).apply { text = "›"; textSize = 26f; tag = "back" })
            home.addView(row)
        }
        category("⚙", "Setup and control", "Permissions, start and stop, tests", pSetup)
        category("🗓", "Schedule and plans", "Timed commands, daily post plans, WhatsApp messages, briefing", pSched)
        category("📣", "Posting", "WhatsApp channel, Facebook, poster, post history", pPost)
        category("⚡", "Automation", "Routines, triggers, shake, digest, reply helper", pAuto)
        category("🎙", "Phone, voice and AI", "Lock screen, limits, voice, AI app", pPhone)
        val styleNames = Style.names
        home.addView(chipRow("Theme", "", styleNames.map { Style.labels[it] ?: it }, styleNames.indexOf(Style.cur(this))) { i ->
            Style.set(this, styleNames[i]); Style.buzz(this, "heavy"); recreate()
        })
        listOf(home, pSetup, pSched, pPost, pAuto, pPhone).forEach { Style.skin(this, it) }
        setContentView(scroll)
        showPage(home)
        Style.enter(home)
        if (b == null) Style.buzz(this, "launch")
    }

    // App kholte hi (ya permission dene ke baad) service khud chalu: mic sirf "MJ" ke liye sunta rehta hai
    override fun onResume() {
        super.onResume()
        refreshHistFn?.invoke()
        permFn?.invoke()
        PlanDraft.take(this)?.let { openPlanFn?.invoke(it) }   // topics written by the AI app: open the plan dialog with them
        if (Settings.canDrawOverlays(this) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) {
            try { startForegroundService(Intent(this, OverlayService::class.java)) } catch (_: Exception) {}
        }
    }
}
