package com.msam.notchcmd

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Offline voice (Vosk): internet ya Google ke bina phone ke andar hi awaaz -> text */
object OfflineVoice {
    private const val BASE = "https://alphacephei.com/vosk/models/"
    private val zips = mapOf("hi" to "vosk-model-small-hi-0.22", "hb" to "vosk-model-hi-0.22", "en" to "vosk-model-small-en-in-0.4")
    private val cache = HashMap<String, Model>()

    fun mode(c: Context): String = c.getSharedPreferences("offvoice", Context.MODE_PRIVATE).getString("m", "off") ?: "off"
    fun setMode(c: Context, m: String) { c.getSharedPreferences("offvoice", Context.MODE_PRIVATE).edit().putString("m", m).apply() }
    /** Google recognizer ki bhasha: "hi" = Hindi+English (hi-IN), "en" = en-IN */
    fun glang(c: Context): String = c.getSharedPreferences("offvoice", Context.MODE_PRIVATE).getString("gl", "hi") ?: "hi"
    fun nextGlang(c: Context): String { val n = if (glang(c) == "hi") "en" else "hi"; c.getSharedPreferences("offvoice", Context.MODE_PRIVATE).edit().putString("gl", n).apply(); return n }
    /** Gboard voice-typing mode: 0 = band, warna itne ms chup rehne par command chalti hai */
    fun gboard(c: Context): Int = c.getSharedPreferences("offvoice", Context.MODE_PRIVATE).getInt("gb", 0)
    fun nextGboard(c: Context): Int {
        val l = listOf(0, 1500, 2000, 3000)
        val n = l[(l.indexOf(gboard(c)) + 1) % l.size]
        c.getSharedPreferences("offvoice", Context.MODE_PRIVATE).edit().putInt("gb", n).apply(); return n
    }
    /** Gboard mode mein keyboard ka mic assistant khud dabaye (default ON) */
    fun gbMic(c: Context): Boolean = c.getSharedPreferences("offvoice", Context.MODE_PRIVATE).getBoolean("gbmic", true)
    fun toggleGbMic(c: Context): Boolean { val n = !gbMic(c); c.getSharedPreferences("offvoice", Context.MODE_PRIVATE).edit().putBoolean("gbmic", n).apply(); return n }
    fun next(c: Context): String { val n = when (mode(c)) { "off" -> "hi"; "hi" -> "hb"; "hb" -> "en"; else -> "off" }; setMode(c, n); return n }

    private fun dir(c: Context, m: String) = File(c.filesDir, "vosk/$m")
    fun ready(c: Context, m: String): Boolean = File(dir(c, m), "am").exists()

    /** model download + unzip (background thread). progress 0..100 */
    fun download(c: Context, m: String, progress: (Int) -> Unit, done: (Boolean, String) -> Unit) {
        val name = zips[m] ?: run { done(false, "Model nahi mila"); return }
        Thread {
            try {
                val tmpZip = File(c.cacheDir, "$name.zip")
                val con = URL(BASE + "$name.zip").openConnection() as HttpURLConnection
                con.connectTimeout = 15000; con.readTimeout = 30000
                val total = con.contentLength.toLong().coerceAtLeast(1L)
                var got = 0L; var last = -1
                con.inputStream.use { ins -> FileOutputStream(tmpZip).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf); if (n < 0) break
                        out.write(buf, 0, n); got += n
                        val p = (got * 100 / total).toInt().coerceAtMost(99)
                        if (p != last) { last = p; progress(p) }
                    }
                } }
                val tmpDir = File(c.filesDir, "vosk/tmp_$m"); tmpDir.deleteRecursively(); tmpDir.mkdirs()
                ZipInputStream(tmpZip.inputStream()).use { zin ->
                    while (true) {
                        val e = zin.nextEntry ?: break
                        val f = File(tmpDir, e.name)
                        if (!f.canonicalPath.startsWith(tmpDir.canonicalPath)) continue   // zip-slip se bachav
                        if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); FileOutputStream(f).use { zin.copyTo(it) } }
                    }
                }
                val inner = tmpDir.listFiles()?.firstOrNull { it.isDirectory } ?: throw Exception("zip khaali")
                val dst = dir(c, m); dst.deleteRecursively(); dst.parentFile?.mkdirs()
                if (!inner.renameTo(dst)) throw Exception("model rakh nahi paya")
                tmpDir.deleteRecursively(); tmpZip.delete(); cache.remove(m)
                progress(100); done(true, "Offline voice model taiyar")
            } catch (e: Exception) { done(false, "Download fail: " + (e.message ?: "error")) }
        }.start()
    }

    private fun model(c: Context, m: String): Model = synchronized(cache) {
        cache.getOrPut(m) { Model(dir(c, m).absolutePath) }
    }

    class Cb(val onReady: () -> Unit, val onPartial: (String) -> Unit, val onFinal: (String) -> Unit, val onError: (String) -> Unit)

    /** lagatar sunta hai (beech mein restart ka gap nahi). stop() se band */
    class Session(c: Context, m: String, private val cb: Cb) {
        @Volatile private var svc: SpeechService? = null
        @Volatile private var stopped = false
        init {
            Thread {
                try {
                    val mdl = model(c.applicationContext, m)
                    if (stopped) return@Thread
                    val rec = Recognizer(mdl, 16000.0f)
                    val s = SpeechService(rec, 16000.0f)
                    svc = s
                    if (stopped) { s.shutdown(); return@Thread }
                    s.startListening(object : org.vosk.android.RecognitionListener {
                        override fun onPartialResult(h: String?) { txt(h, "partial")?.let { if (!stopped) cb.onPartial(it) } }
                        override fun onResult(h: String?) { txt(h, "text")?.let { if (!stopped) cb.onFinal(it) } }
                        override fun onFinalResult(h: String?) { txt(h, "text")?.let { if (!stopped) cb.onFinal(it) } }
                        override fun onError(e: Exception?) { if (!stopped) cb.onError(e?.message ?: "error") }
                        override fun onTimeout() {}
                    })
                    cb.onReady()
                } catch (e: Throwable) { if (!stopped) cb.onError(e.message ?: "error") }
            }.start()
        }
        private fun txt(j: String?, k: String): String? {
            if (j == null) return null
            return try { JSONObject(j).optString(k).trim().ifBlank { null } } catch (_: Exception) { null }
        }
        fun stop() { stopped = true; try { svc?.stop(); svc?.shutdown() } catch (_: Exception) {} }
    }
}
