package com.msam.notchcmd

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.util.Random

/** Poster (image post) settings. */
object PosterPrefs {
    private fun p(c: Context) = c.getSharedPreferences("poster", Context.MODE_PRIVATE)

    /** every Facebook / channel / everywhere post gets a poster image (a command word like "image" does it for one post) */
    fun always(c: Context): Boolean = p(c).getBoolean("always", false)
    fun toggleAlways(c: Context): Boolean { val n = !always(c); p(c).edit().putBoolean("always", n).apply(); return n }

    /** small line at the bottom of the poster; empty = your channel name */
    fun footer(c: Context): String = (p(c).getString("footer", "") ?: "").trim().ifBlank { ChannelPrefs.name(c) }
    fun hasFooter(c: Context): Boolean = (p(c).getString("footer", "") ?: "").isNotBlank()
    fun setFooter(c: Context, v: String) { p(c).edit().putString("footer", v.trim()).apply() }

    /** make the post image with ChatGPT (create, save, then caption in the same chat) instead of drawing a poster */
    fun gpt(c: Context): Boolean = p(c).getBoolean("gpt", false)
    fun toggleGpt(c: Context): Boolean { val n = !gpt(c); p(c).edit().putBoolean("gpt", n).apply(); return n }
    /** less strict picture check when Android hides which app saved the picture (see GptImage.fetch) */
    fun gptLoose(c: Context): Boolean = p(c).getBoolean("gptloose", false)
    fun toggleGptLoose(c: Context): Boolean { val n = !gptLoose(c); p(c).edit().putBoolean("gptloose", n).apply(); return n }
    const val GPT_PROMPT = "Create a beautiful, eye-catching square (1:1) image for a social media post about: {topic}. Do not put any text or words on the image."
    fun gptPrompt(c: Context): String = (p(c).getString("gptp", "") ?: "").ifBlank { GPT_PROMPT }
    fun hasGptPrompt(c: Context): Boolean = (p(c).getString("gptp", "") ?: "").isNotBlank()
    fun setGptPrompt(c: Context, v: String) { p(c).edit().putString("gptp", v.trim()).apply() }
    /** {topic} = what you said after "channel post"; with no topic the start of the post prompt is used */
    fun buildGptPrompt(c: Context, topic: String, fallback: String): String {
        val body = topic.ifBlank { fallback.take(300) }
        val t = gptPrompt(c)
        return if (t.contains("{topic}")) t.replace("{topic}", body) else t + "\n\nTopic: " + body
    }

    /** added to the AI prompt so the answer starts with a short poster line */
    const val PROMPT_SUFFIX = "\n\nFormat of your answer: the first line is a short poster headline (maximum 10 words, plain text, no quotes, no emojis, no markdown). Then one empty line. Then the full post text."
}

object PosterBus {
    /** caption of the last poster, kept in the app so it can be typed in even when the clipboard cannot be read */
    @Volatile var lastCaption: String = ""
    /** title to put on top of the copied post text (PostTitle); the caption step does it where the clipboard may be read */
    @Volatile var prependTitle: String? = null
    @Volatile var titleOnImage: Boolean = false
    /** 0 = title on top, 1 = at the end, 2 = both */
    @Volatile var titlePos: Int = 0
    @Volatile var titleDone: (() -> Unit)? = null
    /** called by PosterActivity with the poster picture (null = could not make it) */
    @Volatile var onDone: ((Uri?) -> Unit)? = null
    /** set = the picture comes from ChatGPT: PosterActivity only reads the caption from the clipboard and hands this picture back */
    @Volatile var fixedUri: Uri? = null
}

/** The picture ChatGPT saved to the gallery: found by time, copied into the app (as JPEG) so it can be shared. */
object GptImage {
    /** what the last search saw: owner app and folder of the new pictures (shown when no picture is taken) */
    @Volatile var diag: String = ""
    fun hasPerm(c: Context): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= 33) c.checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) == 0
        else c.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == 0

    /**
     * blocking (call from a thread): waits up to about 9 s for the picture that ChatGPT itself saved since sinceSec.
     * Privacy first: a picture of any other app (WhatsApp, Telegram, camera, screenshots...) is never taken.
     *  - strict (default): only a picture whose owner app is ChatGPT. Owner not readable = no picture (the poster is used).
     *  - loose (Settings switch): when the owner is not readable, a picture is taken only if exactly ONE new picture sits
     *    in Pictures/ named like ChatGPT names it (file_<32 hex>.png) AND it is square. Two possible pictures = nothing is taken.
     */
    fun fetch(c: Context, sinceSec: Long, loose: Boolean = false): Uri? {
        val base = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val M = android.provider.MediaStore.Images.Media
        val q = android.os.Build.VERSION.SDK_INT >= 29
        val proj = if (q) arrayOf(M._ID, M.OWNER_PACKAGE_NAME, M.RELATIVE_PATH, M.DISPLAY_NAME) else arrayOf(M._ID, M.DATA, M.DISPLAY_NAME)
        val gptPkg = "com.openai.chatgpt"
        val nameRe = Regex("^file_[0-9a-f]{32}\\.(png|jpe?g|webp)$")
        class Row(val id: Long, val owner: String, val path: String, val name: String)
        fun blocked(r: Row): Boolean {
            val p = (r.path + "/" + r.name).lowercase()
            return listOf("whatsapp", "telegram", "signal", "messenger", "instagram", "snapchat", "viber", "dcim/camera", "screenshot").any { p.contains(it) }
        }
        fun inPicturesRoot(r: Row): Boolean {
            val full = (if (r.path.lowercase().endsWith(r.name.lowercase())) r.path else r.path + "/" + r.name).lowercase().replace("//", "/")
            return Regex("(^|/)pictures/[^/]+$").containsMatchIn(full)
        }
        fun load(r: Row): Uri? {
            val u = android.content.ContentUris.withAppendedId(base, r.id)
            val bm = c.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it) } ?: return null
            val out = java.io.ByteArrayOutputStream()
            bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out)
            val dir = File(c.cacheDir, "share").apply { mkdirs() }
            dir.listFiles()?.filter { it.name.startsWith("gpt_") && System.currentTimeMillis() - it.lastModified() > 86_400_000L }?.forEach { it.delete() }
            val fname = "gpt_" + System.currentTimeMillis() + ".jpg"
            File(dir, fname).writeBytes(out.toByteArray())
            return Uri.parse("content://com.msam.notchcmd.share/" + fname)
        }
        fun isSquare(r: Row): Boolean {
            val u = android.content.ContentUris.withAppendedId(base, r.id)
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
            return o.outWidth >= 512 && o.outWidth == o.outHeight
        }
        diag = ""
        for (k in 0 until 13) {
            try {
                val rows = ArrayList<Row>()
                c.contentResolver.query(base, proj, M.DATE_ADDED + " >= ?", arrayOf(sinceSec.toString()), M.DATE_ADDED + " DESC")?.use { cur ->
                    while (cur.moveToNext()) {
                        val owner = if (q) (cur.getString(1) ?: "") else ""
                        val path = if (q) (cur.getString(2) ?: "") else (cur.getString(1) ?: "")
                        rows.add(Row(cur.getLong(0), owner, path, cur.getString(if (q) 3 else 2) ?: ""))
                    }
                }
                val ok = rows.filter { !blocked(it) }
                diag = rows.take(4).joinToString("; ") { (if (it.owner.isBlank()) "owner hidden" else it.owner) + " in " + it.path.ifBlank { "?" } }
                // 1) the owner is readable: it must be ChatGPT, nothing else
                ok.firstOrNull { it.owner == gptPkg }?.let { r -> load(r)?.let { return it } }
                // 2) loose mode, owner not readable: one single ChatGPT-looking square picture
                if (loose) {
                    val maybe = ok.filter { it.owner.isBlank() && inPicturesRoot(it) && nameRe.matches(it.name.lowercase()) }
                    if (maybe.size == 1 && isSquare(maybe[0])) load(maybe[0])?.let { return it }
                    if (maybe.size > 1) diag = "more than one possible picture, none taken (" + diag + ")"
                }
            } catch (_: Throwable) {}
            try { Thread.sleep(700) } catch (_: Exception) {}
        }
        if (diag.isBlank()) diag = "no new picture at all"
        return null
    }
}

object Poster {
    class Result(val uri: Uri, val caption: String)

    private val palettes = arrayOf(
        intArrayOf(0xFF0B3D2E.toInt(), 0xFF1E8A63.toInt()),   // green
        intArrayOf(0xFF0D1B3E.toInt(), 0xFF2F5FB3.toInt()),   // navy
        intArrayOf(0xFF4A0E1E.toInt(), 0xFFB5424F.toInt()),   // maroon
        intArrayOf(0xFF123B45.toInt(), 0xFF2A9D8F.toInt()),   // teal
        intArrayOf(0xFF2B1B3F.toInt(), 0xFF7B4FB0.toInt()),   // purple
        intArrayOf(0xFF1F1F24.toInt(), 0xFF5A5A66.toInt())    // charcoal
    )

    private fun clean(s: String): String =
        s.replace(Regex("[*#_`>]+"), "").replace("\u201c", "").replace("\u201d", "").replace("\"", "")
            .replace(Regex("(?i)^\\s*(headline|title|poster( line)?|caption)\\s*[:\\-]\\s*"), "").trim()

    /** first line = poster headline, the rest = caption (no separate caption -> the whole text is the caption) */
    fun split(text: String): Pair<String, String> {
        val t = text.trim()
        val lines = t.lines()
        val first = clean(lines.firstOrNull() ?: "")
        val rest = lines.drop(1).joinToString("\n").trim()
        if (first.isNotBlank() && rest.isNotBlank() && first.length <= 120) return Pair(first, rest)
        val head = clean(t.split(Regex("(?<=[.!?\\u0964\\u06d4])\\s")).firstOrNull() ?: t).take(110)
        return Pair(head, t)
    }

    fun make(c: Context, text: String): Result? {
        return try {
            val (head, caption) = split(text)
            if (head.isBlank()) return null
            val size = 1080
            val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bm)
            val pal = palettes[Random(System.nanoTime()).nextInt(palettes.size)]
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            bg.shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), pal[0], pal[1], Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bg)
            val line = Paint(Paint.ANTI_ALIAS_FLAG)
            line.style = Paint.Style.STROKE; line.strokeWidth = 4f; line.color = 0x66FFFFFF
            cv.drawRoundRect(RectF(40f, 40f, size - 40f, size - 40f), 36f, 36f, line)

            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
            tp.color = Color.WHITE
            tp.typeface = Typeface.DEFAULT_BOLD
            val maxW = 880
            val maxH = 700
            var px = 104f
            tp.textSize = px
            var lay = StaticLayout.Builder.obtain(head, 0, head.length, tp, maxW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 1.15f).build()
            while (lay.height > maxH && px > 36f) {
                px -= 4f
                tp.textSize = px
                lay = StaticLayout.Builder.obtain(head, 0, head.length, tp, maxW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 1.15f).build()
            }
            cv.save()
            cv.translate((size - maxW) / 2f, (size - lay.height) / 2f - 20f)
            lay.draw(cv)
            cv.restore()

            val foot = PosterPrefs.footer(c)
            if (foot.isNotBlank()) {
                val fp = TextPaint(Paint.ANTI_ALIAS_FLAG)
                fp.color = 0xCCFFFFFF.toInt(); fp.textSize = 38f; fp.textAlign = Paint.Align.CENTER
                cv.drawLine(size / 2f - 90f, size - 150f, size / 2f + 90f, size - 150f, line)
                cv.drawText(foot.take(40), size / 2f, size - 95f, fp)
            }

            val out = java.io.ByteArrayOutputStream()
            bm.compress(Bitmap.CompressFormat.JPEG, 92, out)
            val bytes = out.toByteArray()
            val dir = File(c.cacheDir, "share").apply { mkdirs() }
            val name = "poster_" + System.currentTimeMillis() + ".jpg"
            File(dir, name).writeBytes(bytes)
            Plugins.saveToGallery(c, bytes, "image/jpeg", "poster_" + System.currentTimeMillis())
            Result(Uri.parse("content://com.msam.notchcmd.share/" + name), caption)
        } catch (_: Throwable) { null }
    }
}

/**
 * Transparent Activity: while it is in front it may read the clipboard (a background service may not).
 * Reads the copied AI answer, draws the poster from its first line, puts the caption back on the clipboard.
 */
class PosterActivity : Activity() {
    private var started = false
    override fun onCreate(b: Bundle?) { super.onCreate(b) }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || started) return
        started = true
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val text = try { cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() } catch (_: Exception) { null }
        val pt = PosterBus.prependTitle
        if (pt != null) {   // only put the title on top of the copied post text
            PosterBus.prependTitle = null
            val body = text?.trim().orEmpty()
            val pos = PosterBus.titlePos
            var nt = body
            if (nt.isEmpty()) nt = pt
            else {
                if ((pos == 0 || pos == 2) && !nt.startsWith(pt)) nt = pt + "\n\n" + nt
                if ((pos == 1 || pos == 2) && !nt.endsWith(pt)) nt = nt + "\n\n" + pt
            }
            try { cm.setPrimaryClip(ClipData.newPlainText("post", nt)) } catch (_: Exception) {}
            if (PosterBus.titleOnImage) PosterBus.lastCaption = nt
            val cb1 = PosterBus.titleDone
            PosterBus.titleDone = null
            finish()
            cb1?.invoke()
            return
        }
        val fixed = PosterBus.fixedUri
        if (fixed != null) {   // picture made by ChatGPT: the clipboard holds the caption, keep it as it is
            PosterBus.fixedUri = null
            PosterBus.lastCaption = text?.trim().orEmpty()
            val cb0 = PosterBus.onDone
            PosterBus.onDone = null
            finish()
            cb0?.invoke(fixed)
            return
        }
        if (text.isNullOrBlank()) { deliver(null, null); return }
        Thread {
            val r = Poster.make(this, text)
            Handler(Looper.getMainLooper()).post { deliver(r, cm) }
        }.start()
    }

    private fun deliver(r: Poster.Result?, cm: ClipboardManager?) {
        if (r != null && cm != null) {
            PosterBus.lastCaption = r.caption
            try { cm.setPrimaryClip(ClipData.newPlainText("post", r.caption)) } catch (_: Exception) {}
        }
        val cb = PosterBus.onDone
        PosterBus.onDone = null
        finish()
        cb?.invoke(r?.uri)
    }
}


/** A title that goes on top of every post caption (Settings T1 on/off, T2 titles, T3 how to pick). */
object PostTitle {
    private fun p(c: Context) = c.getSharedPreferences("ptitle", Context.MODE_PRIVATE)
    fun on(c: Context): Boolean = p(c).getBoolean("on", false)
    fun toggle(c: Context): Boolean { val n = !on(c); p(c).edit().putBoolean("on", n).apply(); return n }
    /** one title per line */
    fun list(c: Context): List<String> =
        (p(c).getString("list", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    fun setList(c: Context, v: String) {
        p(c).edit().putString("list", v.split("\n").map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")).apply()
    }
    /** 0 = one after another, 1 = random, 2 = all of them together (one per line) */
    fun mode(c: Context): Int = p(c).getInt("mode", 0)
    fun setMode(c: Context, m: Int) { p(c).edit().putInt("mode", m).apply() }
    /** where the title goes: 0 = top, 1 = end, 2 = top and end */
    fun pos(c: Context): Int = p(c).getInt("pos", 0).coerceIn(0, 2)
    fun setPos(c: Context, v: Int) { p(c).edit().putInt("pos", v).apply() }

    /** the title text for the next post ("" = none) */
    fun next(c: Context): String {
        if (!on(c)) return ""
        val l = list(c)
        if (l.isEmpty()) return ""
        return when (mode(c)) {
            2 -> l.joinToString("\n")
            1 -> l[Random(System.nanoTime()).nextInt(l.size)]
            else -> {
                val i = p(c).getInt("idx", 0).mod(l.size)
                p(c).edit().putInt("idx", (i + 1) % l.size).apply()
                l[i]
            }
        }
    }
}
